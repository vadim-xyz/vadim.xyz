(function () {
 'use strict';
 var __ = window.wp && window.wp.i18n ? window.wp.i18n.__ : function (text) { return text; };
 var sprintf = window.wp && window.wp.i18n ? window.wp.i18n.sprintf : function (text) { var args = arguments; var next = 1; return text.replace(/%(?:(\d+)\$)?s/g, function (_, index) { return args[index || next++]; }); };
 function reveal(root, moveFocus) {
  if (!root || root.closest('[hidden]')) { return; }
  if (moveFocus !== false) {
   if (!root.hasAttribute('tabindex')) { root.tabIndex = -1; }
   root.focus({ preventScroll: true });
  }
  var screen = root.closest('.pf-import') || Array.from(root.querySelectorAll('.pf-import')).find(function (candidate) { return !candidate.closest('[hidden]'); }) || root;
  var toolbar = document.getElementById('wpadminbar');
  var toolbarHeight = toolbar && ['fixed', 'sticky'].includes(window.getComputedStyle(toolbar).position) ? toolbar.getBoundingClientRect().height : 0;
  var top = Math.max(0, window.scrollY + screen.getBoundingClientRect().top - toolbarHeight - 16);
  window.scrollTo({ top: top, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' });
 }
 function choices(form) {
  var selection = { media: [], taxonomies: {}, fields: [], overrides: {}, taxonomy_actions: {} };
  form.querySelectorAll('[name="pageferry_media[]"]:checked').forEach(function (input) { selection.media.push(Number(input.value)); });
  form.querySelectorAll('[name="pageferry_fields[]"]').forEach(function (input) { if (input.checked || input.type === 'hidden') { selection.fields.push(input.value); } });
  form.querySelectorAll('[name^="pageferry_override["]').forEach(function (input) { var field = input.name.slice(19, -1); if (input.value !== input.dataset.source || (field === 'slug' && form.dataset.update === '1')) { selection.overrides[field] = input.value; } });
  form.querySelectorAll('.pf-taxonomy').forEach(function (group) {
   var terms = [];
   group.querySelectorAll('.pf-term input:checked').forEach(function (term) { terms.push(term.value); });
   selection.taxonomies[group.dataset.taxonomy] = terms;
   var clear = group.querySelector('[name="pageferry_clear[]"]');
   selection.taxonomy_actions[group.dataset.taxonomy] = clear && (clear.checked || clear.type === 'hidden') ? 'replace' : 'append';
  });
  form.querySelectorAll('[data-hidden-taxonomy]').forEach(function (input) { selection.taxonomies[input.value] = []; selection.taxonomy_actions[input.value] = form.querySelector('[name="pageferry_clear[]"][value="' + input.value + '"]') ? 'replace' : 'append'; });
  var thumbnail = form.querySelector('[name="pageferry_thumbnail"]:checked');
  if (thumbnail && thumbnail.value !== 'keep') { selection.fields.push('thumbnail'); if (thumbnail.value !== form.dataset.sourceThumbnail) { selection.overrides.thumbnail = thumbnail.value === 'none' ? null : Number(thumbnail.value); } }
  var template = form.querySelector('[name="pageferry_template"]');
  if (template && template.value !== 'keep') { selection.fields.push('template'); if (template.value !== 'source') { selection.overrides.template = template.value === 'none' ? '' : template.value; } }
  return selection;
 }
 function unconfirmed(root, destination) {
  root.replaceChildren();
  function node(tag, className, text) { var element = document.createElement(tag); if (className) { element.className = className; } if (text) { element.textContent = text; } return element; }
  var panel = node('div', 'pf-import pf-result'); panel.tabIndex = -1;
  var steps = node('ol', 'pf-steps'); [__('Set up', 'pageferry'), __('Review', 'pageferry'), __('Result', 'pageferry')].forEach(function (label, index) { var step = node('li', index === 2 ? 'active' : 'pf-step-complete'); var number = node('span', 'pf-step-number', index === 2 ? '3' : '✓'); if (index === 2) { step.setAttribute('aria-current', 'step'); } step.append(number, document.createTextNode(label)); steps.append(step); });
  var workspace = node('div', 'pf-workspace pf-result-workspace'), top = node('section', 'pf-outcome-top');
  function icon(name) { var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('class', 'pf-icon'); svg.setAttribute('viewBox', '0 0 24 24'); svg.setAttribute('aria-hidden', 'true'); if (name === 'info') { var circle = document.createElementNS(svg.namespaceURI, 'circle'); circle.setAttribute('cx', '12'); circle.setAttribute('cy', '12'); circle.setAttribute('r', '9'); svg.append(circle); } var path = document.createElementNS(svg.namespaceURI, 'path'); path.setAttribute('d', name === 'check' ? 'm5 12 4 4L19 6' : name === 'page' ? 'M6 3h9l4 4v14H6zM14 3v5h5M9 12h7M9 16h7' : 'M12 11v6m0-10v.1'); svg.append(path); return svg; }
  steps.querySelectorAll('.pf-step-complete .pf-step-number').forEach(function (number) { number.replaceChildren(icon('check')); });
  var titleRow = node('div', 'pf-outcome-heading'), symbol = node('span', 'pf-outcome-symbol warning'); symbol.append(icon('info'));
  var copy = node('div'); copy.append(node('h2', '', __('We couldn’t confirm the result', 'pageferry')), node('p', '', __('We did not receive a confirmed result. The server may have saved the page.', 'pageferry'))); titleRow.append(symbol, copy);
  var check = node('a', 'button button-primary', __('Check destination', 'pageferry')); check.href = Number(destination.id) > 0 ? 'post.php?post=' + Number(destination.id) + '&action=edit' : 'edit.php?post_type=' + encodeURIComponent(destination.type || 'page');
  var log = node('a', 'pf-text-button', __('View import log', 'pageferry')); log.href = 'tools.php?page=pageferry-import&tab=logs';
  [check, log].forEach(function (link) { link.target = '_blank'; link.rel = 'noopener noreferrer'; });
  var actions = node('div', 'pf-result-actions'); actions.append(check, log); var intended = node('div', 'pf-saved-post'), identity = node('div'); identity.append(node('strong', '', destination.title || __('Intended destination', 'pageferry')), node('p', '', __('Intended destination', 'pageferry') + ' · ' + (destination.type || 'page') + (Number(destination.id) > 0 ? ' · #' + Number(destination.id) : ''))); intended.append(icon('page'), identity); top.append(titleRow, intended, actions);
  var detail = node('section', 'pf-result-detail'); detail.append(node('h3', '', __('Check before trying again', 'pageferry')), node('p', '', __('Check the destination and import log before trying again.', 'pageferry')));
  var instructions = node('ol', 'pf-instructions'); [__('Open the destination and check its title, content, and images.', 'pageferry'), __('Look for this import in the import log.', 'pageferry'), __('If a new draft was created, use that draft rather than importing a duplicate.', 'pageferry')].forEach(function (text) { instructions.append(node('li', '', text)); }); detail.append(instructions, node('p', 'pf-note', __('A missing log entry does not prove the import failed.', 'pageferry')));
  workspace.append(top, detail); panel.append(steps, workspace); root.appendChild(panel); reveal(panel);
  document.dispatchEvent(new Event('pageferry:result'));
 }
 function mount(root, submit) {
  root.querySelectorAll('.pf-media-preview img, .pf-featured-option img').forEach(function (img) {
   img.addEventListener('error', function () { img.hidden = true; });
   if (img.complete && !img.naturalWidth) { img.hidden = true; }
  });
  root.querySelectorAll('.pf-review-form').forEach(function (form) {
   if (form.dataset.enhanced) { return; }
   form.dataset.enhanced = 'true'; form.classList.add('pf-enhanced');
   var dirty = false, busy = false, timer = null;
   var modelNode = form.querySelector('.pf-review-model'), model = modelNode ? JSON.parse(modelNode.textContent) : null;
   var blocked = false, requiresPreparation = false;
   var reviewed = JSON.stringify(choices(form));
   var confirm = form.querySelector('.pf-confirm'), refresh = form.querySelector('.pf-refresh');
   var endConfirm = form.querySelector('.pf-end-confirm'), endRefresh = form.querySelector('.pf-end-refresh');
   var notice = form.querySelector('.pf-review-status');
   function status(text, warning, alert) {
    notice.querySelector('span').textContent = text;
    notice.classList.toggle('dirty', !!warning); notice.setAttribute('role', alert ? 'alert' : 'status');
   }
   function effects() {
    form.querySelectorAll('.pf-taxonomy').forEach(function (group) {
     var inputs = Array.from(group.querySelectorAll('.pf-term input'));
     var all = group.querySelector('[data-tax-all]'), selected = inputs.filter(function (input) { return input.checked; });
     if (all) { all.checked = inputs.length > 0 && selected.length === inputs.length; all.indeterminate = selected.length > 0 && selected.length < inputs.length; }
     var clear = group.querySelector('[name="pageferry_clear[]"]'), replace = clear && (clear.checked || clear.type === 'hidden');
     var final = replace || form.dataset.update !== '1' ? [] : JSON.parse(group.dataset.current);
     var identities = new Set(final.map(function (term) { return 'id:' + term.id; }));
     selected.forEach(function (term) {
      var key = Number(term.dataset.id) > 0 ? 'id:' + term.dataset.id : (term.dataset.slug ? 'slug:' + term.dataset.slug : 'name:' + term.dataset.name);
      if (!identities.has(key)) { identities.add(key); final.push({ name: term.dataset.name }); }
     });
     var label = group.dataset.label, current = JSON.parse(group.dataset.current), effect;
     if (form.dataset.update !== '1' || !current.length) {
      effect = selected.length ? __('Add the selected %s from the ZIP.', 'pageferry') : __('No %s selected. None will be added.', 'pageferry');
     } else if (replace) {
      effect = selected.length ? __('Clear current %1$s, then add the selected %2$s from the ZIP.', 'pageferry') : __('No ZIP %1$s selected. This will clear current %2$s.', 'pageferry');
     } else {
      effect = selected.length ? __('Keep current %1$s and add the selected ZIP %2$s.', 'pageferry') : __('No ZIP %1$s selected. Current %2$s will be kept.', 'pageferry');
     }
     var problem = group.dataset.available !== '1' ? 'unavailable' : selected.length || replace ? (group.dataset.canAssign !== '1' ? 'assignment' : selected.some(function (input) { return input.dataset.status === 'forbidden'; }) ? 'creation' : '') : '';
     var problems = {
      unavailable: __('The %s in this ZIP are unavailable on this site. Deselect them, or ask an administrator to enable the plugin or theme that provides them. Then prepare the review again.', 'pageferry'),
      assignment: __('You do not have permission to add %s to this page. Ask an administrator to import them.', 'pageferry'),
      creation: __('Some selected %s cannot be created with your current permissions. Deselect those marked Permission needed or ask an administrator to import them.', 'pageferry')
     };
     if (problem) { group.querySelector('.pf-taxonomy-effect').textContent = sprintf(problems[problem], label); return; }
     group.querySelector('.pf-taxonomy-effect').textContent = sprintf(effect, label, label) + (selected.length || form.dataset.update === '1' ? ' ' + sprintf(__('After import: %s.', 'pageferry'), final.map(function (term) { return term.name; }).join(', ') || __('None', 'pageferry')) : '');
    });
    form.querySelectorAll('.pf-media-row').forEach(function (row) {
     var selected = row.querySelector('input').checked;
     row.querySelector('.pf-excluded-note').hidden = selected;
     row.querySelector('.pf-media-action').textContent = selected ? row.querySelector('.pf-media-action').dataset.action : __('Excluded', 'pageferry');
    });
    var media = form.querySelectorAll('input[type=checkbox][name="pageferry_media[]"]'), count = form.querySelector('.pf-media-count');
    if (count) { count.textContent = sprintf(__('%1$s of %2$s selected', 'pageferry'), form.querySelectorAll('[name="pageferry_media[]"]:checked').length, media.length); }
    var thumbnail = form.querySelector('[name="pageferry_thumbnail"]:checked');
    var image = thumbnail && /^\d+$/.test(thumbnail.value) ? form.querySelector('[name="pageferry_media[]"][value="' + thumbnail.value + '"]') : null;
    var conflict = !!(image && !image.checked);
    form.querySelector('.pf-featured-conflict').hidden = !conflict;
    refresh.disabled = conflict || busy || requiresPreparation;
    confirm.disabled = blocked || conflict || busy || (model ? !form.checkValidity() : dirty);
    if (endConfirm) { endConfirm.disabled = confirm.disabled; }
    if (endRefresh) { endRefresh.disabled = refresh.disabled; }
    if (model) { window.pageferryReviewModel.patch(form, model, choices(form)); }
   }
   function schedule() {
    window.clearTimeout(timer);
    if (model || !dirty || busy || refresh.disabled) { return; }
    timer = window.setTimeout(function () {
     if (!form.isConnected || !dirty || busy) { return; }
     if (!form.checkValidity()) { status(__('Complete the page details to update your review.', 'pageferry'), true); return; }
     form.requestSubmit(refresh);
    }, 400);
   }
   function changed() {
    dirty = !model && JSON.stringify(choices(form)) !== reviewed; form.classList.toggle('pf-review-dirty', dirty); form.classList.remove('pf-review-error');
    if (!blocked) { status(model ? __('Ready to import', 'pageferry') : dirty || busy ? __('Updating your review…', 'pageferry') : __('Review is up to date', 'pageferry'), dirty || busy); }
    effects(); schedule();
   }
   form.addEventListener('change', changed); form.addEventListener('input', function (event) { if (event.target.matches('input[type=text], textarea')) { changed(); } });
   form.querySelectorAll('.pf-bulk, .pf-tax-all').forEach(function (group) { group.hidden = false; });
   form.querySelectorAll('[data-tax-all]').forEach(function (input) { input.addEventListener('change', function () { input.closest('.pf-taxonomy').querySelectorAll('.pf-term input').forEach(function (term) { term.checked = input.checked; }); changed(); }); });
   form.querySelectorAll('[data-select]').forEach(function (button) {
    button.addEventListener('click', function () { button.closest('[data-choice-group]').querySelectorAll('input[type=checkbox][name="pageferry_media[]"]').forEach(function (input) { if (!input.disabled) { input.checked = button.dataset.select === 'all'; } }); changed(); });
   });
   form.querySelectorAll('[data-reset]').forEach(function (button) { button.addEventListener('click', function () { var input = form.querySelector('#pf-edit-' + button.dataset.reset); input.value = input.dataset.source; input.focus(); changed(); }); });
   if (model) { refresh.remove(); if (endRefresh) { endRefresh.remove(); } status(__('Ready to import', 'pageferry')); }
   effects();
   refresh.textContent = __('Try again', 'pageferry'); if (endRefresh) { endRefresh.textContent = refresh.textContent; }
   var updateNote = form.querySelector('.pf-review-update-note'); if (updateNote) { updateNote.textContent = model ? __('Your changes are applied when you import.', 'pageferry') : __('Changes are checked automatically before you import.', 'pageferry'); }
   form.pageferryReviewFailure = function (message, retry, prepare) {
    requiresPreparation = !!prepare;
    busy = false; blocked = requiresPreparation || !!model && !retry; dirty = !model; reviewed = null; form.removeAttribute('aria-busy');
    form.classList.add('pf-review-dirty'); form.classList.toggle('pf-review-error', !retry);
    status(message, true, true); effects(); if (retry) { schedule(); }
   };
   form.addEventListener('submit', function (event) {
    var execute = event.submitter && event.submitter.value === 'execute';
    if (busy || blocked || refresh.disabled || (execute && dirty)) { event.preventDefault(); return; }
    var selection = choices(form);
    if (!execute && model) { event.preventDefault(); return; }
    window.clearTimeout(timer); form.dataset.refreshSelection = JSON.stringify(selection); form.classList.remove('pf-review-error');
    if (execute) {
     var reviewRoot = form.closest('.pf-review'); reviewRoot.classList.add('pf-review-executing');
     reviewRoot.querySelector('.pf-execution-working').hidden = false;
     reviewRoot.querySelector('.pf-heading h2').textContent = __('Importing your page', 'pageferry');
     reviewRoot.querySelector('.pf-heading p').textContent = __('Applying the changes you confirmed.', 'pageferry');
     reveal(reviewRoot);
    }
    busy = true; form.setAttribute('aria-busy', 'true');
    status(execute ? __('Importing… Keep this page open while the import finishes.', 'pageferry') : __('Updating your review…', 'pageferry'), !execute);
    if (submit) {
     event.preventDefault();
     form.querySelectorAll(execute ? 'button, input, textarea, select' : 'button').forEach(function (input) { input.disabled = true; });
     submit(selection, execute, form.querySelector('[name="pageferry_plan"]').value, !!model);
    } else {
     event.preventDefault();
     var data = new FormData(form);
     form.querySelectorAll('[name="pageferry_fields[]"], [name="pageferry_media[]"], [name="pageferry_taxonomies[]"], .pf-term input, [name^="pageferry_override["], [name="pageferry_clear[]"], [name="pageferry_thumbnail"], [name="pageferry_template"], [name="pageferry_template_source"]').forEach(function (input) { data.delete(input.name); });
     if (execute && model) { data.set('pageferry_local_review', '1'); }
     data.set('pageferry_selection', JSON.stringify(selection)); data.set('pageferry_import_step', execute ? 'execute' : 'review'); data.set('pageferry_response', 'inline');
     var oldRoot = form.closest('.pf-review'), scroll = window.scrollY, focusedId = document.activeElement.id;
     form.querySelectorAll(execute ? 'button, input, textarea, select' : 'button').forEach(function (button) { button.disabled = true; });
     fetch(form.action, { method: 'POST', credentials: 'same-origin', body: data }).then(function (response) {
      return response.text().then(function (html) { return { ok: response.ok, html: html }; });
     }).then(function (response) {
      var parsed = new DOMParser().parseFromString(response.html, 'text/html');
      var refusal = parsed.querySelector('[data-pf-import-started="false"]');
      if (refusal) { refused(oldRoot, refusal.querySelector('p')?.textContent || __('The import was refused.', 'pageferry'), refusal.dataset.pfRecovery); return; }
      if (!response.ok) { throw new Error(__('The review could not be refreshed. Try again or prepare a new review.', 'pageferry')); }
      var replacement = parsed.querySelector('.pf-result') || parsed.querySelector('.pf-review');
      if (!replacement) { throw new Error(parsed.querySelector('.notice-error p')?.textContent || __('This review is unavailable. Select the ZIP and prepare again.', 'pageferry')); }
      var pending = pendingChanges(oldRoot);
      oldRoot.replaceWith(replacement); mount(replacement); restorePending(replacement, pending);
      if (replacement.classList.contains('pf-result')) { document.dispatchEvent(new Event('pageferry:result')); reveal(replacement); return; }
      if (!pending && !replacement.closest('[hidden]')) { var focused = focusedId ? document.getElementById(focusedId) : replacement.querySelector('.pf-confirm'); if (focused) { focused.focus({ preventScroll: true }); } window.scrollTo(0, scroll); }
     }).catch(function (error) {
      if (execute) { var outcomeRoot = document.createElement('div'); oldRoot.replaceWith(outcomeRoot); unconfirmed(outcomeRoot, { id: form.dataset.targetId, type: form.dataset.postType, title: oldRoot.querySelector('.pf-identity > div:last-child strong')?.textContent }); return; }
      form.querySelectorAll('button').forEach(function (button) { button.disabled = false; });
      form.pageferryReviewFailure(error.message, false);
     });

    }
   });
  });
 }
 function pendingChanges(root) {
  var form = root.querySelector('.pf-review-form');
  if (!form || !form.dataset.refreshSelection) { return null; }
  return { changed: JSON.stringify(choices(form)) !== form.dataset.refreshSelection,
   values: Array.from(form.querySelectorAll('input:not([type="hidden"]),textarea,select')).filter(function (input) { return input.name; }).map(function (input) { return { name: input.name, type: input.type, value: input.value, checked: input.checked }; }),
   focus: form.contains(document.activeElement) ? document.activeElement.id : '', scroll: window.scrollY };
 }
 function restorePending(root, pending) {
  var form = root.querySelector('.pf-review-form'); if (!form || !pending) { return; }
  if (pending.changed) {
   pending.values.forEach(function (value) { form.querySelectorAll('input,textarea,select').forEach(function (input) { if (input.name !== value.name) { return; } if (value.type === 'checkbox' || value.type === 'radio') { if (input.value === value.value) { input.checked = value.checked; } } else { input.value = value.value; } }); });
   form.dispatchEvent(new Event('change', { bubbles: true }));
  }
  if (pending.focus && !form.closest('[hidden]')) { var focused = document.getElementById(pending.focus); if (focused) { focused.focus({ preventScroll: true }); } window.scrollTo(0, pending.scroll); }
 }
 function failed(root, message, retry) { var form = root.querySelector('.pf-review-form'); if (form && form.pageferryReviewFailure) { form.pageferryReviewFailure(message, retry); } }
 function refused(root, message, recovery) {
  var form = root.querySelector('.pf-review-form'); if (!form) { return; }
  var review = form.closest('.pf-review'); review.classList.remove('pf-review-executing');
  review.querySelector('.pf-execution-working').hidden = true;
  review.querySelector('.pf-heading h2').textContent = __('Review your import', 'pageferry');
  review.querySelector('.pf-heading p').textContent = __('Edit the details and see every item before importing.', 'pageferry');
  form.querySelectorAll('input, button, textarea, select').forEach(function (input) { input.disabled = input.hasAttribute('data-pf-locked'); });
  var retry = recovery === 'retry', notice = form.querySelector('.pf-review-status');
  form.pageferryReviewFailure(message + ' ' + __('No import started.', 'pageferry') + ' ' + (retry ? __('Review your choices and click Import when ready.', 'pageferry') : __('Prepare a new review before importing.', 'pageferry')), retry, !retry);
  var previous = form.querySelector('[data-pf-prepare-again]'); if (previous) { previous.remove(); }
  if (!retry) { var link = document.createElement('a'); link.className = 'button'; link.dataset.pfPrepareAgain = '1'; link.href = 'tools.php?page=pageferry-import'; link.textContent = __('Prepare again', 'pageferry'); notice.after(link); }
  notice.tabIndex = -1; reveal(notice);
 }
 window.pageferryReview = { mount: mount, choices: choices, unconfirmed: unconfirmed, pending: pendingChanges, restore: restorePending, failed: failed, refused: refused, reveal: reveal };
 mount(document);
 // Wait for core notices so classic-response alignment uses the final layout.
 function initialScreen() {
  window.setTimeout(function () {
   var screen = document.querySelector('#pf-panel-import:not([hidden]) .pf-review, #pf-panel-import:not([hidden]) .pf-result');
   if (screen && window.pageferryReviewConfig?.afterSubmit === '1') { reveal(screen); }
  }, 0);
 }
 if (document.readyState === 'complete') { initialScreen(); } else { window.addEventListener('load', initialScreen); }
 function setupDestination() {
  var upload = document.querySelector('.pf-upload-form');
  if (!upload || !window.pageferryImport || upload.dataset.destinationMounted) { return; }
  upload.dataset.destinationMounted = '1';
  var type = document.getElementById('pageferry-post-type'), search = document.getElementById('pageferry-target-search');
  var target = upload.querySelector('[name="pageferry_target_post"]'), typeValue = upload.querySelector('[name="pageferry_post_type"]');
  var status = document.getElementById('pf-target-status'), pages = upload.querySelector('.pf-target-pages');
  var prev = pages.querySelector('.pf-target-prev'), next = pages.querySelector('.pf-target-next');
  var page = Number(pages.dataset.page || 1), generation = 0, metadataGeneration = 0, metadataWorker = null, manualType = false, zipType = '';
  var file = document.getElementById('pageferry-zip'), metadataNote = document.getElementById('pf-zip-metadata');
  var destination = upload.querySelector('.pf-destination-section');
  destination.hidden = !(file.files && file.files.length);
  var targetList = upload.querySelector('.pf-target-list');
  var targetLabel = upload.querySelector('[for="pageferry-target-post"]');
  target.hidden = true; targetLabel.hidden = true; targetList.hidden = false;
  function renderTargets() {
   targetList.replaceChildren();
   Array.from(target.options).filter(function (option) { return option.value; }).forEach(function (option) {
    var label = document.createElement('label'); label.className = 'pf-target-option';
    var input = document.createElement('input'); input.type = 'radio'; input.name = 'pf_destination_choice'; input.value = option.value; input.className = 'pf-target-choice'; input.checked = target.value === option.value;
    var copy = document.createElement('span'); var title = document.createElement('strong'); title.textContent = option.dataset.title || option.text;
    var url = document.createElement('small'); url.textContent = '/' + (option.dataset.slug || '') + '/ · #' + option.value;
    var badge = document.createElement('span'); badge.className = 'pf-status'; badge.textContent = ({ publish: __('Published', 'pageferry'), draft: __('Draft', 'pageferry'), pending: __('Pending', 'pageferry'), private: __('Private', 'pageferry'), future: __('Scheduled', 'pageferry') })[option.dataset.status] || option.dataset.status || '';
    copy.append(title, url); label.append(input, copy, badge); targetList.append(label);
    input.addEventListener('change', function () { if (input.checked) { target.value = input.value; target.dispatchEvent(new Event('change', { bubbles: true })); } });
   });
   mode();
  }
  var fileArea = upload.querySelector('.pf-file-drop'), trigger = upload.querySelector('.pf-file-trigger');
  fileArea.classList.add('pf-file-enhanced'); upload.querySelector('.pf-file-actions').hidden = false;
  file.tabIndex = -1;
  trigger.addEventListener('keydown', function (event) { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); if (!file.disabled) { file.click(); } } });
  function mode() {
   var update = upload.querySelector('[name="pageferry_target"]:checked').value === 'update';
   var locked = upload.dataset.preparing === '1';
   target.disabled = !update || locked; target.required = false;
   targetList.querySelectorAll('input').forEach(function (input) { input.disabled = !update || locked; input.required = update; });
   upload.querySelector('.pf-post-picker').hidden = !update;
  }
  upload.querySelectorAll('[name="pageferry_target"]').forEach(function (input) { input.addEventListener('change', function () { mode(); if (input.value === 'update' && input.checked) { load(1); } }); });
  upload.addEventListener('pageferry:setup-enabled', mode);
  renderTargets();
  function load(requestedPage) {
   var thisGeneration = ++generation; page = requestedPage;
   typeValue.value = type.value || zipType; target.value = '';
   target.replaceChildren(new Option(__('Loading content…', 'pageferry'), '')); target.disabled = true; targetList.replaceChildren();
   status.textContent = __('Finding content you can edit…', 'pageferry');
   var params = new URLSearchParams({ post_type: typeValue.value, search: search.value, page: String(page) });
   var root = window.pageferryImport.restRoot.replace(/\/?$/, '/');
   fetch(root + 'pageferry/v1/import/targets?' + params, { credentials: 'same-origin', headers: { 'X-WP-Nonce': window.pageferryImport.nonce } }).then(function (response) {
    if (!response.ok) { throw new Error(__('Could not load matching content. Try searching again.', 'pageferry')); } return response.json();
   }).then(function (data) {
    if (thisGeneration !== generation || upload.dataset.preparing === '1') { return; }
    target.replaceChildren(new Option(__('Select content to update…', 'pageferry'), ''));
    data.posts.forEach(function (post) { var option = new Option(post.label, String(post.id)); option.dataset.title = post.title || post.label; option.dataset.slug = post.slug || ''; option.dataset.status = post.status || ''; target.add(option); }); renderTargets();
    prev.hidden = page <= 1; next.hidden = !data.more;
    status.textContent = data.posts.length ? __('Select the page you want to update, even if its title matches the ZIP.', 'pageferry') : __('No results you can edit. Try another search or go to the next page.', 'pageferry'); mode();
   }).catch(function (error) { if (thisGeneration !== generation || upload.dataset.preparing === '1') { return; } target.replaceChildren(new Option(__('Content unavailable', 'pageferry'), '')); status.textContent = error.message; mode(); });
  }
  upload.addEventListener('submit', function (event) { if (event.submitter && event.submitter.classList.contains('pf-find-posts')) { event.preventDefault(); load(1); } });
  type.addEventListener('change', function () { manualType = true; type.setCustomValidity(''); typeValue.value = type.value || zipType; target.value = ''; metadataNote.textContent = __('Content type selected. Review the import again for this destination.', 'pageferry'); if (upload.querySelector('[name="pageferry_target"]:checked').value === 'update') { load(1); } });
  target.addEventListener('change', function () { targetList.querySelectorAll('input').forEach(function (input) { input.checked = input.value === target.value; }); status.textContent = target.value ? __('Content will be replaced. A recovery snapshot is saved first.', 'pageferry') : __('Choose the destination before preparing.', 'pageferry'); });
  prev.addEventListener('click', function (event) { event.preventDefault(); load(Math.max(1, page - 1)); }); next.addEventListener('click', function (event) { event.preventDefault(); load(page + 1); });
  file.addEventListener('change', function () {
   var picked = file.files && file.files[0], current = ++metadataGeneration;
   if (metadataWorker) { metadataWorker.terminate(); metadataWorker = null; }
   file.setCustomValidity(''); zipType = ''; target.value = ''; ++generation; target.dispatchEvent(new Event('change', { bubbles: true }));
   destination.hidden = !picked;
   if (!picked) {
    upload.dataset.metaPending = ''; metadataNote.textContent = ''; type.setCustomValidity('');
    document.getElementById('pf-file-name').textContent = __('Choose the page you want to bring across', 'pageferry');
    document.getElementById('pf-file-info').textContent = __('Selecting a file does not upload it.', 'pageferry');
    upload.querySelector('[for="pageferry-zip"]').textContent = __('Choose ZIP', 'pageferry');
    mode(); return;
   }
   document.getElementById('pf-file-name').textContent = picked.name;
   document.getElementById('pf-working-file').textContent = picked.name;
   document.getElementById('pf-file-info').textContent = (picked.size / 1048576).toFixed(2) + ' MB · ' + __('PageFerry ZIP', 'pageferry');
   upload.querySelector('[for="pageferry-zip"]').textContent = __('Replace ZIP', 'pageferry');
   if (typeof Worker === 'undefined') { metadataNote.textContent = __('The page details will be read when you review the import. Choose a different content type if needed.', 'pageferry'); return; }
   upload.dataset.metaPending = '1'; metadataNote.textContent = __('Reading the page details from your ZIP…', 'pageferry');
   function failed(message) { if (current !== metadataGeneration) { return; } upload.dataset.metaPending = ''; metadataNote.textContent = message; file.setCustomValidity(message); if (metadataWorker) { metadataWorker.terminate(); metadataWorker = null; } }
   try { metadataWorker = new Worker(window.pageferryImport.metadataWorkerUrl); } catch (error) { failed(__('Your browser could not read the ZIP. Reload this screen and select the ZIP again. If it still fails, try another browser.', 'pageferry')); return; }
   metadataWorker.onerror = function () { failed(__('The ZIP could not be read. Choose a ZIP created with PageFerry Export and try again.', 'pageferry')); };
   metadataWorker.onmessage = function (event) {
    if (current !== metadataGeneration) { return; }
    if (event.data.error) { failed(event.data.error); return; }
    upload.dataset.metaPending = ''; metadataWorker.terminate(); metadataWorker = null;
    zipType = event.data.post_type; search.value = event.data.title.slice(0, 200);
    if (!manualType) { type.value = zipType; }
    var available = Array.from(type.options).some(function (option) { return option.value === zipType; });
    if (!manualType && !available) { type.value = ''; type.setCustomValidity(__('The content type in this ZIP is unavailable. Choose another content type.', 'pageferry')); }
    typeValue.value = type.value || zipType;
    metadataNote.textContent = available ? sprintf(__('Content type in ZIP: %s. You can change it above.', 'pageferry'), Array.from(type.options).find(function (option) { return option.value === zipType; }).text) : __('The content type in this ZIP is unavailable here. Choose another content type to continue.', 'pageferry');
    if (upload.querySelector('[name="pageferry_target"]:checked').value === 'update') { load(1); }
   };
   metadataWorker.postMessage({ file: picked, limits: window.pageferryImport.limits });
  });
  upload.addEventListener('submit', function (event) {
   if (event.submitter && event.submitter.classList.contains('pf-find-posts')) { return; }
   if (upload.querySelector('[name="pageferry_target"]:checked').value === 'update' && !target.value) { event.preventDefault(); status.textContent = __('Choose the destination before preparing.', 'pageferry'); return; }
   if (upload.dataset.metaPending === '1' || !type.reportValidity()) { event.preventDefault(); metadataNote.textContent = upload.dataset.metaPending === '1' ? __('Wait for the page details to load, then click Review import.', 'pageferry') : type.validationMessage; }
  });
 }
 if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', setupDestination); } else { setupDestination(); }
 document.addEventListener('pageferry:tab-ready', function () { mount(document); setupDestination(); });
})();
