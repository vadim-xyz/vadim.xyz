<?php
/**
 * Classic ZIP upload/review/execute and browser-worker asset loading.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/**
 * Serves classic ZIP import and enqueues the browser worker transport.
 */
class PageFerry_Import_Admin {

	/**
	 * Import screen hook suffix (set on admin_menu).
	 *
	 * @var string
	 */
	private static $hook_suffix = '';

	/**
	 * Defers upload output until the page callback so headers remain writable.
	 *
	 * @var array|null
	 */
	private static $pending_confirmation = null;

	/**
	 * Upload-step error stashed for the render pass (never echoed early).
	 *
	 * @var string
	 */
	private static $pending_form_error = '';

	/**
	 * Current execution outcome for the render pass.
	 *
	 * @var array|null
	 */
	private static $pending_result = null;

	/**
	 * Refusal before the shared importer was entered.
	 *
	 * @var array|null
	 */
	private static $pending_refusal = null;

	/**
	 * Keeps the legacy menu entry compatible with the consolidated hook owner.
	 *
	 * @return void
	 */
	public static function register_menu(): void {
		self::$hook_suffix = add_management_page(
			__( 'PageFerry Import', 'pageferry' ),
			__( 'PageFerry Import', 'pageferry' ),
			'import',
			'pageferry-import',
			array( __CLASS__, 'render_screen' )
		);

		add_action( 'load-' . self::$hook_suffix, array( __CLASS__, 'handle_post' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Returns the live import-screen hook suffix from the menu owner.
	 *
	 * @return string Hook suffix, '' before admin_menu runs.
	 */
	public static function hook_suffix(): string {
		if ( '' !== self::$hook_suffix ) {
			return self::$hook_suffix;
		}

		if ( class_exists( 'PageFerry_Admin' ) ) {
			return PageFerry_Admin::hook_suffix();
		}

		return '';
	}

	/**
	 * Enqueues the Path B worker handoff script on the import screen only.
	 *
	 * @param string $hook_suffix Current admin screen hook suffix.
	 * @return void
	 */
	public static function enqueue_assets( string $hook_suffix ): void {
		$live_suffix = self::hook_suffix();

		if ( '' === $live_suffix || $hook_suffix !== $live_suffix ) {
			return;
		}

		$asset_version = PAGEFERRY_VERSION . '-import10';
		wp_enqueue_style( 'pageferry-import', plugins_url( 'assets/css/pageferry-import.css', PAGEFERRY_FILE ), array(), $asset_version );
		wp_enqueue_script( 'pageferry-review-model', plugins_url( 'assets/js/pageferry-review-model.js', PAGEFERRY_FILE ), array( 'wp-i18n' ), $asset_version, true );
		wp_set_script_translations( 'pageferry-review-model', 'pageferry' );
		wp_enqueue_script( 'pageferry-review', plugins_url( 'assets/js/pageferry-review.js', PAGEFERRY_FILE ), array( 'wp-i18n', 'pageferry-review-model' ), $asset_version, true );
		wp_localize_script(
			'pageferry-review',
			'pageferryReviewConfig',
			array( 'afterSubmit' => is_array( self::$pending_confirmation ) || is_array( self::$pending_result ) ? 1 : 0 )
		);
		wp_set_script_translations( 'pageferry-review', 'pageferry' );
		wp_enqueue_script(
			'pageferry-fflate',
			plugins_url( 'assets/js/vendor/fflate.min.js', PAGEFERRY_FILE ),
			array(),
			'0.8.3',
			true
		);

		wp_enqueue_script(
			'pageferry-import',
			plugins_url( 'assets/js/pageferry-import.js', PAGEFERRY_FILE ),
			array( 'pageferry-fflate', 'wp-i18n', 'pageferry-review' ),
			$asset_version,
			true
		);

		wp_set_script_translations( 'pageferry-import', 'pageferry' );
		wp_enqueue_script( 'pageferry-tabs', plugins_url( 'assets/js/pageferry-tabs.js', PAGEFERRY_FILE ), array( 'pageferry-import', 'wp-i18n' ), $asset_version, true );
		wp_set_script_translations( 'pageferry-tabs', 'pageferry' );
		wp_localize_script(
			'pageferry-tabs',
			'pageferryTabs',
			array(
				'url'   => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'pageferry_admin_view' ),
			)
		);

		wp_localize_script(
			'pageferry-import',
			'pageferryImport',
			array(
				'maxBytes'          => (int) wp_max_upload_size(),
				'limits'            => PageFerry_Import_Resources::limits(),
				'restRoot'          => esc_url_raw( rest_url() ),
				'namespace'         => 'pageferry/v1',
				'nonce'             => wp_create_nonce( 'wp_rest' ),
				'metadataWorkerUrl' => add_query_arg( 'ver', $asset_version, plugins_url( 'assets/js/import-metadata-worker.js', PAGEFERRY_FILE ) ),
				'workerUrl'         => add_query_arg( 'ver', $asset_version, plugins_url( 'assets/js/import-worker.js', PAGEFERRY_FILE ) ),
				// wp_localize_script() string-casts scalars; send an explicit 1/0 flag.
				'hasZip'            => PageFerry_Importer::zip_available() ? 1 : 0,
			)
		);
	}

	/**
	 * Handles Path A POSTs: upload → stash + confirmation, then execute.
	 *
	 * @return void
	 */
	public static function handle_post(): void {
		if ( ! isset( $_POST['pageferry_import_step'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- step dispatch only; each step verifies its own nonce below.
			return;
		}

		if ( ! current_user_can( 'import' ) ) {
			wp_die(
				self::refusal_html( __( 'You do not have permission to import pages.', 'pageferry' ), 'prepare' ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed refusal markup with escaped text and URL.
				esc_html__( 'PageFerry import failed', 'pageferry' ),
				array( 'response' => 403 )
			);
		}

		$step = sanitize_key( wp_unslash( $_POST['pageferry_import_step'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- step dispatch only; each step verifies its own nonce below.

		if ( 'upload' === $step ) {
			self::handle_upload_step();
		} elseif ( 'execute' === $step || 'review' === $step ) {
			self::handle_execute_step();
		}
	}

	/**
	 * Renders request-local results after the pre-header upload handler finishes.
	 *
	 * @return void
	 */
	public static function render_screen(): void {
		if ( ! current_user_can( 'import' ) ) {
			wp_die(
				esc_html__( 'You do not have permission to import pages.', 'pageferry' ),
				esc_html__( 'PageFerry import failed', 'pageferry' ),
				array( 'response' => 403 )
			);
		}

		if ( is_array( self::$pending_confirmation ) ) {
			$confirmation               = self::$pending_confirmation;
			self::$pending_confirmation = null;
			self::render_confirmation( $confirmation );
			return;
		}

		if ( is_array( self::$pending_refusal ) ) {
			$refusal               = self::$pending_refusal;
			self::$pending_refusal = null;
			echo self::refusal_html( $refusal['message'], $refusal['recovery'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed markup with escaped text and URL.
			return;
		}

		if ( is_array( self::$pending_result ) ) {
			$outcome              = self::$pending_result;
			self::$pending_result = null;
			echo PageFerry_Import_Review::outcome( $outcome ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- shared renderer escapes output.
			return;
		}

		if ( '' !== self::$pending_form_error ) {
			$form_error               = self::$pending_form_error;
			self::$pending_form_error = '';
			self::render_upload_form( $form_error );
			return;
		}

		$result = get_transient( PageFerry::TRANSIENT_RESULT_PREFIX . get_current_user_id() );

		if ( is_array( $result ) ) {
			delete_transient( PageFerry::TRANSIENT_RESULT_PREFIX . get_current_user_id() );
			self::render_result( $result );
			return;
		}

		self::render_upload_form( '' );
	}

	/**
	 * Prepares the upload before headers; the page callback renders its result.
	 *
	 * @return void
	 */
	private static function handle_upload_step(): void {
		check_admin_referer( 'pageferry_import_upload' );

		if ( ! isset( $_FILES['pageferry_zip'] ) || ! is_array( $_FILES['pageferry_zip'] ) ) {
			self::store_upload_error( __( 'Choose a PageFerry ZIP file first.', 'pageferry' ) );
			return;
		}

		$uploaded = $_FILES['pageferry_zip']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- file upload array handled by wp_handle_upload below.

		if ( ! isset( $uploaded['error'] ) || UPLOAD_ERR_OK !== (int) $uploaded['error'] ) {
			self::store_upload_error( __( 'The upload failed. Try again with a PageFerry export ZIP.', 'pageferry' ) );
			return;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		if ( ! PageFerry_Importer::zip_available() ) {
			self::store_upload_error( __( 'This site cannot open ZIP files on the server. Enable JavaScript and select the ZIP again to import through your browser, or ask your host to enable the PHP ZIP extension.', 'pageferry' ) );
			return;
		}

		$upload_size = isset( $uploaded['size'] ) ? (int) $uploaded['size'] : 0;
		$limit_bytes = (int) wp_max_upload_size();

		if ( 0 < $limit_bytes && $limit_bytes < $upload_size ) {
			self::store_upload_error(
				sprintf(
					/* translators: %s: human-readable upload limit. */
					__( 'This ZIP exceeds the upload limit of %s. Enable JavaScript and select it again. Your browser can upload its media files one at a time.', 'pageferry' ),
					size_format( $limit_bytes )
				)
			);
			return;
		}

		$file_check = wp_check_filetype_and_ext( $uploaded['tmp_name'], $uploaded['name'], array( 'zip' => 'application/zip' ) );

		if ( empty( $file_check['ext'] ) || 'zip' !== $file_check['ext'] ) {
			self::store_upload_error( __( 'That file is not a ZIP. Upload a PageFerry export ZIP.', 'pageferry' ) );
			return;
		}

		$type_value  = wp_unslash( $_POST['pageferry_type'] ?? $_POST['pageferry_post_type'] ?? '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- string checked and sanitized below.
		$target_type = is_string( $type_value ) ? sanitize_key( $type_value ) : null;
		$target_type = '' === $target_type ? null : $target_type;
		$prepared    = self::prepare_uploaded_zip( $uploaded, $target_type );

		if ( is_wp_error( $prepared ) ) {
			self::store_upload_error( $prepared->get_error_message() );
			return;
		}

		$target_mode    = isset( $_POST['pageferry_target'] ) && 'update' === sanitize_key( wp_unslash( $_POST['pageferry_target'] ) ) ? 'update' : 'create';
		$target_post_id = isset( $_POST['pageferry_target_post'] ) ? absint( wp_unslash( $_POST['pageferry_target_post'] ) ) : 0;
		$preview        = PageFerry_Importer::preview(
			$prepared['workspace'],
			$prepared['manifest'],
			array(
				'target'           => $target_mode,
				'prepare_review'   => true,
				'target_post_id'   => $target_post_id,
				'target_post_type' => $target_type,
				'selection'        => PageFerry_Import_Selection::defaults( $prepared['manifest'], 'update' === $target_mode ? $target_post_id : 0 ),
			)
		);

		if ( is_wp_error( $preview ) ) {
			PageFerry_Importer::remove_directory( $prepared['workspace'] );
			self::store_upload_error( $preview->get_error_message() );
			return;
		}

		$confirmation_key = 'pf-' . wp_generate_password( 12, false );
		$plan_token       = 'pf-' . wp_generate_password( 24, false );
		set_transient(
			PageFerry::TRANSIENT_IMPORT_PREFIX . $confirmation_key,
			array(
				'plan_token'         => $plan_token,
				'review_model'       => $preview['review_model'],
				'workspace'          => $prepared['workspace'],
				'manifest'           => $prepared['manifest'],
				'target'             => $preview['target'],
				'target_post_type'   => $target_type,
				'selection'          => $preview['review']['selection'],
				'warnings'           => $preview['warnings'],
				'target_post_id'     => isset( $preview['target_post_id'] ) ? (int) $preview['target_post_id'] : $target_post_id,
				'target_modified'    => isset( $preview['target_modified'] ) ? $preview['target_modified'] : null,
				'target_fingerprint' => $preview['target_fingerprint'] ?? null,
				'user_id'            => get_current_user_id(),
			),
			HOUR_IN_SECONDS
		);
		$tracked = PageFerry_Workspace::bind_session( $prepared['workspace'], PageFerry::TRANSIENT_IMPORT_PREFIX . $confirmation_key );
		if ( is_wp_error( $tracked ) ) {
			delete_transient( PageFerry::TRANSIENT_IMPORT_PREFIX . $confirmation_key );
			PageFerry_Importer::remove_directory( $prepared['workspace'] );
			self::store_upload_error( $tracked->get_error_message() );
			return;
		}

		self::$pending_confirmation = array(
			'plan_token' => $plan_token,
			'key'        => $confirmation_key,
			'preview'    => $preview,
		);
	}

	/**
	 * Receives a ZIP only into leased private staging, reclaimable after a crash.
	 *
	 * @param array       $uploaded PHP upload record.
	 * @param string|null $target_type Destination type.
	 * @return array|WP_Error Prepared workspace or upload/preparation refusal.
	 */
	private static function prepare_uploaded_zip( array $uploaded, ?string $target_type ) {
		$staging = PageFerry_Importer::make_workspace( 'pageferry-import-upload-' );
		if ( is_wp_error( $staging ) ) {
			return $staging;
		}
		register_shutdown_function(
			static function () use ( $staging ) {
				if ( is_dir( $staging ) ) {
					PageFerry_Workspace::with_lease( $staging, static fn() => PageFerry_Workspace::retire( $staging ) );
				}
			}
		);
		return PageFerry_Workspace::with_lease(
			$staging,
			static function () use ( $staging, $uploaded, $target_type ) {
				$upload_dir = static function ( $uploads ) use ( $staging ) {
					$uploads['path']    = $staging;
					$uploads['basedir'] = $staging;
					$uploads['subdir']  = '';
					$uploads['error']   = false;
					return $uploads;
				};
				try {
					add_filter( 'upload_dir', $upload_dir, PHP_INT_MAX );
					try {
						$moved = wp_handle_upload(
							$uploaded,
							array(
								'test_form'                => false,
								'mimes'                    => array( 'zip' => 'application/zip' ),
								'unique_filename_callback' => static fn() => 'bundle.zip',
							)
						);
					} finally {
						remove_filter( 'upload_dir', $upload_dir, PHP_INT_MAX );
					}
					if ( isset( $moved['error'] ) ) {
						return new WP_Error( 'pageferry_zip_upload', $moved['error'] );
					}
					if ( ( $moved['file'] ?? null ) !== $staging . '/bundle.zip' ) {
						return PageFerry_Import_Resources::io_error();
					}
					return PageFerry_Importer::prepare_workspace_from_zip( $moved['file'], $target_type );
				} finally {
					PageFerry_Workspace::retire( $staging );
				}
			}
		);
	}

	/**
	 * Stashes an upload-step error for the render pass (never echoes here).
	 *
	 * @param string $error_message Already-localized error text.
	 * @return void
	 */
	private static function store_upload_error( string $error_message ): void {
		self::$pending_form_error = $error_message;
	}

	/**
	 * Renders only server-owned pre-execution facts, never an unknown failure.
	 *
	 * @param string $message Localized refusal.
	 * @param string $recovery Retry the current review or prepare a new one.
	 * @return string
	 */
	private static function refusal_html( string $message, string $recovery ): string {
		return '<div class="pf-notice error" role="alert" data-pf-import-started="false" data-pf-recovery="' . esc_attr( $recovery ) . '"><p>' . esc_html( $message ) . '</p><p>' . esc_html__( 'No import started.', 'pageferry' ) . '</p><a class="button" href="' . esc_url( admin_url( 'tools.php?page=pageferry-import' ) ) . '">' . esc_html__( 'Prepare again', 'pageferry' ) . '</a></div>';
	}

	/**
	 * Stashes a known refusal for the render pass.
	 *
	 * @param string $message Localized refusal.
	 * @param string $recovery Retry the current review or prepare a new one.
	 * @return void
	 */
	private static function store_execute_refusal( string $message, string $recovery = 'prepare' ): void {
		self::$pending_refusal = array(
			'message'  => $message,
			'recovery' => $recovery,
		);
	}

	/**
	 * Validates an opaque confirmation token without lowercasing cache keys.
	 *
	 * @param mixed $raw Unslashed submitted value.
	 * @return string Validated token, or '' when invalid.
	 */
	public static function sanitize_confirmation_key( $raw ): string {
		if ( ! is_string( $raw ) ) {
			return '';
		}

		return 1 === preg_match( '/\Apf-[A-Za-z0-9]{12}\z/', $raw ) ? $raw : '';
	}

	/**
	 * Rejects foreign and expired stashes with the same nondisclosing response.
	 *
	 * @param string $confirmation_key Validated token from sanitize_confirmation_key().
	 * @return array|false Stash array or false.
	 */
	public static function get_confirmation_stash( string $confirmation_key ) {
		if ( '' === $confirmation_key ) {
			return false;
		}

		$stashed = get_transient( PageFerry::TRANSIENT_IMPORT_PREFIX . $confirmation_key );

		if ( ! is_array( $stashed ) || ! isset( $stashed['workspace'], $stashed['manifest'] ) ) {
			return false;
		}

		if ( ! isset( $stashed['user_id'] ) || get_current_user_id() !== (int) $stashed['user_id'] ) {
			return false;
		}

		return $stashed;
	}

	/**
	 * Revalidates and executes before headers; the page callback renders errors.
	 *
	 * @return void
	 */
	private static function handle_execute_step(): void {
		$nonce = isset( $_REQUEST['_wpnonce'] ) && is_string( $_REQUEST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['_wpnonce'] ) ) : '';
		$valid = wp_verify_nonce( $nonce, 'pageferry_import_execute' );
		do_action( 'check_admin_referer', 'pageferry_import_execute', $valid ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- preserves the core nonce-validation hook.
		if ( ! $valid ) {
			status_header( 403 );
			self::store_execute_refusal( __( 'This confirmation has expired. Reload the page and prepare the ZIP again.', 'pageferry' ) );
			return;
		}

		$raw_key          = isset( $_POST['pageferry_key'] ) ? wp_unslash( $_POST['pageferry_key'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- validated case-sensitively below; sanitize_key() would lowercase the opaque token.
		$confirmation_key = self::sanitize_confirmation_key( $raw_key );
		$stashed          = self::get_confirmation_stash( $confirmation_key );

		if ( ! is_array( $stashed ) || ! isset( $stashed['workspace'], $stashed['manifest'] ) ) {
			self::store_execute_refusal( __( 'That confirmation expired. Upload the ZIP again.', 'pageferry' ) );
			return;
		}

		$provided_plan = isset( $_POST['pageferry_plan'] ) && is_string( $_POST['pageferry_plan'] ) ? wp_unslash( $_POST['pageferry_plan'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- opaque token compared exactly below.
		$local_review  = isset( $_POST['pageferry_local_review'] ) && is_string( $_POST['pageferry_local_review'] ) && '1' === sanitize_key( wp_unslash( $_POST['pageferry_local_review'] ) );
		$selection     = null;
		if ( isset( $_POST['pageferry_choices'] ) ) {
			$selection = self::posted_selection( $stashed['manifest'] );
			if ( is_wp_error( $selection ) ) {
				$retry = 'pageferry_selection_invalid' === $selection->get_error_code()
					&& is_string( $stashed['plan_token'] ?? null ) && hash_equals( $stashed['plan_token'], $provided_plan )
					&& is_array( $stashed['review_model'] ?? null ) && PageFerry_Review_Model::valid( $stashed['manifest'], $stashed['review_model'] );
				self::store_execute_refusal( $selection->get_error_message(), $retry ? 'retry' : 'prepare' );
				return;
			}
			$step = isset( $_POST['pageferry_import_step'] ) && is_string( $_POST['pageferry_import_step'] ) ? sanitize_key( wp_unslash( $_POST['pageferry_import_step'] ) ) : '';
			if ( 'review' === $step || ( ! $local_review && ( ( $stashed['selection'] ?? null ) !== $selection || self::is_stash_stale( $stashed ) ) ) ) {
				self::refresh_review( $confirmation_key, $stashed, $selection );
				return;
			}
		}
		if ( isset( $stashed['plan_token'] ) && ! hash_equals( $stashed['plan_token'], $provided_plan ) ) {
			self::store_execute_refusal( __( 'This review has changed since you opened it. Select the ZIP again and prepare a new review.', 'pageferry' ) );
			return;
		}
		$execution = self::execute_stashed( $confirmation_key, $stashed, true, $local_review ? ( $selection ?? array() ) : null );
		if ( ! is_array( $execution ) ) {
			if ( is_wp_error( $execution ) ) {
				$live  = self::get_confirmation_stash( $confirmation_key );
				$retry = is_array( $live ) && is_array( $live['review_model'] ?? null )
					&& PageFerry_Review_Model::valid( $live['manifest'], $live['review_model'] ) && ( $live['plan_token'] ?? null ) === ( $stashed['plan_token'] ?? null )
					&& in_array( $execution->get_error_code(), array( 'pageferry_selection_invalid', 'pageferry_workspace_busy' ), true );
				self::store_execute_refusal( $execution->get_error_message(), $retry ? 'retry' : 'prepare' );
			} else {
				self::$pending_result = array( 'result' => 'unconfirmed' );
			}
			return;
		}
		$outcome         = $execution['outcome'];
		$inline_response = isset( $_POST['pageferry_response'] ) && is_string( $_POST['pageferry_response'] ) && 'inline' === sanitize_key( wp_unslash( $_POST['pageferry_response'] ) );
		if ( is_wp_error( $execution['result'] ) || $inline_response ) {
			self::$pending_result = $outcome;
			return;
		}
		set_transient( PageFerry::TRANSIENT_RESULT_PREFIX . get_current_user_id(), $outcome, MINUTE_IN_SECONDS );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'     => 'pageferry-import',
					'imported' => 1,
				),
				admin_url( 'tools.php' )
			)
		);
		exit;
	}

	/**
	 * Requires a fresh preview if the destination fingerprint changed or is absent.
	 *
	 * @param array $stash Confirmation stash from get_confirmation_stash().
	 * @return bool True when the stash target was edited after preview.
	 */
	public static function is_stash_stale( array $stash ): bool {
		$target_mode = isset( $stash['target'] ) && 'update' === $stash['target'] ? 'update' : 'create';

		if ( 'update' !== $target_mode ) {
			return false;
		}

		$target_post_id = isset( $stash['target_post_id'] ) ? (int) $stash['target_post_id'] : 0;
		// Timestamp-only stashes cannot prove the reviewed destination state.
		return ! is_string( $stash['target_fingerprint'] ?? null )
			|| PageFerry_Importer::target_fingerprint( $target_post_id ) !== $stash['target_fingerprint'];
	}

	/**
	 * Consumes and executes a confirmation only after acquiring its lease.
	 *
	 * @param string     $confirmation_key Exact confirmation token.
	 * @param array      $stashed Initially authorized stash (reloaded under the lease).
	 * @param bool       $with_outcome Include current-operation facts for the result screen.
	 * @param array|null $selection Choices confirmed locally, or null for legacy binding.
	 * @return array|WP_Post|WP_Error
	 */
	private static function execute_stashed( string $confirmation_key, array $stashed, bool $with_outcome = false, ?array $selection = null ) {
		return PageFerry_Workspace::with_lease(
			$stashed['workspace'],
			static function () use ( $confirmation_key, $stashed, $with_outcome, $selection ) {
				$stash = self::get_confirmation_stash( $confirmation_key );
				if ( ! is_array( $stash ) ) {
					return new WP_Error( 'pageferry_session_expired', __( 'That confirmation expired. Upload the ZIP again.', 'pageferry' ) );
				}
				if ( ( $stash['plan_token'] ?? null ) !== ( $stashed['plan_token'] ?? null ) ) {
					return new WP_Error( 'pageferry_plan_mismatch', __( 'Your import choices changed after the review. Review them again before importing.', 'pageferry' ) );
				}
				if ( null !== $selection ) {
					if ( ! is_string( $stash['plan_token'] ?? null ) || '' === $stash['plan_token'] ) {
						return new WP_Error( 'pageferry_plan_missing', __( 'Prepare this import again before confirming.', 'pageferry' ) );
					}
					if ( ! is_array( $stash['review_model'] ?? null ) ) {
						return new WP_Error( 'pageferry_review_stale', __( 'Prepare this import again before confirming.', 'pageferry' ) );
					}
					$checked = PageFerry_Importer::check_review(
						$stash['manifest'],
						$stash['review_model'],
						array(
							'target'         => $stash['target'],
							'target_post_id' => $stash['target_post_id'],
							'selection'      => $selection,
						)
					);
					if ( is_wp_error( $checked ) ) {
						return $checked;
					}
					$stash['selection'] = $checked['selection'];
					$stash['warnings']  = $checked['warnings'];
				}
				delete_transient( PageFerry::TRANSIENT_IMPORT_PREFIX . $confirmation_key );
				try {
					if ( self::is_stash_stale( $stash ) ) {
						return new WP_Error( 'pageferry_plan_stale', __( 'The selected page changed after your review. Select the ZIP again and prepare a new review before importing.', 'pageferry' ) );
					}

					$execution                        = PageFerry_Importer::run_with_outcome(
						$stash['workspace'],
						$stash['manifest'],
						array(
							'target'             => $stash['target'] ?? 'create',
							'target_post_id'     => isset( $stash['target_post_id'] ) ? (int) $stash['target_post_id'] : 0,
							'target_fingerprint' => $stash['target_fingerprint'] ?? null,
							'target_post_type'   => $stash['target_post_type'] ?? null,
							'selection'          => $stash['selection'] ?? null,
						)
					);
					$execution['outcome']['warnings'] = $stash['warnings'] ?? array();
					return $with_outcome ? $execution : $execution['result'];
				} finally {
					PageFerry_Workspace::retire( $stash['workspace'] );
				}
			},
			1000
		);
	}

	/**
	 * Renders the upload form with target picker + worker mount point.
	 *
	 * @param string $error_message Optional error shown above the form.
	 * @return void
	 */
	private static function render_upload_form( string $error_message ): void {
		$types = PageFerry_Exporter::ferryable_post_types();
		$type  = isset( $_GET['pageferry_type'] ) && is_string( $_GET['pageferry_type'] ) ? sanitize_key( wp_unslash( $_GET['pageferry_type'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only filter.
		if ( '' !== $type && ! in_array( $type, $types, true ) ) {
			$type = ''; }
		$search     = isset( $_GET['search'] ) && is_string( $_GET['search'] ) ? sanitize_text_field( wp_unslash( $_GET['search'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only filter.
		$page       = isset( $_GET['destination_page'] ) && is_scalar( $_GET['destination_page'] ) ? max( 1, min( 10000, absint( $_GET['destination_page'] ) ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only filter.
		$candidates = PageFerry_Import_Review::targets( '' !== $type ? $type : 'page', $search, $page );
		$update     = isset( $_GET['pageferry_target'] ) && 'update' === $_GET['pageferry_target']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only setup mode.
		?>
		<div class="pf-import pf-upload">
			<?php PageFerry_Import_Review::steps( 1 ); ?>
			<div class="pf-heading"><div><h2><?php esc_html_e( 'Import a page', 'pageferry' ); ?></h2><p><?php esc_html_e( 'Choose a ZIP and where its content should go.', 'pageferry' ); ?></p></div></div>
			<?php
			if ( '' !== $error_message ) :
				?>
				<div class="pf-notice error" role="alert"><div class="pf-notice-heading"><?php echo PageFerry_Import_Review::icon( 'warning' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?><?php esc_html_e( 'The review could not be prepared', 'pageferry' ); ?></div><p><?php echo esc_html( $error_message ); ?></p><p><?php esc_html_e( 'Select the ZIP again to prepare a new review.', 'pageferry' ); ?></p></div><?php endif; ?>
			<div class="pf-review-layout pf-setup-layout"><form id="pf-upload-form" class="pf-upload-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'tools.php?page=pageferry-import' ) ); ?>">
				<input type="hidden" name="page" value="pageferry-import" />
				<?php wp_nonce_field( 'pageferry_import_upload' ); ?>
				<input type="hidden" name="pageferry_import_step" value="upload" /><input type="hidden" name="pageferry_post_type" value="<?php echo esc_attr( $type ); ?>" />
				<section class="pf-section"><h3><?php esc_html_e( 'Your PageFerry ZIP', 'pageferry' ); ?></h3><div class="pf-file-drop"><span class="pf-file-icon"><?php echo PageFerry_Import_Review::icon( 'zip' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?></span><div class="pf-file-copy"><div class="pf-file-name" id="pf-file-name"><?php esc_html_e( 'Choose the page you want to bring across', 'pageferry' ); ?></div><p id="pf-file-info" role="status"><?php esc_html_e( 'Selecting a file does not upload it.', 'pageferry' ); ?></p><input class="pf-file-input" type="file" id="pageferry-zip" name="pageferry_zip" accept=".zip,application/zip" required /></div><div class="pf-file-actions" hidden><label class="button pf-file-trigger" for="pageferry-zip" tabindex="0"><?php esc_html_e( 'Choose ZIP', 'pageferry' ); ?></label></div></div><p class="pf-note"><?php printf( /* translators: %s: upload size limit. */ esc_html__( 'This site accepts files up to %s each. Larger ZIPs are prepared in your browser.', 'pageferry' ), esc_html( size_format( wp_max_upload_size() ) ) ); ?></p>
				<?php
				if ( ! PageFerry_Importer::zip_available() ) :
					?>
					<p class="pf-caution"><?php esc_html_e( 'Keep JavaScript enabled: this site uses the browser upload method.', 'pageferry' ); ?></p><?php endif; ?></section>
				<section class="pf-section pf-destination-section"><h3><?php esc_html_e( 'Where should it go?', 'pageferry' ); ?></h3><fieldset class="pf-mode"><legend><?php esc_html_e( 'Import as', 'pageferry' ); ?></legend><label class="pf-mode-option"><input type="radio" name="pageferry_target" value="create" <?php checked( ! $update ); ?> /><span><strong><?php esc_html_e( 'Create a new draft', 'pageferry' ); ?></strong><small><?php esc_html_e( 'Review it before publishing.', 'pageferry' ); ?></small></span></label><label class="pf-mode-option"><input type="radio" name="pageferry_target" value="update" <?php checked( $update ); ?> /><span><strong><?php esc_html_e( 'Update existing content', 'pageferry' ); ?></strong><small><?php esc_html_e( 'Replace content on this site.', 'pageferry' ); ?></small></span></label></fieldset>
					<div class="pf-edit-field pf-type-field"><label for="pageferry-post-type"><?php esc_html_e( 'Content type', 'pageferry' ); ?></label><select name="pageferry_type" id="pageferry-post-type"><option value=""><?php esc_html_e( 'Use the ZIP content type', 'pageferry' ); ?></option>
					<?php
					foreach ( $types as $type_slug ) :
						$object = get_post_type_object( $type_slug );
						?>
						<option value="<?php echo esc_attr( $type_slug ); ?>" <?php selected( $type, $type_slug ); ?>><?php echo esc_html( $object instanceof WP_Post_Type ? $object->labels->singular_name : $type_slug ); ?></option><?php endforeach; ?></select><p id="pf-zip-metadata" role="status" class="pf-note"><?php esc_html_e( 'Starts with the content type in the ZIP, such as Page or Post. You can change it.', 'pageferry' ); ?></p></div>
					<div class="pf-post-picker"><div class="pf-search"><label for="pageferry-target-search"><?php esc_html_e( 'Find content to update', 'pageferry' ); ?></label><input id="pageferry-target-search" name="search" type="search" value="<?php echo esc_attr( $search ); ?>" maxlength="200" /><button class="button pf-find-posts" type="submit" formmethod="get" formaction="<?php echo esc_url( admin_url( 'tools.php' ) ); ?>" formnovalidate><?php esc_html_e( 'Search', 'pageferry' ); ?></button></div><noscript><p class="pf-note"><?php esc_html_e( 'Choose a content type and click Search before choosing your ZIP. You will need to select the ZIP again after searching.', 'pageferry' ); ?></p></noscript>
						<label for="pageferry-target-post"><?php esc_html_e( 'Choose the destination', 'pageferry' ); ?></label><select id="pageferry-target-post" name="pageferry_target_post"><option value=""><?php esc_html_e( 'Select content to update…', 'pageferry' ); ?></option>
						<?php
						foreach ( $candidates['posts'] as $candidate ) :
							?>
							<option value="<?php echo (int) $candidate['id']; ?>" data-title="<?php echo esc_attr( $candidate['title'] ); ?>" data-slug="<?php echo esc_attr( $candidate['slug'] ); ?>" data-status="<?php echo esc_attr( $candidate['status'] ); ?>"><?php echo esc_html( $candidate['label'] ); ?></option><?php endforeach; ?></select><div class="pf-target-list" role="radiogroup" aria-label="<?php esc_attr_e( 'Choose the destination', 'pageferry' ); ?>" hidden></div><p id="pf-target-status" class="pf-note" role="status"><?php esc_html_e( 'Select the page you want to update, even if its title matches the ZIP.', 'pageferry' ); ?></p>
						<div class="pf-target-pages" data-page="<?php echo (int) $page; ?>">
						<?php
						foreach ( array(
							'prev' => max( 1, $page - 1 ),
							'next' => $page + 1,
						) as $direction => $number ) :
							?>
								<a class="button pf-target-<?php echo esc_attr( $direction ); ?>" <?php echo ( 'prev' === $direction ? $page <= 1 : ! $candidates['more'] ) ? 'hidden' : ''; ?> href="
								<?php
								echo esc_url(
									add_query_arg(
										array(
											'page'   => 'pageferry-import',
											'pageferry_type' => $type,
											'pageferry_target' => 'update',
											'search' => $search,
											'destination_page' => $number,
										),
										admin_url( 'tools.php' )
									)
								);
								?>
								"><?php echo esc_html( 'prev' === $direction ? __( 'Previous', 'pageferry' ) : __( 'Next', 'pageferry' ) ); ?></a><?php endforeach; ?></div>
					</div>
				</section>
				<div class="pf-setup-footer"><button type="submit" class="button button-primary pf-prepare"><?php esc_html_e( 'Review import', 'pageferry' ); ?><?php echo PageFerry_Import_Review::icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?></button><span><?php esc_html_e( 'Your destination page is not changed during preparation.', 'pageferry' ); ?></span></div>
			</form><aside class="pf-setup-aside"><h3><?php esc_html_e( 'One page. Everything it needs.', 'pageferry' ); ?></h3><p><?php esc_html_e( 'Bring your Gutenberg content, images, and selected page details across in one import.', 'pageferry' ); ?></p><ol><li><?php esc_html_e( 'Choose your ZIP and destination.', 'pageferry' ); ?></li><li><?php esc_html_e( 'Review every item and planned change.', 'pageferry' ); ?></li><li><?php esc_html_e( 'Import, then open the editor.', 'pageferry' ); ?></li></ol><div class="pf-aside-rule"><h3><?php esc_html_e( 'Already in your library?', 'pageferry' ); ?></h3><p><?php esc_html_e( 'Files already in your Media Library are reused when their contents match exactly.', 'pageferry' ); ?></p></div></aside></div>
			<div id="pageferry-worker-ui" class="pf-working" hidden><div class="pf-working-destination"><?php echo PageFerry_Import_Review::icon( 'zip' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?><div><strong id="pf-working-file"></strong><p><?php esc_html_e( 'Your page has not been imported yet.', 'pageferry' ); ?></p></div></div><h3 id="pf-working-heading"><?php esc_html_e( 'Preparing your review…', 'pageferry' ); ?></h3><progress id="pageferry-worker-progress" aria-label="<?php esc_attr_e( 'Media preparation', 'pageferry' ); ?>" hidden></progress><div id="pageferry-worker-indeterminate" class="pf-indeterminate" role="progressbar" aria-label="<?php esc_attr_e( 'Preparing ZIP review', 'pageferry' ); ?>"></div><p id="pageferry-worker-status" role="status"></p><button type="button" id="pageferry-worker-cancel" class="button" hidden><?php esc_html_e( 'Cancel preparation', 'pageferry' ); ?></button></div>
		</div><div id="pf-worker-review"></div>
		<?php
	}

	/**
	 * Renders the shared review with dependency and skip warnings.
	 *
	 * @param array $confirmation Array with key + preview summary.
	 * @return void
	 */
	private static function render_confirmation( array $confirmation ): void {
		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- shared renderer escapes all dynamic values.
		echo PageFerry_Import_Review::render(
			$confirmation['preview'],
			array(
				'transport'  => 'classic',
				'key'        => $confirmation['key'],
				'plan_token' => $confirmation['plan_token'] ?? '',
			)
		);
		// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Renders the saved post and available warning notes.
	 *
	 * @param array $result Array with post_id + title + slug + warning lists.
	 * @return void
	 */
	private static function render_result( array $result ): void {
		echo PageFerry_Import_Review::outcome( $result ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- shared renderer escapes all values.
	}

	/**
	 * Parse classic form choices; the shared validator checks every identity.
	 *
	 * @param array $manifest Original manifest.
	 * @return array|WP_Error
	 */
	private static function posted_selection( array $manifest ) {
		$raw = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- nonce checked by caller; strict shared allowlist below.
		if ( '1' !== ( $raw['pageferry_choices_complete'] ?? null ) ) {
			return new WP_Error( 'pageferry_selection_incomplete', __( 'The server could not receive all your import choices. Enable JavaScript and prepare the review again, or ask your host to increase the PHP max_input_vars setting.', 'pageferry' ) );
		}
		$destination_type = isset( $raw['pageferry_destination_type'] ) && is_string( $raw['pageferry_destination_type'] ) ? $raw['pageferry_destination_type'] : $manifest['post']['post_type'];
		if ( isset( $raw['pageferry_selection'] ) ) {
			if ( ! is_string( $raw['pageferry_selection'] ) || strlen( $raw['pageferry_selection'] ) > PageFerry_Import_Resources::limits()['manifest_bytes'] ) {
				return new WP_Error( 'pageferry_selection_invalid', __( 'Your import choices could not be read. Select the ZIP again and review the import.', 'pageferry' ) );
			}
			$decoded = json_decode( $raw['pageferry_selection'], true );
			if ( ! is_array( $decoded ) ) {
				return new WP_Error( 'pageferry_selection_invalid', __( 'Your import choices could not be read. Select the ZIP again and review the import.', 'pageferry' ) );
			}
			return PageFerry_Import_Selection::normalize( $manifest, $decoded, $destination_type );
		}
		$selection = array(
			'media'      => array(),
			'fields'     => $raw['pageferry_fields'] ?? array(),
			'taxonomies' => array(),
		);
		foreach ( (array) ( $raw['pageferry_media'] ?? array() ) as $id ) {
			if ( ! is_string( $id ) || ! ctype_digit( $id ) ) {
				return new WP_Error( 'pageferry_selection_invalid', __( 'Your media choices could not be read. Select the ZIP again and review the import.', 'pageferry' ) );
			}
			$selection['media'][] = (int) $id;
		}
		foreach ( (array) ( $raw['pageferry_taxonomies'] ?? array() ) as $taxonomy ) {
			if ( ! is_string( $taxonomy ) ) {
				return new WP_Error( 'pageferry_selection_invalid', __( 'Your category or tag choices could not be read. Select the ZIP again and review the import.', 'pageferry' ) );
			}
			$selection['taxonomies'][ $taxonomy ] = $raw['pageferry_terms'][ $taxonomy ] ?? array();
		}
		$selection['overrides'] = $raw['pageferry_override'] ?? array();
		if ( ! is_array( $selection['overrides'] ) ) {
			return new WP_Error( 'pageferry_selection_invalid', __( 'Your edited page details could not be read. Select the ZIP again and review the import.', 'pageferry' ) );
		}
		foreach ( $selection['overrides'] as $field => $value ) {
			if ( ( $manifest['post'][ $field ] ?? null ) === $value ) {
				unset( $selection['overrides'][ $field ] );
			}
		}
		$selection['taxonomy_actions'] = array();
		$clear                         = $raw['pageferry_clear'] ?? array();
		if ( ! is_array( $clear ) || array_diff( $clear, array_keys( $selection['taxonomies'] ) ) ) {
			return new WP_Error( 'pageferry_selection_invalid', __( 'Your category or tag settings could not be read. Select the ZIP again and review the import.', 'pageferry' ) );
		}
		foreach ( $selection['taxonomies'] as $taxonomy => $terms ) {
			$selection['taxonomy_actions'][ $taxonomy ] = in_array( $taxonomy, $clear, true ) ? 'replace' : 'append';
		}
		$thumbnail = $raw['pageferry_thumbnail'] ?? 'keep';
		if ( 'keep' !== $thumbnail ) {
			if ( 'none' !== $thumbnail && ( ! is_string( $thumbnail ) || ! ctype_digit( $thumbnail ) ) ) {
				return new WP_Error( 'pageferry_selection_invalid', __( 'Your featured image choice could not be read. Select the ZIP again and review the import.', 'pageferry' ) );
			}
			$selection['fields'][] = 'thumbnail';
			$chosen_thumbnail      = 'none' === $thumbnail ? null : (int) $thumbnail;
			if ( ! array_key_exists( 'thumbnail_old_id', $manifest['post'] ) || $manifest['post']['thumbnail_old_id'] !== $chosen_thumbnail ) {
				$selection['overrides']['thumbnail'] = $chosen_thumbnail;
			}
		}
		if ( isset( $raw['pageferry_template'] ) && 'keep' !== $raw['pageferry_template'] ) {
			$selection['fields'][] = 'template';
			if ( 'source' !== $raw['pageferry_template'] ) {
				$selection['overrides']['template'] = 'none' === $raw['pageferry_template'] ? '' : $raw['pageferry_template'];
			}
		}
		return PageFerry_Import_Selection::normalize( $manifest, $selection, $destination_type );
	}

	/**
	 * Refresh the bound plan when choices change, without importing anything.
	 *
	 * @param string $key Confirmation key.
	 * @param array  $stash Owner-checked stash.
	 * @param array  $selection Canonical choices.
	 * @return void
	 */
	private static function refresh_review( string $key, array $stash, array $selection ): void {
		$result = PageFerry_Workspace::with_lease(
			$stash['workspace'],
			static function () use ( $key, $selection ) {
				$live = self::get_confirmation_stash( $key );
				if ( ! is_array( $live ) ) {
					return new WP_Error( 'pageferry_session_expired', __( 'This review expired. Upload the ZIP again.', 'pageferry' ) );
				}
				$preview = PageFerry_Importer::preview(
					$live['workspace'],
					$live['manifest'],
					array(
						'target'           => $live['target'],
						'prepare_review'   => true,
						'target_post_id'   => $live['target_post_id'],
						'target_post_type' => $live['target_post_type'] ?? null,
						'selection'        => $selection,
					)
				);
				if ( is_wp_error( $preview ) ) {
					return $preview;
				}
				$live['selection']          = $selection;
				$live['review_model']       = $preview['review_model'];
				$live['plan_token']         = 'pf-' . wp_generate_password( 24, false );
				$live['warnings']           = $preview['warnings'];
				$live['target_fingerprint'] = $preview['target_fingerprint'];
				$live['target_modified']    = $preview['target_modified'];
				set_transient( PageFerry::TRANSIENT_IMPORT_PREFIX . $key, $live, HOUR_IN_SECONDS );
				if ( get_transient( PageFerry::TRANSIENT_IMPORT_PREFIX . $key ) !== $live ) {
					return new WP_Error( 'pageferry_session_persistence', __( 'The review could not be saved. Try again.', 'pageferry' ) );
				}
				return array(
					'key'        => $key,
					'preview'    => $preview,
					'plan_token' => $live['plan_token'],
				);
			},
			1000
		);
		if ( is_wp_error( $result ) ) {
			self::store_execute_refusal( $result->get_error_message() );
			return;
		}
		self::$pending_confirmation = $result;
	}
}
