<?php
/**
 * Plugin Name: PageFerry
 * Plugin URI:  https://vadim.xyz/pageferry
 * Description: Move one WordPress page between sites, with its images and media.
 * Version:     1.3.5
 * Requires at least: 6.5
 * Requires PHP: 8.1
 * Author:      vadim.xyz
 * Author URI:  https://vadim.xyz
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: pageferry
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

define( 'PAGEFERRY_VERSION', '1.3.5' );
define( 'PAGEFERRY_FILE', __FILE__ );
define( 'PAGEFERRY_DIR', plugin_dir_path( __FILE__ ) );

require_once PAGEFERRY_DIR . 'includes/class-pageferry.php';

add_action( 'plugins_loaded', array( 'PageFerry', 'init' ) );
register_activation_hook( __FILE__, array( 'PageFerry', 'activate' ) );
