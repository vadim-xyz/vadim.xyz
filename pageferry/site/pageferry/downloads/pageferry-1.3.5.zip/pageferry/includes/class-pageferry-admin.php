<?php
/**
 * Import screens, export metabox, logs and manual recovery views.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/**
 * Owns the import screen, export metabox, logs and manual backup recovery.
 */
class PageFerry_Admin {

	/**
	 * Capability required to view snapshots whose target no longer exists.
	 *
	 * @var string
	 */
	private const RECOVERY_PRIVILEGED_CAPABILITY = 'manage_options';

	/**
	 * Import screen hook suffix (set on admin_menu).
	 *
	 * @var string
	 */
	private static $hook_suffix = '';

	/**
	 * Registers the import screen with its log/backups tabs.
	 *
	 * @return void
	 */
	public static function register_menu(): void {
		self::$hook_suffix = add_management_page(
			__( 'PageFerry Import', 'pageferry' ),
			__( 'PageFerry Import', 'pageferry' ),
			'import',
			'pageferry-import',
			array( __CLASS__, 'render_screen' )
		);

		add_action( 'load-' . self::$hook_suffix, array( 'PageFerry_Import_Admin', 'handle_post' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Registers metaboxes using the actual post editor; no-argument callers retain legacy behavior.
	 *
	 * @param string|null $post_type Post type of the current edit screen.
	 * @param mixed       $post      Post being edited (ID or object).
	 * @return void
	 */
	public static function register_export_metabox( ?string $post_type = null, $post = null ): void {
		PageFerry_Exporter::register_metabox( $post_type, $post );
	}

	/**
	 * Delegates asset enqueueing while keeping one owner for the menu hook suffix.
	 *
	 * @param string $hook_suffix Current admin screen hook suffix.
	 * @return void
	 */
	public static function enqueue_assets( string $hook_suffix ): void {
		if ( '' === self::$hook_suffix || $hook_suffix !== self::$hook_suffix ) {
			return;
		}

		PageFerry_Import_Admin::enqueue_assets( $hook_suffix );
	}

	/**
	 * Exposes the import screen hook suffix for asset gating.
	 *
	 * @return string Hook suffix from register_menu(), '' before admin_menu runs.
	 */
	public static function hook_suffix(): string {
		return self::$hook_suffix;
	}

	/**
	 * Renders the selected tab; unknown tabs fall back to import.
	 *
	 * @return void
	 */
	public static function render_screen(): void {
		if ( ! current_user_can( 'import' ) ) {
			wp_die(
				esc_html__( 'You do not have permission to import pages.', 'pageferry' ),
				esc_html__( 'PageFerry import failed', 'pageferry' ),
				array( 'response' => 403 )
			);
		}

		$active_tab = isset( $_GET['tab'] ) && is_string( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'import'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- tab switch is a read-only view toggle, not a state change.

		self::render_page_shell( in_array( $active_tab, array( 'import', 'logs', 'backups' ), true ) ? $active_tab : 'import' );
	}

	/** Serves an authenticated tab fragment using the same authorized renderers. */
	public static function serve_view(): void {
		check_ajax_referer( 'pageferry_admin_view', 'nonce' );
		if ( ! current_user_can( 'import' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to import pages.', 'pageferry' ) ), 403 );
		}
		$view = isset( $_POST['view'] ) && is_string( $_POST['view'] ) ? sanitize_key( wp_unslash( $_POST['view'] ) ) : '';
		if ( ! in_array( $view, array( 'import', 'logs', 'backups' ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'This view is unavailable.', 'pageferry' ) ), 400 );
		}
		ob_start();
		self::render_tab_view( $view, self::backup_request( $_POST ) );
		wp_send_json_success( array( 'html' => (string) ob_get_clean() ) );
	}

	/**
	 * Renders a validated tab through its existing view owner.
	 *
	 * @param string $view Validated tab slug.
	 * @param array  $request Validated recovery navigation.
	 * @return void
	 */
	private static function render_tab_view( string $view, array $request = array() ): void {
		if ( 'logs' === $view ) {
			self::render_logs_view();
		} elseif ( 'backups' === $view ) {
			self::render_backups_view( $request );
		} else {
			PageFerry_Import_Admin::render_screen();
		}
	}

	/**
	 * Renders the wrap shell (title + tabs + dismissible notices) around a view.
	 *
	 * @param string $active_tab Active tab slug.
	 * @return void
	 */
	private static function render_page_shell( string $active_tab ): void {
		$request = self::backup_request( $_GET ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only recovery navigation.
		?>
		<div class="wrap pageferry-page">
			<header class="pf-page-header"><h1><?php esc_html_e( 'PageFerry', 'pageferry' ); ?></h1><p><?php esc_html_e( 'Import one page with its media.', 'pageferry' ); ?></p></header>
			<hr class="wp-header-end" />
			<?php self::render_tabs( $active_tab ); ?>
			<?php foreach ( array( 'import', 'logs', 'backups' ) as $tab ) : ?>
				<div id="pf-panel-<?php echo esc_attr( $tab ); ?>" class="pf-tab-panel" data-tab="<?php echo esc_attr( $tab ); ?>" data-backup-page="<?php echo (int) $request['page']; ?>" data-backup-key="<?php echo esc_attr( $request['key'] ); ?>" data-loaded="<?php echo $tab === $active_tab ? '1' : '0'; ?>" <?php echo $tab !== $active_tab ? 'hidden' : ''; ?>>
				<?php
				if ( $tab === $active_tab ) {
					self::render_tab_view( $tab, $request ); }
				?>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Renders the import/logs/backups tab nav.
	 *
	 * @param string $active_tab Active tab slug.
	 * @return void
	 */
	private static function render_tabs( string $active_tab ): void {
		$tabs = array(
			'import'  => __( 'Import', 'pageferry' ),
			'logs'    => __( 'Import log', 'pageferry' ),
			'backups' => __( 'Recovery snapshots', 'pageferry' ),
		);
		?>
		<h2 class="nav-tab-wrapper">
			<?php foreach ( $tabs as $tab_slug => $tab_label ) : ?>
				<?php
				$tab_url = add_query_arg(
					array(
						'page' => 'pageferry-import',
						'tab'  => $tab_slug,
					),
					admin_url( 'tools.php' )
				);
				?>
				<a id="pf-tab-<?php echo esc_attr( $tab_slug ); ?>" data-tab="<?php echo esc_attr( $tab_slug ); ?>" href="<?php echo esc_url( $tab_url ); ?>" class="nav-tab<?php echo $tab_slug === $active_tab ? ' nav-tab-active' : ''; ?>" <?php echo $tab_slug === $active_tab ? 'aria-current="page"' : ''; ?>><?php echo esc_html( $tab_label ); ?></a>
			<?php endforeach; ?>
		</h2>
		<?php
	}

	/**
	 * Renders newest-first logs with transfer and failure details.
	 *
	 * @return void
	 */
	private static function render_logs_view(): void {
		$log_rows = get_option( PageFerry::OPTION_LOGS, array() );

		if ( ! is_array( $log_rows ) ) {
			$log_rows = array();
		}

		$log_rows = array_reverse( $log_rows );
		?>
		<div class="pf-heading"><div><h2><?php esc_html_e( 'Import log', 'pageferry' ); ?></h2><p><?php esc_html_e( 'The recorded outcomes of your imports, newest first.', 'pageferry' ); ?></p></div></div>
		<?php

		if ( array() === $log_rows ) {
			echo '<div class="pf-workspace pf-result-workspace"><section class="pf-section"><h3>';
			esc_html_e( 'No imports logged yet', 'pageferry' );
			echo '</h3><p class="pf-note">';
			esc_html_e( 'Recorded import outcomes will appear here. Choose a ZIP to start an import.', 'pageferry' );
			echo '</p>';
			self::render_return_to_import();
			echo '</section></div>';
			return;
		}
		?>
		<div class="pf-workspace pf-result-workspace"><section class="pf-section">
			<?php foreach ( $log_rows as $log_row ) : ?>
				<?php self::render_log_row( is_array( $log_row ) ? $log_row : array() ); ?>
			<?php endforeach; ?>
			<?php self::render_return_to_import(); ?>
		</section></div>
		<?php
	}

	/**
	 * Renders an escaped log row, including warnings and recovery links.
	 *
	 * @param array $log_row Log row array.
	 * @return void
	 */
	private static function render_log_row( array $log_row ): void {
		$time_stamp = isset( $log_row['time'] ) && is_string( $log_row['time'] ) ? $log_row['time'] : '';
		$action     = isset( $log_row['action'] ) && is_string( $log_row['action'] ) ? $log_row['action'] : '';
		$target_id  = isset( $log_row['target'] ) ? (int) $log_row['target'] : 0;
		$reused     = isset( $log_row['reused'] ) ? (int) $log_row['reused'] : 0;
		$uploaded   = isset( $log_row['uploaded'] ) ? (int) $log_row['uploaded'] : 0;
		$result     = isset( $log_row['result'] ) && is_string( $log_row['result'] ) ? $log_row['result'] : '';
		$backup_ref = isset( $log_row['backup'] ) && is_string( $log_row['backup'] ) ? $log_row['backup'] : '';
		$details    = self::log_row_details( $log_row );
		$post       = $target_id > 0 && current_user_can( 'edit_post', $target_id ) ? get_post( $target_id ) : null;
		$label      = $post instanceof WP_Post && '' !== $post->post_title ? $post->post_title : sprintf( /* translators: %d: recorded destination ID. */ __( 'Imported content #%d', 'pageferry' ), $target_id );
		$statuses   = array(
			'success'     => $details ? __( 'Complete with warnings', 'pageferry' ) : __( 'Complete', 'pageferry' ),
			'partial'     => __( 'Partial', 'pageferry' ),
			'failed'      => __( 'Failed', 'pageferry' ),
			'unconfirmed' => __( 'Unconfirmed', 'pageferry' ),
		);
		$source     = is_string( $log_row['source'] ?? null ) ? (string) wp_parse_url( $log_row['source'], PHP_URL_HOST ) : '';
		?>
		<article class="pf-log-row">
			<div class="pf-log-time"><time datetime="<?php echo esc_attr( $time_stamp ); ?>" title="<?php echo esc_attr( $time_stamp ); ?>"><?php echo esc_html( self::display_time( $time_stamp, true ) ); ?></time></div>
			<div><strong><?php echo esc_html( $label ); ?></strong><p><?php echo esc_html( 'update' === $action ? __( 'Updated existing content', 'pageferry' ) : ( 'create' === $action ? __( 'Created a new draft', 'pageferry' ) : __( 'Import attempt', 'pageferry' ) ) ); ?><?php echo '' !== $source ? ' · ' . esc_html( $source ) : ''; ?></p>
				<p class="pf-note"><?php esc_html_e( 'Target', 'pageferry' ); ?>:
				<?php
				if ( 0 < $target_id && current_user_can( 'edit_post', $target_id ) ) :
					?>
					<a href="<?php echo esc_url( (string) get_edit_post_link( $target_id, 'raw' ) ); ?>">#<?php echo (int) $target_id; ?></a>
					<?php
else :
	?>
					#<?php echo (int) $target_id; ?><?php endif; ?> · <?php printf( /* translators: 1: reused media count, 2: uploaded media count. */ esc_html__( '%1$d reused, %2$d uploaded', 'pageferry' ), (int) $reused, (int) $uploaded ); ?></p>
				<?php
				if ( $details ) :
					?>
					<?php self::render_log_details( $details ); ?><?php endif; ?>
				<?php
				if ( '' !== $backup_ref ) :
					?>
					<p class="pf-note"><a href="<?php echo esc_url( self::backup_url( $backup_ref ) ); ?>" title="<?php echo esc_attr( $backup_ref ); ?>"><?php esc_html_e( 'View recovery snapshot', 'pageferry' ); ?></a></p><?php endif; ?>
			</div><span class="pf-status <?php echo esc_attr( 'success' === $result && ! $details ? 'success' : ( 'failed' === $result ? 'error' : 'warning' ) ); ?>"><?php echo esc_html( $statuses[ $result ] ?? $result ); ?></span>
		</article>
		<?php
	}

	/**
	 * Formats a recorded timestamp for readable display.
	 *
	 * @param string $value Recorded ISO timestamp.
	 * @param bool   $short Omit the year in compact log rows.
	 * @return string Localized readable date.
	 */
	private static function display_time( string $value, bool $short = false ): string {
		$timestamp = strtotime( $value );
		return false !== $timestamp ? wp_date( ( $short ? 'j M' : 'j M Y' ) . ' · ' . get_option( 'time_format' ), $timestamp ) : ( '' !== $value ? $value : '—' );
	}

	/** Renders a return action whose label reflects any retained import result. */
	private static function render_return_to_import(): void {
		?>
		<div class="pf-result-actions"><a class="button button-primary" data-import-return href="<?php echo esc_url( admin_url( 'tools.php?page=pageferry-import' ) ); ?>"><?php esc_html_e( 'Back to import', 'pageferry' ); ?></a></div>
		<?php
	}

	/**
	 * Normalizes structured warnings from current and legacy log rows.
	 *
	 * @param array $log_row Log row array.
	 * @return array List of human-readable detail strings.
	 */
	private static function log_row_details( array $log_row ): array {
		$details = array();

		if ( isset( $log_row['missing'] ) && is_array( $log_row['missing'] ) && array() !== $log_row['missing'] ) {
			$missing_ids = array();

			foreach ( $log_row['missing'] as $missing_id ) {
				if ( is_numeric( $missing_id ) ) {
					$missing_ids[] = (string) (int) $missing_id;
				}
			}

			if ( array() !== $missing_ids ) {
				$details[] = sprintf(
					/* translators: %s: comma-separated source attachment IDs with no file. */
					__( 'Missing media (source IDs: %s).', 'pageferry' ),
					implode( ', ', $missing_ids )
				);
			}
		}

		foreach ( array( 'export_warnings', 'pattern_warnings', 'template_warnings', 'acf_skipped', 'term_errors', 'thumbnail_errors', 'template_errors', 'media_errors', 'acf_errors', 'cleanup_errors' ) as $list_key ) {
			if ( ! isset( $log_row[ $list_key ] ) || ! is_array( $log_row[ $list_key ] ) ) {
				continue;
			}

			foreach ( $log_row[ $list_key ] as $note ) {
				if ( is_string( $note ) && '' !== trim( $note ) ) {
					$details[] = $note;
				}
			}
		}

		return $details;
	}

	/**
	 * Renders the details cell for one log row.
	 *
	 * @param array $details Detail strings from log_row_details().
	 * @return void
	 */
	private static function render_log_details( array $details ): void {
		if ( array() === $details ) {
			echo '&mdash;';
			return;
		}

		echo '<ul>';

		foreach ( $details as $detail ) {
			echo '<li>';
			echo esc_html( $detail );
			echo '</li>';
		}

		echo '</ul>';
	}

	/**
	 * Renders authorized recovery snapshots; hidden rows must disclose no recovery data.
	 *
	 * @param array $request Validated recovery navigation.
	 * @return void
	 */
	private static function render_backups_view( array $request = array() ): void {
		if ( ! current_user_can( 'import' ) ) {
			return;
		}
		$history = PageFerry_Backups::history();
		$visible = array();
		foreach ( $history ?? array() as $key => $summary ) {
			if ( self::can_view_backup( $summary ) ) {
				$visible[ $key ] = $summary;
			}
		}
		$page = max( 1, (int) ( $request['page'] ?? 1 ) );
		$key  = $request['key'] ?? '';
		if ( '' === $key && ! empty( $request['anchor'] ) ) {
			foreach ( $visible as $candidate => $summary ) {
				if ( md5( (string) $candidate ) === $request['anchor'] ) {
					$key = (string) $candidate;
					break;
				}
			}
		}
		?>
		<div class="pf-heading"><div><h2><?php esc_html_e( 'Recovery snapshots', 'pageferry' ); ?></h2><p><?php esc_html_e( 'Snapshots preserve the previous version when existing content is updated.', 'pageferry' ); ?></p></div></div>
		<?php
		if ( null === $history || '' !== $key ) {
			$backup = isset( $visible[ $key ] ) ? PageFerry_Backups::find( $key ) : null;
			if ( is_array( $backup ) && self::can_view_backup( $backup ) ) {
				self::render_backup_row( $key, $backup );
			} else {
				echo '<div class="pf-workspace pf-result-workspace"><section class="pf-section"><p role="alert">';
				esc_html_e( 'This recovery snapshot is unavailable. Open the history to choose an available snapshot.', 'pageferry' );
				echo '</p></section></div>';
			}
			?>
			<p class="pf-recovery-back"><a class="button" href="<?php echo esc_url( self::backup_url( '', $page ) ); ?>"><?php esc_html_e( 'Back to recovery history', 'pageferry' ); ?></a></p>
			<?php
		} elseif ( array() === $visible ) {
			?>
			<div class="pf-workspace pf-result-workspace"><section class="pf-section"><h3><?php esc_html_e( 'No recovery snapshots are available', 'pageferry' ); ?></h3><p class="pf-note"><?php esc_html_e( 'Updating an existing page saves its previous title, content and page details here. Creating a new draft does not replace an existing page, so it has no previous version to recover.', 'pageferry' ); ?></p></section></div>
			<?php
		} else {
			$pages = (int) ceil( count( $visible ) / 10 );
			$page  = min( $page, $pages );
			?>
			<div class="pf-workspace pf-result-workspace"><section class="pf-section">
			<?php foreach ( array_slice( array_reverse( $visible, true ), ( $page - 1 ) * 10, 10, true ) as $backup_key => $summary ) : ?>
				<article class="pf-log-row pf-backup-summary" id="pageferry-backup-<?php echo esc_attr( md5( (string) $backup_key ) ); ?>">
					<div class="pf-log-time"><time><?php echo esc_html( self::display_time( $summary['time'], true ) ); ?></time></div>
					<div><h3><?php echo esc_html( '' !== $summary['post_title'] ? $summary['post_title'] : __( 'Recovery data', 'pageferry' ) ); ?></h3><p class="pf-note"><?php printf( /* translators: 1: target post ID, 2: snapshot size. */ esc_html__( 'Target #%1$d · %2$s', 'pageferry' ), (int) $summary['post_id'], esc_html( size_format( $summary['bytes'] ) ) ); ?></p><p><a class="button" href="<?php echo esc_url( self::backup_url( (string) $backup_key, $page ) ); ?>"><?php esc_html_e( 'Open recovery snapshot', 'pageferry' ); ?></a></p></div>
				</article>
			<?php endforeach; ?>
			<nav class="pf-result-actions" aria-label="<?php esc_attr_e( 'Recovery history pages', 'pageferry' ); ?>">
				<?php
				if ( 1 < $page ) :
					?>
					<a class="button" href="<?php echo esc_url( self::backup_url( '', $page - 1 ) ); ?>"><?php esc_html_e( 'Newer snapshots', 'pageferry' ); ?></a><?php endif; ?>
				<span><?php printf( /* translators: 1: current history page, 2: total history pages. */ esc_html__( 'Page %1$d of %2$d', 'pageferry' ), (int) $page, (int) $pages ); ?></span>
				<?php
				if ( $page < $pages ) :
					?>
					<a class="button" href="<?php echo esc_url( self::backup_url( '', $page + 1 ) ); ?>"><?php esc_html_e( 'Older snapshots', 'pageferry' ); ?></a><?php endif; ?>
			</nav></section></div>
			<?php
		}
		self::render_return_to_import();
	}

	/**
	 * Normalizes read-only recovery navigation for full pages and AJAX fragments.
	 *
	 * @param array $input Request query or nonce-checked AJAX body.
	 * @return array Validated page, opaque snapshot key and legacy anchor.
	 */
	private static function backup_request( array $input ): array {
		$key    = is_string( $input['backup'] ?? null ) ? wp_unslash( $input['backup'] ) : '';
		$anchor = is_string( $input['backup_anchor'] ?? null ) ? $input['backup_anchor'] : '';
		return array(
			'page'   => is_scalar( $input['backup_page'] ?? null ) ? max( 1, absint( $input['backup_page'] ) ) : 1,
			'key'    => strlen( $key ) <= 190 && ! preg_match( '/[\x00-\x1f\x7f]/', $key ) ? $key : '',
			'anchor' => preg_match( '/^[a-f0-9]{32}$/D', $anchor ) ? $anchor : '',
		);
	}

	/**
	 * Links directly to one snapshot or an authorized history page.
	 *
	 * @param string $key Snapshot key, or empty for history.
	 * @param int    $page History page to retain when returning from detail.
	 * @return string Recovery URL.
	 */
	public static function backup_url( string $key = '', int $page = 1 ): string {
		$args = array(
			'page'        => 'pageferry-import',
			'tab'         => 'backups',
			'backup_page' => max( 1, $page ),
		);
		if ( '' !== $key ) {
			$args['backup'] = $key;
		}
		return add_query_arg( $args, admin_url( 'tools.php' ) ) . ( '' !== $key ? '#pageferry-backup-' . md5( $key ) : '' );
	}

	/**
	 * Checks target edit authority, or privileged access for orphaned snapshots.
	 *
	 * @param array $backup Snapshot array.
	 * @return bool True when the recovery data may be rendered.
	 */
	public static function can_view_backup( array $backup ): bool {
		if ( ! current_user_can( 'import' ) ) {
			return false;
		}

		$post_id = isset( $backup['post_id'] ) ? (int) $backup['post_id'] : 0;

		if ( 0 >= $post_id ) {
			return current_user_can( self::RECOVERY_PRIVILEGED_CAPABILITY );
		}

		$target_post = get_post( $post_id );

		if ( ! $target_post instanceof WP_Post ) {
			return current_user_can( self::RECOVERY_PRIVILEGED_CAPABILITY );
		}

		return current_user_can( 'edit_post', $target_post->ID );
	}

	/**
	 * Checks additional authority for protected historical metadata.
	 *
	 * @param array  $backup Snapshot array.
	 * @param string $meta_key Stored meta key.
	 * @return bool True when the key may be rendered.
	 */
	private static function can_view_backup_meta_key( array $backup, string $meta_key ): bool {
		if ( ! self::is_protected_backup_meta_key( $meta_key ) ) {
			return true;
		}

		if ( current_user_can( self::RECOVERY_PRIVILEGED_CAPABILITY ) ) {
			return true;
		}

		$post_id = isset( $backup['post_id'] ) ? (int) $backup['post_id'] : 0;

		if ( 0 >= $post_id ) {
			return false;
		}

		$target_post = get_post( $post_id );

		if ( ! $target_post instanceof WP_Post ) {
			return false;
		}

		return current_user_can( 'edit_post_meta', $target_post->ID, $meta_key );
	}

	/**
	 * Uses filtered WordPress protected-meta rules to match edit_post_meta checks.
	 *
	 * @param string $meta_key Stored meta key.
	 * @return bool True for protected keys.
	 */
	private static function is_protected_backup_meta_key( string $meta_key ): bool {
		if ( function_exists( 'is_protected_meta' ) ) {
			return is_protected_meta( $meta_key, 'post' );
		}

		return isset( $meta_key[0] ) && '_' === $meta_key[0];
	}

	/**
	 * Renders an authorized snapshot; absent legacy fields are marked unrecorded.
	 *
	 * @param string $backup_key Snapshot key.
	 * @param array  $backup Snapshot array.
	 * @return void
	 */
	private static function render_backup_row( string $backup_key, array $backup ): void {
		if ( ! self::can_view_backup( $backup ) ) {
			return;
		}

		$time_stamp = isset( $backup['time'] ) && is_string( $backup['time'] ) ? $backup['time'] : '';
		$post_id    = isset( $backup['post_id'] ) ? (int) $backup['post_id'] : 0;
		$title      = array_key_exists( 'post_title', $backup ) && is_string( $backup['post_title'] ) ? $backup['post_title'] : null;
		$content    = isset( $backup['post_content'] ) && is_string( $backup['post_content'] ) ? $backup['post_content'] : null;
		$excerpt    = array_key_exists( 'post_excerpt', $backup ) && is_string( $backup['post_excerpt'] ) ? $backup['post_excerpt'] : null;
		$slug       = isset( $backup['post_name'] ) && is_string( $backup['post_name'] ) ? $backup['post_name'] : null;
		$details_id = 'pageferry-backup-' . md5( $backup_key );
		$edit_link  = 0 < $post_id ? get_edit_post_link( $post_id, 'display' ) : null;
		?>
		<article id="<?php echo esc_attr( $details_id ); ?>" class="pf-workspace pf-result-workspace pf-backup-card">
			<section class="pf-result-detail"><h3><?php echo esc_html( $title ?? __( 'Recovery data', 'pageferry' ) ); ?></h3><dl class="pf-recovery-meta"><div><dt><?php esc_html_e( 'Saved', 'pageferry' ); ?></dt><dd><?php echo '' !== $time_stamp ? esc_html( self::display_time( $time_stamp ) ) : '&mdash;'; ?></dd></div><div><dt><?php esc_html_e( 'Target', 'pageferry' ); ?></dt><dd>
			<?php
			if ( 0 < $post_id && is_string( $edit_link ) && '' !== $edit_link ) :
				?>
				<a href="<?php echo esc_url( $edit_link ); ?>"><?php echo (int) $post_id; ?></a>
				<?php
else :
	?>
				<?php echo (int) $post_id; ?><?php endif; ?></dd></div><div><dt><?php esc_html_e( 'Snapshot ID', 'pageferry' ); ?></dt><dd><code><?php echo esc_html( $backup_key ); ?></code></dd></div></dl><div class="pf-notice"><div class="pf-notice-heading"><?php echo PageFerry_Import_Review::icon( 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?><?php esc_html_e( 'This snapshot is read-only', 'pageferry' ); ?></div><p><?php esc_html_e( 'Recovery is manual. Opening the snapshot does not change the saved page.', 'pageferry' ); ?></p></div></section>
			<section class="pf-result-detail"><h3><?php esc_html_e( 'Previous page details', 'pageferry' ); ?></h3>
				<?php self::render_backup_value( __( 'Title', 'pageferry' ), $title ); ?>
				<?php self::render_backup_value( __( 'Excerpt', 'pageferry' ), $excerpt ); ?>
				<?php self::render_backup_value( __( 'URL slug', 'pageferry' ), $slug ); ?>
				<div class="pf-detail-row"><div class="pf-detail-name"><?php esc_html_e( 'Categories and tags', 'pageferry' ); ?></div><div><?php self::render_backup_terms( $backup ); ?></div></div>
				<div class="pf-detail-row"><div class="pf-detail-name"><?php esc_html_e( 'Featured image', 'pageferry' ); ?></div><div><?php self::render_backup_thumbnail( $backup ); ?></div></div>
			</section>
			<section class="pf-result-detail"><h3><?php esc_html_e( 'Previous content', 'pageferry' ); ?></h3>
				<?php self::render_backup_value( __( 'Content', 'pageferry' ), $content, 8 ); ?>
			</section>
			<section class="pf-result-detail"><h3><?php esc_html_e( 'Stored page metadata', 'pageferry' ); ?></h3><?php self::render_backup_meta( $backup ); ?></section>
			<section class="pf-result-detail"><h3><?php esc_html_e( 'Recover the previous version', 'pageferry' ); ?></h3><ol class="pf-instructions"><li><?php esc_html_e( 'Open the saved page in the WordPress editor.', 'pageferry' ); ?></li><li><?php esc_html_e( 'Use the snapshot to restore the title, content, excerpt and URL slug you need.', 'pageferry' ); ?></li><li><?php esc_html_e( 'Check the terms, featured image and template before updating the page. Ask a developer to re-apply other stored post meta if needed.', 'pageferry' ); ?></li></ol>
			<?php
			if ( is_string( $edit_link ) && '' !== $edit_link ) :
				?>
				<div class="pf-result-actions"><a class="button button-primary" href="<?php echo esc_url( $edit_link ); ?>"><?php esc_html_e( 'Open saved page', 'pageferry' ); ?></a></div><?php endif; ?></section>
		</article>
		<?php
	}

	/**
	 * Renders an exact copyable value with a compact descriptive label.
	 *
	 * @param string      $label Field label.
	 * @param string|null $value Stored value, or null when not recorded.
	 * @param int         $rows Visible textarea rows.
	 * @return void
	 */
	private static function render_backup_value( string $label, ?string $value, int $rows = 2 ): void {
		?>
		<div class="pf-detail-row"><div class="pf-detail-name"><?php echo esc_html( $label ); ?></div><div>
		<?php if ( null === $value ) : ?>
			<p class="pf-note"><?php printf( /* translators: %s: snapshot field label. */ esc_html__( '%s was not recorded for this snapshot.', 'pageferry' ), esc_html( $label ) ); ?></p>
		<?php else : ?>
			<textarea readonly rows="<?php echo (int) $rows; ?>" aria-label="<?php echo esc_attr( $label ); ?>"><?php echo esc_textarea( $value ); ?></textarea>
		<?php endif; ?></div></div>
		<?php
	}

	/**
	 * Renders recorded terms; missing legacy data is distinct from an empty set.
	 *
	 * @param array $backup Snapshot array.
	 * @return void
	 */
	private static function render_backup_terms( array $backup ): void {
		if ( ! array_key_exists( 'terms', $backup ) || ! is_array( $backup['terms'] ) ) {
			echo '<p><em>';
			esc_html_e( 'Terms were not recorded for this snapshot (taken before the backup fix).', 'pageferry' );
			echo '</em></p>';
			return;
		}

		if ( array() === $backup['terms'] ) {
			echo '&mdash;';
			return;
		}

		echo '<ul>';

		foreach ( $backup['terms'] as $taxonomy => $terms ) {
			if ( ! is_string( $taxonomy ) || '' === $taxonomy || ! is_array( $terms ) ) {
				continue;
			}

			$object = get_taxonomy( $taxonomy );
			echo '<li><strong>';
			echo esc_html( $object instanceof WP_Taxonomy ? $object->label : $taxonomy );
			echo '</strong>: ';

			if ( array() === $terms ) {
				echo esc_html__( '(none)', 'pageferry' );
			} else {
				$names = array();

				foreach ( $terms as $term ) {
					if ( ! is_array( $term ) ) {
						continue;
					}

					if ( isset( $term['name'] ) && is_string( $term['name'] ) && '' !== $term['name'] ) {
						$names[] = $term['name'];
					} elseif ( isset( $term['slug'] ) && is_string( $term['slug'] ) && '' !== $term['slug'] ) {
						$names[] = $term['slug'];
					}
				}

				echo array() !== $names ? esc_html( implode( ', ', $names ) ) : esc_html__( '(none)', 'pageferry' );
			}

			echo '</li>';
		}

		echo '</ul>';
	}

	/**
	 * Renders the recorded thumbnail, with legacy metadata fallback.
	 *
	 * @param array $backup Snapshot array.
	 * @return void
	 */
	private static function render_backup_thumbnail( array $backup ): void {
		$thumbnail_id = null;

		if ( array_key_exists( 'thumbnail_id', $backup ) && is_numeric( $backup['thumbnail_id'] ) ) {
			$thumbnail_id = (int) $backup['thumbnail_id'];
		} elseif ( isset( $backup['post_meta'] ) && is_array( $backup['post_meta'] ) && isset( $backup['post_meta']['_thumbnail_id'] ) && is_array( $backup['post_meta']['_thumbnail_id'] ) && isset( $backup['post_meta']['_thumbnail_id'][0] ) && is_numeric( $backup['post_meta']['_thumbnail_id'][0] ) ) {
			$thumbnail_id = (int) $backup['post_meta']['_thumbnail_id'][0];
		}

		if ( null === $thumbnail_id ) {
			echo '<p><em>';
			esc_html_e( 'Featured image was not recorded for this snapshot (taken before the backup fix).', 'pageferry' );
			echo '</em></p>';
			return;
		}

		if ( 0 >= $thumbnail_id ) {
			echo esc_html__( '(none)', 'pageferry' );
			return;
		}

		echo esc_html( (string) $thumbnail_id );
	}

	/**
	 * Renders authorized stored metadata and identifies withheld protected keys.
	 *
	 * @param array $backup Snapshot array.
	 * @return void
	 */
	private static function render_backup_meta( array $backup ): void {
		if ( ! isset( $backup['post_meta'] ) || ! is_array( $backup['post_meta'] ) ) {
			echo '&mdash;';
			return;
		}

		if ( array() === $backup['post_meta'] ) {
			echo esc_html__( '(none)', 'pageferry' );
			return;
		}

		$withheld = 0;
		$items    = array();

		foreach ( $backup['post_meta'] as $meta_key => $meta_values ) {
			if ( ! is_string( $meta_key ) || '' === $meta_key || ! is_array( $meta_values ) ) {
				continue;
			}

			if ( ! self::can_view_backup_meta_key( $backup, $meta_key ) ) {
				++$withheld;
				continue;
			}

			$rendered_values = array();

			foreach ( $meta_values as $meta_value ) {
				if ( is_array( $meta_value ) ) {
					$encoded           = wp_json_encode( $meta_value );
					$rendered_values[] = is_string( $encoded ) ? $encoded : '(array)';
				} elseif ( is_string( $meta_value ) ) {
					$rendered_values[] = $meta_value;
				} elseif ( is_numeric( $meta_value ) || is_bool( $meta_value ) ) {
					$rendered_values[] = (string) $meta_value;
				} else {
					continue;
				}
			}

			if ( array() === $rendered_values ) {
				continue;
			}

			$value = implode( ', ', $rendered_values );
			if ( 512 < strlen( $value ) ) {
				$label   = sprintf( /* translators: %s: stored metadata key. */ __( 'Stored value for %s', 'pageferry' ), $meta_key );
				$items[] = '<li><code>' . esc_html( $meta_key ) . '</code><textarea readonly rows="4" aria-label="' . esc_attr( $label ) . '">' . esc_textarea( $value ) . '</textarea></li>';
			} else {
				$items[] = '<li><code>' . esc_html( $meta_key ) . '</code>: ' . esc_html( $value ) . '</li>';
			}
		}

		if ( array() !== $items ) {
			echo '<ul>';
			foreach ( $items as $item ) {
				echo $item; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
			}
			echo '</ul>';
		} elseif ( 0 === $withheld ) {
			echo esc_html__( '(none)', 'pageferry' );
			return;
		}

		if ( 0 < $withheld ) {
			echo '<p><em>';
			esc_html_e( 'Some protected meta keys are hidden: you lack permission to view them.', 'pageferry' );
			echo '</em></p>';
		}
	}
}
