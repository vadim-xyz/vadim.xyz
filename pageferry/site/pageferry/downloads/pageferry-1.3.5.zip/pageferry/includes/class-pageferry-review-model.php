<?php
/**
 * Prepared, nonauthoritative display facts for interactive import review.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/** Keeps expensive inventories reusable without granting media write authority. */
class PageFerry_Review_Model {
	/**
	 * Unpublished inventory generations, scoped to each site.
	 *
	 * @var array<int, string>
	 */
	private static $pending = array();

	/**
	 * Sites edited since their last review observation.
	 *
	 * @var array<int, bool>
	 */
	private static $bursts = array();

	/**
	 * Prevent recursive publication from option callbacks.
	 *
	 * @var array<int, bool>
	 */
	private static $publishing = array();

	/**
	 * Whether the late PHP shutdown publisher is registered.
	 *
	 * @var bool
	 */
	private static $shutdown_registered = false;

	/**
	 * Builds bounded display data after the importer verified all staged media.
	 *
	 * @param array $manifest Validated original manifest.
	 * @param array $preview Full preparation preview.
	 * @param array $media Verified media groups, keyed by source ID.
	 * @return array
	 */
	public static function build( array $manifest, array $preview, array $media ): array {
		$warnings = array_merge( $preview['export_warnings'], $preview['acf_warnings'], $preview['pattern_warnings'] );
		if ( $manifest['post']['post_type'] !== $preview['post_type'] ) {
			$warnings[] = sprintf(
				/* translators: 1: source post type, 2: destination post type. */
				__( 'This bundle was exported as %1$s and will be imported as %2$s. Check the available taxonomies and template on this site.', 'pageferry' ),
				$manifest['post']['post_type'],
				$preview['post_type']
			);
		}
		foreach ( $preview['review']['media'] as $entry ) {
			$media[ $entry['id'] ] += $entry;
			if ( $entry['likely_false_positive'] ) {
				$warnings[] = __( 'Some media was detected from a number in a block setting, without a matching image URL or a known media field. That number may be unrelated to an attachment. Inspect the items marked “Check this item” before importing.', 'pageferry' );
			}
		}
		$fields = array();
		foreach ( array( 'title', 'excerpt', 'slug', 'template', 'thumbnail_old_id' ) as $field ) {
			if ( array_key_exists( $field, $manifest['post'] ) ) {
				$fields[ $field ] = $manifest['post'][ $field ];
			}
		}
		return array(
			'version'              => 1,
			'manifest_hash'        => hash( 'sha256', (string) wp_json_encode( $manifest ) ),
			'environment'          => self::environment(),
			'target'               => $preview['target'],
			'target_post_id'       => $preview['target_post_id'],
			'target_fingerprint'   => $preview['target_fingerprint'],
			'target_title'         => $preview['target_title'],
			'target_slug'          => $preview['target_slug'],
			'post_type'            => $preview['post_type'],
			'media'                => $media,
			'media_order'          => array_map( 'intval', array_column( $manifest['media'], 'old_id' ) ),
			'groups'               => PageFerry_Import_Selection::taxonomies( $manifest ),
			'taxonomies'           => $preview['review']['taxonomies'],
			'templates'            => $preview['templates'],
			'validation_templates' => wp_get_theme()->get_page_templates( null, $preview['post_type'] ),
			'fields'               => $fields,
			'warnings'             => array_values( array_unique( $warnings ) ),
			'taxonomy_warnings'    => $preview['review_taxonomy_warnings'],
			'template_warnings'    => $preview['review_template_warnings'],
		);
	}

	/**
	 * Counts selected verified groups in the same order as execution.
	 *
	 * @param array $model Prepared display facts.
	 * @param array $selection Canonical choices.
	 * @return array
	 */
	public static function media_plan( array $model, array $selection ): array {
		$plan = array(
			'new'         => 0,
			'reuse'       => 0,
			'missing_ids' => array(),
			'actions'     => array(),
		);
		$seen = array();
		foreach ( $model['media_order'] as $id ) {
			$entry  = $model['media'][ $id ];
			$action = 'excluded';
			if ( in_array( $id, $selection['media'], true ) ) {
				if ( $entry['missing'] ) {
					$action                = 'missing';
					$plan['missing_ids'][] = $id;
				} else {
					$action = $entry['library'] || isset( $seen[ $entry['hash'] ] ) ? 'reuse' : 'new';
					++$plan[ $action ];
					$seen[ $entry['hash'] ] = true;
				}
			}
			$plan['actions'][ $id ] = $action;
		}
		return $plan;
	}

	/**
	 * Derives selection notes from prepared facts without provider/file lookups.
	 *
	 * @param array $model Prepared facts.
	 * @param array $selection Canonical choices.
	 * @param array $effective Choice-filtered manifest.
	 * @return array
	 */
	public static function warnings( array $model, array $selection, array $effective ): array {
		$warnings = $model['warnings'];
		$plan     = self::media_plan( $model, $selection );
		if ( $plan['missing_ids'] ) {
			$warnings[] = sprintf(
				/* translators: 1: missing media count, 2: source IDs. */
				__( '%1$d media entries have no file and will be skipped (source IDs: %2$s).', 'pageferry' ),
				count( $plan['missing_ids'] ),
				implode( ', ', $plan['missing_ids'] )
			);
		}
		if ( count( $model['media'] ) > count( $selection['media'] ) ) {
			$warnings[] = __( 'Deselected media will not be imported or remapped. Its references stay in the content and block values; images or links may still point to the source site or need repair.', 'pageferry' );
		}
		$thumbnail = $effective['post']['thumbnail_old_id'] ?? null;
		if ( 'update' === $model['target'] && $thumbnail && ( ! isset( $plan['actions'][ $thumbnail ] ) || in_array( $plan['actions'][ $thumbnail ], array( 'missing', 'excluded' ), true ) ) ) {
			$warnings[] = __( 'Featured image source is missing — the target image will be kept.', 'pageferry' );
		}
		if ( ! empty( $effective['post']['template'] ) && ( $model['fields']['template'] ?? null ) === $effective['post']['template'] ) {
			$warnings = array_merge( $warnings, $model['template_warnings'] );
		}
		foreach ( $model['taxonomies'] as $taxonomy ) {
			$keys = $selection['taxonomies'][ $taxonomy['slug'] ] ?? array();
			if ( $keys ) {
				$warnings = array_merge( $warnings, $model['taxonomy_warnings'][ $taxonomy['slug'] ] );
			}
			foreach ( $taxonomy['terms'] as $term ) {
				$included = in_array( $term['key'], $keys, true );
				foreach ( $effective['tax_terms'][ $taxonomy['slug'] ] ?? array() as $required ) {
					$included = $included || ( $required['name'] === $term['name'] && ( $required['slug'] ?? '' ) === $term['slug'] );
				}
				if ( $included && 'forbidden' === $term['status'] ) {
					$warnings[] = sprintf(
						/* translators: 1: term name, 2: taxonomy label. */
						__( 'You do not have permission to create “%1$s” in %2$s. Deselect it or ask a site administrator to create the term first.', 'pageferry' ),
						$term['name'],
						$taxonomy['label']
					);
				}
			}
		}
		return array_values( array_unique( $warnings ) );
	}

	/**
	 * Detects a changed bundle or environment without scanning files/inventories.
	 *
	 * @param array $manifest Server-owned original manifest.
	 * @param array $model Server-owned preparation.
	 * @return bool
	 */
	public static function valid( array $manifest, array $model ): bool {
		foreach ( array( 'media', 'media_order', 'groups', 'templates', 'validation_templates', 'fields', 'taxonomies', 'warnings', 'taxonomy_warnings', 'template_warnings' ) as $key ) {
			if ( ! is_array( $model[ $key ] ?? null ) ) {
				return false;
			}
		}
		return 1 === ( $model['version'] ?? null )
			&& ( $model['manifest_hash'] ?? null ) === hash( 'sha256', (string) wp_json_encode( $manifest ) )
			&& ( $model['environment'] ?? null ) === self::environment();
	}

	/**
	 * Fingerprints provider registration and explicit inventory invalidation.
	 *
	 * @return string
	 */
	public static function environment(): string {
		$taxonomies = array();
		foreach ( get_taxonomies( array(), 'objects' ) as $name => $taxonomy ) {
			$taxonomies[ $name ] = array( $taxonomy->object_type, $taxonomy->hierarchical, $taxonomy->cap, $taxonomy->label, current_user_can( $taxonomy->cap->assign_terms ), current_user_can( $taxonomy->cap->manage_terms ) );
		}
		$theme           = wp_get_theme();
		$plugins         = get_option( 'active_plugins', array() );
		$network_plugins = get_site_option( 'active_sitewide_plugins', array() );
		self::flush_invalidations();
		$site = get_current_blog_id();
		unset( self::$bursts[ $site ] );
		$generation = self::$pending[ $site ] ?? get_option( 'pageferry_review_generation', '' );
		return hash(
			'sha256',
			(string) wp_json_encode(
				array( $generation, $plugins, $network_plugins, $theme->get_stylesheet(), $theme->get_template(), $theme->get( 'Version' ), $taxonomies )
			)
		);
	}

	/**
	 * Invalidates prepared inventories after library, taxonomy or provider edits.
	 *
	 * @return void
	 */
	public static function invalidate(): void {
		if ( self::is_uninstalling() ) {
			return;
		}
		if ( ! self::$shutdown_registered ) {
			register_shutdown_function( array( self::class, 'flush_all_invalidations' ) );
			self::$shutdown_registered = true;
		}
		$site                   = get_current_blog_id();
		self::$pending[ $site ] = wp_generate_uuid4();
		if ( ! isset( self::$bursts[ $site ] ) ) {
			self::$bursts[ $site ] = true;
			// Publish now in case the request never reaches shutdown.
			self::flush_invalidations();
		}
	}

	/**
	 * Publishes the current site's edits before review facts can be reused.
	 *
	 * @return void
	 */
	public static function flush_invalidations(): void {
		$site = get_current_blog_id();
		if ( self::is_uninstalling() || ! isset( self::$pending[ $site ] ) || isset( self::$publishing[ $site ] ) ) {
			return;
		}
		$generation                = self::$pending[ $site ];
		self::$publishing[ $site ] = true;
		try {
			update_option( 'pageferry_review_generation', $generation, false );
			if ( get_option( 'pageferry_review_generation', '' ) === $generation && self::$pending[ $site ] === $generation ) {
				unset( self::$pending[ $site ] );
			}
		} finally {
			unset( self::$publishing[ $site ] );
		}
	}

	/**
	 * Flushes touched sites after WordPress shutdown hooks, retaining site context.
	 *
	 * @return void
	 */
	public static function flush_all_invalidations(): void {
		if ( self::is_uninstalling() ) {
			self::$pending = array();
			self::$bursts  = array();
			return;
		}
		foreach ( array_keys( self::$pending ) as $site ) {
			$switched = get_current_blog_id() !== $site;
			if ( $switched ) {
				switch_to_blog( $site );
			}
			try {
				self::flush_invalidations();
			} finally {
				if ( $switched ) {
					restore_current_blog();
				}
			}
		}
	}

	/**
	 * Invalidates supported provider definitions saved as posts.
	 *
	 * @param int     $post_id Saved post ID.
	 * @param WP_Post $post Saved post.
	 * @return void
	 */
	public static function saved_provider( int $post_id, WP_Post $post ): void {
		if ( in_array( $post->post_type, array( 'attachment', 'acf-field', 'acf-field-group', 'wp_template', 'wp_template_part' ), true ) ) {
			self::invalidate();
		}
	}

	/** Avoid recreating options only while this plugin is being removed. */
	private static function is_uninstalling(): bool {
		return defined( 'WP_UNINSTALL_PLUGIN' ) && plugin_basename( dirname( __DIR__ ) . '/pageferry.php' ) === WP_UNINSTALL_PLUGIN;
	}

	/**
	 * Invalidates library facts when WordPress changes attachment files/metadata.
	 *
	 * @param mixed  $meta_id Changed metadata ID(s).
	 * @param int    $post_id Object ID.
	 * @param string $key Metadata key.
	 * @return void
	 */
	public static function changed_media_meta( $meta_id, int $post_id, string $key ): void {
		if ( in_array( $key, array( '_wp_attached_file', '_wp_attachment_metadata' ), true ) && 'attachment' === get_post_type( $post_id ) ) {
			self::invalidate();
		}
	}
}
