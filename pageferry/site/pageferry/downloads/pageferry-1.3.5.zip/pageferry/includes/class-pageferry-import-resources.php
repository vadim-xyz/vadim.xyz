<?php
/**
 * Shared bounded import policy and stream operations.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/** Import limits. Filters may only lower the positive integer defaults. */
class PageFerry_Import_Resources {
	/**
	 * Effective byte and count ceilings, also used by the browser transport.
	 *
	 * @return array<string,int>
	 */
	public static function limits(): array {
		$upload   = (int) wp_max_upload_size();
		$limits   = array(
			'manifest_bytes'     => 4 * 1024 * 1024,
			'required_files'     => 500,
			'media_records'      => 5000,
			'media_file_bytes'   => 0 < $upload ? min( $upload, 256 * 1024 * 1024 ) : 256 * 1024 * 1024,
			'path_a_bytes'       => 0 < $upload ? 2 * min( $upload, 512 * 1024 * 1024 ) : 512 * 1024 * 1024,
			'path_b_bytes'       => 512 * 1024 * 1024,
			'core_bytes'         => 1024 * 1024 * 1024,
			'zip_bytes'          => 1024 * 1024 * 1024,
			'zip_entries'        => 2048,
			'zip_metadata_bytes' => 16 * 1024 * 1024,
			'zip_name_bytes'     => 4096,
		);
		$filtered = apply_filters( 'pageferry_import_resource_limits', $limits );
		if ( is_array( $filtered ) ) {
			foreach ( $limits as $key => $default ) {
				if ( isset( $filtered[ $key ] ) && is_int( $filtered[ $key ] ) && 0 < $filtered[ $key ] ) {
					$limits[ $key ] = min( $default, $filtered[ $key ] );
				}
			}
		}
		return $limits;
	}

	/**
	 * Checks a byte lower bound before encoding; objects and resources cannot invoke serializers.
	 *
	 * @param mixed $value Decoded manifest value.
	 * @param int   $limit Compact manifest ceiling.
	 * @return bool
	 */
	public static function manifest_fits( $value, int $limit ): bool {
		return self::measure_manifest( $value, $limit, 0 );
	}

	/**
	 * Traverses at most the byte budget, with PHP's JSON depth ceiling.
	 *
	 * @param mixed $value JSON-like value.
	 * @param int   $remaining Remaining compact-byte lower bound.
	 * @param int   $depth Number of enclosing arrays.
	 * @return bool
	 */
	private static function measure_manifest( $value, int &$remaining, int $depth ): bool {
		if ( is_array( $value ) ) {
			$count = count( $value );
			// Reject oversized containers before traversing them or calling array_is_list().
			if ( 512 <= $depth || 2 > $remaining || ( 0 < $count && $count > intdiv( $remaining - 1, 2 ) ) ) {
				return false;
			}
			$remaining -= 2 + max( 0, $count - 1 );
			$is_list    = array_is_list( $value );
			foreach ( $value as $key => $child ) {
				if ( ! $is_list ) {
					$key_bytes = strlen( (string) $key );
					if ( 3 > $remaining || $key_bytes > $remaining - 3 ) {
						return false;
					}
					$remaining -= $key_bytes + 3;
				}
				if ( ! self::measure_manifest( $child, $remaining, $depth + 1 ) ) {
					return false;
				}
			}
			return true;
		}
		if ( is_string( $value ) ) {
			$bytes = strlen( $value );
			if ( 2 > $remaining || $bytes > $remaining - 2 ) {
				return false;
			}
			$remaining -= $bytes + 2;
			return true;
		}
		if ( null === $value || is_bool( $value ) ) {
			$bytes = false === $value ? 5 : 4;
		} elseif ( is_int( $value ) || ( is_float( $value ) && is_finite( $value ) ) ) {
			$bytes = 1;
		} else {
			return false;
		}
		if ( $bytes > $remaining ) {
			return false;
		}
		$remaining -= $bytes;
		return true;
	}

	/**
	 * Stable resource refusal.
	 *
	 * @return WP_Error
	 */
	public static function exceeded(): WP_Error {
		return new WP_Error( 'pageferry_resource_limit', __( 'PageFerry cannot import this bundle: it exceeds an import resource limit.', 'pageferry' ), array( 'status' => 413 ) );
	}

	/**
	 * Compatibility per-file refusal.
	 *
	 * @param string $filename Media filename.
	 * @return WP_Error
	 */
	public static function file_exceeded( string $filename = '' ): WP_Error {
		return new WP_Error(
			'pageferry_media_too_large',
			sprintf(
				/* translators: 1: media filename, 2: allowed size. */
				__( 'PageFerry cannot import media file %1$s: it is larger than this site allows (%2$s).', 'pageferry' ),
				$filename,
				size_format( self::limits()['media_file_bytes'] )
			),
			array( 'status' => 400 )
		);
	}

	/**
	 * Malformed archive refusal retaining the ZIP transport compatibility code.
	 *
	 * @return WP_Error
	 */
	private static function zip_error(): WP_Error {
		return new WP_Error( 'pageferry_zip_open', __( 'PageFerry could not open the uploaded ZIP. It may be corrupt.', 'pageferry' ), array( 'status' => 400 ) );
	}

	/**
	 * Checked stream I/O refusal.
	 *
	 * @return WP_Error
	 */
	public static function io_error(): WP_Error {
		return new WP_Error( 'pageferry_workspace_write', __( 'PageFerry could not read or store the import files.', 'pageferry' ), array( 'status' => 500 ) );
	}

	/**
	 * Reads at most limit bytes, with one non-retained sentinel byte.
	 *
	 * @param resource $source Readable stream.
	 * @param int      $limit Byte ceiling.
	 * @return string|WP_Error
	 */
	public static function read( $source, int $limit ) {
		$result = '';
		while ( ! feof( $source ) ) {
			$chunk = fread( $source, min( 65536, $limit - strlen( $result ) + 1 ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- bounded private stream.
			if ( false === $chunk || ( '' === $chunk && ! feof( $source ) ) ) {
				return self::io_error();
			}
			if ( strlen( $chunk ) > $limit - strlen( $result ) ) {
				return self::exceeded();
			}
			$result .= $chunk;
		}
		return $result;
	}

	/**
	 * Copies with hard actual-byte ceilings; excess bytes are never written.
	 *
	 * @param resource $source Readable stream.
	 * @param resource $destination Writable stream.
	 * @param int      $file_limit Per-file remaining budget.
	 * @param int      $aggregate_limit Remaining aggregate budget.
	 * @return int|WP_Error Actual copied bytes.
	 */
	public static function copy( $source, $destination, int $file_limit, int $aggregate_limit ) {
		$written = 0;
		$limit   = min( $file_limit, $aggregate_limit );
		while ( ! feof( $source ) ) {
			$chunk = fread( $source, min( 65536, $limit - $written + 1 ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- bounded private stream.
			if ( false === $chunk || ( '' === $chunk && ! feof( $source ) ) ) {
				return self::io_error();
			}
			$length = strlen( $chunk );
			if ( $length > $limit - $written ) {
				return $file_limit <= $aggregate_limit ? self::file_exceeded() : self::exceeded();
			}
			$offset = 0;
			while ( $offset < $length ) {
				$count = fwrite( $destination, substr( $chunk, $offset ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- checked private stream write.
				if ( false === $count || 0 === $count ) {
					return self::io_error();
				}
				$offset += $count;
			}
			$written += $length;
		}
		return fflush( $destination ) ? $written : self::io_error();
	}

	/**
	 * Reads an actual regular file size without following links.
	 *
	 * @param string $path Owned or upload-temp file.
	 * @return int|WP_Error
	 */
	public static function file_size( string $path ) {
		clearstatcache( true, $path );
		if ( is_link( $path ) || ! is_file( $path ) || ! is_readable( $path ) ) {
			return self::io_error();
		}
		$size = @filesize( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- disappearance races are reported as I/O errors.
		return false === $size ? self::io_error() : $size;
	}

	/**
	 * Bounded source-to-candidate copy with checked closure and actual size.
	 *
	 * @param string $source Source file.
	 * @param string $destination Unique, nonexistent candidate.
	 * @param int    $aggregate_limit Remaining aggregate budget.
	 * @return int|WP_Error
	 */
	public static function copy_file( string $source, string $destination, int $aggregate_limit ) {
		$input  = fopen( $source, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- private upload source.
		$output = fopen( $destination, 'xb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- unique private candidate, never overwrite.
		if ( ! is_resource( $input ) || ! is_resource( $output ) ) {
			if ( is_resource( $input ) ) {
				fclose( $input ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- owned stream.
			}
			if ( is_resource( $output ) ) {
				fclose( $output ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- owned stream.
			}
			return self::io_error();
		}
		$result        = self::copy( $input, $output, self::limits()['media_file_bytes'], $aggregate_limit );
		$closed_input  = fclose( $input ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- owned stream.
		$closed_output = fclose( $output ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- owned stream.
		clearstatcache( true, $destination );
		if ( ! $closed_input || ! $closed_output || ( is_int( $result ) && filesize( $destination ) !== $result ) ) {
			return self::io_error();
		}
		return $result;
	}

	/**
	 * Bounds central metadata before ZipArchive allocates; the library validates ZIP structure.
	 *
	 * @param string $path ZIP path.
	 * @return WP_Error|null
	 */
	public static function check_zip_metadata( string $path ): ?WP_Error {
		$limits = self::limits();
		clearstatcache( true, $path );
		if ( ! is_file( $path ) || ! is_readable( $path ) ) {
			return self::zip_error();
		}
		$size = @filesize( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- readable source can disappear; report archive error.
		if ( false === $size ) {
			return self::zip_error();
		}
		if ( 22 > $size ) {
			return self::zip_error();
		}
		if ( $size > $limits['zip_bytes'] ) {
			return self::exceeded();
		}
		$stream = fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- bounded ZIP metadata source.
		if ( false === $stream ) {
			return self::io_error();
		}
		$error = null;
		try {
			$tail_size = min( $size, 65557 );
			if ( 0 !== fseek( $stream, $size - $tail_size ) ) {
				return self::io_error();
			}
			$tail = self::read( $stream, $tail_size );
			if ( ! is_string( $tail ) ) {
				return $tail;
			}
			// ZIP comments can contain EOCD signatures; only the archive-ending candidate is valid.
			$position = strlen( $tail ) - 22;
			while ( 0 <= $position ) {
				if ( "PK\x05\x06" === substr( $tail, $position, 4 ) ) {
					$comment = unpack( 'vlength', substr( $tail, $position + 20, 2 ) );
					if ( is_array( $comment ) && strlen( $tail ) === $position + 22 + $comment['length'] ) {
						break;
					}
				}
				--$position;
			}
			if ( 0 > $position ) {
				return self::zip_error();
			}
			$end = unpack( 'vdisk/vcentral_disk/ventries_disk/ventries/Vbytes/Voffset', substr( $tail, $position + 4, 16 ) );
			if ( ! is_array( $end ) || 0 !== $end['disk'] || 0 !== $end['central_disk'] || $end['entries_disk'] !== $end['entries'] ) {
				return self::zip_error();
			}
			if ( 65535 === $end['entries'] || 4294967295 === $end['bytes'] || 4294967295 === $end['offset'] ) {
				$absolute_end = $size - $tail_size + $position;
				if ( 20 > $absolute_end || 0 !== fseek( $stream, $absolute_end - 20 ) ) {
					return self::io_error();
				}
				$locator = fread( $stream, 20 ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- fixed metadata.
				if ( ! is_string( $locator ) || 20 !== strlen( $locator ) || "PK\x06\x07" !== substr( $locator, 0, 4 ) ) {
					return self::zip_error();
				}
				$located = unpack( 'Vdisk/Poffset/Vdisks', substr( $locator, 4 ) );
				if ( ! is_array( $located ) || 0 !== $located['disk'] || 1 !== $located['disks'] || ! is_int( $located['offset'] ) || 0 > $located['offset'] || $located['offset'] > $absolute_end - 76 || 0 !== fseek( $stream, $located['offset'] ) ) {
					return self::zip_error();
				}
				$record = fread( $stream, 56 ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- fixed ZIP64 header.
				if ( ! is_string( $record ) || 56 !== strlen( $record ) || "PK\x06\x06" !== substr( $record, 0, 4 ) ) {
					return self::zip_error();
				}
				$extended = unpack( 'Plength/vmade/vneeded/Vdisk/Vcentral_disk/Pentries_disk/Pentries/Pbytes/Poffset', substr( $record, 4 ) );
				if ( ! is_array( $extended ) || 0 !== $extended['disk'] || 0 !== $extended['central_disk'] || $extended['entries_disk'] !== $extended['entries'] || ! is_int( $extended['length'] ) || 44 > $extended['length'] || $extended['length'] > $limits['zip_metadata_bytes'] ) {
					return self::exceeded();
				}
				$end = $extended;
			}
			foreach ( array( 'entries', 'bytes', 'offset' ) as $key ) {
				if ( ! is_int( $end[ $key ] ) || 0 > $end[ $key ] ) {
					return self::exceeded();
				}
			}
			if ( $end['entries'] > $limits['zip_entries'] || $end['bytes'] > $limits['zip_metadata_bytes'] || $end['offset'] > $size || $end['bytes'] > $size - $end['offset'] ) {
				return self::exceeded();
			}
		} finally {
			if ( ! fclose( $stream ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions -- owned ZIP stream.
				$error = self::io_error();
			}
		}
		return $error;
	}

	/**
	 * Recounts all physical canonical files; only exact known sidecars skip.
	 *
	 * @param string $workspace Owned workspace.
	 * @param array  $media_index Validated media states.
	 * @param int    $budget Actual aggregate ceiling.
	 * @param bool   $reclaim_candidates Reclaim exact orphan candidates under lease.
	 * @return array|WP_Error Actual bytes, per-basename sizes and declared basenames.
	 */
	public static function usage( string $workspace, array $media_index, int $budget, bool $reclaim_candidates = false ) {
		$limits   = self::limits();
		$declared = array();
		foreach ( $media_index as $state ) {
			if ( ! $state['missing'] ) {
				$declared[ basename( (string) $state['entry']['file'] ) ] = true;
			}
		}
		$directory = opendir( $workspace );
		if ( false === $directory ) {
			return self::io_error();
		}
		$bytes = 0;
		$files = array();
		$error = null;
		while ( false !== ( $name = readdir( $directory ) ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition -- directory traversal idiom.
			if ( in_array( $name, array( '.', '..' ), true ) ) {
				continue;
			}
			$path = $workspace . '/' . $name;
			if ( $reclaim_candidates && 1 === preg_match( '/\A\.pageferry-receipt-[a-f0-9]{32}\z/', $name ) ) {
				if ( ! unlink( $path ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions -- exact owned orphan under the lease.
					$error = self::io_error();
					break;
				}
				continue;
			}
			clearstatcache( true, $path );
			if ( is_link( $path ) ) {
				$error = self::io_error();
				break;
			}
			if ( in_array( $name, array( 'index.php', '.htaccess', PageFerry_Workspace::ACTIVITY_FILE, PageFerry_Workspace::LOCK_FILE ), true ) && is_file( $path ) ) {
				continue;
			}
			if ( ( ! isset( $declared[ $name ] ) && ! PageFerry_Importer::media_basename_allowed( $name ) ) || ! is_file( $path ) || ! is_readable( $path ) ) {
				$error = self::io_error();
				break;
			}
			$size = filesize( $path );
			if ( false === $size ) {
				$error = self::io_error();
				break;
			}
			if ( $size > $limits['media_file_bytes'] ) {
				$error = self::file_exceeded( $name );
				break;
			}
			if ( count( $files ) >= $limits['required_files'] || $size > $budget - $bytes ) {
				$error = self::exceeded();
				break;
			}
			$files[ $name ] = $size;
			$bytes         += $size;
		}
		closedir( $directory );
		return $error instanceof WP_Error ? $error : array(
			'bytes'    => $bytes,
			'files'    => $files,
			'declared' => $declared,
		);
	}
}
