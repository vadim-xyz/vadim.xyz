<?php
/**
 * Core loader for PageFerry.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/**
 * Owns hook wiring and canonical storage names.
 */
class PageFerry {

	/**
	 * Option holding the sha256 → attachment ID reuse index.
	 *
	 * @var string
	 */
	const OPTION_HASH_INDEX = 'pageferry_hash_index';

	/**
	 * Option holding plain-language import log rows.
	 *
	 * @var string
	 */
	const OPTION_LOGS = 'pageferry_logs';

	/**
	 * Option holding pre-overwrite snapshots, keyed by import ID.
	 *
	 * @var string
	 */
	const OPTION_BACKUPS = 'pageferry_backups';

	/**
	 * Transient prefix for Path B import sessions (validate→file→commit).
	 *
	 * @var string
	 */
	const TRANSIENT_SESSION_PREFIX = 'pageferry_session_';

	/**
	 * Transient prefix for the Path A two-step form stash.
	 *
	 * @var string
	 */
	const TRANSIENT_IMPORT_PREFIX = 'pageferry_import_';

	/**
	 * Transient prefix for the post-import success notice.
	 *
	 * @var string
	 */
	const TRANSIENT_RESULT_PREFIX = 'pageferry_import_result_';

	/**
	 * Option holding the last workspace GC run timestamp.
	 *
	 * @var string
	 */
	const OPTION_LAST_GC = 'pageferry_last_gc';

	/**
	 * Transient prefix for the per-user Path B session-creation quota.
	 *
	 * @var string
	 */
	const TRANSIENT_QUOTA_PREFIX = 'pageferry_quota_';

	/**
	 * Registers hooks without performing import or export work.
	 *
	 * @return void
	 */
	public static function init() {
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-media-collector.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-builder-guard.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-exporter.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-filesystem.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-workspace.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-import-resources.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-import-selection.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-review-model.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-backups.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-importer.php';
		add_filter( 'pre_option_pageferry_backups', array( 'PageFerry_Backups', 'legacy_option' ) );
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-import-review.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-import-admin.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-rest-import.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-admin.php';

		add_action( 'add_meta_boxes', array( 'PageFerry_Admin', 'register_export_metabox' ), 10, 2 );
		add_action( 'admin_post_pageferry_preview_media', array( 'PageFerry_Import_Review', 'serve_media' ) );
		add_action( 'admin_post_pageferry_export', array( 'PageFerry_Exporter', 'handle_export_request' ) );
		add_action( 'admin_menu', array( 'PageFerry_Admin', 'register_menu' ) );
		add_action( 'wp_ajax_pageferry_admin_view', array( 'PageFerry_Admin', 'serve_view' ) );
		add_action( 'rest_api_init', array( 'PageFerry_Rest_Import', 'register_routes' ) );
		add_action( 'rest_api_init', array( 'PageFerry_Import_Review', 'register_routes' ) );
		add_filter( 'rest_pre_dispatch', array( 'PageFerry_Rest_Import', 'guard_validate_body' ), 10, 3 );
		foreach ( array( 'add_attachment', 'edit_attachment', 'delete_attachment', 'created_term', 'edited_term', 'delete_term' ) as $hook ) {
			add_action( $hook, array( 'PageFerry_Review_Model', 'invalidate' ) );
		}
		add_action( 'save_post', array( 'PageFerry_Review_Model', 'saved_provider' ), 10, 2 );
		add_action( 'before_delete_post', array( 'PageFerry_Review_Model', 'saved_provider' ), 10, 2 );
		foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $hook ) {
			add_action( $hook, array( 'PageFerry_Review_Model', 'changed_media_meta' ), 10, 3 );
		}
		add_action( 'admin_init', array( 'PageFerry_Importer', 'maybe_gc_workspaces' ) );
	}

	/**
	 * Requires PHP 8.1; options survive deactivation for reactivation.
	 *
	 * @return void
	 */
	public static function activate() {
		if ( version_compare( PHP_VERSION, '8.1', '<' ) ) {
			deactivate_plugins( plugin_basename( PAGEFERRY_FILE ) );
			wp_die( esc_html__( 'PageFerry requires PHP 8.1 or higher.', 'pageferry' ) );
		}
		flush_rewrite_rules();
	}
}
