<?php
/**
 * Filesystem cleanup shared by import workspaces and uninstall.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/** Removes a selected tree without following links or crossing its boundary. */
class PageFerry_Filesystem {

	/**
	 * Removes only the allowed subtree without following links; callers own leases and concurrency.
	 *
	 * @param string $path Absolute directory or leaf-link path.
	 * @param string $allowed_base Absolute allowed base, which is never removed.
	 * @return bool True when absent/removed; false for refusal or incomplete cleanup.
	 */
	public static function remove_directory( string $path, string $allowed_base ): bool {
		$path      = self::normalize_path( $path );
		$base_path = self::normalize_path( $allowed_base );
		if ( null === $path || null === $base_path ) {
			return false;
		}

		$real_base = realpath( $base_path );
		$real_base = is_string( $real_base ) ? self::normalize_path( $real_base ) : null;
		if ( null === $real_base || '/' === $real_base || 1 === preg_match( '/^[A-Za-z]:$/', $real_base ) || ! is_dir( $real_base ) ) {
			return false;
		}

		$relative = null;
		foreach ( array( $base_path, $real_base ) as $base ) {
			if ( str_starts_with( $path, $base . '/' ) ) {
				$relative = substr( $path, strlen( $base ) + 1 );
				break;
			}
		}
		if ( null === $relative ) {
			return false;
		}

		// realpath() alone would hide intermediate links inside the allowed base.
		$parts   = explode( '/', $relative );
		$current = $real_base;
		foreach ( $parts as $index => $part ) {
			$current .= '/' . $part;
			clearstatcache( true, $current );
			$stat = @lstat( $current ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- missing paths are checked against their parent below.
			if ( ! is_array( $stat ) ) {
				return self::is_missing( $current );
			}
			if ( count( $parts ) - 1 !== $index && ( is_link( $current ) || ! is_dir( $current ) || self::normalize_path( (string) realpath( $current ) ) !== $current ) ) {
				return false;
			}
		}

		if ( is_link( $current ) ) {
			return self::remove_file( $current );
		}
		if ( ! is_dir( $current ) || self::normalize_path( (string) realpath( $current ) ) !== $current ) {
			return false;
		}

		return self::remove_tree( $current, $current );
	}

	/**
	 * Accepts local absolute paths without traversal components.
	 *
	 * @param string $path Supplied path.
	 * @return string|null Normalized local path or null.
	 */
	private static function normalize_path( string $path ): ?string {
		if ( '\\' === DIRECTORY_SEPARATOR ) {
			$path = str_replace( '\\', '/', $path );
		}
		if ( '' === $path || str_contains( $path, "\0" ) || str_contains( $path, '://' ) || ( '/' !== $path[0] && 1 !== preg_match( '#^[A-Za-z]:/#', $path ) ) ) {
			return null;
		}
		foreach ( explode( '/', $path ) as $part ) {
			if ( '.' === $part || '..' === $part ) {
				return null;
			}
		}
		$path = preg_replace( '#/+#', '/', $path );
		return is_string( $path ) ? ( '/' === $path ? '/' : rtrim( $path, '/' ) ) : null;
	}

	/**
	 * Distinguishes an absent entry from an unreadable or unstatable entry.
	 *
	 * @param string $path Entry beneath an already validated parent.
	 * @return bool Whether its parent confirms absence.
	 */
	private static function is_missing( string $path ): bool {
		$entries = @scandir( dirname( $path ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- a failed parent read is an incomplete cleanup, not absence.
		return is_array( $entries ) && ! in_array( basename( $path ), $entries, true );
	}

	/**
	 * Deletes children first, anchored to the original selected tree.
	 *
	 * @param string $path Current entry.
	 * @param string $scope Original canonical directory.
	 * @return bool Whether this entry is completely removed.
	 */
	private static function remove_tree( string $path, string $scope ): bool {
		if ( $path !== $scope && ! str_starts_with( $path, $scope . '/' ) ) {
			return false;
		}
		clearstatcache( true, $path );
		$stat = @lstat( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- disappearance/failure is checked explicitly.
		if ( ! is_array( $stat ) ) {
			return self::is_missing( $path );
		}
		if ( is_link( $path ) || ! is_dir( $path ) ) {
			return self::remove_file( $path );
		}
		if ( self::normalize_path( (string) realpath( $path ) ) !== $path ) {
			return false;
		}

		$entries = @scandir( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- unreadable directories remain retryable.
		if ( ! is_array( $entries ) ) {
			return false;
		}
		$complete = true;
		foreach ( $entries as $entry ) {
			if ( '.' !== $entry && '..' !== $entry && ! self::remove_tree( $path . '/' . $entry, $scope ) ) {
				$complete = false;
			}
		}
		if ( ! $complete ) {
			return false;
		}
		$removed = @rmdir( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors.Discouraged -- checked child-first removal of the validated directory.
		clearstatcache( true, $path );
		return $removed && ! file_exists( $path ) && ! is_link( $path );
	}

	/**
	 * Honors WordPress deletion vetoes without allowing path redirection.
	 *
	 * @param string $path Validated ordinary file or link itself.
	 * @return bool Whether unlink completed.
	 */
	private static function remove_file( string $path ): bool {
		// wp_delete_file() can redirect paths; checked unlink keeps deletion inside the scope.
		if ( apply_filters( 'wp_delete_file', $path ) !== $path ) { // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- honoring the existing WordPress deletion-veto hook.
			return false;
		}
		$removed = @unlink( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors.Discouraged -- checked unlink must remove the link itself, never follow its target.
		clearstatcache( true, $path );
		$remaining = @lstat( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- absence is expected after a successful unlink.
		return $removed && false === $remaining && ! is_link( $path );
	}
}
