<?php
/**
 * Indexed, verified recovery snapshots with legacy read compatibility.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/** Stores full snapshots separately from their lightweight history. */
class PageFerry_Backups {

	/** Versioned nonautoloaded history option. */
	public const INDEX_OPTION = 'pageferry_backup_index';

	/** Owned payload option prefix; suffixes are SHA-256 snapshot-key hashes. */
	public const PAYLOAD_PREFIX = 'pageferry_backup_';

	/**
	 * Reads bounded summaries; unknown index versions fail closed.
	 *
	 * @return array|null Keyed summaries, or null on read/schema failure.
	 */
	public static function history(): ?array {
		$index  = self::read_index();
		$legacy = self::read_option( PageFerry::OPTION_BACKUPS );
		if ( null === $index || null === $legacy || ! is_array( $legacy ) ) {
			return null;
		}
		$rows = array();
		foreach ( $legacy as $key => $snapshot ) {
			if ( is_array( $snapshot ) ) {
				$rows[ $key ] = self::summary( $snapshot );
			}
		}
		return array_replace( $rows, $index );
	}

	/**
	 * Reads one exact snapshot; callers must enforce object/meta authority.
	 *
	 * @param string $key Snapshot key.
	 * @return array|null Full snapshot, or null if absent/unverifiable.
	 */
	public static function find( string $key ): ?array {
		$index = self::read_index();
		if ( null === $index ) {
			return null;
		}
		if ( isset( $index[ $key ] ) ) {
			$snapshot = self::read_payload( $key, $index[ $key ] );
			if ( is_array( $snapshot ) ) {
				return $snapshot;
			}
		}
		$legacy = self::read_option( PageFerry::OPTION_BACKUPS );
		return is_array( $legacy ) && is_array( $legacy[ $key ] ?? null ) ? $legacy[ $key ] : null;
	}

	/**
	 * Resolves complete history for recovery integrations and diagnostics.
	 *
	 * @return array Keyed full snapshots; display callers should use history/find.
	 */
	public static function all(): array {
		$legacy = self::read_option( PageFerry::OPTION_BACKUPS );
		$rows   = is_array( $legacy ) ? $legacy : array();
		foreach ( self::read_index() ?? array() as $key => $summary ) {
			$snapshot = self::read_payload( (string) $key, $summary );
			if ( is_array( $snapshot ) ) {
				$rows[ $key ] = $snapshot;
			}
		}
		return $rows;
	}

	/**
	 * Keeps legacy get_option() integrations working; explicit reads load all snapshots.
	 *
	 * @param mixed $pre Earlier pre-option filter result.
	 * @return mixed Earlier substitution, complete recovery data, or false.
	 */
	public static function legacy_option( $pre ) {
		if ( false !== $pre ) {
			return $pre;
		}
		$rows = self::all();
		return array() !== $rows ? $rows : false;
	}

	/**
	 * Persists a full snapshot before publishing its index reference.
	 *
	 * @param string $key New snapshot key.
	 * @param array  $snapshot Exact pre-overwrite state.
	 * @return bool Whether both payload and reference are stored and verified.
	 */
	public static function save( string $key, array $snapshot ): bool {
		return self::mutate(
			static function ( array $index ) use ( $key, $snapshot ): ?array {
				if ( isset( $index[ $key ] ) || ! self::write_payload( $key, $snapshot ) ) {
					return null;
				}
				$index[ $key ] = self::summary( $snapshot );
				return $index;
			},
			static fn() => self::read_payload( $key, self::summary( $snapshot ) ) === $snapshot,
			$key
		);
	}

	/**
	 * Removes references first; failed payload deletion only leaves owned orphans.
	 *
	 * @param string|null $key Snapshot to forget, or null to success-prune history.
	 * @return bool Whether the new history is verified.
	 */
	public static function remove( ?string $key = null ): bool {
		return self::mutate(
			static function ( array $index ) use ( $key ): array {
				if ( null !== $key ) {
					unset( $index[ $key ] );
					return $index;
				}
				return array_slice( $index, -PageFerry_Importer::MAX_BACKUPS, null, true );
			}
		);
	}

	/**
	 * Migrates under the per-site lock; legacy data survives until every new payload is verified.
	 *
	 * @param callable      $operation Index transformation, or null on failure.
	 * @param callable|null $verify Final payload verification under the lock.
	 * @param string|null   $new_key New payload to reclaim if never referenced.
	 * @return bool Whether the requested mutation is verified.
	 */
	private static function mutate( callable $operation, ?callable $verify = null, ?string $new_key = null ): bool {
		global $wpdb;
		static $held = array();
		$name        = substr( 'pageferry-backups-' . hash( 'sha256', (string) constant( 'DB_NAME' ) . ':' . $wpdb->options ), 0, 64 );
		if ( isset( $held[ $name ] ) || '1' !== (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $name ) ) ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- connection-owned backup synchronization.
			return false;
		}
		$held[ $name ] = true;
		try {
			$index  = self::read_index();
			$legacy = self::read_option( PageFerry::OPTION_BACKUPS );
			if ( null === $index || null === $legacy || ! is_array( $legacy ) ) {
				return false;
			}
			if ( array() !== $legacy ) {
				$migrated = array();
				foreach ( $legacy as $key => $snapshot ) {
					if ( ! is_array( $snapshot ) || ( isset( $index[ $key ] ) && self::summary( $snapshot ) !== $index[ $key ] ) || ! self::write_payload( (string) $key, $snapshot ) ) {
						return false;
					}
					$migrated[ $key ] = self::summary( $snapshot );
				}
				// Insertion order must survive interrupted migration for retention.
				$index = array_replace( $migrated, $index );
				if ( ! self::write_index( $index ) ) {
					return false;
				}
				foreach ( $legacy as $key => $snapshot ) {
					if ( self::read_payload( (string) $key, $index[ $key ] ) !== $snapshot ) {
						return false;
					}
				}
				if ( ! self::write_option( PageFerry::OPTION_BACKUPS, array() ) ) {
					return false;
				}
			}
			$updated = $operation( $index );
			if ( ! is_array( $updated ) || ! self::write_index( $updated ) ) {
				return false;
			}
			if ( null !== $verify && ! $verify() ) {
				return false;
			}
			foreach ( array_diff_key( $index, $updated ) as $key => $summary ) {
				$option = self::payload_option( (string) $key );
				delete_option( $option );
				self::clear_cache( $option );
			}
			return true;
		} finally {
			try {
				if ( null !== $new_key ) {
					$stored = self::read_index();
					if ( null !== $stored && ! isset( $stored[ $new_key ] ) ) {
						delete_option( self::payload_option( $new_key ) );
						self::clear_cache( self::payload_option( $new_key ) );
					}
				}
			} finally {
				unset( $held[ $name ] );
				$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $name ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- release only this connection's backup lock.
			}
		}
	}

	/**
	 * Checks one persisted envelope against its indexed identity and full hash.
	 *
	 * @param string $key Snapshot key.
	 * @param array  $summary Expected index facts.
	 * @return array|null Verified snapshot, or null on mismatch/read failure.
	 */
	private static function read_payload( string $key, array $summary ): ?array {
		$value = self::read_option( self::payload_option( $key ) );
		if ( ! is_array( $value ) || 1 !== ( $value['version'] ?? null ) || ( $value['key'] ?? null ) !== $key || ! is_array( $value['snapshot'] ?? null ) ) {
			return null;
		}
		return self::summary( $value['snapshot'] ) === $summary ? $value['snapshot'] : null;
	}

	/**
	 * Produces small display facts without changing full recovery data.
	 *
	 * @param array $snapshot Exact snapshot.
	 * @return array Summary and integrity binding.
	 */
	private static function summary( array $snapshot ): array {
		$serialized = maybe_serialize( $snapshot );
		return array(
			'post_id'    => (int) ( $snapshot['post_id'] ?? 0 ),
			'post_title' => wp_html_excerpt( is_string( $snapshot['post_title'] ?? null ) ? $snapshot['post_title'] : '', 200, '…' ),
			'time'       => is_string( $snapshot['time'] ?? null ) ? substr( $snapshot['time'], 0, 40 ) : '',
			'bytes'      => strlen( $serialized ),
			'sha256'     => hash( 'sha256', $serialized ),
		);
	}

	/**
	 * Reads the versioned index, refusing malformed or unknown schema versions.
	 *
	 * @return array|null Keyed summaries, or null on schema/read failure.
	 */
	private static function read_index(): ?array {
		$value = self::read_option( self::INDEX_OPTION );
		if ( array() === $value ) {
			return array();
		}
		if ( ! is_array( $value ) || 1 !== ( $value['version'] ?? null ) || ! is_array( $value['items'] ?? null ) ) {
			return null;
		}
		foreach ( $value['items'] as $summary ) {
			if ( ! is_array( $summary ) || ! is_int( $summary['post_id'] ?? null ) || ! is_string( $summary['post_title'] ?? null ) || ! is_string( $summary['time'] ?? null ) || ! is_int( $summary['bytes'] ?? null ) || ! is_string( $summary['sha256'] ?? null ) ) {
				return null;
			}
		}
		return $value['items'];
	}

	/**
	 * Writes one exact snapshot envelope.
	 *
	 * @param string $key Snapshot key.
	 * @param array  $snapshot Snapshot data.
	 * @return bool Whether the envelope is verified in storage.
	 */
	private static function write_payload( string $key, array $snapshot ): bool {
		return self::write_option(
			self::payload_option( $key ),
			array(
				'version'  => 1,
				'key'      => $key,
				'snapshot' => $snapshot,
			)
		);
	}

	/**
	 * Publishes a versioned index.
	 *
	 * @param array $index Keyed summaries.
	 * @return bool Whether the index is verified in storage.
	 */
	private static function write_index( array $index ): bool {
		return self::write_option(
			self::INDEX_OPTION,
			array(
				'version' => 1,
				'items'   => $index,
			)
		);
	}

	/**
	 * Derives a bounded option name without trusting a request-supplied key.
	 *
	 * @param string $key Snapshot key.
	 * @return string Owned option name.
	 */
	public static function payload_option( string $key ): string {
		return self::PAYLOAD_PREFIX . hash( 'sha256', $key );
	}

	/**
	 * Reads authoritative persisted options without cache/filter substitution.
	 *
	 * @param string $option Option name.
	 * @return mixed Stored value, empty array when absent, null on DB failure.
	 */
	private static function read_option( string $option ) {
		global $wpdb;
		$value = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $option ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- authoritative recovery read and write verification.
		return '' !== $wpdb->last_error ? null : ( null === $value ? array() : maybe_unserialize( $value ) );
	}

	/**
	 * Preserves WordPress option hooks while verifying meaningful persistence.
	 *
	 * @param string $option Option name.
	 * @param array  $value Required persisted value.
	 * @return bool Whether the exact value is persisted.
	 */
	private static function write_option( string $option, array $value ): bool {
		self::clear_cache( $option );
		try {
			update_option( $option, $value, false );
			return self::read_option( $option ) === $value;
		} finally {
			self::clear_cache( $option );
		}
	}

	/**
	 * Invalidates individual, autoloaded and negative option cache forms.
	 *
	 * @param string $option Option name.
	 */
	private static function clear_cache( string $option ): void {
		wp_cache_delete( $option, 'options' );
		wp_cache_delete( 'alloptions', 'options' );
		wp_cache_delete( 'notoptions', 'options' );
	}
}
