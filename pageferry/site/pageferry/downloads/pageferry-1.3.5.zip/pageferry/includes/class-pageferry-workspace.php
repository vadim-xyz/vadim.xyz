<?php
/**
 * Workspace activity and request leases shared by both import transports.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/** Keeps GC independent of directory mtime and transient storage internals. */
class PageFerry_Workspace {

	/**
	 * Private activity record (never a manifest entry).
	 *
	 * @var string
	 */
	const ACTIVITY_FILE = '.pageferry-activity.json';

	/**
	 * Stable inode shared by request leases and GC.
	 *
	 * @var string
	 */
	const LOCK_FILE = '.pageferry-lock';

	/**
	 * Leases held by this request, allowing shared-core calls to nest.
	 *
	 * @var array<string, resource>
	 */
	private static $leases = array();

	/**
	 * Requires site-scoped private storage; unavailable storage never falls back to uploads.
	 *
	 * @param bool $create Whether to create the site directory.
	 * @return string|WP_Error Canonical site directory or refusal.
	 */
	public static function private_root( bool $create = false ) {
		$parent = defined( 'PAGEFERRY_PRIVATE_DIR' ) ? constant( 'PAGEFERRY_PRIVATE_DIR' ) : sys_get_temp_dir();
		$parent = apply_filters( 'pageferry_private_directory', $parent );
		if ( ! is_string( $parent ) || '' === $parent || ( '/' !== $parent[0] && 1 !== preg_match( '#^[A-Za-z]:[\\\\/]#', $parent ) ) || str_contains( $parent, "\0" ) || str_contains( $parent, '://' ) ) {
			return self::private_error();
		}
		$parent = realpath( $parent );
		if ( ! is_string( $parent ) || ! is_dir( $parent ) ) {
			return self::private_error();
		}
		$uploads = wp_get_upload_dir()['basedir'];
		$scope   = ABSPATH . ':' . ( defined( 'DB_NAME' ) ? constant( 'DB_NAME' ) : '' ) . ':' . $uploads;
		$root    = rtrim( $parent, '/\\' ) . '/pageferry-private-' . hash( 'sha256', $scope );
		$public  = array( ABSPATH, $uploads );
		if ( defined( 'WP_CONTENT_DIR' ) ) {
			$public[] = constant( 'WP_CONTENT_DIR' );
		}
		if ( isset( $_SERVER['DOCUMENT_ROOT'] ) && is_string( $_SERVER['DOCUMENT_ROOT'] ) && '' !== $_SERVER['DOCUMENT_ROOT'] ) {
			$public[] = $_SERVER['DOCUMENT_ROOT']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- refusal-only server configuration; preserve the filesystem path without request-input transformations.
		}
		foreach ( $public as $directory ) {
			if ( ! is_string( $directory ) || '' === $directory ) {
				continue;
			}
			foreach ( array( $directory, realpath( $directory ) ) as $boundary ) {
				if ( is_string( $boundary ) ) {
					$boundary = rtrim( str_replace( '\\', '/', $boundary ), '/' );
					$path     = str_replace( '\\', '/', $root );
					if ( $path === $boundary || str_starts_with( $path, $boundary . '/' ) ) {
						return self::private_error();
					}
				}
			}
		}
		if ( is_link( $root ) ) {
			return self::private_error();
		}
		if ( $create && ! is_dir( $root ) && ! @mkdir( $root, 0700 ) && ! is_dir( $root ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors.Discouraged -- private mode at creation; concurrent creators are checked below.
			return self::private_error();
		}
		clearstatcache( true, $root );
		if ( file_exists( $root ) && ( ! is_dir( $root ) || is_link( $root ) || false === fileperms( $root ) || 0 !== ( fileperms( $root ) & 0077 ) || ! is_readable( $root ) || ! wp_is_writable( $root ) || ( function_exists( 'posix_geteuid' ) && fileowner( $root ) !== posix_geteuid() ) ) ) {
			return self::private_error();
		}
		return $root;
	}

	/**
	 * Reports unavailable private staging before accepting persistent bytes.
	 *
	 * @return WP_Error
	 */
	private static function private_error(): WP_Error {
		return new WP_Error( 'pageferry_private_directory', __( 'PageFerry needs a writable private temporary directory outside WordPress and uploads. Ask your host to configure PAGEFERRY_PRIVATE_DIR with private permissions, then prepare the ZIP again.', 'pageferry' ), array( 'status' => 500 ) );
	}

	/**
	 * Uses an OS-owned lease so a live request can outlast its transient, including on fatal exit.
	 *
	 * @param string   $workspace Workspace directory.
	 * @param callable $operation Work to execute while GC is excluded.
	 * @param int      $wait_ms Optional acquisition wait, capped at one second.
	 * @return mixed|WP_Error Operation result, or a lease/activity error.
	 */
	public static function with_lease( string $workspace, callable $operation, int $wait_ms = 0 ) {
		$real_workspace = realpath( $workspace );
		if ( ! is_string( $real_workspace ) ) {
			return self::activity_error();
		}
		if ( isset( self::$leases[ $real_workspace ] ) ) {
			return $operation();
		}

		// Retry only lease acquisition; replaying the operation could duplicate writes.
		$retries = (int) ceil( min( 1000, max( 0, $wait_ms ) ) / 50 );
		do {
			$lease = self::acquire( $workspace );
			if ( ! is_wp_error( $lease ) || 'pageferry_workspace_busy' !== $lease->get_error_code() || $retries-- <= 0 ) {
				break;
			}
			usleep( 50000 );
		} while ( true );
		if ( is_wp_error( $lease ) ) {
			return $lease;
		}

		self::$leases[ $real_workspace ] = $lease;
		try {
			if ( ! self::heartbeat( $workspace ) ) {
				return self::activity_error();
			}
			return $operation();
		} finally {
			// Terminal cleanup may detach the directory while its lease is still held.
			if ( is_dir( $workspace ) ) {
				self::heartbeat( $workspace );
			}
			unset( self::$leases[ $real_workspace ] );
			self::release( $lease );
		}
	}

	/**
	 * Associates activity with the exact, case-sensitive session transient key.
	 *
	 * @param string $workspace Workspace directory.
	 * @param string $transient_key Path A stash or Path B session key.
	 * @return bool|WP_Error True or error (caller must not offer an untracked session).
	 */
	public static function bind_session( string $workspace, string $transient_key ) {
		return self::with_lease(
			$workspace,
			static function () use ( $workspace, $transient_key ) {
				return self::heartbeat( $workspace, $transient_key ) ? true : self::activity_error();
			}
		);
	}

	/**
	 * Acquires without waiting; inode checks reject locks unlinked by GC.
	 *
	 * @param string $workspace Workspace directory.
	 * @param bool   $allow_legacy Whether cleanup may lease old uploads workspaces.
	 * @return resource|WP_Error Locked handle or error.
	 */
	public static function acquire( string $workspace, bool $allow_legacy = false ) {
		$base      = self::private_root();
		$real_base = is_string( $base ) ? realpath( $base ) : false;
		$real_dir  = realpath( $workspace );
		$lock_path = $workspace . '/' . self::LOCK_FILE;
		$is_owned  = is_string( $real_base ) && is_string( $real_dir ) && dirname( $real_dir ) === $real_base;
		if ( ! $is_owned && $allow_legacy ) {
			$legacy   = realpath( wp_get_upload_dir()['basedir'] );
			$activity = self::read_activity( $workspace );
			$is_owned = is_string( $legacy ) && is_string( $real_dir ) && dirname( $real_dir ) === $legacy && ( str_starts_with( basename( $real_dir ), 'pageferry-import-' ) || str_starts_with( basename( $real_dir ), 'pageferry-session-' ) ) && isset( $activity['heartbeat'] ) && is_int( $activity['heartbeat'] ) && is_file( $lock_path ) && self::has_legacy_guards( $workspace );
		}
		if ( ! $is_owned || ! is_dir( $workspace ) || is_link( $workspace ) || is_link( $lock_path ) ) {
			return self::activity_error();
		}

		$lease = @fopen( $lock_path, 'c' ); // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors.Discouraged -- lease inode in our workspace; races/failures are reported below.
		if ( false === $lease ) {
			return self::activity_error();
		}
		if ( isset( self::$leases[ $real_dir ] ) || ! flock( $lease, LOCK_EX | LOCK_NB ) ) {
			fclose( $lease ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- closing our lease handle.
			return new WP_Error(
				'pageferry_workspace_busy',
				__( 'PageFerry is already using this import workspace. Wait for that request to finish and try again.', 'pageferry' ),
				array( 'status' => 409 )
			);
		}

		clearstatcache( true, $lock_path );
		$handle_stat = fstat( $lease );
		$path_stat   = @stat( $lock_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- GC may have unlinked the inode before we acquired it.
		if ( ! is_array( $handle_stat ) || ! is_array( $path_stat ) || $handle_stat['ino'] !== $path_stat['ino'] || $handle_stat['dev'] !== $path_stat['dev'] ) {
			self::release( $lease );
			return self::activity_error();
		}
		return $lease;
	}

	/**
	 * Distinguishes created legacy workspaces from ordinary folders adopted by old GC.
	 *
	 * @param string $workspace Candidate under the legacy uploads boundary.
	 * @return bool Whether both original creation guards remain intact.
	 */
	private static function has_legacy_guards( string $workspace ): bool {
		$guards = array(
			'.htaccess' => "Require all denied\n",
			'index.php' => "<?php\n// Silence is golden.\n",
		);
		foreach ( $guards as $name => $expected ) {
			$path = $workspace . '/' . $name;
			if ( is_link( $path ) || ! is_file( $path ) || ! is_readable( $path ) || file_get_contents( $path, false, null, 0, 64 ) !== $expected ) { // phpcs:ignore WordPress.WP.AlternativeFunctions -- bounded comparison of the original workspace creation guards.
				return false;
			}
		}
		return true;
	}

	/**
	 * Releases a request/sweep lease.
	 *
	 * @param resource $lease Locked handle.
	 * @return void
	 */
	public static function release( $lease ): void {
		flock( $lease, LOCK_UN );
		fclose( $lease ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- closing our lease handle.
	}

	/**
	 * Detaches before deletion so competing requests cannot recreate the live lock inode.
	 *
	 * @param string $workspace Workspace directory (caller holds its lease).
	 * @return bool Whether all workspace files were removed.
	 */
	public static function retire( string $workspace ): bool {
		$retired = dirname( $workspace ) . '/pageferry-import-retired-' . wp_generate_password( 12, false );
		if ( ! @rename( $workspace, $retired ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors.Discouraged -- atomic same-filesystem detach under the workspace lease; failure leaves it for a later sweep.
			return false;
		}
		return PageFerry_Filesystem::remove_directory( $retired, dirname( $retired ) );
	}

	/**
	 * Allows one adoption grace period for legacy workspaces, including cache-only sessions.
	 *
	 * @param string $workspace Workspace directory (GC holds the lease).
	 * @param int    $max_age_seconds Idle age qualifying for deletion.
	 * @return bool Whether to remove the directory.
	 */
	public static function is_abandoned( string $workspace, int $max_age_seconds ): bool {
		$activity = self::read_activity( $workspace );
		if ( ! isset( $activity['heartbeat'] ) || ! is_int( $activity['heartbeat'] ) ) {
			self::heartbeat( $workspace, null, true );
			return false;
		}
		if ( isset( $activity['legacy_until'] ) && is_int( $activity['legacy_until'] ) && time() < $activity['legacy_until'] ) {
			return false;
		}

		$key = $activity['transient_key'] ?? '';
		if ( is_string( $key ) && self::is_session_key( $key ) ) {
			$session = get_transient( $key );
			if ( is_array( $session ) && isset( $session['workspace'] ) && is_string( $session['workspace'] ) && realpath( $session['workspace'] ) === realpath( $workspace ) ) {
				return false;
			}
		}

		return time() - $activity['heartbeat'] >= max( 0, $max_age_seconds );
	}

	/**
	 * Accepts only canonical Path A/B session keys, preserving token case.
	 *
	 * @param string $key Transient key from the private activity record.
	 * @return bool
	 */
	private static function is_session_key( string $key ): bool {
		foreach ( array( PageFerry::TRANSIENT_SESSION_PREFIX, PageFerry::TRANSIENT_IMPORT_PREFIX ) as $prefix ) {
			if ( str_starts_with( $key, $prefix ) && 1 === preg_match( '/\Apf-[A-Za-z0-9-]+\z/', substr( $key, strlen( $prefix ) ) ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Writes explicit activity, preserving the bound transient on refresh.
	 *
	 * @param string      $workspace Workspace directory (caller holds its lease).
	 * @param string|null $transient_key New key, or null to preserve the binding.
	 * @param bool        $adopt_legacy Whether to give an untracked legacy session one TTL of grace.
	 * @return bool Whether the complete activity record was stored.
	 */
	private static function heartbeat( string $workspace, ?string $transient_key = null, bool $adopt_legacy = false ): bool {
		$path = $workspace . '/' . self::ACTIVITY_FILE;
		if ( is_link( $path ) ) {
			return false;
		}
		$activity                  = self::read_activity( $workspace );
		$activity['heartbeat']     = time();
		$activity['transient_key'] = $transient_key ?? ( $activity['transient_key'] ?? '' );
		if ( $adopt_legacy ) {
			$activity['legacy_until'] = time() + HOUR_IN_SECONDS;
		} elseif ( null !== $transient_key ) {
			unset( $activity['legacy_until'] );
		}
		$json = wp_json_encode( $activity );
		return is_string( $json ) && strlen( $json ) === @file_put_contents( $path, $json ); // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors.Discouraged -- private leased activity record; caller reports write failures.
	}

	/**
	 * Reads only our private activity record.
	 *
	 * @param string $workspace Workspace directory.
	 * @return array Activity, or empty for legacy/malformed records.
	 */
	private static function read_activity( string $workspace ): array {
		$path = $workspace . '/' . self::ACTIVITY_FILE;
		if ( ! is_file( $path ) || ! is_readable( $path ) || is_link( $path ) ) {
			return array();
		}
		$json     = file_get_contents( $path, false, null, 0, 8192 ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- bounded private activity record under its lease.
		$activity = is_string( $json ) ? json_decode( $json, true ) : null;
		return is_array( $activity ) ? $activity : array();
	}

	/**
	 * Reports unusable workspaces rather than running without GC protection.
	 *
	 * @return WP_Error
	 */
	private static function activity_error(): WP_Error {
		return new WP_Error(
			'pageferry_workspace_activity',
			__( 'PageFerry could not track this import workspace safely. Start the import again or ask your host to check uploads-directory permissions and filesystem locking.', 'pageferry' ),
			array( 'status' => 500 )
		);
	}
}
