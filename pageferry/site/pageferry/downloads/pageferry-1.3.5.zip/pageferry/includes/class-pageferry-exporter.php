<?php
/**
 * Page exporter for PageFerry.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/**
 * Exports one Gutenberg-compatible post with its media.
 */
class PageFerry_Exporter {

	/**
	 * Returns ferryable types; editor preferences are checked per post at the export UI.
	 *
	 * @return array Sorted list of ferryable post-type slugs.
	 */
	public static function ferryable_post_types(): array {
		$supported = array( 'page', 'post' );

		foreach ( get_post_types(
			array(
				'show_in_rest' => true,
				'show_ui'      => true,
			),
			'objects'
		) as $post_type => $type_object ) {
			if ( in_array( $post_type, $supported, true ) || $type_object->_builtin ) {
				continue;
			}

			if ( post_type_supports( $post_type, 'editor' ) ) {
				$supported[] = $post_type;
			}
		}

		sort( $supported );

		return $supported;
	}

	/**
	 * Manifest schema version written by this exporter.
	 *
	 * @var int
	 */
	const MANIFEST_VERSION = 1;

	/**
	 * Builds a hash-verified ZIP; missing source media remains explicit in the manifest.
	 *
	 * @param int $post_id Post ID to export.
	 * @return string|WP_Error Absolute path to the built ZIP, or WP_Error.
	 */
	public static function export( int $post_id ): string|WP_Error {
		$validation_error = self::validate_post( $post_id );

		if ( $validation_error instanceof WP_Error ) {
			return $validation_error;
		}

		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error(
				'pageferry_no_zip',
				__( 'PageFerry export needs the PHP zip extension, which is missing on this host. Ask your host to enable it.', 'pageferry' )
			);
		}

		$collection = PageFerry_Media_Collector::collect( $post_id );
		// Editing the source post does not grant access to its referenced attachments.
		foreach ( $collection['items'] as $item ) {
			$attachment_id = (int) $item['old_id'];
			if ( 'attachment' === get_post_type( $attachment_id ) && ! current_user_can( 'read_post', $attachment_id ) ) {
				return new WP_Error(
					'pageferry_media_cap',
					__( 'You do not have permission to export one or more attachments referenced by this post.', 'pageferry' ),
					array( 'status' => 403 )
				);
			}
		}

		$limits = PageFerry_Import_Resources::limits();
		if ( count( $collection['items'] ) > $limits['media_records'] ) {
			return self::resource_error();
		}
		$media_map = self::build_media_entries( $collection['items'] );
		if ( $media_map instanceof WP_Error ) {
			return $media_map;
		}
		$media_entries = array_column( $media_map, 'manifest' );
		$manifest      = self::build_manifest(
			get_post( $post_id ),
			$media_entries,
			$collection['warnings'],
			PageFerry_Media_Collector::collect_acf_post_meta( $post_id ),
			PageFerry_Media_Collector::collect_acf_post_fields( $post_id )
		);
		if ( ! PageFerry_Import_Resources::manifest_fits( $manifest, $limits['manifest_bytes'] ) ) {
			return self::resource_error();
		}
		// Import encodes escaped slashes, which can increase the manifest size.
		$validation_json = wp_json_encode( $manifest );
		$manifest_json   = wp_json_encode( $manifest, JSON_UNESCAPED_SLASHES );
		if ( ! is_string( $validation_json ) || ! is_string( $manifest_json ) ) {
			return self::write_error();
		}
		if ( max( strlen( $validation_json ), strlen( $manifest_json ) ) > $limits['manifest_bytes'] ) {
			return self::resource_error();
		}
		unset( $validation_json, $manifest );

		$workspace = PageFerry_Importer::make_workspace();
		if ( $workspace instanceof WP_Error ) {
			return $workspace;
		}
		register_shutdown_function( static fn() => self::cleanup_export( $workspace ) );
		$result = PageFerry_Workspace::with_lease(
			$workspace,
			static function () use ( $workspace, $media_map, $media_entries, $manifest_json, $limits ) {
				return self::package_export( $workspace, $media_map, $media_entries, $manifest_json, $limits );
			}
		);
		if ( $result instanceof WP_Error ) {
			self::cleanup_export( $workspace );
		}
		return $result;
	}

	/**
	 * Packages bounded immutable media copies under the caller's workspace lease.
	 *
	 * @param string $workspace Private owned tree.
	 * @param array  $media_map Media declarations and source paths.
	 * @param array  $media_entries Manifest media.
	 * @param string $manifest_json Encoded manifest.
	 * @param array  $limits Effective import ceilings.
	 * @return string|WP_Error
	 */
	private static function package_export( string $workspace, array $media_map, array $media_entries, string $manifest_json, array $limits ) {
		$total = 0;
		$paths = array();
		foreach ( $media_map as $position => $entry ) {
			if ( ! isset( $entry['source_path'] ) ) {
				continue;
			}
			$path   = $workspace . '/media-' . $position;
			$input  = @fopen( $entry['source_path'], 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors.Discouraged -- source may disappear after collection.
			$output = @fopen( $path, 'xb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors.Discouraged -- exclusive owned private candidate.
			if ( ! is_resource( $input ) || ! is_resource( $output ) ) {
				if ( is_resource( $input ) ) {
					fclose( $input ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- owned stream.
				}
				if ( is_resource( $output ) ) {
					fclose( $output ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- owned stream.
				}
				return self::write_error();
			}
			try {
				$copied = PageFerry_Import_Resources::copy( $input, $output, $entry['manifest']['bytes'], min( $limits['core_bytes'], max( $limits['path_a_bytes'], $limits['path_b_bytes'] ) ) - $total );
			} finally {
				$input_closed  = fclose( $input ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- checked owned stream.
				$output_closed = fclose( $output ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- checked owned stream.
			}
			if ( $copied instanceof WP_Error || ! $input_closed || ! $output_closed || $copied !== $entry['manifest']['bytes'] || hash_file( 'sha256', $path ) !== $entry['manifest']['sha256'] ) {
				return self::write_error();
			}
			$total += $copied;
			$paths[ 'media/' . $entry['manifest']['file'] ] = $path;
		}
		$temp_zip = $workspace . '/export.zip';
		$zip      = new ZipArchive();
		if ( true !== $zip->open( $temp_zip, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			return new WP_Error( 'pageferry_zip_open_failed', __( 'PageFerry could not open the export ZIP for writing.', 'pageferry' ) );
		}
		try {
			foreach ( $paths as $name => $path ) {
				if ( ! $zip->addFile( $path, $name ) ) {
					return self::write_error();
				}
			}
			if ( ! $zip->addFromString( 'pageferry-manifest.json', $manifest_json ) ) {
				return self::write_error();
			}
		} finally {
			$closed = $zip->close();
		}
		if ( ! $closed ) {
			return self::write_error();
		}
		$size = PageFerry_Import_Resources::file_size( $temp_zip );
		if ( $size instanceof WP_Error ) {
			return self::write_error();
		}
		$transport = $size > (int) wp_max_upload_size() ? 'path_b_bytes' : 'path_a_bytes';
		if ( $total > min( $limits[ $transport ], $limits['core_bytes'] ) ) {
			return self::resource_error();
		}
		$metadata_error = PageFerry_Import_Resources::check_zip_metadata( $temp_zip );
		if ( $metadata_error instanceof WP_Error ) {
			return 'pageferry_resource_limit' === $metadata_error->get_error_code() ? self::resource_error() : self::write_error();
		}
		$error = self::verify_zip_integrity( $temp_zip, $media_entries );
		return $error instanceof WP_Error ? $error : $temp_zip;
	}

	/**
	 * Retires only the export-owned workspace while holding its lease.
	 *
	 * @param string $workspace Owned tree.
	 * @return void
	 */
	private static function cleanup_export( string $workspace ): void {
		if ( is_dir( $workspace ) ) {
			PageFerry_Workspace::with_lease( $workspace, static fn() => PageFerry_Workspace::retire( $workspace ) );
		}
	}

	/**
	 * Refuses an export which cannot fit the effective import policy.
	 *
	 * @return WP_Error
	 */
	private static function resource_error(): WP_Error {
		return new WP_Error( 'pageferry_export_resource_limit', __( 'PageFerry cannot export this page: the bundle exceeds this site’s import limits. Reduce its content or media and try again.', 'pageferry' ), array( 'status' => 413 ) );
	}

	/**
	 * Reports export file or encoding failure.
	 *
	 * @return WP_Error
	 */
	private static function write_error(): WP_Error {
		return new WP_Error( 'pageferry_zip_write_failed', __( 'PageFerry could not read or write the export files. Try exporting again.', 'pageferry' ), array( 'status' => 500 ) );
	}

	/**
	 * Opens a regular download file and reads its size from the same handle.
	 *
	 * @param string $path Export ZIP.
	 * @return array|WP_Error Stream and byte count, or clean refusal before headers.
	 */
	private static function open_download( string $path ) {
		clearstatcache( true, $path );
		if ( is_link( $path ) || ! is_file( $path ) || ! is_readable( $path ) ) {
			return self::write_error();
		}
		$stream = @fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors.Discouraged -- handle disappearance before sending headers.
		if ( ! is_resource( $stream ) ) {
			return self::write_error();
		}
		$stat = fstat( $stream );
		if ( ! is_array( $stat ) || 0100000 !== ( $stat['mode'] & 0170000 ) || 0 >= $stat['size'] || $stat['size'] > PageFerry_Import_Resources::limits()['zip_bytes'] ) {
			fclose( $stream ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- refused owned stream.
			return self::write_error();
		}
		return array(
			'stream' => $stream,
			'bytes'  => $stat['size'],
		);
	}

	/**
	 * Streams an export ZIP to the browser and exits after owned cleanup.
	 *
	 * @param int $post_id Post ID to export.
	 * @return void
	 */
	public static function stream_download( int $post_id ): void {
		$build_result = self::export( $post_id );
		if ( $build_result instanceof WP_Error ) {
			wp_die(
				esc_html( $build_result->get_error_message() ),
				esc_html__( 'PageFerry export failed', 'pageferry' ),
				array( 'response' => (int) ( $build_result->get_error_data()['status'] ?? 500 ) )
			);
		}
		self::stream_export( $build_result, $post_id );
	}

	/**
	 * Streams an already built export after checking its open file handle.
	 *
	 * @param string $build_result Private export ZIP.
	 * @param int    $post_id Source post for the download name.
	 * @return void
	 */
	private static function stream_export( string $build_result, int $post_id ): void {
		$download = self::open_download( $build_result );
		if ( $download instanceof WP_Error ) {
			self::cleanup_export( dirname( $build_result ) );
			wp_die(
				esc_html( $download->get_error_message() ),
				esc_html__( 'PageFerry export failed', 'pageferry' ),
				array( 'response' => (int) ( $download->get_error_data()['status'] ?? 500 ) )
			);
		}
		$source_post = get_post( $post_id );
		$post_slug   = $source_post instanceof WP_Post ? $source_post->post_name : 'page';
		$zip_name    = sprintf( 'pageferry-%s-%s.zip', sanitize_title( $post_slug ), gmdate( 'YmdHis' ) );
		try {
			nocache_headers();
			header( 'Content-Type: application/zip' );
			header( 'Content-Disposition: attachment; filename="' . $zip_name . '"' );
			header( 'Content-Length: ' . $download['bytes'] );
			while ( 0 < ob_get_level() ) {
				ob_end_clean();
			}
			fpassthru( $download['stream'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- stream the already opened binary download.
		} finally {
			fclose( $download['stream'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- owned download stream.
			self::cleanup_export( dirname( $build_result ) );
		}
		exit;
	}

	/**
	 * Checks the actual editor; core intentionally returns false during its metabox-loader request.
	 *
	 * @param WP_Post $post                  Post being edited.
	 * @param bool    $allow_loader_fallback Whether the loader branch applies.
	 *                                       Validation passes false so a
	 *                                       crafted loader param cannot widen
	 *                                       export access.
	 * @return bool True when the export box may show.
	 */
	private static function is_gutenberg_post( WP_Post $post, bool $allow_loader_fallback = true ): bool {
		if ( ! in_array( $post->post_type, self::ferryable_post_types(), true ) ) {
			return false;
		}

		if ( $allow_loader_fallback && isset( $_GET['meta-box-loader'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only loader detection, no state change.
			$use_block_editor = function_exists( 'use_block_editor_for_post_type' ) ? use_block_editor_for_post_type( $post->post_type ) : in_array( $post->post_type, self::ferryable_post_types(), true );

			return (bool) apply_filters( 'use_block_editor_for_post', $use_block_editor, $post ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- mirroring core's own per-post result.
		}

		if ( function_exists( 'use_block_editor_for_post' ) ) {
			return use_block_editor_for_post( $post );
		}

		return in_array( $post->post_type, self::ferryable_post_types(), true );
	}

	/**
	 * Registers metaboxes per post, preserving type-list behavior for legacy callers.
	 *
	 * @param string|null $post_type Post type of the current edit screen.
	 * @param mixed       $post     Post being edited (ID or object).
	 * @return void
	 */
	public static function register_metabox( ?string $post_type = null, $post = null ): void {
		if ( null !== $post ) {
			if ( $post instanceof WP_Post ) {
				$resolved_post = $post;
			} elseif ( is_int( $post ) || ( is_string( $post ) && ctype_digit( $post ) ) ) {
				$resolved_post = get_post( (int) $post );
			} else {
				$resolved_post = null;
			}

			if ( $resolved_post instanceof WP_Post ) {
				if ( ! self::is_gutenberg_post( $resolved_post ) ) {
					return;
				}

				add_meta_box(
					'pageferry-export',
					__( 'PageFerry Export', 'pageferry' ),
					array( __CLASS__, 'render_metabox' ),
					array( $resolved_post->post_type ),
					'side',
					'default'
				);

				return;
			}
		}

		if ( null !== $post_type && '' !== $post_type ) {
			if ( ! in_array( $post_type, self::ferryable_post_types(), true ) ) {
				return;
			}

			add_meta_box(
				'pageferry-export',
				__( 'PageFerry Export', 'pageferry' ),
				array( __CLASS__, 'render_metabox' ),
				array( $post_type ),
				'side',
				'default'
			);

			return;
		}

		add_meta_box(
			'pageferry-export',
			__( 'PageFerry Export', 'pageferry' ),
			array( __CLASS__, 'render_metabox' ),
			self::ferryable_post_types(),
			'side',
			'default'
		);
	}

	/**
	 * Renders only in the block editor, including when editor mode changed after registration.
	 *
	 * @param WP_Post $source_post Post being edited.
	 * @return void
	 */
	public static function render_metabox( WP_Post $source_post ): void {
		if ( ! self::is_gutenberg_post( $source_post ) ) {
			return;
		}
		$export_url = add_query_arg(
			array(
				'action' => 'pageferry_export',
				'post'   => $source_post->ID,
			),
			admin_url( 'admin-post.php' )
		);
		$export_url = wp_nonce_url( $export_url, 'pageferry_export_' . $source_post->ID );
		$import_url = admin_url( 'tools.php?page=pageferry-import' );

		printf(
			'<p>%s</p><p><a class="button button-primary" href="%s">%s</a></p><p><a href="%s">%s</a></p>',
			esc_html__( 'Download this page as a portable ZIP (content + media).', 'pageferry' ),
			esc_url( $export_url ),
			esc_html__( 'Ferry this page', 'pageferry' ),
			esc_url( $import_url ),
			esc_html__( 'Import a ferried page', 'pageferry' )
		);
	}

	/**
	 * Handles the admin-post export request.
	 *
	 * @return void
	 */
	public static function handle_export_request(): void {
		$post_id = isset( $_GET['post'] ) ? absint( wp_unslash( $_GET['post'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce is verified below.
		$nonce   = isset( $_GET['_wpnonce'] ) ? sanitize_key( wp_unslash( $_GET['_wpnonce'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce is verified below.

		if ( 0 === $post_id || ! wp_verify_nonce( $nonce, 'pageferry_export_' . $post_id ) ) {
			wp_die(
				esc_html__( 'This export link is invalid or expired. Return to the page editor and try again.', 'pageferry' ),
				esc_html__( 'PageFerry export failed', 'pageferry' ),
				array( 'response' => 403 )
			);
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			wp_die(
				esc_html__( 'You do not have permission to export this page.', 'pageferry' ),
				esc_html__( 'PageFerry export failed', 'pageferry' ),
				array( 'response' => 403 )
			);
		}

		self::stream_download( $post_id );
	}

	/**
	 * Requires an existing post configured to use the block editor.
	 *
	 * @param int $post_id Post ID to validate.
	 * @return WP_Error|null WP_Error on failure, null when valid.
	 */
	private static function validate_post( int $post_id ): ?WP_Error {
		$source_post = get_post( $post_id );

		if ( ! $source_post instanceof WP_Post ) {
			return new WP_Error(
				'pageferry_post_not_found',
				__( 'PageFerry could not find that page.', 'pageferry' )
			);
		}

		if ( ! in_array( $source_post->post_type, self::ferryable_post_types(), true ) ) {
			return new WP_Error(
				'pageferry_unsupported_post_type',
				__( 'PageFerry cannot move this post type. Custom types need editor, admin-screen and REST support; internal WordPress types are not supported.', 'pageferry' )
			);
		}

		if ( ! self::is_gutenberg_post( $source_post, false ) ) {
			return new WP_Error(
				'pageferry_unsupported_post_type',
				__( 'PageFerry exports Gutenberg content only (pages, posts, and block-editor custom post types).', 'pageferry' )
			);
		}

		return null;
	}

	/**
	 * Builds manifest media entries without exposing absolute server paths.
	 *
	 * @param array $items Collector schema items.
	 * @return array|WP_Error List of declarations/sources, or resource/I/O refusal.
	 */
	private static function build_media_entries( array $items ) {
		$media_map  = array();
		$used_names = array();
		$limits     = PageFerry_Import_Resources::limits();
		$total      = 0;

		foreach ( $items as $item ) {
			$old_id = isset( $item['old_id'] ) ? (int) $item['old_id'] : 0;

			$file_missing = ! isset( $item['file_path'] ) || ! is_string( $item['file_path'] );
			$hash_missing = ! isset( $item['sha256'] ) || ! is_string( $item['sha256'] );

			if ( $file_missing || $hash_missing ) {
				$media_map[] = array(
					'manifest' => array(
						'old_id'                => $old_id,
						'file'                  => null,
						'filename'              => null,
						'sha256'                => null,
						'bytes'                 => null,
						'url'                   => isset( $item['url'] ) && is_string( $item['url'] ) ? $item['url'] : null,
						'alt'                   => $item['alt'] ?? null,
						'caption'               => $item['caption'] ?? null,
						'title'                 => $item['title'] ?? null,
						'description'           => $item['description'] ?? null,
						'featured'              => ! empty( $item['featured'] ),
						'likely_false_positive' => ! empty( $item['likely_false_positive'] ),
						'block_refs'            => $item['block_refs'] ?? array(),
						'missing'               => true,
					),
				);
				continue;
			}

			$size = PageFerry_Import_Resources::file_size( $item['file_path'] );
			if ( $size instanceof WP_Error ) {
				return self::write_error();
			}
			if ( count( $used_names ) >= $limits['required_files'] || $size > $limits['media_file_bytes'] || $size > min( $limits['core_bytes'], max( $limits['path_a_bytes'], $limits['path_b_bytes'] ) ) - $total ) {
				return self::resource_error();
			}
			$total   += $size;
			$zip_name = self::unique_zip_name( basename( $item['file_path'] ), $used_names );
			if ( strlen( 'media/' . $zip_name ) > $limits['zip_name_bytes'] ) {
				return self::resource_error();
			}

			$media_map[] = array(
				'source_path' => $item['file_path'],
				'manifest'    => array(
					'old_id'                => $old_id,
					'file'                  => $zip_name,
					'filename'              => basename( $item['file_path'] ),
					'sha256'                => $item['sha256'],
					'bytes'                 => $size,
					'url'                   => isset( $item['url'] ) && is_string( $item['url'] ) ? $item['url'] : null,
					'alt'                   => $item['alt'] ?? null,
					'caption'               => $item['caption'] ?? null,
					'title'                 => $item['title'] ?? null,
					'description'           => $item['description'] ?? null,
					'featured'              => ! empty( $item['featured'] ),
					'likely_false_positive' => ! empty( $item['likely_false_positive'] ),
					'block_refs'            => $item['block_refs'] ?? array(),
					'missing'               => false,
				),
			);
		}

		if ( count( $used_names ) + 1 > $limits['zip_entries'] || strlen( 'pageferry-manifest.json' ) > $limits['zip_name_bytes'] ) {
			return self::resource_error();
		}
		return $media_map;
	}

	/**
	 * Keeps readable basenames, suffixing only ZIP entry collisions.
	 *
	 * @param string $basename   Original file basename.
	 * @param array  $used_names Names already taken (appended to).
	 * @return string Unique safe name.
	 */
	private static function unique_zip_name( string $basename, array &$used_names ): string {
		$safe_basename = (string) preg_replace( '/[^A-Za-z0-9._-]+/', '-', $basename );
		$safe_basename = trim( $safe_basename, '.-' );

		if ( '' === $safe_basename ) {
			$safe_basename = 'media-file';
		}

		if ( ! isset( $used_names[ $safe_basename ] ) ) {
			$used_names[ $safe_basename ] = true;

			return $safe_basename;
		}

		$dot_position = strrpos( $safe_basename, '.' );

		if ( false === $dot_position ) {
			$stem      = $safe_basename;
			$extension = '';
		} else {
			$stem      = substr( $safe_basename, 0, $dot_position );
			$extension = substr( $safe_basename, (int) $dot_position );
		}

		$suffix = 1;

		do {
			$candidate_name = $stem . '-' . $suffix . $extension;
			++$suffix;
		} while ( isset( $used_names[ $candidate_name ] ) );

		$used_names[ $candidate_name ] = true;

		return $candidate_name;
	}

	/**
	 * Builds manifest v1 with raw ACF values for destination remapping.
	 *
	 * @param WP_Post|false|null $source_post     Post being exported.
	 * @param array              $media_entries   Manifest media entries.
	 * @param array              $warnings        Collector warnings.
	 * @param array              $acf_post_meta   ACF usePostMeta entries.
	 * @param array              $acf_post_fields ACF post field values (name => raw value).
	 * @return array Manifest array.
	 */
	private static function build_manifest( WP_Post|false|null $source_post, array $media_entries, array $warnings, array $acf_post_meta = array(), array $acf_post_fields = array() ): array {
		$post_type     = $source_post instanceof WP_Post ? $source_post->post_type : 'page';
		$thumbnail_raw = $source_post instanceof WP_Post ? get_post_meta( $source_post->ID, '_thumbnail_id', true ) : 0;
		$thumbnail_id  = is_numeric( $thumbnail_raw ) ? (int) $thumbnail_raw : 0;

		// Legacy bundles omit the template key to preserve the destination setting.
		$template_raw = $source_post instanceof WP_Post ? get_post_meta( $source_post->ID, '_wp_page_template', true ) : '';
		$template     = is_string( $template_raw ) ? trim( $template_raw ) : '';

		if ( 'default' === $template ) {
			$template = '';
		}

		$taxonomies = array();
		$tax_detail = array();
		if ( $source_post instanceof WP_Post ) {
			// Keep core taxonomies for compatibility with v1 bundles, including pages.
			$taxonomy_slugs = array_unique(
				array_merge(
					array( 'category', 'post_tag' ),
					get_object_taxonomies( $source_post->post_type, 'names' )
				)
			);

			foreach ( $taxonomy_slugs as $taxonomy_slug ) {
				$term_names                   = wp_get_object_terms( $source_post->ID, $taxonomy_slug, array( 'fields' => 'names' ) );
				$taxonomies[ $taxonomy_slug ] = is_wp_error( $term_names ) ? array() : array_values( $term_names );

				$object_terms = wp_get_object_terms( $source_post->ID, $taxonomy_slug );
				$term_ids     = is_wp_error( $object_terms ) ? array() : wp_list_pluck( $object_terms, 'term_id' );

				$tax_detail[ $taxonomy_slug ] = self::describe_terms( $term_ids, $taxonomy_slug );
			}
		}

		return array(
			'plugin'           => 'pageferry',
			'manifest_version' => self::MANIFEST_VERSION,
			'source'           => array(
				'url'        => home_url(),
				'wp_version' => get_bloginfo( 'version' ),
				'date'       => gmdate( 'c' ),
			),
			'post'             => array(
				'post_type'        => $source_post instanceof WP_Post ? $source_post->post_type : '',
				'slug'             => $source_post instanceof WP_Post ? $source_post->post_name : '',
				'title'            => $source_post instanceof WP_Post ? $source_post->post_title : '',
				'status'           => $source_post instanceof WP_Post ? $source_post->post_status : '',
				'content'          => $source_post instanceof WP_Post ? $source_post->post_content : '',
				'excerpt'          => $source_post instanceof WP_Post ? $source_post->post_excerpt : '',
				'tax'              => $taxonomies,
				'thumbnail_old_id' => 0 < $thumbnail_id ? $thumbnail_id : null,
				'template'         => $template,
			),
			'media'            => $media_entries,
			'tax_terms'        => $tax_detail,
			'options'          => array(
				'land_as_draft' => true,
			),
			'builder_detected' => $source_post instanceof WP_Post ? PageFerry_Builder_Guard::detect( $source_post->ID ) : false,
			'export_warnings'  => array_values( $warnings ),
			'acf_post_meta'    => array_values( $acf_post_meta ),
			'acf_post_fields'  => $acf_post_fields,
			'supports'         => array( $post_type ),
		);
	}

	/**
	 * Includes ancestors to rebuild hierarchy; only assigned terms attach directly.
	 *
	 * @param array  $term_ids Term IDs on the source site.
	 * @param string $taxonomy Taxonomy slug.
	 * @return array List of array( 'name' => string, 'slug' => string, 'parent' => string, 'parent_slug' => string, 'assigned' => bool ).
	 */
	private static function describe_terms( array $term_ids, string $taxonomy ): array {
		$by_id = array();

		foreach ( $term_ids as $term_id ) {
			$term = get_term( (int) $term_id, $taxonomy );

			if ( ! $term instanceof WP_Term ) {
				continue;
			}

			$by_id[ (int) $term->term_id ] = $term;
		}

		$closure = $by_id;

		foreach ( $by_id as $term ) {
			$seen_ids       = array( (int) $term->term_id => true );
			$parent_term_id = (int) $term->parent;
			$guard          = 0;

			while ( 0 < $parent_term_id && 20 > $guard && ! isset( $seen_ids[ $parent_term_id ] ) ) {
				if ( isset( $closure[ $parent_term_id ] ) ) {
					$parent_term = $closure[ $parent_term_id ];
				} else {
					$parent_term = get_term( $parent_term_id, $taxonomy );

					if ( ! $parent_term instanceof WP_Term ) {
						break;
					}

					$closure[ $parent_term_id ] = $parent_term;
				}

				$seen_ids[ $parent_term_id ] = true;
				$parent_term_id              = (int) $parent_term->parent;
				++$guard;
			}
		}

		// Corrupt parent cycles must not stall export.
		$ordered       = array();
		$closure_count = count( $closure );
		$ordered_count = 0;

		while ( $ordered_count < $closure_count ) {
			$progress = false;

			foreach ( $closure as $term_id => $term ) {
				if ( isset( $ordered[ $term_id ] ) ) {
					continue;
				}

				$parent_id = (int) $term->parent;

				if ( 0 !== $parent_id && isset( $closure[ $parent_id ] ) && ! isset( $ordered[ $parent_id ] ) ) {
					continue;
				}

				$ordered[ $term_id ] = $term;
				$progress            = true;
			}

			$ordered_count = count( $ordered );

			if ( ! $progress ) {
				foreach ( $closure as $term_id => $term ) {
					if ( ! isset( $ordered[ $term_id ] ) ) {
						$ordered[ $term_id ] = $term;
					}
				}
				break;
			}
		}

		$described = array();

		foreach ( $ordered as $term_id => $term ) {
			$parent_name = '';
			$parent_slug = '';
			$parent_id   = (int) $term->parent;

			if ( 0 < $parent_id ) {
				if ( isset( $closure[ $parent_id ] ) ) {
					$parent_name = $closure[ $parent_id ]->name;
					$parent_slug = $closure[ $parent_id ]->slug;
				} else {
					$parent_term = get_term( $parent_id, $taxonomy );

					if ( $parent_term instanceof WP_Term ) {
						$parent_name = $parent_term->name;
						$parent_slug = $parent_term->slug;
					}
				}
			}

			$described[] = array(
				'name'        => $term->name,
				'slug'        => $term->slug,
				'parent'      => $parent_name,
				'parent_slug' => $parent_slug,
				'assigned'    => isset( $by_id[ $term_id ] ),
			);
		}

		return $described;
	}

	/**
	 * Verifies packaged media hashes without modifying the ZIP.
	 *
	 * @param string $zip_path      Absolute path to the built ZIP.
	 * @param array  $media_entries Manifest media entries.
	 * @return WP_Error|null WP_Error on mismatch, null when valid.
	 */
	private static function verify_zip_integrity( string $zip_path, array $media_entries ): ?WP_Error {
		$zip = new ZipArchive();

		if ( true !== $zip->open( $zip_path, ZipArchive::RDONLY ) ) {
			return new WP_Error(
				'pageferry_zip_verify_failed',
				__( 'PageFerry could not verify the export ZIP.', 'pageferry' )
			);
		}

		foreach ( $media_entries as $entry ) {
			if ( ! isset( $entry['file'] ) || ! is_string( $entry['file'] ) || ! isset( $entry['sha256'] ) || ! is_string( $entry['sha256'] ) ) {
				continue;
			}

			$stream = $zip->getStream( 'media/' . $entry['file'] );

			if ( ! is_resource( $stream ) ) {
				$zip->close();
				return new WP_Error(
					'pageferry_zip_verify_failed',
					sprintf(
						/* translators: %s: media file name inside the export ZIP. */
						__( 'PageFerry could not verify media file %s in the export ZIP.', 'pageferry' ),
						$entry['file']
					)
				);
			}

			$hash_context = hash_init( 'sha256' );
			$read_bytes   = hash_update_stream( $hash_context, $stream );
			$closed       = fclose( $stream ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- checked ZIP entry stream.

			if ( ! $closed || $read_bytes !== $entry['bytes'] || hash_final( $hash_context ) !== $entry['sha256'] ) {
				$zip->close();
				return new WP_Error(
					'pageferry_zip_verify_failed',
					sprintf(
						/* translators: %s: media file name inside the export ZIP. */
						__( 'Export integrity check failed for media file %s.', 'pageferry' ),
						$entry['file']
					)
				);
			}
		}

		return $zip->close() ? null : self::write_error();
	}
}
