<?php
/**
 * Destination import choices shared by both transports.
 *
 * @package PageFerry
 */

defined( 'ABSPATH' ) || exit;

/** Applies a validated allowlist without changing the source bundle. */
class PageFerry_Import_Selection {

	/**
	 * List selectable terms, preserving the importer's detailed/flat precedence.
	 *
	 * @param array $manifest Source manifest.
	 * @return array
	 */
	public static function taxonomies( array $manifest ): array {
		$detailed = is_array( $manifest['tax_terms'] ?? null ) ? $manifest['tax_terms'] : array();
		$flat     = is_array( $manifest['post']['tax'] ?? null ) ? $manifest['post']['tax'] : array();
		$groups   = array();
		foreach ( array_unique( array_merge( array_keys( $detailed ), array_keys( $flat ) ) ) as $taxonomy ) {
			if ( ! is_string( $taxonomy ) || '' === $taxonomy ) {
				continue;
			}
			$rows = array();
			foreach ( (array) ( $detailed[ $taxonomy ] ?? array() ) as $index => $term ) {
				if ( ! is_array( $term ) || ! is_string( $term['name'] ?? null ) || '' === trim( $term['name'] ) ) {
					continue;
				}
				$rows[ 'd:' . $index ] = array(
					'name'        => $term['name'],
					'slug'        => is_string( $term['slug'] ?? null ) ? $term['slug'] : '',
					'parent'      => is_string( $term['parent'] ?? null ) ? $term['parent'] : '',
					'parent_slug' => is_string( $term['parent_slug'] ?? null ) ? $term['parent_slug'] : '',
					'assigned'    => ! array_key_exists( 'assigned', $term ) || ! empty( $term['assigned'] ),
				);
			}
			$assigned = array_filter(
				$rows,
				static function ( $row ) {
					return $row['assigned'];
				}
			);
			if ( array() === $assigned ) {
				$rows = array();
				foreach ( (array) ( $flat[ $taxonomy ] ?? array() ) as $index => $name ) {
					if ( is_scalar( $name ) && '' !== trim( (string) $name ) ) {
						$rows[ 'f:' . $index ] = array(
							'name'        => (string) $name,
							'slug'        => '',
							'parent'      => '',
							'parent_slug' => '',
							'assigned'    => true,
						);
					}
				}
			}
			$groups[ $taxonomy ] = $rows;
		}
		return $groups;
	}

	/**
	 * Canonical choices; absence keeps the legacy import-all behavior.
	 *
	 * @param array      $manifest Validated original manifest.
	 * @param mixed      $selection Submitted choices, or null for all.
	 * @param string     $post_type Destination type for available templates.
	 * @param array|null $prepared Server-owned inventories for lightweight review.
	 * @return array|WP_Error
	 */
	public static function normalize( array $manifest, $selection = null, string $post_type = '', ?array $prepared = null ) {
		$ids    = array_map( 'intval', array_column( $manifest['media'], 'old_id' ) );
		$id_set = array_fill_keys( $ids, true );
		$groups = $prepared['groups'] ?? self::taxonomies( $manifest );
		$fields = array( 'title', 'excerpt', 'thumbnail', 'template', 'slug' );
		$all    = array(
			'media'      => $ids,
			'taxonomies' => array(),
			'fields'     => $fields,
		);
		foreach ( $groups as $taxonomy => $rows ) {
			$all['taxonomies'][ $taxonomy ] = array_keys(
				array_filter(
					$rows,
					static function ( $row ) {
						return $row['assigned'];
					}
				)
			);
		}
		if ( null === $selection ) {
			$selection = $all;
		}
		if ( ! is_array( $selection ) || array_diff( array_keys( $selection ), array_merge( array_keys( $all ), array( 'overrides', 'taxonomy_actions' ) ) ) || ! isset( $selection['media'], $selection['taxonomies'], $selection['fields'] ) || ! is_array( $selection['media'] ) || ! is_array( $selection['taxonomies'] ) || ! is_array( $selection['fields'] ) ) {
			return self::error();
		}
		foreach ( $selection['media'] as $id ) {
			if ( ! is_int( $id ) || ! isset( $id_set[ $id ] ) ) {
				return self::error();
			}
		}
		foreach ( $selection['fields'] as $field ) {
			if ( ! is_string( $field ) || ! in_array( $field, $fields, true ) ) {
				return self::error();
			}
		}
		foreach ( $selection['taxonomies'] as $taxonomy => $keys ) {
			if ( ! isset( $groups[ $taxonomy ] ) || ! is_array( $keys ) ) {
				return self::error();
			}
			foreach ( $keys as $key ) {
				if ( ! is_string( $key ) || ! isset( $groups[ $taxonomy ][ $key ] ) || ! $groups[ $taxonomy ][ $key ]['assigned'] ) {
					return self::error();
				}
			}
			$selection['taxonomies'][ $taxonomy ] = array_values( array_unique( $keys ) );
			sort( $selection['taxonomies'][ $taxonomy ] );
		}
		if ( array_key_exists( 'taxonomy_actions', $selection ) ) {
			if ( ! is_array( $selection['taxonomy_actions'] ) ) {
				return self::error();
			}
			foreach ( $selection['taxonomy_actions'] as $taxonomy => $action ) {
				if ( ! array_key_exists( $taxonomy, $selection['taxonomies'] ) || ! in_array( $action, array( 'append', 'replace' ), true ) ) {
					return self::error();
				}
			}
			ksort( $selection['taxonomy_actions'] );
		}
		if ( array_key_exists( 'overrides', $selection ) ) {
			if ( ! is_array( $selection['overrides'] ) || array_diff( array_keys( $selection['overrides'] ), $fields ) ) {
				return self::error();
			}
			foreach ( $selection['overrides'] as $field => $value ) {
				if ( ! in_array( $field, $selection['fields'], true ) ) {
					return self::error();
				}
				if ( 'thumbnail' === $field ) {
					if ( null !== $value && ( ! is_int( $value ) || ! in_array( $value, $selection['media'], true ) ) ) {
						return self::error();
					}
					if ( null !== $value ) {
						$entry = $manifest['media'][ array_search( $value, $ids, true ) ];
						$mime  = wp_check_filetype( PageFerry_Importer::original_filename( $entry ) )['type'];
						if ( ! empty( $entry['missing'] ) || ! is_string( $mime ) || 0 !== strpos( $mime, 'image/' ) ) {
							return self::error();
						}
					}
				} else {
					if ( ! is_string( $value ) || strlen( $value ) > ( 'excerpt' === $field ? 65536 : 2000 ) ) {
						return self::error();
					}
					if ( 'template' === $field && '' !== $value && ( $manifest['post']['template'] ?? null ) !== $value && ! array_key_exists( $value, $prepared['validation_templates'] ?? wp_get_theme()->get_page_templates( null, '' !== $post_type ? $post_type : $manifest['post']['post_type'] ) ) ) {
						return self::error();
					}
					$selection['overrides'][ $field ] = 'slug' === $field ? _truncate_post_slug( sanitize_title( $value ), 200 ) : ( 'template' === $field ? $value : ( 'excerpt' === $field ? sanitize_textarea_field( $value ) : sanitize_text_field( $value ) ) );
				}
			}
			$thumbnail = array_key_exists( 'thumbnail', $selection['overrides'] ) ? $selection['overrides']['thumbnail'] : ( $manifest['post']['thumbnail_old_id'] ?? null );
			if ( in_array( 'thumbnail', $selection['fields'], true ) && is_numeric( $thumbnail ) && (int) $thumbnail > 0 && ! in_array( (int) $thumbnail, $selection['media'], true ) ) {
				return self::error();
			}
			ksort( $selection['overrides'] );
		}
		$selection['media']  = array_values( array_unique( $selection['media'] ) );
		$selection['fields'] = array_values( array_unique( $selection['fields'] ) );
		sort( $selection['media'] );
		sort( $selection['fields'] );
		ksort( $selection['taxonomies'] );
		ksort( $selection );
		return $selection;
	}

	/**
	 * Initial editable choices for the admin flow; legacy API defaults stay unchanged.
	 *
	 * @param array $manifest Validated source.
	 * @param int   $target_id Authorized update target, or zero.
	 * @return array
	 */
	public static function defaults( array $manifest, int $target_id = 0 ): array {
		$selection = self::normalize( $manifest );
		if ( is_wp_error( $selection ) ) {
			return array();
		}
		$selection['fields'] = array( 'title', 'excerpt', 'slug', 'thumbnail' );
		if ( array_key_exists( 'template', $manifest['post'] ) ) {
			$selection['fields'][] = 'template';
		}
		$selection['taxonomy_actions'] = array_fill_keys( array_keys( $selection['taxonomies'] ), 'append' );
		$selection['overrides']        = array();
		$target                        = $target_id > 0 ? get_post( $target_id ) : null;
		if ( $target instanceof WP_Post && current_user_can( 'edit_post', $target_id ) && ( $manifest['post']['slug'] ?? '' ) !== $target->post_name ) {
			$selection['overrides']['slug'] = $target->post_name;
		}
		$canonical = self::normalize( $manifest, $selection );
		return is_array( $canonical ) ? $canonical : array();
	}

	/**
	 * Build an execution-only manifest, retaining required ancestors.
	 *
	 * @param array      $manifest Validated source.
	 * @param array      $selection Canonical choices.
	 * @param array|null $groups Prepared source term graph.
	 * @return array
	 */
	public static function apply( array $manifest, array $selection, ?array $groups = null ): array {
		$groups                  = $groups ?? self::taxonomies( $manifest );
		$selected_media          = array_fill_keys( $selection['media'], true );
		$manifest['media']       = array_values(
			array_filter(
				$manifest['media'],
				static function ( $entry ) use ( $selected_media ) {
					return isset( $selected_media[ (int) $entry['old_id'] ] );
				}
			)
		);
		$details                 = $manifest['tax_terms'] ?? array();
		$flat                    = $manifest['post']['tax'] ?? array();
		$manifest['tax_terms']   = array();
		$manifest['post']['tax'] = array();
		foreach ( $selection['taxonomies'] as $taxonomy => $keys ) {
			if ( array() === $keys && 'append' === ( $selection['taxonomy_actions'][ $taxonomy ] ?? null ) ) {
				continue;
			}
			$manifest['post']['tax'][ $taxonomy ] = array();
			$manifest['tax_terms'][ $taxonomy ]   = array();
			$needed                               = $keys;
			$selected_keys                        = array_fill_keys( $keys, true );
			$included                             = $selected_keys;
			$by_slug                              = array();
			$by_name                              = array();
			foreach ( $groups[ $taxonomy ] as $row_key => $row ) {
				if ( '' !== $row['slug'] && ! isset( $by_slug[ $row['slug'] ] ) ) {
					$by_slug[ $row['slug'] ] = $row_key;
				}
				if ( ! isset( $by_name[ $row['name'] ] ) ) {
					$by_name[ $row['name'] ] = $row_key;
				}
			}
			$needed_count = count( $needed );
			for ( $cursor = 0; $cursor < $needed_count; ++$cursor ) {
				$row        = $groups[ $taxonomy ][ $needed[ $cursor ] ];
				$parent_key = '' !== $row['parent_slug'] ? ( $by_slug[ $row['parent_slug'] ] ?? null ) : ( $by_name[ $row['parent'] ] ?? null );
				if ( null !== $parent_key && ! isset( $included[ $parent_key ] ) ) {
					$needed[] = $parent_key;
					++$needed_count;
					$included[ $parent_key ] = true;
				}
			}
			foreach ( $groups[ $taxonomy ] as $key => $row ) {
				if ( ! isset( $included[ $key ] ) ) {
					continue;
				}
				$index = substr( $key, 2 );
				if ( 0 === strpos( $key, 'd:' ) ) {
					$term                                 = $details[ $taxonomy ][ $index ];
					$term['assigned']                     = isset( $selected_keys[ $key ] );
					$manifest['tax_terms'][ $taxonomy ][] = $term;
				} else {
					$manifest['post']['tax'][ $taxonomy ][] = $flat[ $taxonomy ][ $index ];
				}
			}
		}
		foreach ( array(
			'thumbnail' => 'thumbnail_old_id',
			'template'  => 'template',
		) as $choice => $key ) {
			if ( ! in_array( $choice, $selection['fields'], true ) ) {
				unset( $manifest['post'][ $key ] );
			}
		}
		foreach ( array( 'title', 'excerpt', 'slug' ) as $key ) {
			if ( ! in_array( $key, $selection['fields'], true ) ) {
				$manifest['post'][ $key ] = '';
			}
		}
		foreach ( $selection['overrides'] ?? array() as $field => $value ) {
			$manifest['post'][ 'thumbnail' === $field ? 'thumbnail_old_id' : $field ] = $value;
		}
		return $manifest;
	}

	/**
	 * Nonwriting review inventory from the original manifest.
	 *
	 * @param array  $manifest Source manifest.
	 * @param array  $selection Canonical choices.
	 * @param string $post_type Destination type.
	 * @param array  $media_actions Actual dedupe plan by source ID.
	 * @param int    $target_id Authorized update target, or zero.
	 * @return array
	 */
	public static function review( array $manifest, array $selection, string $post_type, array $media_actions, int $target_id = 0 ): array {
		$review         = array(
			'selection'  => $selection,
			'media'      => array(),
			'taxonomies' => array(),
			'fields'     => array(),
		);
		$selected_media = array_fill_keys( $selection['media'], true );
		foreach ( $manifest['media'] as $entry ) {
			$id                = (int) $entry['old_id'];
			$selected          = isset( $selected_media[ $id ] );
			$review['media'][] = array(
				'id'                    => $id,
				'filename'              => PageFerry_Importer::original_filename( $entry ),
				'mime'                  => is_string( $entry['mime'] ?? null ) ? $entry['mime'] : (string) wp_check_filetype( PageFerry_Importer::original_filename( $entry ) )['type'],
				'bytes'                 => (int) ( $entry['bytes'] ?? 0 ),
				'selected'              => $selected,
				'missing'               => ! empty( $entry['missing'] ),
				'likely_false_positive' => ! empty( $entry['likely_false_positive'] ),
				'featured'              => ! empty( $entry['featured'] ),
				'refs'                  => is_array( $entry['block_refs'] ?? null ) ? $entry['block_refs'] : array(),
				'status'                => $selected ? ( $media_actions[ $id ] ?? 'missing' ) : 'excluded',
			);
		}
		$effective = self::apply( $manifest, $selection );
		foreach ( self::taxonomies( $manifest ) as $taxonomy => $rows ) {
			$object         = get_taxonomy( $taxonomy );
			$available      = $object instanceof WP_Taxonomy && ( in_array( $taxonomy, array( 'category', 'post_tag' ), true ) || is_object_in_taxonomy( $post_type, $taxonomy ) );
			$group          = array(
				'slug'      => $taxonomy,
				'label'     => $object instanceof WP_Taxonomy ? $object->label : $taxonomy,
				'selected'  => isset( $selection['taxonomies'][ $taxonomy ] ),
				'available' => $available,
				'terms'     => array(),
			);
			$selected_keys  = array_fill_keys( $selection['taxonomies'][ $taxonomy ] ?? array(), true );
			$required_pairs = array();
			foreach ( $effective['tax_terms'][ $taxonomy ] ?? array() as $required ) {
				$required_slug = is_string( $required['slug'] ?? null ) ? $required['slug'] : '';
				$required_pairs[ $required_slug ][ $required['name'] ] = true;
			}
			foreach ( $rows as $key => $row ) {
				$parent_term = '' !== $row['parent_slug'] && $available ? get_term_by( 'slug', $row['parent_slug'], $taxonomy ) : false;
				if ( ! $parent_term && '' !== $row['parent'] && $available ) {
					$parent_term = get_term_by( 'name', wp_slash( $row['parent'] ), $taxonomy );
				}
				$has_parent              = '' !== $row['parent'] || '' !== $row['parent_slug'];
				$parent                  = $parent_term instanceof WP_Term ? $parent_term->term_id : ( $has_parent ? -1 : 0 );
				$existing                = $available ? PageFerry_Importer::existing_term_id( $row['name'], $taxonomy, $row['slug'], $parent ) : null;
				$destination_term        = null !== $existing ? get_term( $existing, $taxonomy ) : null;
				$row['existing_id']      = $existing ?? 0;
				$row['destination_name'] = $destination_term instanceof WP_Term ? $destination_term->name : $row['name'];
				$row['destination_slug'] = $destination_term instanceof WP_Term ? $destination_term->slug : $row['slug'];
				$row['key']              = $key;
				$row['selected']         = isset( $selected_keys[ $key ] );
				$can_create              = $object instanceof WP_Taxonomy && current_user_can( $object->cap->manage_terms );
				$row['status']           = ! $available ? 'unavailable' : ( null !== $existing ? 'existing' : ( $can_create ? 'create' : 'forbidden' ) );
				$row['included']         = $group['selected'] && ( $row['selected'] || isset( $required_pairs[ $row['slug'] ][ $row['name'] ] ) );
				$row['required']         = $row['included'] && ! $row['selected'];
				$group['terms'][]        = $row;
			}
			$current          = $target_id > 0 && $object instanceof WP_Taxonomy ? wp_get_object_terms( $target_id, $taxonomy ) : array();
			$group['current'] = array();
			foreach ( is_array( $current ) ? $current : array() as $term ) {
				$group['current'][] = array(
					'id'   => (int) $term->term_id,
					'name' => $term->name,
					'slug' => $term->slug,
				);
			}
			$group['action']        = $selection['taxonomy_actions'][ $taxonomy ] ?? 'replace';
			$review['taxonomies'][] = $group;
		}
		$labels = array(
			'title'     => __( 'Title', 'pageferry' ),
			'excerpt'   => __( 'Excerpt', 'pageferry' ),
			'thumbnail' => __( 'Featured image', 'pageferry' ),
			'template'  => __( 'Page template', 'pageferry' ),
			'slug'      => __( 'URL slug', 'pageferry' ),
		);
		foreach ( $labels as $key => $label ) {
			$source_key = 'thumbnail' === $key ? 'thumbnail_old_id' : $key;
			if ( ! array_key_exists( $source_key, $manifest['post'] ) ) {
				continue;
			}
			$value        = $manifest['post'][ $source_key ];
			$source_value = is_scalar( $value ) ? (string) $value : '';
			$value        = $selection['overrides'][ $key ] ?? $value;
			if ( 'thumbnail' === $key && is_numeric( $value ) && (int) $value > 0 ) {
				foreach ( $review['media'] as $image ) {
					if ( $image['id'] === (int) $value ) {
						$value = $image['filename'];
						break;
					}
				}
			}
			$review['fields'][] = array(
				'source'   => $source_value,
				'key'      => $key,
				'label'    => $label,
				'value'    => is_scalar( $value ) ? (string) $value : '',
				'selected' => in_array( $key, $selection['fields'], true ),
			);
		}
		return $review;
	}

	/**
	 * Report invalid choices.
	 *
	 * @return WP_Error
	 */
	private static function error(): WP_Error {
		return new WP_Error( 'pageferry_selection_invalid', __( 'The import choices are invalid. Review the bundle again.', 'pageferry' ), array( 'status' => 400 ) );
	}
}
