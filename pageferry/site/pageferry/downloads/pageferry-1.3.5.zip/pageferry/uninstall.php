<?php
/**
 * Removes plugin state and idle staging; imported posts, media and terms remain user content.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Keep literals in sync with PageFerry constants so uninstall works without the main class.
$pageferry_uninstall_option_names = array(
	'pageferry_hash_index',
	'pageferry_logs',
	'pageferry_backups',
	'pageferry_backup_index',
	'pageferry_last_gc',
	'pageferry_review_generation',
);

foreach ( $pageferry_uninstall_option_names as $pageferry_uninstall_option_name ) {
	delete_option( $pageferry_uninstall_option_name );
	delete_transient( $pageferry_uninstall_option_name );
}

// Cache-backed transients also need eviction after the options-table sweep.
global $wpdb;

$pageferry_uninstall_prefixes = array(
	'_transient_pageferry_session_',
	'_transient_timeout_pageferry_session_',
	'_transient_pageferry_import_',
	'_transient_timeout_pageferry_import_',
	'_transient_pageferry_quota_',
	'_transient_timeout_pageferry_quota_',
);

foreach ( $pageferry_uninstall_prefixes as $pageferry_uninstall_prefix ) {
	$pageferry_uninstall_like = $wpdb->esc_like( $pageferry_uninstall_prefix ) . '%';

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- uninstall cleanup has no API for prefix-matched transients.
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $pageferry_uninstall_like ) );
}

$pageferry_payload_names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( 'pageferry_backup_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- enumerate owned payload options during uninstall.
foreach ( $pageferry_payload_names as $pageferry_payload_name ) {
	if ( preg_match( '/^pageferry_backup_[a-f0-9]{64}$/D', $pageferry_payload_name ) ) {
		delete_option( $pageferry_payload_name );
	}
}

require_once __DIR__ . '/includes/class-pageferry-filesystem.php';
require_once __DIR__ . '/includes/class-pageferry-workspace.php';

// Expired transients can outlive active requests; retire only unleased trees before deletion.
$pageferry_upload_dir    = wp_get_upload_dir();
$pageferry_basedir       = isset( $pageferry_upload_dir['basedir'] ) && is_string( $pageferry_upload_dir['basedir'] ) ? $pageferry_upload_dir['basedir'] : '';
$pageferry_private_root  = PageFerry_Workspace::private_root();
$pageferry_cleanup_roots = array( $pageferry_basedir );
if ( is_string( $pageferry_private_root ) ) {
	$pageferry_cleanup_roots[] = $pageferry_private_root;
}

foreach ( $pageferry_cleanup_roots as $pageferry_basedir ) {
	if ( '' === $pageferry_basedir || ! is_dir( $pageferry_basedir ) ) {
		continue;
	}
	$pageferry_real_base = realpath( $pageferry_basedir );

	if ( is_string( $pageferry_real_base ) ) {
		$pageferry_top_entries = scandir( $pageferry_real_base );

		if ( is_array( $pageferry_top_entries ) ) {
			foreach ( $pageferry_top_entries as $pageferry_top_entry ) {
				if ( 0 !== strpos( $pageferry_top_entry, 'pageferry-import-' ) && 0 !== strpos( $pageferry_top_entry, 'pageferry-session-' ) ) {
					continue;
				}

				$pageferry_candidate = $pageferry_real_base . '/' . $pageferry_top_entry;

				if ( is_link( $pageferry_candidate ) ) {
					if ( $pageferry_basedir === $pageferry_private_root ) {
						PageFerry_Filesystem::remove_directory( $pageferry_candidate, $pageferry_real_base );
					}
					continue;
				}
				if ( ! is_dir( $pageferry_candidate ) ) {
					continue;
				}
				if ( str_starts_with( $pageferry_top_entry, 'pageferry-import-retired-' ) ) {
					clearstatcache( true, $pageferry_candidate );
					$pageferry_retired_activity = filemtime( $pageferry_candidate );
					if ( ! is_int( $pageferry_retired_activity ) || time() - $pageferry_retired_activity < HOUR_IN_SECONDS ) {
						continue;
					}
				}
				// Use a separate handle because with_lease() allows nesting within this request.
				$pageferry_lease = PageFerry_Workspace::acquire( $pageferry_candidate, $pageferry_basedir !== $pageferry_private_root );
				if ( is_wp_error( $pageferry_lease ) ) {
					continue;
				}
				try {
					PageFerry_Workspace::retire( $pageferry_candidate );
				} finally {
					PageFerry_Workspace::release( $pageferry_lease );
				}
			}
		}
	}
}

wp_cache_flush();
