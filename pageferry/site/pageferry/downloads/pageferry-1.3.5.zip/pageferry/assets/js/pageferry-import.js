(function () {
	'use strict';
	function initialize() {

	var __ = window.wp && window.wp.i18n ? window.wp.i18n.__ : function (text) { return text; };
	var form = document.querySelector('form input[name="pageferry_zip"]');
	var workerUI = document.getElementById('pageferry-worker-ui');
	var progress = document.getElementById('pageferry-worker-progress');
	var indeterminate = document.getElementById('pageferry-worker-indeterminate');
	var status = document.getElementById('pageferry-worker-status');

	if (!form || !workerUI || !progress || !status) {
		return;
	}

	var fileInput = form;
	var uploadForm = fileInput.closest('form');

	if (!uploadForm || uploadForm.dataset.importMounted) {
		return;
	}
	uploadForm.dataset.importMounted = '1';

	var activeWorker = null;
	var jobActive = false;
	var preparationCancellable = false;
	var activeGeneration = 0;
	var activeAbortController = null;
	var activeTransfer = null;
	var submitButton = (uploadForm.querySelector ? uploadForm.querySelector('.pf-prepare') : null);
	var cancelButton = (document.getElementById ? document.getElementById('pageferry-worker-cancel') : null);

	var frozenTarget = null;
	var frozenTargetPostId = null;
	var pendingPlanToken = null;
	var frozenPostType = null;
	var frozenSelection = null;
	var reviewContext = null;
	var reviewMount = document.getElementById('pf-worker-review');

	function targetControls() {
		var controls = [];

		if (!uploadForm || !uploadForm.querySelectorAll) {
			return controls;
		}

		try {
			var found = uploadForm.querySelectorAll('input[name="pageferry_target"], select[name="pageferry_target_post"], input[name="pageferry_post_type"]');

			for (var i = 0; i < found.length; i++) {
				controls.push(found[i]);
			}
		} catch (ignore) {
		}

		document.querySelectorAll('#pageferry-post-type, #pageferry-target-search, .pf-find-posts, .pf-target-choice').forEach(function (control) { controls.push(control); });
		return controls;
	}

	function setTargetControlsDisabled(disabled) {
		var controls = targetControls();

		for (var i = 0; i < controls.length; i++) {
			if (controls[i] && 'disabled' in controls[i]) {
				controls[i].disabled = disabled;
			}
		}
	}

	function readTargetSelection() {
		var target = uploadForm.querySelector ? uploadForm.querySelector('input[name="pageferry_target"]:checked') : null;
		var targetPost = uploadForm.querySelector ? uploadForm.querySelector('select[name="pageferry_target_post"]') : null;

		return {
			target: target && target.value === 'update' ? 'update' : 'create',
			targetPostId: targetPost ? targetPost.value : 0,
			postType: uploadForm.querySelector('[name="pageferry_post_type"]') ? uploadForm.querySelector('[name="pageferry_post_type"]').value : null
		};
	}

	function setStatus(message) {
		status.textContent = message;
	}

	function setIndeterminate() {
		progress.removeAttribute('value'); progress.hidden = true;
		if (indeterminate) { indeterminate.hidden = false; }
	}

	function setProgress(done, total) {
		progress.hidden = false;
		if (indeterminate) { indeterminate.hidden = true; }
		progress.max = total > 0 ? total : 100;
		progress.value = done;
	}

	function setJobActive(on, cancellable) {
		jobActive = on;
		preparationCancellable = on && cancellable !== false;
		uploadForm.dataset.preparing = on ? '1' : '';
		var setupRoot = uploadForm.closest('.pf-upload');
		setupRoot.classList.toggle('pf-preparing', on);
		setupRoot.querySelector('.pf-heading h2').textContent = on ? __('Preparing your review', 'pageferry') : __('Import a page', 'pageferry');
		setupRoot.querySelector('.pf-heading p').textContent = on ? __('Your page has not been imported yet.', 'pageferry') : __('Choose a ZIP and where its content should go.', 'pageferry');
		if (on) { window.pageferryReview.reveal(setupRoot); }
		if (!on) { uploadForm.dispatchEvent(new Event('pageferry:setup-enabled')); }
		if (submitButton && 'disabled' in submitButton) {
			submitButton.disabled = on;
		}
		if (cancelButton && 'hidden' in cancelButton) {
			cancelButton.hidden = !preparationCancellable;
		}
	}

	function endJob() {
		if (activeWorker) {
			try {
				activeWorker.terminate();
			} catch (ignore) {
			}
			activeWorker = null;
		}
		activeAbortController = null;
		activeTransfer = null;
		frozenTarget = null;
		frozenTargetPostId = null;
		pendingPlanToken = null;
		frozenPostType = null;
		frozenSelection = null;
		setTargetControlsDisabled(false);
		setJobActive(false);
		var update = uploadForm.querySelector('[name="pageferry_target"]:checked').value === 'update';
		uploadForm.querySelector('[name="pageferry_target_post"]').disabled = !update;
	}

	function cancelActiveJob() {
		if (!jobActive || !preparationCancellable) {
			return;
		}
		// Invalidate callbacks before aborting; a fetch may already be resolving.
		activeGeneration += 1;
		if (activeAbortController && typeof activeAbortController.abort === 'function') {
			try {
				activeAbortController.abort();
			} catch (ignore) {
			}
		}
		setStatus(__('Preparation cancelled. The page was not imported. Temporary files may remain until cleanup. You can prepare again.', 'pageferry'));
		endJob();
		window.pageferryReview.reveal(uploadForm.closest('.pf-upload'));
	}

	if (cancelButton && typeof cancelButton.addEventListener === 'function') {
		cancelButton.addEventListener('click', function () {
			cancelActiveJob();
		});
	}

	function restUrl(path) {
		var root = window.pageferryImport.restRoot || '/wp-json/';
		if (root.charAt(root.length - 1) !== '/') {
			root += '/';
		}
		var namespace = window.pageferryImport.namespace || 'pageferry/v1';
		return root + namespace + path;
	}

	function restHeaders(extra) {
		var headers = { 'X-WP-Nonce': window.pageferryImport.nonce };
		if (extra) {
			for (var key in extra) {
				if (Object.prototype.hasOwnProperty.call(extra, key)) {
					headers[key] = extra[key];
				}
			}
		}
		return headers;
	}

	function uploadOneFile(sessionId, name, blob, attempt, displayName, signal, generation) {
		if (generation !== activeGeneration) { return Promise.reject(new Error('Import cancelled.')); }
		var data = new FormData();
		data.append('session_id', sessionId);
		data.append('file', blob, name);

		var options = {
			method: 'POST',
			credentials: 'same-origin',
			headers: restHeaders(),
			body: data
		};

		if (signal) {
			options.signal = signal;
		}

		return fetch(restUrl('/import/file'), options).then(function (response) {
			if (generation !== activeGeneration) { throw new Error('Import cancelled.'); }
			if (!response.ok) {
				if (response.status >= 500 && attempt < 3) {
					return uploadOneFile(sessionId, name, blob, attempt + 1, displayName, signal, generation);
				}
				throw new Error('Upload failed for ' + (displayName || name) + ' (HTTP ' + response.status + ').');
			}
			return response.json();
		});
	}

	function runWorkerPath(zipFile) {
		if (jobActive) {
			setStatus('An import is already in progress. Finish or cancel it before starting another.');
			return;
		}

		workerUI.hidden = false;
		setStatus(__('Inspecting the ZIP in the browser…', 'pageferry'));
		setIndeterminate();
		// Freeze the target so the confirmed write cannot drift from the prepared destination.
		var initialTarget = readTargetSelection();
		frozenTarget = initialTarget.target;
		frozenTargetPostId = initialTarget.targetPostId;
		frozenPostType = initialTarget.postType;
		frozenSelection = null;
		pendingPlanToken = null;
		if (reviewMount) { reviewMount.replaceChildren(); }
		setJobActive(true);
		setTargetControlsDisabled(true);

		activeGeneration += 1;
		var generation = activeGeneration;

		if (typeof AbortController !== 'undefined') {
			try {
				activeAbortController = new AbortController();
			} catch (error) {
				activeAbortController = null;
			}
		} else {
			activeAbortController = null;
		}

		var worker;
		try {
			worker = new Worker(window.pageferryImport.workerUrl);
		} catch (error) {
			setStatus('This browser blocked the import worker. Use a smaller ZIP or raise the upload limit.');
			frozenTarget = null;
			frozenTargetPostId = null;
			pendingPlanToken = null;
			setTargetControlsDisabled(false);
			setJobActive(false);
			activeAbortController = null;
			return;
		}

		activeWorker = worker;

		var protocol = 'manifest';
		var transferLimits = null;
		function protocolFailure(error) {
			if (generation !== activeGeneration) { return; }
			activeGeneration += 1;
			if (activeAbortController) { try { activeAbortController.abort(); } catch (ignore) {  } }
			setStatus(error.message || 'Invalid import worker protocol.');
			endJob();
		}
		worker.onmessage = function (event) {
			if (generation !== activeGeneration || !jobActive) { return; }
			var message = event.data || {};
			try {
				if (message.type === 'error') { throw new Error(message.message || 'The worker could not read that ZIP.'); }
				if (message.type === 'manifest' && protocol === 'manifest') {
					protocol = 'validate';
					startSession(message.manifest, message.files, generation).then(function (plan) {
						if (generation !== activeGeneration) { return; }
						transferLimits = plan.limits;
						activeTransfer = { sessionId: plan.sessionId, queue: plan.files, total: plan.total, completed: plan.completed, parts: null, bytes: 0 };
						protocol = 'file';
						worker.postMessage({ type: 'plan', files: plan.files.map(function (file) { return file.name; }), limits: plan.limits });
					}).catch(protocolFailure);
				} else if (message.type === 'file-start' && protocol === 'file' && activeTransfer && activeTransfer.queue.length) {
					var expected = activeTransfer.queue[0];
					if (message.name !== expected.name || message.size !== expected.size || message.size > transferLimits.media_file_bytes) { throw new Error('Invalid import file metadata.'); }
					activeTransfer.parts = []; activeTransfer.bytes = 0; protocol = 'chunks';
				} else if (message.type === 'file-chunk' && protocol === 'chunks') {
					if (message.name !== activeTransfer.queue[0].name || !(message.data instanceof ArrayBuffer) || !message.data.byteLength || message.data.byteLength > 65536 || message.data.byteLength > activeTransfer.queue[0].size - activeTransfer.bytes) { throw new Error('Invalid import file chunk.'); }
					activeTransfer.bytes += message.data.byteLength; activeTransfer.parts.push(message.data);
				} else if (message.type === 'file-end' && protocol === 'chunks') {
					var next = activeTransfer.queue[0];
					if (message.name !== next.name || message.size !== next.size || activeTransfer.bytes !== next.size) { throw new Error('Incomplete import file.'); }
					protocol = 'upload';
					var blob = new Blob(activeTransfer.parts); activeTransfer.parts = null;
					setStatus(__('Uploading media:', 'pageferry') + ' ' + (activeTransfer.completed + 1) + ' / ' + activeTransfer.total + ' · ' + next.display);
					var signal = activeAbortController ? activeAbortController.signal : null;
					uploadOneFile(activeTransfer.sessionId, next.name, blob, 1, next.display, signal, generation).then(function () {
						blob = null;
						if (generation !== activeGeneration) { return; }
						activeTransfer.queue.shift(); activeTransfer.completed += 1;
						setProgress(activeTransfer.completed, activeTransfer.total); protocol = 'file';
						worker.postMessage({ type: 'ack', name: next.name });
					}).catch(function (error) { blob = null; protocolFailure(error); });
				} else if (message.type === 'done' && protocol === 'file' && activeTransfer && !activeTransfer.queue.length) {
					protocol = 'commit';
					var sessionId = activeTransfer.sessionId; activeTransfer = null;
					setStatus(__('All files uploaded. Preparing the review…', 'pageferry')); setIndeterminate(); commitSession(sessionId, worker, false, generation);
				} else { throw new Error('Invalid import worker protocol.'); }
			} catch (error) { protocolFailure(error); }
		};

		worker.onerror = function () {
			if (generation !== activeGeneration) {
				return;
			}
			protocolFailure(new Error('The worker could not read that ZIP.'));
		};

		// FormData cannot cross the worker boundary; File can.
		try {
			worker.postMessage({ file: zipFile, limits: window.pageferryImport.limits });
		} catch (error) {
			setStatus('The browser could not send that ZIP to the import worker. Select the file again.');
			endJob();
		}
	}

	/**
	 * Keeps picker hints and submit routing consistent.
	 *
	 * @param {File} picked Chosen ZIP file.
	 * @return {boolean} True when the worker path handles the upload.
	 */
	function isPathBBundle(picked) {
		// Localized flags are strings; stale enqueues without hasZip retain size-based routing.
		var serverZipMissing = window.pageferryImport && window.pageferryImport.hasZip === '0';

		return !!(picked && (serverZipMissing || picked.size > window.pageferryImport.maxBytes));
	}

	function effectiveLimits(input) {
		var defaults = { media_file_bytes: 268435456, path_b_bytes: 536870912, core_bytes: 1073741824, required_files: 500 };
		Object.keys(defaults).forEach(function (key) {
			var local = window.pageferryImport.limits && window.pageferryImport.limits[key];
			if (Number.isSafeInteger(local) && local > 0) { defaults[key] = Math.min(defaults[key], local); }
			if (input && Number.isSafeInteger(input[key]) && input[key] > 0) { defaults[key] = Math.min(defaults[key], input[key]); }
		});
		return defaults;
	}

	function startSession(manifest, files, generation) {
		if (!Array.isArray(files) || files.some(function (file) { return !file || typeof file.name !== 'string' || !Number.isSafeInteger(file.size) || file.size < 0 || file.data; })) { return Promise.reject(new Error('Invalid worker manifest metadata.')); }
		var validateOptions = {
			method: 'POST', credentials: 'same-origin', headers: restHeaders({ 'Content-Type': 'application/json' }), body: JSON.stringify({ manifest: manifest, target_post_type: frozenPostType, target: frozenTarget, target_post_id: frozenTargetPostId })
		};
		if (activeAbortController) { validateOptions.signal = activeAbortController.signal; }
		return fetch(restUrl('/import/validate'), validateOptions).then(function (response) {
			return response.json().then(function (body) { return { ok: response.ok, status: response.status, body: body }; });
		}).then(function (result) {
			if (generation !== activeGeneration) { return; }
			if (!result.ok) { throw new Error((result.body && result.body.message) || 'The server refused the manifest (HTTP ' + result.status + ').'); }
			frozenSelection = result.body.review_selection || null;
			if (!result.body.session_id || !Array.isArray(result.body.plan)) { throw new Error('Invalid server upload plan.'); }
			var received = Object.create(null), planned = Object.create(null), displayNames = Object.create(null), seen = Object.create(null), budget = 0;
			if (Array.isArray(result.body.received)) { result.body.received.forEach(function (name) { received[name] = true; }); }
			else { Object.keys(result.body.received || {}).forEach(function (name) { if (result.body.received[name] === true) { received[name] = true; } }); }
			result.body.plan.forEach(function (item) { if (item && typeof item.file === 'string' && item.file) { planned[item.file.split('/').pop()] = true; } });
			(manifest.media || []).forEach(function (entry) { if (entry && typeof entry.file === 'string') { displayNames[entry.file] = typeof entry.filename === 'string' && entry.filename ? entry.filename.split('/').pop() : entry.file; } });
			var bounds = effectiveLimits(result.body.limits);
			var selected = files.filter(function (file) { return planned[file.name]; }).map(function (file) {
				if (seen[file.name] || file.size > bounds.media_file_bytes) { throw new Error('The media exceeds the import resource limit.'); }
				seen[file.name] = true; budget += file.size;
				return { name: file.name, size: file.size, display: displayNames[file.name] || file.name };
			});
			if (Object.keys(planned).some(function (name) { return !seen[name]; }) || selected.length > bounds.required_files || budget > Math.min(bounds.path_b_bytes, bounds.core_bytes)) { throw new Error('The upload plan exceeds the import resource limit or is incomplete.'); }
			var queue = selected.filter(function (file) { return !received[file.name]; });
			setProgress(selected.length - queue.length, selected.length);
			return { sessionId: result.body.session_id, files: queue, total: selected.length, completed: selected.length - queue.length, limits: bounds };
		});
	}

	function commitSession(sessionId, worker, confirmed, generation, nextSelection, localReview) {
		if (generation !== activeGeneration) {
			return;
		}

		// The server may finish a dispatched write after abort, so cancellation cannot be promised.
		if (confirmed && cancelButton && 'hidden' in cancelButton) {
			cancelButton.hidden = true;
		}

		if (nextSelection) { frozenSelection = nextSelection; }
		var commitBody = {
			prepare_review: !confirmed,
			local_review: !!(confirmed && localReview),
			session_id: sessionId,
			target: frozenTarget,
			target_post_id: frozenTargetPostId,
			target_post_type: frozenPostType,
			confirm: confirmed
		};
		if (frozenSelection) { commitBody.selection = frozenSelection; }

		if (confirmed && pendingPlanToken) {
			commitBody.plan_token = pendingPlanToken;
		}

		if (!confirmed && reviewMount && reviewMount.querySelector('.pf-review-form')) {
			var focused = document.activeElement;
			reviewContext = { id: focused.id, refresh: focused.classList.contains('pf-refresh'), scroll: window.scrollY };
		}
		var commitOptions = {
			method: 'POST',
			credentials: 'same-origin',
			headers: restHeaders({ 'Content-Type': 'application/json' }),
			body: JSON.stringify(commitBody)
		};

		if (activeAbortController && activeAbortController.signal) {
			commitOptions.signal = activeAbortController.signal;
		}

		fetch(restUrl('/import/commit'), commitOptions)
			.then(function (response) {
				return response.json().then(function (body) {
					return { ok: response.ok, status: response.status, body: body };
				});
			})
			.then(function (result) {
				if (generation !== activeGeneration) {
					return;
				}

				if (!result.ok) {
					if (result.body && result.body.data && result.body.data.result_html) {
						endJob(); reviewMount.innerHTML = result.body.data.result_html; document.dispatchEvent(new Event('pageferry:result')); window.pageferryReview.reveal(reviewMount.querySelector('.pf-result')); return;
					}
					var failure = new Error((result.body && result.body.message) || 'Commit failed (HTTP ' + result.status + ').');
					var facts = result.body && result.body.data;
					if (facts && facts.import_started === false) { failure.refusal = facts.recovery === 'retry' ? 'retry' : 'prepare'; }
					// Core rejects these errors before the commit callback can run.
					else if (result.body && ((result.body.code === 'rest_invalid_param' && result.status === 400) || (result.body.code === 'rest_cookie_invalid_nonce' && result.status === 403) || (result.body.code === 'rest_forbidden' && [401, 403].indexOf(result.status) !== -1))) { failure.refusal = result.body.code === 'rest_invalid_param' ? 'retry' : 'prepare'; }
					throw failure;
				}

				if (result.body.preview && !result.body.post_id) {
					if (!result.body.plan_token) {
						setStatus('The preview did not issue a confirmation. Start the import again.');
						endJob();
						return;
					}

					pendingPlanToken = result.body.plan_token;

					frozenSelection = result.body.preview.review.selection;
					if (!reviewMount || !result.body.review_html || !window.pageferryReview) { throw new Error('The review could not be displayed. Reload and try again.'); }
					// Trust only escaped HTML from the authenticated same-origin renderer.
					var pendingEdits = window.pageferryReview.pending ? window.pageferryReview.pending(reviewMount) : null;
					reviewMount.innerHTML = result.body.review_html;
					window.pageferryReview.mount(reviewMount, function (selection, execute, planToken, localReview) {
						if (generation !== activeGeneration || !jobActive) { return; }
						if (execute && planToken) { pendingPlanToken = planToken; }
						commitSession(sessionId, worker, execute, generation, selection, localReview);
					});
					if (window.pageferryReview.restore) { window.pageferryReview.restore(reviewMount, pendingEdits); }
					uploadForm.closest('.pf-upload').hidden = true;
					if (reviewContext && !pendingEdits) {
						var restore = reviewContext.id ? document.getElementById(reviewContext.id) : reviewMount.querySelector('.pf-confirm');
						if (restore) { restore.focus({ preventScroll: true }); }
						window.scrollTo(0, reviewContext.scroll); reviewContext = null;
					} else if (!pendingEdits) { window.pageferryReview.reveal(reviewMount.querySelector('.pf-review')); }
					reviewContext = null;
					return;
				}

				if (!result.body || !Number.isInteger(Number(result.body.post_id)) || Number(result.body.post_id) <= 0) {
					throw new Error(__('The server did not return a confirmed import result.', 'pageferry'));
				}
				setProgress(1, 1);
				setStatus(__('Import finished. Opening the result…', 'pageferry'));
				endJob();

				if (reviewMount && result.body.result_html) {
					reviewMount.innerHTML = result.body.result_html;
					document.dispatchEvent(new Event('pageferry:result'));
					window.pageferryReview.reveal(reviewMount.querySelector('.pf-result'));
				} else if (result.body.edit_url) {
					window.location.href = result.body.edit_url;
				} else { window.location.reload(); }

			})
			.catch(function (error) {
				if (generation !== activeGeneration) {
					return;
				}
				setStatus(error.message);
				if (error.refusal && reviewMount && reviewMount.querySelector('.pf-review-form')) {
					if (error.refusal !== 'retry') { endJob(); }
					window.pageferryReview.refused(reviewMount, error.message, error.refusal);
					return;
				}
				if (reviewMount && reviewMount.querySelector('.pf-review-form')) {
					var reviewStatus = reviewMount.querySelector('.pf-review-status');
					if (reviewStatus) { reviewStatus.querySelector('span').textContent = error.message; reviewStatus.setAttribute('role', 'alert'); }
					if (!confirmed) {
						pendingPlanToken = null;
						reviewMount.querySelector('.pf-review-form').removeAttribute('aria-busy');
						reviewMount.querySelector('.pf-review').classList.remove('pf-review-executing');
						reviewMount.querySelector('.pf-execution-working').hidden = true;
						reviewMount.querySelector('.pf-heading h2').textContent = __('Review your import', 'pageferry');
						reviewMount.querySelector('.pf-heading p').textContent = __('Edit the details and see every item before importing.', 'pageferry');
						reviewMount.querySelector('.pf-review-form').classList.add('pf-review-dirty');
						reviewMount.querySelectorAll('input, button, textarea, select').forEach(function (input) { input.disabled = false; });
						var confirmButton = reviewMount.querySelector('.pf-confirm');
						if (confirmButton) { confirmButton.disabled = true; }
						if (window.pageferryReview.failed) { window.pageferryReview.failed(reviewMount, error.message, false); }
						return;
					}
				}
				var unconfirmedDestination = { id: frozenTargetPostId, type: frozenPostType, title: reviewMount?.querySelector('.pf-identity > div:last-child strong')?.textContent };
				endJob();
				if (confirmed && reviewMount) { window.pageferryReview.unconfirmed(reviewMount, unconfirmedDestination); }
			});
	}

	fileInput.addEventListener('change', function () {
		var picked = fileInput.files && fileInput.files[0];

		if (!picked) {
			return;
		}

		if (jobActive) {
			setStatus('An import is already in progress. Finish or cancel it before starting another.');
			return;
		}

		if (!isPathBBundle(picked)) {
			workerUI.hidden = true;
			return;
		}

		if (typeof Worker === 'undefined' || typeof window.fflate === 'undefined') {
			setStatus('Large-bundle path needs Web Workers + the bundled fflate. Use a smaller ZIP or raise the upload limit.');
			workerUI.hidden = false;
			return;
		}

		workerUI.hidden = true;
		setStatus('Large bundle selected. Press "Prepare review" to start the browser upload.');
	});

	uploadForm.addEventListener('submit', function (event) {
		if (event.submitter && event.submitter.classList.contains('pf-find-posts')) { return; }
		var picked = fileInput.files && fileInput.files[0];
		if (uploadForm.querySelector('[name="pageferry_target"]:checked').value === 'update' && !uploadForm.querySelector('[name="pageferry_target_post"]').value) { event.preventDefault(); return; }
		if (event.defaultPrevented || uploadForm.dataset.metaPending === '1' || !document.getElementById('pageferry-post-type').checkValidity()) { event.preventDefault(); return; }
		if (jobActive) { event.preventDefault(); return; }

		if (isPathBBundle(picked)) {
			event.preventDefault();
			runWorkerPath(picked);
		} else {
			setJobActive(true, false); submitButton.disabled = true;
			workerUI.hidden = false; setIndeterminate();
			setStatus(__('Preparing your review… Files are staged before you confirm the import.', 'pageferry'));
		}
	});
	}
	document.addEventListener('pageferry:tab-ready', initialize);
	initialize();
})();
