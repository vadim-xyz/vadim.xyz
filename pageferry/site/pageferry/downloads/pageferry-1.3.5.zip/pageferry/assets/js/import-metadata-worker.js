/* global self, importScripts, PageFerryZip */
importScripts('vendor/fflate.min.js', 'import-zip-reader.js');
self.onmessage = async function (event) {
	try {
		var reader = await new PageFerryZip.Reader(event.data.file, event.data.limits).index();
		var result = await reader.manifest();
		self.postMessage({ title: typeof result.manifest.post.title === 'string' ? result.manifest.post.title : '', post_type: result.manifest.post.post_type });
	} catch (error) { self.postMessage({ error: error.message || 'Could not read the ZIP metadata.' }); }
};
