/* ZIP structure: PKWARE APPNOTE 6.3.10; decoder: fflate 0.8.3. */
(function (root) {
	'use strict';
	var defaults = { manifest_bytes: 4194304, required_files: 500, media_records: 5000, media_file_bytes: 268435456, path_b_bytes: 536870912, core_bytes: 1073741824, zip_bytes: 1073741824, zip_entries: 2048, zip_metadata_bytes: 16777216, zip_name_bytes: 4096 };
	function limits(input, base) {
		var result = {};
		Object.keys(defaults).forEach(function (key) {
			var ceiling = base ? base[key] : defaults[key];
			result[key] = input && Number.isSafeInteger(input[key]) && input[key] > 0 ? Math.min(ceiling, input[key]) : ceiling;
		});
		return result;
	}
	function refuse(message) { throw new Error(message || 'That ZIP has invalid or unsupported metadata.'); }
	function bound(value, maximum) { if (!Number.isSafeInteger(value) || value < 0 || value > maximum) { refuse('The ZIP exceeds the import resource limit.'); } }
	function u64(view, offset) {
		var value = view.getUint32(offset, true) + view.getUint32(offset + 4, true) * 4294967296;
		if (!Number.isSafeInteger(value)) { refuse(); }
		return value;
	}
	var crcTable = new Uint32Array(256);
	for (var tableIndex = 0; tableIndex < 256; tableIndex++) {
		var tableValue = tableIndex;
		for (var bit = 0; bit < 8; bit++) { tableValue = (tableValue >>> 1) ^ ((tableValue & 1) ? 0xedb88320 : 0); }
		crcTable[tableIndex] = tableValue;
	}
	function crc(bytes, previous) {
		var value = previous === undefined ? -1 : previous;
		for (var i = 0; i < bytes.length; i++) { value = (value >>> 8) ^ crcTable[(value ^ bytes[i]) & 255]; }
		return value;
	}
	function extras(bytes) {
		var result = Object.create(null), view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), at = 0;
		while (at < bytes.length) {
			if (at + 4 > bytes.length) { refuse(); }
			var id = view.getUint16(at, true), length = view.getUint16(at + 2, true);
			if (at + 4 + length > bytes.length || result[id]) { refuse(); }
			result[id] = bytes.subarray(at + 4, at + 4 + length); at += 4 + length;
		}
		return result;
	}
	var cp437 = 'ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜ¢£¥₧ƒáíóúñÑªº¿⌐¬½¼¡«»░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀αßΓπΣσµτΦΘΩδ∞φε∩≡±≥≤⌠⌡÷≈°∙·√ⁿ²■ ';
	function nameOf(bytes, flags, extra) {
		var name;
		if (flags & 2048) { name = new TextDecoder('utf-8', { fatal: true }).decode(bytes); }
		else { name = Array.from(bytes, function (byte) { return byte < 128 ? String.fromCharCode(byte) : cp437[byte - 128]; }).join(''); }
		var unicode = extra[0x7075];
		if (unicode && unicode.length >= 5 && unicode[0] === 1 && new DataView(unicode.buffer, unicode.byteOffset).getUint32(1, true) === ((crc(bytes) ^ -1) >>> 0)) {
			name = new TextDecoder('utf-8', { fatal: true }).decode(unicode.subarray(5));
		}
		if (name.indexOf('\0') !== -1 || name.indexOf('\\') !== -1) { refuse('Unsafe archive path.'); }
		return name;
	}
	function sizes(view, extra, local) {
		var size = view.getUint32(local ? 22 : 24, true), compressed = view.getUint32(local ? 18 : 20, true), offset = local ? 0 : view.getUint32(42, true), disk = local ? 0 : view.getUint16(34, true);
		if (size === 0xffffffff || compressed === 0xffffffff || offset === 0xffffffff || disk === 0xffff) {
			var bytes = extra[1], at = 0;
			if (!bytes) { refuse(); }
			var zip64 = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
			function next() { if (at + 8 > bytes.length) { refuse(); } var value = u64(zip64, at); at += 8; return value; }
			if (size === 0xffffffff) { size = next(); }
			if (compressed === 0xffffffff) { compressed = next(); }
			if (offset === 0xffffffff) { offset = next(); }
			if (disk === 0xffff) { if (at + 4 > bytes.length) { refuse(); } disk = zip64.getUint32(at, true); }
		}
		if (disk !== 0) { refuse('Multidisk ZIP archives are unsupported.'); }
		return { size: size, compressed: compressed, offset: offset };
	}
	function Reader(blob, input) {
		this.blob = blob; this.limits = limits(input); this.entries = []; this.byName = Object.create(null);
		bound(blob.size, this.limits.zip_bytes);
	}
	Reader.prototype.read = async function (start, length) {
		bound(start, this.blob.size); bound(length, this.blob.size - start);
		var bytes = new Uint8Array(await this.blob.slice(start, start + length).arrayBuffer());
		if (bytes.length !== length) { refuse('The ZIP could not be read completely.'); }
		return bytes;
	};
	Reader.prototype.index = async function () {
		// EOCD can have a 64 KiB comment; its signature need not be at the file end.
		var length = Math.min(this.blob.size, 65557), tail = await this.read(this.blob.size - length, length), view = new DataView(tail.buffer), at;
		for (at = length - 22; at >= 0; at--) { if (view.getUint32(at, true) === 0x06054b50 && at + 22 + view.getUint16(at + 20, true) === length) { break; } }
		if (at < 0 || view.getUint16(at + 4, true) || view.getUint16(at + 6, true)) { refuse(); }
		var count = view.getUint16(at + 10, true), centralSize = view.getUint32(at + 12, true), centralAt = view.getUint32(at + 16, true), end = this.blob.size - length + at;
		if (view.getUint16(at + 8, true) !== count) { refuse(); }
		if (count === 65535 || centralSize === 0xffffffff || centralAt === 0xffffffff) {
			var locator = new DataView((await this.read(end - 20, 20)).buffer);
			if (locator.getUint32(0, true) !== 0x07064b50 || locator.getUint32(4, true) || locator.getUint32(16, true) !== 1) { refuse(); }
			var zip64At = u64(locator, 8), record = new DataView((await this.read(zip64At, 56)).buffer);
			bound(u64(record, 4), this.limits.zip_metadata_bytes);
			if (record.getUint32(0, true) !== 0x06064b50 || record.getUint32(16, true) || record.getUint32(20, true) || u64(record, 4) < 44 || zip64At + 12 + u64(record, 4) !== end - 20) { refuse(); }
			count = u64(record, 32); if (count !== u64(record, 24)) { refuse(); }
			centralSize = u64(record, 40); centralAt = u64(record, 48); end = zip64At;
		}
		bound(count, this.limits.zip_entries); bound(centralSize, this.limits.zip_metadata_bytes);
		if (centralAt + centralSize !== end) { refuse(); }
		this.centralAt = centralAt;
		var central = await this.read(centralAt, centralSize), position = 0;
		for (var i = 0; i < count; i++) {
			if (position + 46 > central.length) { refuse(); }
			var header = new DataView(central.buffer, position), nameLength = header.getUint16(28, true), extraLength = header.getUint16(30, true), commentLength = header.getUint16(32, true), fullLength = 46 + nameLength + extraLength + commentLength;
			bound(nameLength, this.limits.zip_name_bytes);
			if (header.getUint32(0, true) !== 0x02014b50 || position + fullLength > central.length) { refuse(); }
			var rawName = central.slice(position + 46, position + 46 + nameLength), extra = extras(central.subarray(position + 46 + nameLength, position + 46 + nameLength + extraLength)), flags = header.getUint16(8, true), name = nameOf(rawName, flags, extra), info = sizes(header, extra, false);
			bound(new TextEncoder().encode(name).length, this.limits.zip_name_bytes);
			bound(info.offset, centralAt); bound(info.compressed, centralAt - info.offset);
			if (info.offset + 30 + nameLength > centralAt || info.compressed > centralAt - info.offset - 30 - nameLength) { refuse(); }
			if (name.slice(-1) !== '/' && (name.indexOf('..') !== -1 || name.charAt(0) === '/')) { refuse('Unsafe archive path.'); }
			info.name = name; info.rawName = rawName; info.flags = flags; info.method = header.getUint16(10, true); info.crc = header.getUint32(16, true);
			if (name === 'pageferry-manifest.json' || /^media\/[^/]+$/.test(name)) { if (this.byName[name]) { refuse('Duplicate archive entry.'); } this.byName[name] = info; }
			this.entries.push(info); position += fullLength;
		}
		if (position !== central.length) { refuse(); }
		return this;
	};
	Reader.prototype.prepare = async function (entry, maximum) {
		// Descriptor archives keep authoritative sizes in the central directory.
		if (!entry) { refuse('A required archive entry is missing.'); }
		bound(entry.size, maximum);
		if ((entry.flags & (1 | 64 | 8192)) || (entry.method !== 0 && entry.method !== 8)) { refuse('A required ZIP entry uses unsupported encryption or compression.'); }
		if (entry.offset + 30 > this.centralAt) { refuse(); }
		var fixed = new DataView((await this.read(entry.offset, 30)).buffer), nameLength = fixed.getUint16(26, true), extraLength = fixed.getUint16(28, true);
		bound(nameLength, this.limits.zip_name_bytes);
		if (fixed.getUint32(0, true) !== 0x04034b50 || fixed.getUint16(6, true) !== entry.flags || fixed.getUint16(8, true) !== entry.method) { refuse(); }
		var dataAt = entry.offset + 30 + nameLength + extraLength;
		if (dataAt + entry.compressed > this.centralAt) { refuse(); }
		var variable = await this.read(entry.offset + 30, nameLength + extraLength), rawName = variable.subarray(0, nameLength), extra = extras(variable.subarray(nameLength));
		if (rawName.length !== entry.rawName.length || rawName.some(function (byte, i) { return byte !== entry.rawName[i]; }) || ((extra[0x7075] || (entry.flags & 2048)) && nameOf(rawName, entry.flags, extra) !== entry.name)) { refuse(); }
		if (!(entry.flags & 8)) {
			var local = sizes(fixed, extra, true);
			if (local.size !== entry.size || local.compressed !== entry.compressed || fixed.getUint32(14, true) !== entry.crc) { refuse(); }
		} else {
			if ((fixed.getUint32(14, true) && fixed.getUint32(14, true) !== entry.crc) || (fixed.getUint32(18, true) !== 0 && fixed.getUint32(18, true) !== 0xffffffff && fixed.getUint32(18, true) !== entry.compressed) || (fixed.getUint32(22, true) !== 0 && fixed.getUint32(22, true) !== 0xffffffff && fixed.getUint32(22, true) !== entry.size)) { refuse(); }
			var descriptorAt = dataAt + entry.compressed, descriptor = new DataView((await this.read(descriptorAt, Math.min(24, this.centralAt - descriptorAt))).buffer), wide = !!extra[1];
			function matchesDescriptor(offset) {
				if (descriptor.byteLength < offset + (wide ? 20 : 12) || descriptor.getUint32(offset, true) !== entry.crc) { return false; }
				try {
					return (wide ? u64(descriptor, offset + 4) : descriptor.getUint32(offset + 4, true)) === entry.compressed && (wide ? u64(descriptor, offset + 12) : descriptor.getUint32(offset + 8, true)) === entry.size;
				} catch (invalidRange) { return false; }
			}
			// A descriptor CRC can equal the optional signature; match the complete layout.
			if (!matchesDescriptor(0) && !(descriptor.byteLength >= 4 && descriptor.getUint32(0, true) === 0x08074b50 && matchesDescriptor(4))) { refuse(); }
		}
		if (entry.method === 0 && entry.size !== entry.compressed) { refuse(); }
		entry.dataAt = dataAt;
		return entry;
	};
	Reader.prototype.extract = async function (entry, maximum, output) {
		await this.prepare(entry, maximum);
		var total = 0, checksum = -1, finalSeen = false;
		function retain(bytes, final) {
			if (bytes.length > maximum - total || bytes.length > entry.size - total) { refuse('The ZIP exceeds the import resource limit.'); }
			total += bytes.length; checksum = crc(bytes, checksum); finalSeen = !!final;
			if (bytes.length) { output(bytes); }
		}
		// fflate allocates before the callback; small compressed pushes bound that exposure.
		var inflater = entry.method === 8 ? new root.fflate.Inflate(retain) : null;
		for (var at = 0; at < entry.compressed; at += 1024) {
			var bytes = await this.read(entry.dataAt + at, Math.min(1024, entry.compressed - at)), final = at + bytes.length === entry.compressed;
			if (inflater) { inflater.push(bytes, final); } else { retain(bytes, final); }
		}
		if (!entry.compressed) { if (inflater) { inflater.push(new Uint8Array(0), true); } else { retain(new Uint8Array(0), true); } }
		if (!finalSeen || total !== entry.size || ((checksum ^ -1) >>> 0) !== entry.crc) { refuse('The ZIP entry is truncated or corrupt.'); }
		return total;
	};
	Reader.prototype.manifest = async function () {
		var parts = [], entry = this.byName['pageferry-manifest.json'];
		await this.extract(entry, this.limits.manifest_bytes, function (bytes) { parts.push(bytes.slice()); });
		var manifest;
		try { manifest = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(await new Blob(parts).arrayBuffer())); } catch (error) { refuse('The manifest in that ZIP is not valid JSON.'); }
		bound(new TextEncoder().encode(JSON.stringify(manifest)).length, this.limits.manifest_bytes);
		if (!manifest || typeof manifest !== 'object' || Array.isArray(manifest) || Number(manifest.manifest_version) !== 1 || !Array.isArray(manifest.media) || !manifest.post || typeof manifest.post !== 'object' || Array.isArray(manifest.post) || typeof manifest.post.content !== 'string' || typeof manifest.post.post_type !== 'string' || typeof manifest.post.slug !== 'string' || (typeof manifest.builder_detected === 'string' && manifest.builder_detected)) { refuse('Invalid PageFerry manifest.'); }
		bound(manifest.media.length, this.limits.media_records);
		var declared = Object.create(null), ids = Object.create(null), files = [], total = 0, declaredTotal = 0, aggregateLimit = Math.min(this.limits.path_b_bytes, this.limits.core_bytes);
		for (var i = 0; i < manifest.media.length; i++) {
			var item = manifest.media[i];
			if (!item || typeof item !== 'object' || !['string', 'number'].includes(typeof item.old_id) || !/^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/.test(String(item.old_id).trim()) || !Number.isFinite(Number(item.old_id)) || ids[Math.trunc(Number(item.old_id))]) { refuse('Invalid or duplicate media record.'); }
			ids[Math.trunc(Number(item.old_id))] = true;
			if (item.missing) { continue; }
			if (typeof item.file !== 'string' || !item.file || item.file.indexOf('/') !== -1 || item.file.indexOf('\\') !== -1 || item.file.indexOf('..') !== -1 || typeof item.sha256 !== 'string' || !item.sha256 || declared[item.file]) { refuse('Invalid or duplicate media filename/hash.'); }
			declared[item.file] = true;
			var media = await this.prepare(this.byName['media/' + item.file], this.limits.media_file_bytes);
			if (item.bytes !== undefined) { bound(Number(item.bytes), this.limits.media_file_bytes); declaredTotal += Number(item.bytes); bound(declaredTotal, aggregateLimit); }
			total += media.size; bound(total, aggregateLimit);
			files.push({ name: item.file, size: media.size }); bound(files.length, this.limits.required_files);
		}
		this.entries.forEach(function (item) {
			var basename = item.name.split('/').pop();
			if (item.name.indexOf('media/') === 0 && declared[basename] && item.name !== 'media/' + basename) { refuse('Nested aliases of required media are forbidden.'); }
		});
		return { manifest: manifest, files: files };
	};
	root.PageFerryZip = { Reader: Reader, limits: limits };
})(typeof self !== 'undefined' ? self : globalThis);
