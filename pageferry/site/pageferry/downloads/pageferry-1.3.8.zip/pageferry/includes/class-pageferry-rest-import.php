<?php
/**
 * REST import transport for PageFerry.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers the pageferry/v1 import routes.
 */
class PageFerry_Rest_Import {

	/**
	 * REST namespace for the import routes.
	 *
	 * @var string
	 */
	const NAMESPACE = 'pageferry/v1';

	/**
	 * Session time-to-live in seconds (~1 hour).
	 *
	 * @var int
	 */
	const SESSION_TTL = 3600;

	/** Receipt validation format; bump when the structural validation contract changes. */
	private const RECEIPT_CACHE_VERSION = 1;

	/**
	 * Registers routes on rest_api_init.
	 *
	 * @return void
	 */
	public static function register_routes(): void {
		register_rest_route(
			self::NAMESPACE,
			'/import/review',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_review' ),
				'permission_callback' => array( __CLASS__, 'check_permissions' ),
				'args'                => array(
					'transport' => array(
						'type'     => 'string',
						'enum'     => array( 'classic', 'rest' ),
						'required' => true,
					),
					'key'       => array(
						'type'      => 'string',
						'maxLength' => 100,
						'required'  => true,
					),
					'selection' => array(
						'type'     => 'object',
						'required' => true,
					),
				),
			)
		);
		register_rest_route(
			self::NAMESPACE,
			'/import/validate',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_validate' ),
				'permission_callback' => array( __CLASS__, 'check_permissions' ),
				'args'                => array(
					'target_post_type' => array(
						'type'     => 'string',
						'required' => false,
					),
					'manifest'         => array(
						'type'     => 'object',
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/import/file',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_file' ),
				'permission_callback' => array( __CLASS__, 'check_permissions' ),
				'args'                => array(
					'session_id' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/import/commit',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_commit' ),
				'permission_callback' => array( __CLASS__, 'check_permissions' ),
				'args'                => array(
					'target_post_type' => array(
						'type'     => 'string',
						'required' => false,
					),
					'selection'        => array(
						'type'     => 'object',
						'required' => false,
					),
					'local_review'     => array(
						'type'    => 'boolean',
						'default' => false,
					),
					'prepare_review'   => array(
						'type'    => 'boolean',
						'default' => false,
					),
					'session_id'       => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);
	}

	/**
	 * Caps raw validate JSON before WordPress parses parameters.
	 *
	 * @param mixed           $result Earlier pre-dispatch result.
	 * @param WP_REST_Server  $server REST server.
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public static function guard_validate_body( $result, WP_REST_Server $server, WP_REST_Request $request ) {
		if ( null !== $result || ! in_array( $request->get_route(), array( '/pageferry/v1/import/validate', '/pageferry/v1/import/commit', '/pageferry/v1/import/review' ), true ) || 'POST' !== $request->get_method() ) {
			return $result;
		}
		return strlen( $request->get_body() ) > PageFerry_Import_Resources::limits()['manifest_bytes'] + 65536 ? PageFerry_Import_Resources::exceeded() : $result;
	}

	/**
	 * Mirrors the import-screen capability.
	 *
	 * @return bool Whether the current user may import.
	 */
	public static function check_permissions(): bool {
		return current_user_can( 'import' );
	}

	/**
	 * Checks either transport's prepared choices without reading media files.
	 *
	 * @param WP_REST_Request $request Owner-bound key and choices.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function handle_review( WP_REST_Request $request ) {
		$classic = 'classic' === $request->get_param( 'transport' );
		$key     = (string) $request->get_param( 'key' );
		$load    = static function () use ( $classic, $key ) {
			return $classic ? PageFerry_Import_Admin::get_confirmation_stash( PageFerry_Import_Admin::sanitize_confirmation_key( $key ) ) : self::get_session( $key );
		};
		$record  = $load();
		if ( is_wp_error( $record ) ) {
			return $record;
		}
		if ( ! is_array( $record ) ) {
			return new WP_Error( 'pageferry_session_expired', __( 'This review expired. Select the ZIP and prepare again.', 'pageferry' ), array( 'status' => 410 ) );
		}
		return PageFerry_Workspace::with_lease(
			$record['workspace'],
			static function () use ( $request, $classic, $key, $load ) {
				$live = $load();
				if ( ! is_array( $live ) ) {
					return is_wp_error( $live ) ? $live : new WP_Error( 'pageferry_session_expired', __( 'This review expired. Select the ZIP and prepare again.', 'pageferry' ), array( 'status' => 410 ) );
				}
				if ( ! is_array( $live['review_model'] ?? null ) ) {
					return new WP_Error( 'pageferry_review_stale', __( 'This review needs a new preparation. Select the ZIP and prepare again.', 'pageferry' ), array( 'status' => 409 ) );
				}
				if ( ! $classic && ! is_array( $live['plan'] ?? null ) ) {
					return new WP_Error( 'pageferry_plan_missing', __( 'This review needs a new preparation. Select the ZIP and prepare again.', 'pageferry' ), array( 'status' => 409 ) );
				}
				$plan   = $classic ? $live : $live['plan'];
				$result = PageFerry_Importer::check_review(
					$live['manifest'],
					$live['review_model'],
					array(
						'target'         => $plan['target'],
						'target_post_id' => $plan['target_post_id'],
						'status'         => $plan['status'] ?? '',
						'selection'      => $request->get_param( 'selection' ),
					)
				);
				if ( is_wp_error( $result ) ) {
					return $result;
				}
				$live['plan_token'] = 'pf-' . wp_generate_password( 24, false );
				if ( $classic ) {
					$live['selection']          = $result['selection'];
					$live['warnings']           = $result['warnings'];
					$live['target_modified']    = $result['target_modified'];
					$live['target_fingerprint'] = $result['target_fingerprint'];
				} else {
					$live['plan']['selection']          = $result['selection'];
					$live['plan']['target_modified']    = $result['target_modified'];
					$live['plan']['target_fingerprint'] = $result['target_fingerprint'];
				}
				$transient = ( $classic ? PageFerry::TRANSIENT_IMPORT_PREFIX : PageFerry::TRANSIENT_SESSION_PREFIX ) . $key;
				set_transient( $transient, $live, self::SESSION_TTL );
				if ( get_transient( $transient ) !== $live ) {
					return new WP_Error( 'pageferry_session_persistence', __( 'The review could not be saved. Try again.', 'pageferry' ), array( 'status' => 500 ) );
				}
				$result['plan_token'] = $live['plan_token'];
				return rest_ensure_response( $result );
			},
			1000
		);
	}

	/**
	 * Validates a manifest, creates a session + workspace, returns the plan.
	 *
	 * @param WP_REST_Request $request REST request with a manifest param.
	 * @return WP_REST_Response|WP_Error Session plan or error.
	 */
	public static function handle_validate( WP_REST_Request $request ) {
		$manifest = $request->get_param( 'manifest' );

		if ( ! is_array( $manifest ) ) {
			return new WP_Error(
				'pageferry_manifest_invalid',
				__( 'The page information was not received. Select the ZIP again and prepare a new review.', 'pageferry' ),
				array( 'status' => 400 )
			);
		}

		$requested_type = $request->get_param( 'target_post_type' );
		if ( null !== $requested_type && ! is_string( $requested_type ) ) {
			return new WP_Error( 'pageferry_unsupported_post_type', __( 'Choose an available content type, such as Page or Post.', 'pageferry' ), array( 'status' => 400 ) );
		}
		$validated = PageFerry_Importer::validate( $manifest, $requested_type );

		if ( $validated instanceof WP_Error ) {
			if ( ! is_array( $validated->get_error_data() ) || ! isset( $validated->get_error_data()['status'] ) ) {
				$validated->add_data( array( 'status' => 400 ) );
			}
			return $validated;
		}

		$media_cap_error = PageFerry_Importer::check_media_upload_capability( $validated['media_index'] );

		if ( $media_cap_error instanceof WP_Error ) {
			$media_cap_error->add_data( array( 'status' => 403 ) );
			return $media_cap_error;
		}

		$limits         = PageFerry_Import_Resources::limits();
		$limit_bytes    = $limits['media_file_bytes'];
		$plan           = array();
		$declared_total = 0;

		foreach ( $validated['media_index'] as $media_state ) {
			if ( $media_state['missing'] ) {
				continue;
			}

			$file_name   = (string) $media_state['entry']['file'];
			$entry_bytes = isset( $media_state['entry']['bytes'] ) && is_numeric( $media_state['entry']['bytes'] )
				? (int) $media_state['entry']['bytes']
				: 0;

			if ( 0 < $limit_bytes && 0 < $entry_bytes && $limit_bytes < $entry_bytes ) {
				return new WP_Error(
					'pageferry_media_too_large',
					sprintf(
						/* translators: 1: media file name, 2: human-readable size limit. */
						__( 'Media file %1$s exceeds the file size limit of %2$s. Reduce its size and export again, or ask your host to raise a lower upload limit.', 'pageferry' ),
						PageFerry_Importer::original_filename( $media_state['entry'] ),
						size_format( $limit_bytes )
					),
					array( 'status' => 400 )
				);
			}

			if ( $entry_bytes > min( $limits['path_b_bytes'], $limits['core_bytes'] ) - $declared_total ) {
				return PageFerry_Import_Resources::exceeded();
			}
			$declared_total += max( 0, $entry_bytes );
			$plan[]          = array(
				'file'     => $file_name,
				'filename' => PageFerry_Importer::original_filename( $media_state['entry'] ),
				'bytes'    => $entry_bytes,
				'received' => false,
			);
		}

		$workspace = PageFerry_Importer::make_workspace( 'pageferry-session-' );

		if ( is_wp_error( $workspace ) ) {
			$workspace->add_data( array( 'status' => 500 ) );
			return $workspace;
		}

		// Each session reserves disk space, so bound creation per user.
		$quota_key   = PageFerry::TRANSIENT_QUOTA_PREFIX . get_current_user_id();
		$quota_used  = (int) get_transient( $quota_key );
		$quota_limit = 20;

		if ( $quota_limit <= $quota_used ) {
			PageFerry_Importer::remove_directory( $workspace );
			return new WP_Error(
				'pageferry_rate_limited',
				__( 'Too many imports have been started recently. Finish or cancel preparation for an open import, then try again later.', 'pageferry' ),
				array( 'status' => 429 )
			);
		}

		set_transient( $quota_key, $quota_used + 1, HOUR_IN_SECONDS );

		$session_id  = 'pf-' . wp_generate_password( 16, false );
		$session_key = PageFerry::TRANSIENT_SESSION_PREFIX . $session_id;
		$session     = array(
			'target_post_type' => $requested_type,
			'workspace'        => $workspace,
			'manifest'         => $validated['manifest'],
			'received'         => array(),
			'user_id'          => get_current_user_id(),
		);

		set_transient(
			$session_key,
			$session,
			self::SESSION_TTL
		);
		if ( get_transient( $session_key ) !== $session ) {
			self::destroy_session( $session_id, array( 'workspace' => $workspace ) );
			return new WP_Error(
				'pageferry_session_persistence',
				__( 'The import could not be prepared. Select the ZIP again and review the import.', 'pageferry' ),
				array( 'status' => 500 )
			);
		}

		$tracked = PageFerry_Workspace::bind_session( $workspace, PageFerry::TRANSIENT_SESSION_PREFIX . $session_id );
		if ( is_wp_error( $tracked ) ) {
			self::destroy_session( $session_id, array( 'workspace' => $workspace ) );
			return $tracked;
		}

		return rest_ensure_response(
			array(
				'review_selection' => PageFerry_Import_Selection::defaults( $validated['manifest'], 'update' === $request->get_param( 'target' ) ? absint( $request->get_param( 'target_post_id' ) ) : 0 ),
				'session_id'       => $session_id,
				'received'         => array(),
				'plan'             => $plan,
				'limits'           => $limits,
			)
		);
	}

	/**
	 * Stores ONE manifest-declared media file into the session workspace.
	 *
	 * @param WP_REST_Request $request REST request with session_id + file upload.
	 * @return WP_REST_Response|WP_Error Receipt or error.
	 */
	public static function handle_file( WP_REST_Request $request ) {
		$session = self::get_session( (string) $request->get_param( 'session_id' ) );
		if ( is_wp_error( $session ) ) {
			return $session;
		}
		return PageFerry_Workspace::with_lease(
			$session['workspace'],
			static function () use ( $request ) {
				// A preceding commit may have consumed the session while this request waited.
				return self::receive_file_leased( $request );
			}
		);
	}

	/**
	 * Receives one file while the session workspace is leased.
	 *
	 * @param WP_REST_Request $request File request.
	 * @return WP_REST_Response|WP_Error
	 */
	private static function receive_file_leased( WP_REST_Request $request ) {
		$session_id = (string) $request->get_param( 'session_id' );
		$session    = self::get_session( $session_id );

		if ( is_wp_error( $session ) ) {
			return $session;
		}
		$tracked = PageFerry_Workspace::bind_session( $session['workspace'], PageFerry::TRANSIENT_SESSION_PREFIX . $session_id );
		if ( is_wp_error( $tracked ) ) {
			return $tracked;
		}

		// Cached structure grants neither current upload authority nor a disk allowance.
		$validated = self::receipt_validation( $session );

		if ( $validated instanceof WP_Error ) {
			if ( in_array( $validated->get_error_code(), array( 'pageferry_resource_limit', 'pageferry_media_too_large' ), true ) ) {
				self::destroy_session( $session_id, $session );
			}
			if ( ! is_array( $validated->get_error_data() ) || ! isset( $validated->get_error_data()['status'] ) ) {
				$validated->add_data( array( 'status' => 400 ) );
			}
			return $validated;
		}

		$limits = PageFerry_Import_Resources::limits();
		$budget = min( $limits['path_b_bytes'], $limits['core_bytes'] );
		$usage  = PageFerry_Import_Resources::usage( $session['workspace'], $validated['media_index'], $budget, true );
		if ( $usage instanceof WP_Error ) {
			self::destroy_session( $session_id, $session );
			return $usage;
		}

		$media_cap_error = PageFerry_Importer::check_media_upload_capability( $validated['media_index'] );

		if ( $media_cap_error instanceof WP_Error ) {
			$media_cap_error->add_data( array( 'status' => 403 ) );
			return $media_cap_error;
		}

		$file_params = $request->get_file_params();

		if ( ! isset( $file_params['file'] ) || ! is_array( $file_params['file'] ) ) {
			return new WP_Error(
				'pageferry_file_missing',
				__( 'The media upload could not be read. Select the ZIP again and prepare a new review.', 'pageferry' ),
				array( 'status' => 400 )
			);
		}

		$uploaded = $file_params['file'];

		if ( ! isset( $uploaded['error'] ) || UPLOAD_ERR_OK !== (int) $uploaded['error'] ) {
			return new WP_Error(
				'pageferry_file_upload',
				__( 'The server could not receive this file. It may exceed the upload limit. Reduce the file size and export again, or ask your host to check the upload limit.', 'pageferry' ),
				array( 'status' => 413 )
			);
		}

		$declared = $usage['declared'];
		$basename = isset( $uploaded['name'] ) ? basename( (string) $uploaded['name'] ) : '';

		if ( '' === $basename || ! isset( $declared[ $basename ] ) ) {
			return new WP_Error(
				'pageferry_file_undeclared',
				__( 'This file is not listed in the ZIP page information. Export the page again and try the new ZIP.', 'pageferry' ),
				array( 'status' => 400 )
			);
		}

		if ( ! PageFerry_Importer::media_basename_allowed( $basename ) ) {
			return new WP_Error(
				'pageferry_unsupported_media_type',
				sprintf(
					/* translators: %s: media file name with a disallowed extension. */
					__( 'Media file %s has a file type this site does not allow. Ask an administrator to check the file type before importing.', 'pageferry' ),
					$basename
				),
				array( 'status' => 400 )
			);
		}

		$tmp_name = isset( $uploaded['tmp_name'] ) ? (string) $uploaded['tmp_name'] : '';

		if ( '' === $tmp_name || ! is_readable( $tmp_name ) ) {
			return new WP_Error(
				'pageferry_file_upload',
				__( 'The uploaded media file could not be read. Select the ZIP again and prepare a new review.', 'pageferry' ),
				array( 'status' => 400 )
			);
		}

		clearstatcache( true, $tmp_name );
		$actual_bytes = filesize( $tmp_name );
		if ( false === $actual_bytes || is_link( $tmp_name ) || ! is_file( $tmp_name ) ) {
			return PageFerry_Import_Resources::io_error();
		}
		if ( $actual_bytes > $limits['media_file_bytes'] ) {
			return PageFerry_Import_Resources::file_exceeded( $basename );
		}
		if ( ! array_key_exists( $basename, $usage['files'] ) && count( $usage['files'] ) >= $limits['required_files'] ) {
			return PageFerry_Import_Resources::exceeded();
		}
		$old_bytes = $usage['files'][ $basename ] ?? 0;
		$remaining = $budget - ( $usage['bytes'] - $old_bytes );
		if ( $actual_bytes > $remaining ) {
			return PageFerry_Import_Resources::exceeded();
		}

		// Private transport staging uses the same type checks as ZIP extraction.
		$incoming_hash = hash_file( 'sha256', $tmp_name );
		if ( ! is_string( $incoming_hash ) ) {
			return PageFerry_Import_Resources::io_error();
		}
		if ( ! PageFerry_Importer::staged_media_file_allowed( $tmp_name, $basename ) ) {
			return new WP_Error(
				'pageferry_unsupported_media_type',
				sprintf(
					/* translators: %s: media file name with a disallowed or mismatched type. */
					__( 'Media file %s has a file type this site does not allow. Ask an administrator to check the file type before importing.', 'pageferry' ),
					$basename
				),
				array( 'status' => 400 )
			);
		}

		$destination    = $session['workspace'] . '/' . $basename;
		$candidate_name = '.pageferry-receipt-' . bin2hex( random_bytes( 16 ) );
		$candidate      = $session['workspace'] . '/' . $candidate_name;

		// Keep transport bytes private; PHP cleans up its request-owned upload temporary file.
		$copied = PageFerry_Import_Resources::copy_file( $tmp_name, $candidate, $remaining );
		if ( $copied instanceof WP_Error ) {
			if ( 'pageferry_media_too_large' === $copied->get_error_code() ) {
				$copied = PageFerry_Import_Resources::file_exceeded( $basename );
			}
			wp_delete_file( $candidate );
			return $copied;
		}
		if ( ! PageFerry_Importer::staged_media_file_allowed( $candidate, $basename ) ) {
			wp_delete_file( $candidate );
			return new WP_Error( 'pageferry_unsupported_media_type', __( 'This media file does not match its stated file type. Check the source file and export the page again.', 'pageferry' ), array( 'status' => 400 ) );
		}
		// Filterable type probes can alter the candidate; recheck its physical bytes.
		$checked_bytes = PageFerry_Import_Resources::file_size( $candidate );
		$error         = null;
		if ( $checked_bytes instanceof WP_Error ) {
			$error = $checked_bytes;
		} elseif ( $checked_bytes > $limits['media_file_bytes'] ) {
			$error = PageFerry_Import_Resources::file_exceeded( $basename );
		} elseif ( $checked_bytes > $remaining ) {
			$error = PageFerry_Import_Resources::exceeded();
		} elseif ( $checked_bytes !== $copied ) {
			$error = PageFerry_Import_Resources::io_error();
		}
		if ( ! ( $error instanceof WP_Error ) ) {
			$staged_hash = hash_file( 'sha256', $candidate );
			if ( ! is_string( $staged_hash ) || ! hash_equals( $incoming_hash, $staged_hash ) ) {
				$error = PageFerry_Importer::media_processing_error( $basename );
				$error->add_data( array( 'status' => 400 ) );
			}
		}
		if ( $error instanceof WP_Error ) {
			wp_delete_file( $candidate );
			return $error;
		}
		// Atomic replacement preserves accepted bytes if the new receipt fails.
		if ( ! @rename( $candidate, $destination ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors.Discouraged -- atomic leased replacement; reported failure preserves old bytes.
			wp_delete_file( $candidate );
			return PageFerry_Import_Resources::io_error();
		}

		$session['received'][ $basename ] = true;
		$session['receipt_cache']         = $validated['receipt_cache'] ?? array();
		unset( $session['review_model'], $session['plan'], $session['plan_token'] );
		set_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id, $session, self::SESSION_TTL );

		return rest_ensure_response(
			array(
				'session_id' => $session_id,
				'file'       => $basename,
				'received'   => array_keys( $session['received'] ),
			)
		);
	}

	/**
	 * Caches only exact manifest structure; physical usage and current capabilities remain live checks.
	 *
	 * @param array $session Leased server-stored session.
	 * @return array|WP_Error Compact required-media index or validation error.
	 */
	private static function receipt_validation( array $session ) {
		$manifest = $session['manifest'];
		$target   = $session['target_post_type'] ?? null;
		$limits   = PageFerry_Import_Resources::limits();
		if ( ! is_array( $manifest ) ) {
			return PageFerry_Importer::validate( $manifest, $target );
		}
		if ( ( isset( $manifest['media'] ) && is_array( $manifest['media'] ) && count( $manifest['media'] ) > $limits['media_records'] ) || ! PageFerry_Import_Resources::manifest_fits( $manifest, $limits['manifest_bytes'] ) ) {
			return PageFerry_Import_Resources::exceeded();
		}
		// Repaired UTF-8 cannot prove exact manifest identity for cache reuse.
		$encoded = json_encode( $manifest ); // phpcs:ignore WordPress.WP.AlternativeFunctions.json_encode_json_encode -- exact encoding is required for cache identity.
		if ( ! is_string( $encoded ) ) {
			return PageFerry_Importer::validate( $manifest, $target );
		}
		if ( strlen( $encoded ) > $limits['manifest_bytes'] ) {
			return PageFerry_Import_Resources::exceeded();
		}
		$fingerprint = hash( 'sha256', $encoded );
		$post_type   = $target ?? ( $manifest['post']['post_type'] ?? '' );
		$policy      = hash(
			'sha256',
			(string) wp_json_encode(
				array(
					'limits'     => $limits,
					'mimes'      => get_allowed_mime_types(),
					'post_types' => PageFerry_Exporter::ferryable_post_types(),
					'target'     => $target,
					'registered' => is_string( $post_type ) && post_type_exists( $post_type ),
				)
			)
		);
		$cache       = $session['receipt_cache'] ?? null;
		if (
			is_array( $cache ) &&
			isset( $cache['version'], $cache['manifest'], $cache['policy'], $cache['media_index'], $cache['signature'] ) &&
			self::RECEIPT_CACHE_VERSION === $cache['version'] &&
			$fingerprint === $cache['manifest'] && $policy === $cache['policy'] &&
			is_array( $cache['media_index'] ) && count( $cache['media_index'] ) <= $limits['required_files'] &&
			is_string( $cache['signature'] ) &&
			PageFerry_Import_Resources::manifest_fits( $cache, $limits['manifest_bytes'] ) &&
			hash_equals( self::receipt_cache_signature( $cache ), $cache['signature'] )
		) {
			return array(
				'media_index'   => $cache['media_index'],
				'receipt_cache' => $cache,
			);
		}

		$validated = PageFerry_Importer::validate( $manifest, $target );
		if ( $validated instanceof WP_Error ) {
			return $validated;
		}
		$index = array();
		foreach ( $validated['media_index'] as $id => $state ) {
			if ( ! $state['missing'] ) {
				$index[ $id ] = array(
					'entry'   => array( 'file' => $state['entry']['file'] ),
					'missing' => false,
				);
			}
		}
		$cache              = array(
			'version'     => self::RECEIPT_CACHE_VERSION,
			'manifest'    => $fingerprint,
			'policy'      => $policy,
			'media_index' => $index,
		);
		$cache['signature'] = self::receipt_cache_signature( $cache );
		return array(
			'media_index'   => $index,
			'receipt_cache' => $cache,
		);
	}

	/**
	 * Authenticates the compact index as a server-produced validation result.
	 *
	 * @param array $cache Receipt validation metadata.
	 * @return string
	 */
	private static function receipt_cache_signature( array $cache ): string {
		unset( $cache['signature'] );
		return hash_hmac( 'sha256', (string) json_encode( $cache ), wp_salt( 'auth' ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.json_encode_json_encode -- never authenticate repaired cache bytes.
	}

	/**
	 * Verifies received files before preview or token-bound commit.
	 *
	 * @param WP_REST_Request $request REST request with session_id + target args.
	 * @return WP_REST_Response|WP_Error Summary, result, or error.
	 */
	public static function handle_commit( WP_REST_Request $request ) {
		$session = self::get_session( (string) $request->get_param( 'session_id' ) );
		if ( is_wp_error( $session ) ) {
			return self::commit_refusal( $session, $request );
		}
		$started = false;
		$result  = PageFerry_Workspace::with_lease(
			$session['workspace'],
			static function () use ( $request, &$started ) {
				return self::commit_leased( $request, $started );
			},
			1000
		);
		return is_wp_error( $result ) && ! $started ? self::commit_refusal( $result, $request ) : $result;
	}

	/**
	 * Marks a refusal before execution; only a still-bound review can retry.
	 *
	 * @param WP_Error        $error Pre-execution error.
	 * @param WP_REST_Request $request Commit request.
	 * @return WP_Error
	 */
	private static function commit_refusal( WP_Error $error, WP_REST_Request $request ): WP_Error {
		$session = self::get_session( (string) $request->get_param( 'session_id' ) );
		$retry   = is_array( $session ) && is_array( $session['review_model'] ?? null )
			&& PageFerry_Review_Model::valid( $session['manifest'], $session['review_model'] )
			&& is_string( $session['plan_token'] ?? null )
			&& hash_equals( $session['plan_token'], self::sanitize_plan_token( $request->get_param( 'plan_token' ) ) )
			&& in_array( $error->get_error_code(), array( 'pageferry_selection_invalid', 'pageferry_workspace_busy', 'pageferry_target_busy' ), true );
		$data    = $error->get_error_data();
		$error->add_data(
			array_merge(
				is_array( $data ) ? $data : array(),
				array(
					'import_started' => false,
					'recovery'       => $retry ? 'retry' : 'prepare',
				)
			)
		);
		return $error;
	}

	/**
	 * Previews/commits while GC and other requests are excluded.
	 *
	 * @param WP_REST_Request $request Commit request.
	 * @param bool            $started Whether the shared importer was entered.
	 * @return WP_REST_Response|WP_Error
	 */
	private static function commit_leased( WP_REST_Request $request, bool &$started ) {
		$session_id = (string) $request->get_param( 'session_id' );
		$session    = self::get_session( $session_id );

		if ( is_wp_error( $session ) ) {
			return $session;
		}
		$tracked = PageFerry_Workspace::bind_session( $session['workspace'], PageFerry::TRANSIENT_SESSION_PREFIX . $session_id );
		if ( is_wp_error( $tracked ) ) {
			return $tracked;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$requested_type = $request->get_param( 'target_post_type' );
		if ( null !== $requested_type && ! is_string( $requested_type ) ) {
			return new WP_Error( 'pageferry_unsupported_post_type', __( 'Choose an available content type, such as Page or Post.', 'pageferry' ), array( 'status' => 400 ) );
		}
		$validated = PageFerry_Importer::validate( $session['manifest'], $requested_type );

		if ( $validated instanceof WP_Error ) {
			self::destroy_session( $session_id, $session );
			if ( ! is_array( $validated->get_error_data() ) || ! isset( $validated->get_error_data()['status'] ) ) {
				$validated->add_data( array( 'status' => 400 ) );
			}
			return $validated;
		}

		$limits = PageFerry_Import_Resources::limits();
		$usage  = PageFerry_Import_Resources::usage( $session['workspace'], $validated['media_index'], min( $limits['path_b_bytes'], $limits['core_bytes'] ), true );
		if ( $usage instanceof WP_Error ) {
			self::destroy_session( $session_id, $session );
			return $usage;
		}

		// Read confirmation intent first so incomplete previews retain their retryable session.
		$target_mode    = 'update' === (string) $request->get_param( 'target' ) ? 'update' : 'create';
		$target_post_id = absint( (string) $request->get_param( 'target_post_id' ) );
		$confirmed      = rest_sanitize_boolean( $request->get_param( 'confirm' ) );
		$local_review   = $confirmed && true === $request->get_param( 'local_review' );

		$provided_plan_token  = self::sanitize_plan_token( $request->get_param( 'plan_token' ) );
		$requested_status_raw = $request->get_param( 'status' );
		$normalized_status    = self::normalize_plan_status( $requested_status_raw );

		$required_files = PageFerry_Importer::check_required_files( $session['workspace'], $validated['media_index'] );

		if ( $required_files instanceof WP_Error ) {
			if ( ! $confirmed ) {
				set_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id, $session, self::SESSION_TTL );
				$required_files->add_data( array( 'status' => 400 ) );
				return $required_files;
			}

			self::destroy_session( $session_id, $session );
			$required_files->add_data( array( 'status' => 400 ) );
			return $required_files;
		}

		foreach ( $validated['media_index'] as $media_state ) {
			if ( $media_state['missing'] ) {
				continue;
			}

			$file_name  = (string) $media_state['entry']['file'];
			$media_file = PageFerry_Importer::workspace_file( $session['workspace'], $file_name );

			if ( ! is_string( $media_file ) ) {
				$race_error = new WP_Error(
					'pageferry_file_incomplete',
					sprintf(
						/* translators: %s: media file name not yet uploaded. */
						__( 'Media file %s has not finished uploading. Wait for preparation to finish before importing.', 'pageferry' ),
						PageFerry_Importer::original_filename( $media_state['entry'] )
					),
					array( 'status' => 400 )
				);

				if ( ! $confirmed ) {
					set_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id, $session, self::SESSION_TTL );
					return $race_error;
				}

				self::destroy_session( $session_id, $session );
				return $race_error;
			}

			$actual_hash = hash_file( 'sha256', $media_file );

			if ( ! is_string( $actual_hash ) || ! hash_equals( strtolower( (string) $media_state['entry']['sha256'] ), strtolower( $actual_hash ) ) ) {
				$hash_error = new WP_Error(
					'pageferry_media_hash',
					sprintf(
						/* translators: %s: media file name with a hash mismatch. */
						__( 'Media file %s does not match the exported file. Export the page again and try the new ZIP.', 'pageferry' ),
						PageFerry_Importer::original_filename( $media_state['entry'] )
					),
					array( 'status' => 400 )
				);

				// Corrupt preview uploads can be replaced; a confirmed write is terminal.
				if ( ! $confirmed ) {
					set_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id, $session, self::SESSION_TTL );
					return $hash_error;
				}

				self::destroy_session( $session_id, $session );
				return $hash_error;
			}

			$staged_bytes = filesize( $media_file );
			$size_limit   = PageFerry_Import_Resources::limits()['media_file_bytes'];

			if ( is_int( $staged_bytes ) && 0 < $size_limit && $size_limit < $staged_bytes ) {
				self::destroy_session( $session_id, $session );
				return new WP_Error(
					'pageferry_media_too_large',
					sprintf(
						/* translators: 1: media file name, 2: human-readable size limit. */
						__( 'Media file %1$s exceeds the file size limit of %2$s. Reduce its size and export again, or ask your host to raise a lower upload limit.', 'pageferry' ),
						PageFerry_Importer::original_filename( $media_state['entry'] ),
						size_format( $size_limit )
					),
					array( 'status' => 400 )
				);
			}
		}

		$commit_args = array(
			'target'         => $target_mode,
			'target_post_id' => $target_post_id,
		);

		if ( null !== $requested_type ) {
			$commit_args['target_post_type'] = $requested_type;
		}
		$requested_selection = $request->get_param( 'selection' );
		$canonical_selection = PageFerry_Import_Selection::normalize( $validated['manifest'], $requested_selection, $requested_type ?? $validated['manifest']['post']['post_type'] );
		if ( is_wp_error( $canonical_selection ) ) {
			return $canonical_selection;
		}
		if ( null !== $requested_selection ) {
			$commit_args['selection'] = $canonical_selection;
		}
		if ( '' !== $normalized_status ) {
			$commit_args['status'] = $normalized_status;
		}

		$preview = null;

		if ( ! $confirmed ) {
			$commit_args['prepare_review'] = true === $request->get_param( 'prepare_review' );
			$preview                       = PageFerry_Importer::preview(
				$session['workspace'],
				$validated['manifest'],
				$commit_args
			);

			if ( is_wp_error( $preview ) ) {
				$preview_code = $preview->get_error_code();

				if ( in_array( $preview_code, array( 'pageferry_file_incomplete', 'pageferry_media_hash' ), true ) ) {
					set_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id, $session, self::SESSION_TTL );
					$preview->add_data( array( 'status' => 400 ) );
					return $preview;
				}

				self::destroy_session( $session_id, $session );
				$preview->add_data( array( 'status' => 400 ) );
				return $preview;
			}

			// Replacing the stored plan invalidates every earlier confirmation.
			$plan_token = 'pf-' . wp_generate_password( 24, false );

			$session['plan_token'] = $plan_token;
			if ( isset( $preview['review_model'] ) ) {
				$session['review_model'] = $preview['review_model'];
			} else {
				unset( $session['review_model'] );
			}
			$session['plan'] = array(
				'target'             => $target_mode,
				'target_post_id'     => $target_post_id,
				'status'             => $normalized_status,
				'target_modified'    => isset( $preview['target_modified'] ) ? $preview['target_modified'] : null,
				'target_fingerprint' => $preview['target_fingerprint'] ?? null,
				'manifest_hash'      => self::manifest_fingerprint( $validated['manifest'] ),
				'target_post_type'   => $requested_type,
				'selection'          => $canonical_selection,
			);

			set_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id, $session, self::SESSION_TTL );
			return rest_ensure_response(
				array(
					'session_id'  => $session_id,
					'preview'     => $preview,
					'plan_token'  => $plan_token,
					'review_html' => PageFerry_Import_Review::render(
						$preview,
						array(
							'transport' => 'rest',
							'key'       => $session_id,
						)
					),
				)
			);
		}

		// Reject retargeted confirmations before preview so staged bytes remain available for retry.
		$stored_token = isset( $session['plan_token'] ) && is_string( $session['plan_token'] ) ? $session['plan_token'] : '';
		$stored_plan  = isset( $session['plan'] ) && is_array( $session['plan'] ) ? $session['plan'] : null;

		if ( '' === $provided_plan_token || '' === $stored_token || null === $stored_plan ) {
			set_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id, $session, self::SESSION_TTL );
			return new WP_Error(
				'pageferry_plan_missing',
				__( 'Review the import again before confirming. Keep the selected destination unchanged after reviewing.', 'pageferry' ),
				array( 'status' => 400 )
			);
		}

		if ( ! hash_equals( $stored_token, $provided_plan_token ) ) {
			set_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id, $session, self::SESSION_TTL );
			return new WP_Error(
				'pageferry_plan_mismatch',
				__( 'Your confirmation does not match the review. Review the import again before confirming.', 'pageferry' ),
				array( 'status' => 409 )
			);
		}

		$stored_target    = isset( $stored_plan['target'] ) && 'update' === $stored_plan['target'] ? 'update' : 'create';
		$stored_target_id = isset( $stored_plan['target_post_id'] ) ? (int) $stored_plan['target_post_id'] : 0;
		$stored_status    = isset( $stored_plan['status'] ) && is_string( $stored_plan['status'] ) ? $stored_plan['status'] : '';

		if ( $stored_target !== $target_mode || $stored_target_id !== $target_post_id || $stored_status !== $normalized_status || ( $stored_plan['target_post_type'] ?? null ) !== $requested_type || ( ! $local_review && ( isset( $stored_plan['selection'] ) ? $stored_plan['selection'] : PageFerry_Import_Selection::normalize( $validated['manifest'] ) ) !== $canonical_selection ) ) {
			set_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id, $session, self::SESSION_TTL );
			return new WP_Error(
				'pageferry_plan_mismatch',
				__( 'The selected destination changed after your review. Review the import again before confirming.', 'pageferry' ),
				array( 'status' => 409 )
			);
		}

		if ( self::manifest_fingerprint( $validated['manifest'] ) !== ( isset( $stored_plan['manifest_hash'] ) && is_string( $stored_plan['manifest_hash'] ) ? $stored_plan['manifest_hash'] : "\0" ) ) {
			set_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id, $session, self::SESSION_TTL );
			return new WP_Error(
				'pageferry_plan_mismatch',
				__( 'The ZIP information changed after your review. Review the import again before confirming.', 'pageferry' ),
				array( 'status' => 409 )
			);
		}

		if ( 'update' === $target_mode ) {
			$stored_fingerprint = $stored_plan['target_fingerprint'] ?? null;
			if ( ! is_string( $stored_fingerprint ) || PageFerry_Importer::target_fingerprint( $target_post_id ) !== $stored_fingerprint ) {
				set_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id, $session, self::SESSION_TTL );
				return new WP_Error(
					'pageferry_plan_stale',
					__( 'The selected page changed after your review. Review the import again before confirming.', 'pageferry' ),
					array( 'status' => 409 )
				);
			}
		}

		if ( $local_review && ! is_array( $session['review_model'] ?? null ) ) {
			return new WP_Error( 'pageferry_review_stale', __( 'Prepare this import again before confirming.', 'pageferry' ), array( 'status' => 409 ) );
		}

		// Legacy clients still confirm the selection they previously reviewed.
		$preview = $local_review
			? PageFerry_Importer::check_review( $validated['manifest'], $session['review_model'] ?? array(), $commit_args )
			: PageFerry_Importer::preview( $session['workspace'], $validated['manifest'], $commit_args );

		if ( is_wp_error( $preview ) ) {
			self::destroy_session( $session_id, $session );
			$preview->add_data( array( 'status' => 400 ) );
			return $preview;
		}

		if ( 'update' === $target_mode ) {
			$target_post = get_post( $target_post_id );

			if ( ! $target_post instanceof WP_Post ) {
				self::destroy_session( $session_id, $session );
				return new WP_Error(
					'pageferry_target_missing',
					__( 'The selected page no longer exists. Choose another destination and review the import again.', 'pageferry' ),
					array( 'status' => 400 )
				);
			}

			if ( ( $requested_type ?? $validated['manifest']['post']['post_type'] ) !== $target_post->post_type ) {
				self::destroy_session( $session_id, $session );
				return new WP_Error(
					'pageferry_target_type',
					__( 'The selected page has a different content type. Choose a matching destination and review the import again.', 'pageferry' ),
					array( 'status' => 400 )
				);
			}

			if ( ! current_user_can( 'edit_post', $target_post->ID ) ) {
				self::destroy_session( $session_id, $session );
				return new WP_Error(
					'pageferry_target_cap',
					__( 'You do not have permission to update the selected page. Choose another destination or ask an administrator for help.', 'pageferry' ),
					array( 'status' => 403 )
				);
			}
		}

		if ( 'update' === $target_mode ) {
			$commit_args['target_fingerprint'] = $stored_plan['target_fingerprint'];
		}

		$started   = true;
		$execution = PageFerry_Importer::run_with_outcome(
			$session['workspace'],
			$validated['manifest'],
			$commit_args
		);

		$imported            = $execution['result'];
		$outcome             = $execution['outcome'];
		$outcome['warnings'] = $preview['warnings'] ?? array();
		if ( is_wp_error( $imported ) && 'pageferry_target_busy' === $imported->get_error_code() ) {
			return self::commit_refusal( $imported, $request );
		}
		if ( is_wp_error( $imported ) && 'pageferry_plan_stale' === $imported->get_error_code() ) {
			// Keep staged bytes for re-preview after a competing destination update.
			$imported->add_data(
				array_merge(
					(array) $imported->get_error_data(),
					array(
						'status'      => 409,
						'outcome'     => $outcome,
						'result_html' => PageFerry_Import_Review::outcome( $outcome ),
					)
				)
			);
			return $imported;
		}

		self::destroy_session( $session_id, $session );

		if ( is_wp_error( $imported ) ) {
			$error_data = $imported->get_error_data();
			$imported->add_data(
				array_merge(
					is_array( $error_data ) ? $error_data : array(),
					array(
						'status'      => 400,
						'outcome'     => $outcome,
						'result_html' => PageFerry_Import_Review::outcome( $outcome ),
					)
				)
			);
			return $imported;
		}

		return rest_ensure_response(
			array(
				'session_id'  => $session_id,
				'post_id'     => $imported->ID,
				'slug'        => $imported->post_name,
				'edit_url'    => get_edit_post_link( $imported->ID, 'raw' ),
				'view_url'    => get_permalink( $imported->ID ),
				'preview'     => $preview,
				'outcome'     => $outcome,
				'result_html' => PageFerry_Import_Review::result( $imported, $preview['warnings'] ?? array(), $outcome ),
			)
		);
	}

	/**
	 * Loads a session or fails closed (expired/unknown → error + no writes).
	 *
	 * @param string $session_id Session ID from the request.
	 * @return array|WP_Error Session array or WP_Error.
	 */
	private static function get_session( string $session_id ) {
		if ( '' === $session_id || 1 !== preg_match( '/^[A-Za-z0-9-]+$/', $session_id ) ) {
			return new WP_Error(
				'pageferry_session_invalid',
				__( 'This import is no longer available. Select the ZIP again and prepare a new review.', 'pageferry' ),
				array( 'status' => 400 )
			);
		}

		$session = get_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id );

		if ( ! is_array( $session ) || ! isset( $session['workspace'], $session['manifest'] ) ) {
			return new WP_Error(
				'pageferry_session_expired',
				__( 'This import has expired. Select the ZIP again and prepare a new review.', 'pageferry' ),
				array( 'status' => 410 )
			);
		}

		if ( ! isset( $session['user_id'] ) || get_current_user_id() !== (int) $session['user_id'] ) {
			return new WP_Error(
				'pageferry_session_expired',
				__( 'This import has expired. Select the ZIP again and prepare a new review.', 'pageferry' ),
				array( 'status' => 410 )
			);
		}

		if ( ! is_dir( $session['workspace'] ) ) {
			delete_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id );
			return new WP_Error(
				'pageferry_session_expired',
				__( 'This import has expired. Select the ZIP again and prepare a new review.', 'pageferry' ),
				array( 'status' => 410 )
			);
		}

		if ( ! isset( $session['received'] ) || ! is_array( $session['received'] ) ) {
			$session['received'] = array();
		}

		return $session;
	}

	/**
	 * Destroys a session: workspace removed, transient deleted, zero DB writes.
	 *
	 * @param string $session_id Session ID.
	 * @param array  $session Session array.
	 * @return void
	 */
	private static function destroy_session( string $session_id, array $session ): void {
		delete_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id );
		if ( isset( $session['workspace'] ) && is_string( $session['workspace'] ) ) {
			PageFerry_Workspace::with_lease(
				$session['workspace'],
				static function () use ( $session ) {
					return PageFerry_Workspace::retire( $session['workspace'] );
				}
			);
		}
	}

	/**
	 * Binds confirmation to the validated bundle, preventing cross-session plan reuse.
	 *
	 * @param array $manifest Validated manifest array.
	 * @return string Hex sha256 of the canonical JSON encoding.
	 */
	private static function manifest_fingerprint( array $manifest ): string {
		$encoded = wp_json_encode( $manifest );

		return is_string( $encoded ) ? hash( 'sha256', $encoded ) : '';
	}

	/**
	 * Normalizes optional status identically for preview and confirmation.
	 *
	 * @param mixed $raw Raw status request param.
	 * @return string Normalized status ('', or lowercased choice).
	 */
	private static function normalize_plan_status( $raw ): string {
		if ( ! is_string( $raw ) || '' === trim( $raw ) ) {
			return '';
		}

		return strtolower( trim( $raw ) );
	}

	/**
	 * Validates token shape only; equality with the stored plan grants confirmation.
	 *
	 * @param mixed $raw Raw plan_token request param.
	 * @return string Validated token, or '' when malformed.
	 */
	public static function sanitize_plan_token( $raw ): string {
		if ( ! is_string( $raw ) ) {
			return '';
		}

		return 1 === preg_match( '/\Apf-[A-Za-z0-9]{24}\z/', $raw ) ? $raw : '';
	}
}
