<?php
/**
 * Changes block attribute values without reserializing unrelated content.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/** Preserves the source spelling and formatting around changed media IDs. */
class PageFerry_Content_Remapper {

	/**
	 * Applies mapped attributes to the original WordPress delimiter tokens.
	 *
	 * @param string $content Original post content.
	 * @param array  $blocks Parsed blocks with remapped attribute values.
	 * @return string|WP_Error Preserved content or an ambiguous-token error.
	 */
	public static function apply( string $content, array $blocks ) {
		if ( parse_blocks( $content ) === $blocks ) {
			return $content;
		}
		$flat = array();
		self::flatten( $blocks, $flat );
		$next             = 0;
		$edits            = array();
		$parser           = new WP_Block_Parser();
		$parser->document = $content;
		$parser->offset   = 0;
		while ( true ) {
			list( $type, $name, $attrs, $offset, $length ) = $parser->next_token();
			if ( 'no-more-tokens' === $type ) {
				break;
			}
			$parser->offset = $offset + $length;
			if ( 'block-closer' === $type ) {
				continue;
			}
			if ( ! isset( $flat[ $next ] ) || $flat[ $next ]['blockName'] !== $name ) {
				return self::error();
			}
			$mapped = $flat[ $next ]['attrs'];
			++$next;
			if ( $attrs === $mapped ) {
				continue;
			}
			$token = substr( $content, $offset, $length );
			$start = strpos( $token, '{' );
			$end   = strrpos( $token, '}' );
			if ( false === $start || false === $end || ! is_array( $mapped ) ) {
				return self::error();
			}
			$json = substr( $token, $start, $end - $start + 1 );
			foreach ( self::json_edits( $json, $mapped ) as $edit ) {
				$edit[0] += $offset + $start;
				$edits[]  = $edit;
			}
		}
		if ( count( $flat ) !== $next ) {
			return self::error();
		}
		return self::replace( $content, $edits );
	}

	/**
	 * Lists named blocks in delimiter order; freeform content stays outside the map.
	 *
	 * @param array $blocks Parsed block tree.
	 * @param array $flat Named blocks in document order.
	 * @return void
	 */
	private static function flatten( array $blocks, array &$flat ) {
		foreach ( $blocks as $block ) {
			if ( ! empty( $block['blockName'] ) ) {
				$flat[] = $block;
			}
			self::flatten( $block['innerBlocks'] ?? array(), $flat );
		}
	}

	/**
	 * Computes scalar edits using JSON tokens rather than encoding whole objects.
	 *
	 * @param string $json Original JSON.
	 * @param mixed  $mapped Mapped value with the same container shape.
	 * @return array Offset/length/replacement triples.
	 */
	private static function json_edits( string $json, $mapped ): array {
		preg_match_all( '/"(?:[^"\\\\]|\\\\.)*"|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?|true|false|null|[{}\[\]:,]/s', $json, $matches, PREG_OFFSET_CAPTURE );
		$cursor = 0;
		$edits  = array();
		self::walk_json( $matches[0], $cursor, $mapped, $edits );
		return $edits;
	}

	/**
	 * Visits each value once, leaving keys and unchanged scalar spellings intact.
	 *
	 * @param array $tokens JSON tokens with source offsets.
	 * @param int   $cursor Current token index.
	 * @param mixed $mapped Mapped value.
	 * @param array $edits Collected source edits.
	 * @return void
	 */
	private static function walk_json( array $tokens, int &$cursor, $mapped, array &$edits ) {
		list( $token, $offset ) = $tokens[ $cursor++ ];
		if ( '{' === $token || '[' === $token ) {
			$close     = '{' === $token ? '}' : ']';
			$index     = 0;
			$last_keys = '{' === $token ? self::last_object_keys( $tokens, $cursor ) : array();
			while ( isset( $tokens[ $cursor ] ) && $tokens[ $cursor ][0] !== $close ) {
				$key          = $index++;
				$key_position = $cursor;
				if ( '{' === $token ) {
					$key = json_decode( $tokens[ $cursor++ ][0], true );
					++$cursor;
				}
				if ( '{' === $token && $last_keys[ $key ] !== $key_position ) {
					self::skip_json( $tokens, $cursor );
				} else {
					self::walk_json( $tokens, $cursor, $mapped[ $key ], $edits );
				}
				if ( isset( $tokens[ $cursor ] ) && ',' === $tokens[ $cursor ][0] ) {
					++$cursor;
				}
			}
			++$cursor;
			return;
		}
		$original = json_decode( $token, true );
		if ( $original === $mapped ) {
			return;
		}
		if ( is_string( $original ) && is_string( $mapped ) ) {
			$nested = json_decode( $mapped, true );
			if ( is_array( $nested ) && is_array( json_decode( $original, true ) ) ) {
				foreach ( self::string_edits( $token, self::json_edits( $original, $nested ) ) as $edit ) {
					$edit[0] += $offset;
					$edits[]  = $edit;
				}
				return;
			}
		}
		$edits[] = array( $offset, strlen( $token ), (string) wp_json_encode( $mapped ) );
	}


	/**
	 * Finds effective object keys; JSON decoding ignores earlier duplicate keys.
	 *
	 * @param array $tokens JSON tokens.
	 * @param int   $cursor First key position.
	 * @return array Last token position for each key.
	 */
	private static function last_object_keys( array $tokens, int $cursor ): array {
		$keys = array();
		while ( isset( $tokens[ $cursor ] ) && '}' !== $tokens[ $cursor ][0] ) {
			$keys[ json_decode( $tokens[ $cursor ][0], true ) ] = $cursor;
			$cursor += 2;
			self::skip_json( $tokens, $cursor );
			if ( isset( $tokens[ $cursor ] ) && ',' === $tokens[ $cursor ][0] ) {
				++$cursor;
			}
		}
		return $keys;
	}

	/**
	 * Skips an ignored value without altering its original tokens.
	 *
	 * @param array $tokens JSON tokens.
	 * @param int   $cursor Value position, advanced to the following separator.
	 * @return void
	 */
	private static function skip_json( array $tokens, int &$cursor ) {
		$token = $tokens[ $cursor++ ][0];
		$depth = in_array( $token, array( '{', '[' ), true ) ? 1 : 0;
		while ( $depth > 0 && isset( $tokens[ $cursor ] ) ) {
			$token = $tokens[ $cursor++ ][0];
			if ( in_array( $token, array( '{', '[' ), true ) ) {
				++$depth;
			} elseif ( in_array( $token, array( '}', ']' ), true ) ) {
				--$depth;
			}
		}
	}

	/**
	 * Projects nested edits through the original string's JSON escape boundaries.
	 *
	 * @param string $token Quoted JSON string.
	 * @param array  $edits Edits in the decoded string.
	 * @return array Edits in the quoted source token.
	 */
	private static function string_edits( string $token, array $edits ): array {
		$inner = substr( $token, 1, -1 );
		preg_match_all( '/\\\\u[dD][89aAbB][0-9a-fA-F]{2}\\\\u[dD][c-fC-F][0-9a-fA-F]{2}|\\\\u[0-9a-fA-F]{4}|\\\\.|[^\\\\]+/s', $inner, $matches, PREG_OFFSET_CAPTURE );
		$boundaries = array( 0 => 1 );
		$position   = 0;
		foreach ( $matches[0] as $chunk ) {
			list( $raw, $offset ) = $chunk;
			$decoded              = '\\' === $raw[0] ? json_decode( '"' . $raw . '"' ) : $raw;
			$length               = strlen( $decoded );
			for ( $i = 0; $i < $length; ++$i ) {
				$boundaries[ $position + $i ] = 1 + $offset + ( '\\' === $raw[0] ? 0 : $i );
			}
			$position               += $length;
			$boundaries[ $position ] = 1 + $offset + strlen( $raw );
		}
		$result = array();
		foreach ( $edits as $edit ) {
			$start       = $boundaries[ $edit[0] ];
			$end         = $boundaries[ $edit[0] + $edit[1] ];
			$replacement = substr( (string) wp_json_encode( $edit[2], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ), 1, -1 );
			$result[]    = array( $start, $end - $start, $replacement );
		}
		return $result;
	}

	/**
	 * Applies disjoint edits from the end so source offsets remain stable.
	 *
	 * @param string $source Original text.
	 * @param array  $edits Offset/length/replacement triples.
	 * @return string Edited text.
	 */
	private static function replace( string $source, array $edits ): string {
		usort(
			$edits,
			static function ( array $a, array $b ): int {
				return $b[0] <=> $a[0];
			}
		);
		foreach ( $edits as $edit ) {
			$source = substr_replace( $source, $edit[2], $edit[0], $edit[1] );
		}
		return $source;
	}

	/**
	 * Refuses uncertain positions instead of normalizing or changing the wrong block.
	 *
	 * @return WP_Error Refusal.
	 */
	private static function error(): WP_Error {
		return new WP_Error( 'pageferry_content_remap', __( 'PageFerry could not update the image and file references in this page. The page was not saved. Open and save the source page in the block editor, then export it again.', 'pageferry' ) );
	}
}
