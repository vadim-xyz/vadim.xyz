/* global self, importScripts, PageFerryZip */
importScripts('vendor/fflate.min.js', 'import-zip-reader.js' + (self.location ? self.location.search : ''));
self.onmessage = async function (event) {
	try {
		var reader = await new PageFerryZip.Reader(event.data.file, event.data.limits).index();
		var result = await reader.manifest();
		self.postMessage({ title: typeof result.manifest.post.title === 'string' ? result.manifest.post.title : '', post_type: result.manifest.post.post_type });
	} catch (error) { self.postMessage({ error: error.message || 'The page details in this ZIP could not be read. Export the page again and try the new ZIP.' }); }
};
