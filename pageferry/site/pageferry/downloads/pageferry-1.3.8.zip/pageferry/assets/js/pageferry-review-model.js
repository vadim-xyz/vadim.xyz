/* Display facts grant no write authority. */
(function () {
 'use strict';
 var __ = window.wp.i18n.__, _n = window.wp.i18n._n, sprintf = window.wp.i18n.sprintf;
 function derive(model, selection) {
  var update = model.target === 'update', seen = new Set(), actions = {}, added = 0, reused = 0, missing = [];
  var warnings = model.warnings.slice(), facts = [update ? __('Replace the page content', 'pageferry') : __('Create a new draft', 'pageferry')];
  var fields = model.fields, overrides = selection.overrides || {};
  function value(key) { return Object.prototype.hasOwnProperty.call(overrides, key) ? overrides[key] : fields[key === 'thumbnail' ? 'thumbnail_old_id' : key]; }
  function selected(key) { return selection.fields.indexOf(key) !== -1; }
  var title = selected('title') ? value('title') || '' : update ? model.target_title : '';
  var slug = selected('slug') ? value('slug') || '' : model.target_slug;
  facts.push(sprintf(__('Title: %s', 'pageferry'), title));
  facts.push(sprintf(update ? (slug === model.target_slug ? __('Keep current URL: %s', 'pageferry') : __('Requested URL slug: %s', 'pageferry')) : __('Requested URL slug: %s', 'pageferry'), slug));
  facts.push(!selected('excerpt') ? (update ? __('Keep current excerpt', 'pageferry') : __('No excerpt', 'pageferry')) : value('excerpt') ? __('Use the excerpt shown', 'pageferry') : update ? __('Clear the excerpt', 'pageferry') : __('No excerpt', 'pageferry'));
  model.media_order.forEach(function (id) {
   var media = model.media[id], action = 'excluded';
   if (selection.media.indexOf(id) !== -1) {
    if (media.missing) { action = 'missing'; missing.push(id); }
    else { action = media.library || seen.has(media.hash) ? 'reuse' : 'new'; seen.add(media.hash); if (action === 'new') { added++; } else { reused++; } }
   }
   actions[id] = action;
  });
  if (missing.length) { warnings.push(sprintf(_n('%1$d media file is missing and will be skipped. Check the page after importing. Source media ID: %2$s.', '%1$d media files are missing and will be skipped. Check the page after importing. Source media IDs: %2$s.', missing.length, 'pageferry'), missing.length, missing.join(', '))); }
  if (selection.media.length < model.media_order.length) { warnings.push(__('Files you deselect will not be imported. Images and links that use them may still point to the source site or stop working. Check them in the editor after importing.', 'pageferry')); }
  var image = value('thumbnail'), imageText;
  if (!selected('thumbnail') || image === undefined) { imageText = update ? __('Keep the current featured image', 'pageferry') : __('No featured image', 'pageferry'); }
  else if (!image) { imageText = update ? __('Remove the featured image', 'pageferry') : __('No featured image', 'pageferry'); }
  else if (!model.media[image] || model.media[image].missing || selection.media.indexOf(Number(image)) === -1) {
   imageText = update ? __('Keep the current featured image', 'pageferry') : __('No featured image', 'pageferry');
   if (update) { warnings.push(__('The selected featured image is unavailable. The current featured image will be kept.', 'pageferry')); }
  } else { imageText = sprintf(__('Featured image: %s', 'pageferry'), model.media[image].filename); }
  facts.push(imageText);
  if (Object.prototype.hasOwnProperty.call(fields, 'template')) {
   var template = value('template');
   var templateLabel = typeof template === 'string' ? template.trim() : template;
   if (templateLabel === 'default') { templateLabel = ''; }
   facts.push(!selected('template') ? __('Keep current template', 'pageferry') : sprintf(__('Template: %s', 'pageferry'), model.templates[templateLabel] || templateLabel || __('Default', 'pageferry')));
   if (selected('template') && template && template === fields.template) { warnings = warnings.concat(model.template_warnings); }
  }
  facts.push(sprintf(_n('%1$d new file · %2$d reused', '%1$d new files · %2$d reused', added, 'pageferry'), added, reused));
  var taxonomies = {};
  model.taxonomies.forEach(function (taxonomy) {
   var keys = selection.taxonomies[taxonomy.slug] || [], rows = model.groups[taxonomy.slug], required = new Set(keys), queue = keys.slice(), bySlug = new Map(), byName = new Map();
   Object.keys(rows).forEach(function (key) { var row = rows[key]; if (row.slug && !bySlug.has(row.slug)) { bySlug.set(row.slug, key); } if (!byName.has(row.name)) { byName.set(row.name, key); } });
   for (var cursor = 0; cursor < queue.length; cursor++) {
    var row = rows[queue[cursor]], parent = row.parent_slug ? bySlug.get(row.parent_slug) : byName.get(row.parent);
    if (parent && !required.has(parent)) { required.add(parent); queue.push(parent); }
   }
   var replace = selection.taxonomy_actions[taxonomy.slug] === 'replace', final = update && !replace ? taxonomy.current.slice() : [];
   var identities = new Set(final.map(function (term) { return 'id:' + term.id; }));
   taxonomy.terms.forEach(function (term) {
    if (required.has(term.key) && term.status === 'forbidden') { warnings.push(sprintf(__('You do not have permission to create “%1$s” in %2$s. Deselect it or ask an administrator to create it first.', 'pageferry'), term.name, taxonomy.label)); }
    if (keys.indexOf(term.key) === -1) { return; }
    var identity = term.existing_id > 0 ? 'id:' + term.existing_id : term.slug ? 'slug:' + term.slug : 'name:' + term.name;
    if (!identities.has(identity)) { identities.add(identity); final.push({ name: term.destination_name }); }
   });
   if (keys.length) { warnings = warnings.concat(model.taxonomy_warnings[taxonomy.slug] || []); }
   taxonomies[taxonomy.slug] = { required: required, final: final };
  });
  return { title: title, facts: facts, warnings: Array.from(new Set(warnings)), actions: actions, taxonomies: taxonomies };
 }
 function patch(form, model, selection) {
  var view = derive(model, selection), summary = form.querySelector('.pf-summary-list'), check = summary.querySelector('svg').cloneNode(true);
  var warningIcon = form.querySelector('.pf-review-warning-icon').content.firstElementChild;
  function node(tag, className, text) { var element = document.createElement(tag); element.className = className || ''; if (text !== undefined) { element.textContent = text; } return element; }
  var facts = view.facts.slice();
  if (model.target !== 'update') { form.closest('.pf-review').querySelector('.pf-destination-title').textContent = view.title || __('(Untitled)', 'pageferry'); }
  form.querySelectorAll('.pf-taxonomy').forEach(function (group) {
   var slug = group.dataset.taxonomy, taxonomy = model.taxonomies.find(function (entry) { return entry.slug === slug; });
   group.querySelectorAll('.pf-term').forEach(function (row, index) {
    var term = taxonomy.terms[index], needed = view.taxonomies[slug].required.has(term.key), chosen = (selection.taxonomies[slug] || []).indexOf(term.key) !== -1;
    row.classList.toggle('pf-term-required', needed && !chosen);
    row.querySelector('.pf-status').textContent = needed && !chosen || !term.assigned ? __('Parent only · included when needed', 'pageferry') : ({ existing: __('Existing', 'pageferry'), create: __('New', 'pageferry'), forbidden: __('Permission needed', 'pageferry'), unavailable: __('Unavailable', 'pageferry') })[term.status];
   });
   var selected = taxonomy.terms.filter(function (term) { return (selection.taxonomies[slug] || []).indexOf(term.key) !== -1; }).map(function (term) { return term.destination_name; });
   var replace = selection.taxonomy_actions[slug] === 'replace', label = group.dataset.label;
   if (group.dataset.available !== '1' || group.dataset.canAssign !== '1' || taxonomy.terms.some(function (term) { return view.taxonomies[slug].required.has(term.key) && term.status === 'forbidden'; })) { return; }
   if (!selected.length && !taxonomy.current.length && !replace) { return; }
   if (model.target !== 'update' || !taxonomy.current.length) { facts.push(sprintf(__('%1$s: %2$s', 'pageferry'), taxonomy.label, selected.join(', ') || __('None selected', 'pageferry'))); }
   else { facts.push(sprintf(replace ? __('Clear current %s', 'pageferry') : __('Keep current %s', 'pageferry'), label) + (selected.length ? sprintf(replace ? __('; add %s', 'pageferry') : __('; include %s', 'pageferry'), selected.join(', ')) : '')); }
  });
  summary.replaceChildren();
  facts.forEach(function (text) { var li = node('li'); li.append(check.cloneNode(true), node('span', '', text)); summary.append(li); });
  form.querySelectorAll('.pf-media-row').forEach(function (row) {
   var action = view.actions[Number(row.querySelector('input').value)], badge = row.querySelector('.pf-media-action');
   badge.className = 'pf-status pf-media-action ' + (action === 'new' ? 'add' : action);
   badge.textContent = ({ new: __('Add file', 'pageferry'), reuse: __('Reuse existing', 'pageferry'), missing: __('Missing', 'pageferry'), excluded: __('Excluded', 'pageferry') })[action];
  });
  var notice = form.querySelector('.pf-warning');
  if (!notice) {
   notice = node('div', 'pf-notice pf-warning'); var link = node('a', '', __('Review media files', 'pageferry')); link.href = '#pf-media-heading';
   var heading = node('div', 'pf-notice-heading', __('Items to check', 'pageferry')); heading.prepend(warningIcon.cloneNode(true));
   notice.append(heading, node('ul'), link); form.querySelector('.pf-review-details').prepend(notice);
  }
  notice.hidden = !view.warnings.length; var list = notice.querySelector('ul'); list.replaceChildren();
  view.warnings.forEach(function (text) { list.append(node('li', '', text)); });
  var compatibility = Array.from(form.querySelectorAll('.pf-section')).find(function (section) { return section.querySelector('.pf-compatibility-row, .pf-failure-item'); });
  if (compatibility) {
   compatibility.querySelectorAll('.pf-compatibility-row, .pf-failure-item').forEach(function (element) { element.remove(); });
   if (!view.warnings.length) { var ok = node('p', 'pf-compatibility-row'); ok.append(check.cloneNode(true), node('span', '', __('No compatibility notes were reported.', 'pageferry'))); compatibility.append(ok); }
   view.warnings.forEach(function (text) { var note = node('div', 'pf-failure-item'), copy = node('div'); copy.append(node('p', '', text)); note.append(warningIcon.cloneNode(true), copy); compatibility.append(note); });
  }
 }
 window.pageferryReviewModel = { derive: derive, patch: patch };
})();
