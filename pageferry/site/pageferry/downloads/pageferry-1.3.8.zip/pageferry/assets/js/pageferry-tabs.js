(function () {
 'use strict';
 var shell = document.querySelector('.pageferry-page');
 if (!shell || !window.pageferryTabs) { return; }
 var __ = window.wp.i18n.__;
 var nav = shell.querySelector('.nav-tab-wrapper');
 var tabs = Array.from(nav.querySelectorAll('[data-tab]'));
 var panels = {}, loads = {}, versions = { import: 0, logs: 0, backups: 0 };
 tabs.forEach(function (tab) {
  var panel = document.getElementById('pf-panel-' + tab.dataset.tab);
  panels[tab.dataset.tab] = panel;
  tab.setAttribute('role', 'tab'); tab.setAttribute('aria-controls', panel.id);
  panel.setAttribute('role', 'tabpanel'); panel.setAttribute('aria-labelledby', tab.id); panel.tabIndex = 0;
 });
 nav.setAttribute('role', 'tablist'); nav.setAttribute('aria-label', __('PageFerry views', 'pageferry'));
 function backupState(url) {
  var parsed = new URL(url, location.href);
  var key = parsed.searchParams.get('backup') || '';
  var state = new URLSearchParams({ backup_page: parsed.searchParams.get('backup_page') || '1', backup: key });
  if (!key && /^#pageferry-backup-[a-f0-9]{32}$/.test(parsed.hash)) { state.set('backup_anchor', parsed.hash.slice(18)); }
  return state.toString();
 }
 var backupSelection = new URLSearchParams({ backup_page: panels.backups.dataset.backupPage || '1', backup: panels.backups.dataset.backupKey || '' }).toString();
 var active = tabs.find(function (tab) { return tab.classList.contains('nav-tab-active'); }).dataset.tab;
 function updateTabs() {
  tabs.forEach(function (tab) {
   var selected = tab.dataset.tab === active;
   tab.classList.toggle('nav-tab-active', selected); tab.setAttribute('aria-selected', String(selected));
   tab.tabIndex = selected ? 0 : -1; tab.removeAttribute('aria-current'); panels[tab.dataset.tab].hidden = !selected;
  });
  shell.querySelectorAll('[data-import-return]').forEach(function (link) {
   link.textContent = panels.import.querySelector('.pf-result') ? __('Back to result', 'pageferry') : __('Back to import', 'pageferry');
  });
 }
 function loading(panel, failed) {
  panel.replaceChildren();
  var box = document.createElement('div'); box.className = 'pf-workspace pf-tab-state';
  var text = document.createElement(failed ? 'p' : 'h3'); text.setAttribute('role', failed ? 'alert' : 'status');
  text.textContent = failed ? __('This view could not be loaded. Try again.', 'pageferry') : ({ import: __('Loading import form…', 'pageferry'), logs: __('Loading import log…', 'pageferry'), backups: __('Loading recovery snapshots…', 'pageferry') })[panel.dataset.tab];
  box.append(text);
  if (!failed) {
   var note = document.createElement('p'); note.className = 'pf-note';
   note.textContent = ({ import: __('Opening the import form.', 'pageferry'), logs: __('Loading recent import results.', 'pageferry'), backups: __('Loading previous page versions.', 'pageferry') })[panel.dataset.tab];
   var activity = document.createElement('div'); activity.className = 'pf-indeterminate'; activity.setAttribute('aria-hidden', 'true');
   box.append(note, activity);
  }
  if (failed) {
   var retry = document.createElement('button'); retry.type = 'button'; retry.className = 'button'; retry.textContent = __('Try again', 'pageferry');
   retry.addEventListener('click', function () { loading(panel); load(panel.dataset.tab).catch(function () {}); }); box.append(retry);
  }
  panel.append(box);
 }
 function load(name) {
  var panel = panels[name];
  if (panel.dataset.loaded === '1') { return Promise.resolve(); }
  if (loads[name]) { return loads[name]; }
  var version = versions[name];
  var data = new URLSearchParams({ action: 'pageferry_admin_view', nonce: window.pageferryTabs.nonce, view: name });
  if (name === 'backups') { new URLSearchParams(backupSelection).forEach(function (value, key) { data.set(key, value); }); }
  panel.setAttribute('aria-busy', 'true');
  var request = fetch(window.pageferryTabs.url, { method: 'POST', credentials: 'same-origin', body: data }).then(function (response) {
   if (!response.ok) { throw new Error('View unavailable'); } return response.json();
  }).then(function (response) {
   if (!response.success || typeof response.data.html !== 'string') { throw new Error('View unavailable'); }
   if (versions[name] !== version) { return; }
   // Trust only escaped HTML from the authenticated, capability-filtered renderer.
   panel.innerHTML = response.data.html; panel.dataset.loaded = '1'; panel.removeAttribute('aria-busy');
   document.dispatchEvent(new Event('pageferry:tab-ready')); updateTabs();
  }).catch(function (error) {
   if (versions[name] === version) { panel.removeAttribute('aria-busy'); loading(panel, true); } throw error;
  }).finally(function () {
   if (loads[name] === request) { delete loads[name]; }
   if (versions[name] !== version && name === active) { load(name).catch(function () {}); }
  });
  loads[name] = request; return request;
 }
 function select(name, url, push) {
  if (!panels[name]) { return; }
  if (name === 'backups') {
   var nextBackup = backupState(url);
   if (nextBackup !== backupSelection) { backupSelection = nextBackup; versions.backups++; panels.backups.dataset.loaded = '0'; }
  }
  active = name; updateTabs();
  if (push) { history.pushState(null, '', url); }
  if (panels[name].dataset.loaded !== '1' && !loads[name]) { loading(panels[name]); }
  load(name).then(function () {
   if (active !== name) { return; }
   var hash = new URL(url, location.href).hash;
   if (hash) { var target = document.getElementById(hash.slice(1)); if (target && panels[name].contains(target)) { target.scrollIntoView(); } }
  }).catch(function () {});
 }
 shell.addEventListener('click', function (event) {
  var link = event.target.closest('a[href]');
  if (!link || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || link.target || link.hasAttribute('download')) { return; }
  var url = new URL(link.href, location.href);
  if (url.origin !== location.origin || url.pathname !== location.pathname || url.searchParams.get('page') !== 'pageferry-import') { return; }
  var name = url.searchParams.get('tab') || 'import';
  if (!panels[name] || (!link.dataset.tab && name === 'import' && !link.hasAttribute('data-import-return'))) { return; }
  event.preventDefault(); select(name, url.href, true);
 });
 nav.addEventListener('keydown', function (event) {
  var index = tabs.indexOf(event.target); if (index < 0) { return; }
  var direction = getComputedStyle(nav).direction === 'rtl' ? -1 : 1;
  if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
   event.preventDefault(); tabs[(index + (event.key === 'ArrowRight' ? direction : -direction) + tabs.length) % tabs.length].focus();
  } else if (event.key === 'Home' || event.key === 'End') { event.preventDefault(); tabs[event.key === 'Home' ? 0 : tabs.length - 1].focus(); }
  else if (event.key === ' ' || event.key === 'Enter') { event.preventDefault(); select(event.target.dataset.tab, event.target.href, true); }
 });
 window.addEventListener('popstate', function () { select(new URL(location.href).searchParams.get('tab') || 'import', location.href, false); });
 document.addEventListener('pageferry:result', function () {
  ['logs', 'backups'].forEach(function (name) { versions[name]++; panels[name].dataset.loaded = '0'; });
  updateTabs();
  if (active !== 'import') { load(active).catch(function () {}); }
 });
 updateTabs();
 // Recovery payloads can be large; load them only on explicit navigation.
 if (active === 'backups' && backupState(location.href) !== backupSelection) { select('backups', location.href, false); }
 var warm = function () { load('logs').catch(function () {}); };
 if (window.requestIdleCallback) { window.requestIdleCallback(warm, { timeout: 1500 }); } else { window.setTimeout(warm, 300); }
})();
