/* global self, importScripts, PageFerryZip */
try { importScripts('vendor/fflate.min.js', 'import-zip-reader.js' + (self.location ? self.location.search : '')); } catch (loadError) { /* Defer load failures until the client sends start. */ }
(function () {
	'use strict';
	var state = 'idle', reader, queue, current, total = 0, used = 0, declared;
	function fail(error) {
		if (state !== 'failed') { state = 'failed'; reader = null; queue = null; self.postMessage({ type: 'error', message: error.message || 'Your browser could not read this ZIP. Export the page again and try the new ZIP.' }); }
	}
	async function next() {
		if (!queue.length) { state = 'done'; reader = null; self.postMessage({ type: 'done' }); return; }
		current = queue.shift(); state = 'extracting';
		var entry = reader.byName['media/' + current], pending = new Uint8Array(65536), length = 0;
		self.postMessage({ type: 'file-start', name: current, size: entry.size });
		function send() {
			var buffer = length === pending.length ? pending.buffer : pending.slice(0, length).buffer;
			self.postMessage({ type: 'file-chunk', name: current, data: buffer }, [buffer]);
			pending = new Uint8Array(65536); length = 0;
		}
		await reader.extract(entry, Math.min(reader.limits.media_file_bytes, reader.limits.path_b_bytes - used, reader.limits.core_bytes - used), function (bytes) {
			if (state === 'failed') { throw new Error('ZIP preparation has stopped. Select the ZIP again and prepare a new review.'); }
			for (var at = 0; at < bytes.length;) {
				var take = Math.min(pending.length - length, bytes.length - at);
				pending.set(bytes.subarray(at, at + take), length); at += take; length += take;
				if (length === pending.length) { send(); }
			}
		});
		if (state === 'failed') { return; }
		if (length) { send(); }
		used += entry.size; pending = null; state = 'ack';
		self.postMessage({ type: 'file-end', name: current, size: entry.size });
	}
	self.onmessage = function (event) {
		Promise.resolve().then(async function () {
			var message = event.data || {};
			if (state === 'failed' || state === 'done') { return; }
			if (state === 'idle' && message.file) {
				state = 'indexing';
				if (typeof PageFerryZip === 'undefined' || typeof self.fflate === 'undefined') { throw new Error('Your browser could not load the ZIP reader. Reload this screen and try again.'); }
				if (!(message.file instanceof Blob)) { throw new Error('Choose a PageFerry ZIP, then prepare the review again.'); }
				var indexed = await new PageFerryZip.Reader(message.file, message.limits).index();
				if (state === 'failed') { return; }
				reader = indexed;
				var result = await reader.manifest();
				if (state === 'failed') { return; }
				state = 'plan'; declared = Object.create(null);
				result.files.forEach(function (file) { declared[file.name] = true; });
				self.postMessage({ type: 'manifest', manifest: result.manifest, files: result.files });
			} else if (state === 'plan' && message.type === 'plan' && Array.isArray(message.files)) {
				reader.limits = PageFerryZip.limits(message.limits, reader.limits);
				var seen = Object.create(null); total = 0;
				queue = message.files.map(function (name) {
					var entry = typeof name === 'string' && reader.byName['media/' + name];
					if (!entry || !declared[name] || seen[name] || entry.size > reader.limits.media_file_bytes) { throw new Error('The browser could not prepare the media uploads. Select the ZIP again and prepare a new review.'); }
					seen[name] = true; total += entry.size; return name;
				});
				if (queue.length > reader.limits.required_files || total > Math.min(reader.limits.path_b_bytes, reader.limits.core_bytes)) { throw new Error('This ZIP exceeds the import limits. Reduce the page content or media files and export again.'); }
				await next();
			} else if (state === 'ack' && message.type === 'ack' && message.name === current) { await next(); }
			else { throw new Error('The browser could not prepare the import. Reload this screen and select your ZIP again.'); }
		}).catch(fail);
	};
})();
