<?php
/**
 * Shared import review, destination lookup and private image previews.
 *
 * @package PageFerry
 */

defined( 'ABSPATH' ) || exit;

/** Server-rendered views used by the classic and browser transports. */
class PageFerry_Import_Review {

	/**
	 * Fixed decorative icons for the shared import views.
	 *
	 * @param string $name Fixed icon name.
	 * @return string
	 */
	public static function icon( string $name ): string {
		$paths = array(
			'check'   => '<path d="m5 12 4 4L19 6"/>',
			'arrow'   => '<path d="M4 12h16m-6-6 6 6-6 6"/>',
			'page'    => '<path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M9 12h7M9 16h7"/>',
			'zip'     => '<path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M10 3v3m0 2v2m0 2v2"/><rect x="9" y="15" width="3" height="3" rx=".5"/>',
			'refresh' => '<path d="M20 7v5h-5M4 17v-5h5"/><path d="M6 8a7 7 0 0 1 12-2l2 2M4 16l2 2a7 7 0 0 0 12-2"/>',
			'image'   => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8" cy="9" r="1.5"/><path d="m3 17 5-5 4 4 4-6 5 7"/>',
			'info'    => '<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.1"/>',
			'warning' => '<path d="m12 3 10 18H2zM12 9v5m0 3v.1"/>',
			'close'   => '<path d="m6 6 12 12M6 18 18 6"/>',
			'shield'  => '<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6z"/><path d="m8 12 3 3 5-6"/>',
		);
		return '<svg class="pf-icon" viewBox="0 0 24 24" aria-hidden="true">' . ( $paths[ $name ] ?? $paths['info'] ) . '</svg>';
	}

	/**
	 * Register destination lookup.
	 *
	 * @return void
	 */
	public static function register_routes(): void {
		register_rest_route(
			'pageferry/v1',
			'/import/targets',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'permission_callback' => array( 'PageFerry_Rest_Import', 'check_permissions' ),
				'callback'            => static function ( WP_REST_Request $request ) {
					return rest_ensure_response( self::targets( (string) $request['post_type'], (string) $request['search'], max( 1, (int) $request['page'] ) ) );
				},
				'args'                => array(
					'post_type' => array(
						'type'     => 'string',
						'required' => true,
					),
					'search'    => array(
						'type'      => 'string',
						'default'   => '',
						'maxLength' => 200,
					),
					'page'      => array(
						'type'    => 'integer',
						'minimum' => 1,
						'maximum' => 10000,
						'default' => 1,
					),
				),
			)
		);
	}

	/**
	 * A bounded page of destinations; never expose an uneditable post title.
	 *
	 * @param string $type Destination type.
	 * @param string $search Optional title/content search.
	 * @param int    $page Result page.
	 * @return array
	 */
	public static function targets( string $type, string $search = '', int $page = 1 ): array {
		if ( ! current_user_can( 'import' ) || ! in_array( $type, PageFerry_Exporter::ferryable_post_types(), true ) ) {
			return array(
				'posts' => array(),
				'more'  => false,
			);
		}
		$query = new WP_Query(
			array(
				'post_type'      => $type,
				'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
				'posts_per_page' => 50,
				'paged'          => $page,
				's'              => $search,
				'orderby'        => 'modified',
				'order'          => 'DESC',
			)
		);
		$posts = array();
		foreach ( $query->posts as $post ) {
			if ( $post instanceof WP_Post && current_user_can( 'edit_post', $post->ID ) ) {
				$posts[] = array(
					'id'     => $post->ID,
					'title'  => '' !== $post->post_title ? $post->post_title : __( '(Untitled)', 'pageferry' ),
					'slug'   => $post->post_name,
					'status' => $post->post_status,
					'label'  => ( '' !== $post->post_title ? $post->post_title : __( '(Untitled)', 'pageferry' ) ) . ' — ' . $post->post_name . ' (' . $post->post_status . ')',
				);
			}
		}
		return array(
			'posts' => $posts,
			'more'  => $page < (int) $query->max_num_pages,
		);
	}

	/**
	 * Progress through the import flow.
	 *
	 * @param int $step Active step.
	 * @return void
	 */
	public static function steps( int $step ): void {
		$labels = array(
			1 => __( 'Set up', 'pageferry' ),
			2 => __( 'Review', 'pageferry' ),
			3 => __( 'Result', 'pageferry' ),
		);
		echo '<ol class="pf-steps" aria-label="' . esc_attr__( 'Import progress', 'pageferry' ) . '">';
		foreach ( $labels as $number => $label ) {
			echo '<li' . ( $number < $step ? ' class="pf-step-complete"' : '' ) . ( $number === $step ? ' aria-current="step"' : '' ) . '><span class="pf-step-number">' . ( $number < $step ? self::icon( 'check' ) : (string) (int) $number ) . '</span>' . esc_html( $label ) . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- icon contains only fixed SVG markup.
		}
		echo '</ol>';
	}

	/**
	 * Full review form; all manifest strings are escaped here.
	 *
	 * @param array $preview Shared core preview.
	 * @param array $context Transport and owner-bound session key.
	 * @return string HTML.
	 */
	public static function render( array $preview, array $context ): string {
		$review = $preview['review'] ?? array(
			'media'      => array(),
			'taxonomies' => array(),
			'fields'     => array(),
			'selection'  => array( 'fields' => array() ),
		);

		$update     = 'update' === $preview['target'];
		$taxonomies = array_values(
			array_filter(
				$review['taxonomies'],
				static function ( array $taxonomy ) use ( $update ): bool {
					$object = get_taxonomy( $taxonomy['slug'] );
					return ! empty( $taxonomy['terms'] ) || ( $update && ! empty( $taxonomy['current'] ) && $taxonomy['available'] && $object instanceof WP_Taxonomy && current_user_can( $object->cap->assign_terms ) );
				}
			)
		);
		$fields     = array_column( $review['fields'], null, 'key' );
		$labels     = array(
			'new'         => __( 'Add file', 'pageferry' ),
			'reuse'       => __( 'Reuse existing', 'pageferry' ),
			'missing'     => __( 'Missing', 'pageferry' ),
			'excluded'    => __( 'Excluded', 'pageferry' ),
			'existing'    => __( 'Existing', 'pageferry' ),
			'create'      => __( 'New', 'pageferry' ),
			'unavailable' => __( 'Unavailable', 'pageferry' ),
			'forbidden'   => __( 'Permission needed', 'pageferry' ),
		);

		$source_thumbnail = isset( $fields['thumbnail'] ) ? ( ! empty( $fields['thumbnail']['source'] ) ? $fields['thumbnail']['source'] : 'none' ) : ( $update ? 'keep' : 'none' );
		$thumbnail        = in_array( 'thumbnail', $review['selection']['fields'], true ) ? ( array_key_exists( 'thumbnail', $review['selection']['overrides'] ?? array() ) ? $review['selection']['overrides']['thumbnail'] : $source_thumbnail ) : 'keep';
		$thumbnail        = null === $thumbnail || '' === $thumbnail ? 'none' : $thumbnail;
		$current_image    = '';
		if ( $update && current_user_can( 'edit_post', (int) $preview['target_post_id'] ) ) {
			$current_thumbnail = get_post_thumbnail_id( (int) $preview['target_post_id'] );
			if ( $current_thumbnail && current_user_can( 'read_post', $current_thumbnail ) ) {
				$current_image = (string) wp_get_attachment_image_url( $current_thumbnail, 'medium' );
			}
		}
		$facts     = array( $update ? __( 'Replace the page content', 'pageferry' ) : __( 'Create a new draft', 'pageferry' ) );
		$facts[]   = sprintf( /* translators: %s: reviewed title. */ __( 'Title: %s', 'pageferry' ), $preview['title'] );
		$url_label = $update && ( $preview['target_slug'] ?? '' ) === $preview['slug'] ? __( 'Keep current URL: %s', 'pageferry' ) : __( 'Requested URL slug: %s', 'pageferry' );
		$facts[]   = sprintf( $url_label, $preview['slug'] );
		if ( ! in_array( 'excerpt', $review['selection']['fields'], true ) ) {
			$facts[] = $update ? __( 'Keep current excerpt', 'pageferry' ) : __( 'No excerpt', 'pageferry' );
		} else {
			$facts[] = '' === ( $fields['excerpt']['value'] ?? '' ) ? ( $update ? __( 'Clear the excerpt', 'pageferry' ) : __( 'No excerpt', 'pageferry' ) ) : __( 'Use the excerpt shown', 'pageferry' );
		}
		$facts[]               = array(
			'set'    => sprintf( /* translators: %s: featured image filename. */ __( 'Featured image: %s', 'pageferry' ), $fields['thumbnail']['value'] ?? __( 'Use selected image', 'pageferry' ) ),
			'retain' => __( 'Keep the current featured image', 'pageferry' ),
			'remove' => __( 'Remove the featured image', 'pageferry' ),
			'none'   => __( 'No featured image', 'pageferry' ),
		)[ $preview['thumbnail_action'] ];
		$template_source       = '';
		$template_value        = '';
		$current_template_name = __( 'Default', 'pageferry' );
		if ( isset( $fields['template'] ) ) {
			$template_source       = trim( $fields['template']['source'] );
			$template_source       = 'default' === $template_source ? '' : $template_source;
			$template_value        = trim( $fields['template']['value'] );
			$template_value        = 'default' === $template_value ? '' : $template_value;
			$template_name         = $preview['templates'][ $template_value ] ?? ( '' !== $template_value ? $template_value : __( 'Default', 'pageferry' ) );
			$facts[]               = ! $fields['template']['selected'] ? __( 'Keep current template', 'pageferry' ) : sprintf( /* translators: %s: template display name. */ __( 'Template: %s', 'pageferry' ), $template_name );
			$current_template      = $update ? get_page_template_slug( (int) $preview['target_post_id'] ) : '';
			$current_template_name = $preview['templates'][ $current_template ] ?? ( $current_template ? $current_template : __( 'Default', 'pageferry' ) );
		}
		$facts[]       = sprintf( /* translators: 1: new files, 2: reused files. */ _n( '%1$d new file · %2$d reused', '%1$d new files · %2$d reused', (int) $preview['media_new'], 'pageferry' ), (int) $preview['media_new'], (int) $preview['reused'] );
		$confirm_label = $update ? sprintf( /* translators: %s: singular destination post type label. */ __( 'Update %s', 'pageferry' ), self::post_type_label( $preview['post_type'] ) ) : __( 'Create draft', 'pageferry' );
		foreach ( $taxonomies as $taxonomy ) {
			$names = array_column( array_filter( $taxonomy['terms'], static fn( $term ) => $term['assigned'] && $term['selected'] ), 'name' );
			if ( '' !== self::taxonomy_problem( $taxonomy ) || ( ! $names && ! $taxonomy['current'] && 'append' === $taxonomy['action'] ) ) {
				continue;
			}
			$facts[] = self::taxonomy_effect( $taxonomy, $update, true );
		}
		ob_start();
		?>
		<div class="pf-import pf-review" tabindex="-1">
			<?php self::steps( 2 ); ?>
			<div class="pf-heading"><div><h2><?php esc_html_e( 'Review your import', 'pageferry' ); ?></h2><p><?php esc_html_e( 'Edit the details and see every item before importing.', 'pageferry' ); ?></p></div></div>
			<div class="pf-identity">
				<div><div class="pf-identity-label"><?php esc_html_e( 'From the ZIP', 'pageferry' ); ?></div><strong><?php echo esc_html( $preview['source_title'] ?? $preview['title'] ); ?></strong><p><?php echo esc_html( $preview['source_url'] ?? '' ); ?><?php echo self::source_date( $preview['source_date'] ?? '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes date markup. ?></p></div>
				<?php echo self::icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?>
				<div><div class="pf-identity-label"><?php echo esc_html( $update ? __( 'Updating on this site', 'pageferry' ) : __( 'Creating on this site', 'pageferry' ) ); ?></div><strong class="pf-destination-title"><?php echo esc_html( '' !== (string) ( $update ? $preview['target_title'] : $preview['title'] ) ? ( $update ? $preview['target_title'] : $preview['title'] ) : __( '(Untitled)', 'pageferry' ) ); ?></strong><p><?php echo esc_html( self::post_type_label( $preview['post_type'] ) ); ?> ·
					<?php if ( $update ) : ?>
						<a href="<?php echo esc_url( (string) get_edit_post_link( (int) $preview['target_post_id'], 'raw' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( self::status_label( $preview['status'] ) ); ?></a> · #<?php echo (int) $preview['target_post_id']; ?>
					<?php else : ?>
						<?php echo esc_html( self::status_label( $preview['status'] ) ); ?>
					<?php endif; ?>
					</p>
				<?php
				if ( $update ) :
					?>
					<p><?php esc_html_e( 'Current URL:', 'pageferry' ); ?> <a href="<?php echo esc_url( (string) ( $preview['target_url'] ?? '' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $preview['target_url'] ?? $preview['target_slug'] ?? '' ); ?></a></p><?php endif; ?></div>
			</div>
			<form class="pf-review-form" method="post" action="<?php echo esc_url( admin_url( 'tools.php?page=pageferry-import' ) ); ?>" data-target-id="<?php echo (int) ( $preview['target_post_id'] ?? 0 ); ?>" data-post-type="<?php echo esc_attr( $preview['post_type'] ); ?>" data-transport="<?php echo esc_attr( $context['transport'] ); ?>" data-source-thumbnail="<?php echo esc_attr( $source_thumbnail ); ?>" data-update="<?php echo $update ? '1' : '0'; ?>" data-current-slug="<?php echo esc_attr( $preview['target_slug'] ?? '' ); ?>">
				<?php wp_nonce_field( 'pageferry_import_execute' ); ?>
				<input type="hidden" name="pageferry_key" value="<?php echo esc_attr( $context['key'] ); ?>" />
				<input type="hidden" name="pageferry_choices" value="1" /><input type="hidden" name="pageferry_destination_type" value="<?php echo esc_attr( $preview['post_type'] ); ?>" />
				<input type="hidden" name="pageferry_plan" value="<?php echo esc_attr( $context['plan_token'] ?? '' ); ?>" />
				<?php if ( isset( $preview['review_model'] ) ) : ?>
					<template class="pf-review-warning-icon"><?php echo self::icon( 'warning' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?></template>
					<script type="application/json" class="pf-review-model"><?php echo wp_json_encode( $preview['review_model'], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON hex escaping prevents script termination. ?></script>
				<?php endif; ?>
				<div class="pf-review-layout">
					<aside class="pf-summary" aria-labelledby="pf-summary-heading">
						<h3 id="pf-summary-heading"><?php esc_html_e( 'This import will', 'pageferry' ); ?></h3>
						<ul class="pf-summary-list">
						<?php
						foreach ( $facts as $fact ) :
							?>
							<li><?php echo self::icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?><span><?php echo esc_html( $fact ); ?></span></li><?php endforeach; ?></ul>
						<div class="pf-summary-notice"><p><?php echo esc_html( $update ? sprintf( /* translators: %s: retained destination status. */ __( 'Status stays %s.', 'pageferry' ), self::status_label( $preview['status'] ) ) : __( 'The new content stays a draft until you publish it in WordPress.', 'pageferry' ) ); ?></p>
						<?php
						if ( $update ) :
							?>
							<p><?php esc_html_e( 'A recovery snapshot is saved before the update.', 'pageferry' ); ?></p><?php endif; ?></div>
						<div class="pf-review-actions">
							<p class="pf-review-status" role="status"><?php echo self::icon( 'shield' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?><span><?php esc_html_e( 'Review is up to date', 'pageferry' ); ?></span></p>
							<button type="submit" name="pageferry_import_step" value="review" class="button pf-refresh"><?php esc_html_e( 'Refresh review', 'pageferry' ); ?></button>
							<button type="submit" name="pageferry_import_step" value="execute" class="button button-primary pf-confirm"><?php echo esc_html( $confirm_label ); ?></button>
							<p><a href="<?php echo esc_url( admin_url( 'tools.php?page=pageferry-import' ) ); ?>"><?php esc_html_e( 'Choose another destination', 'pageferry' ); ?></a></p>
							<p class="pf-note"><?php esc_html_e( 'Choose the ZIP again to change destination.', 'pageferry' ); ?></p>
						</div>
					</aside>
					<div class="pf-review-details">
						<?php
						if ( ! empty( $preview['warnings'] ) ) :
							?>
							<div class="pf-notice pf-warning"><div class="pf-notice-heading"><?php echo self::icon( 'warning' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?><?php esc_html_e( 'Items to check', 'pageferry' ); ?></div><ul>
							<?php
							foreach ( array_unique( $preview['warnings'] ) as $warning ) :
								?>
							<li><?php echo esc_html( $warning ); ?></li><?php endforeach; ?></ul><a href="#pf-media-heading"><?php esc_html_e( 'Review media files', 'pageferry' ); ?></a></div><?php endif; ?>
						<div class="pf-workspace">
						<section class="pf-section"><h3><?php esc_html_e( 'Page details', 'pageferry' ); ?></h3><p class="pf-included-note"><?php echo self::icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?><span><?php echo esc_html( $update ? __( 'The page content and supported custom field values will be imported. The details below come from the ZIP, except the URL slug, which starts with the current page URL.', 'pageferry' ) : __( 'The page content and supported custom field values will be imported. You can edit the details from the ZIP below.', 'pageferry' ) ); ?></span></p>
						<?php
						foreach ( array(
							'title'   => __( 'Title', 'pageferry' ),
							'slug'    => __( 'URL slug', 'pageferry' ),
							'excerpt' => __( 'Excerpt', 'pageferry' ),
						) as $key => $label ) :
							?>
							<div class="pf-edit-field"><div class="pf-section-heading"><label for="pf-edit-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label><button type="button" class="button-link pf-reset" data-reset="<?php echo esc_attr( $key ); ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: field name. */ __( 'Reset %s to the ZIP value', 'pageferry' ), $label ) ); ?>"><?php esc_html_e( 'Reset', 'pageferry' ); ?></button></div>
								<input type="hidden" name="pageferry_fields[]" value="<?php echo esc_attr( $key ); ?>" />
															<?php
															if ( 'excerpt' === $key ) :
																?>
																<textarea rows="3" id="pf-edit-excerpt" name="pageferry_override[excerpt]" data-source="<?php echo esc_attr( $fields[ $key ]['source'] ?? '' ); ?>"><?php echo esc_textarea( $fields[ $key ]['value'] ?? '' ); ?></textarea>
																<?php
								else :
									?>
									<input type="text" id="pf-edit-<?php echo esc_attr( $key ); ?>" name="pageferry_override[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $fields[ $key ]['value'] ?? '' ); ?>" data-source="<?php echo esc_attr( $fields[ $key ]['source'] ?? '' ); ?>" maxlength="2000" <?php echo 'slug' === $key ? 'aria-describedby="pf-slug-hint" spellcheck="false" autocomplete="off"' : ''; ?> <?php echo $update && 'slug' === $key && '' !== ( $preview['target_slug'] ?? '' ) ? 'required' : ''; ?> /><?php endif; ?>
															<?php
															if ( 'slug' === $key ) :
																?>
																<p class="pf-note pf-url-effect" id="pf-slug-hint"><?php echo esc_html( $update ? __( 'Changing this may affect existing links.', 'pageferry' ) : __( 'WordPress may adjust this if the URL is already in use.', 'pageferry' ) ); ?></p><?php endif; ?>
							</div>
						<?php endforeach; ?>
						<fieldset class="pf-featured"><legend><?php esc_html_e( 'Featured image', 'pageferry' ); ?></legend><p class="pf-note"><?php echo esc_html( $update ? __( 'Choose an imported image, keep the current image, or remove it.', 'pageferry' ) : __( 'Choose an imported image, or leave this empty.', 'pageferry' ) ); ?></p><div class="pf-featured-options">
							<?php foreach ( $review['media'] as $media ) : ?>
								<?php
								if ( $media['missing'] || ( 0 !== strpos( $media['mime'], 'image/' ) && 'svg' !== strtolower( pathinfo( $media['filename'], PATHINFO_EXTENSION ) ) ) ) {
									continue; }
								?>
								<label class="pf-featured-option"><span class="pf-featured-preview"><img data-pf-preview-src="<?php echo esc_url( self::media_url( $context, $media['id'] ) ); ?>" alt="" hidden /><noscript><img src="<?php echo esc_url( self::media_url( $context, $media['id'] ) ); ?>" alt="" loading="lazy" /></noscript></span><input type="radio" name="pageferry_thumbnail" value="<?php echo (int) $media['id']; ?>" <?php checked( (string) $thumbnail, (string) (int) $media['id'] ); ?> /><span><?php echo esc_html( $media['filename'] ); ?></span></label>
							<?php endforeach; ?>
							<?php
							if ( $update ) :
								?>
								<label class="pf-featured-option">
								<?php
								if ( $current_image ) :
									?>
								<span class="pf-featured-preview"><img data-pf-preview-src="<?php echo esc_url( $current_image ); ?>" alt="" hidden /><noscript><img src="<?php echo esc_url( $current_image ); ?>" alt="" loading="lazy" /></noscript></span>
									<?php
else :
	?>
	<span class="pf-featured-empty"><?php echo self::icon( 'image' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?></span><?php endif; ?><input type="radio" name="pageferry_thumbnail" value="keep" <?php checked( 'keep' === $thumbnail ); ?> /><span><?php esc_html_e( 'Keep current image', 'pageferry' ); ?></span></label><?php endif; ?>
							<label class="pf-featured-option"><span class="pf-featured-empty"><?php echo self::icon( 'image' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?></span><input type="radio" name="pageferry_thumbnail" value="none" <?php checked( 'none' === $thumbnail || ( 0 === (int) $thumbnail && 'keep' !== $thumbnail ) ); ?> /><span><?php echo esc_html( $update ? __( 'Remove featured image', 'pageferry' ) : __( 'No featured image', 'pageferry' ) ); ?></span></label>
						</div></fieldset><p class="pf-featured-conflict pf-caution" role="status" hidden><?php esc_html_e( 'Include the featured image in Media, or choose another featured image before importing.', 'pageferry' ); ?></p>
						<?php
						if ( isset( $fields['template'] ) ) :
							?>
							<div class="pf-template-line"><label for="pf-template"><?php esc_html_e( 'Page template', 'pageferry' ); ?></label><select id="pf-template" name="pageferry_template">
							<?php
							if ( $update ) :
								?>
								<option value="keep" <?php selected( ! $fields['template']['selected'] ); ?>><?php echo esc_html( sprintf( /* translators: %s: current template display name. */ __( 'Keep current — %s', 'pageferry' ), $current_template_name ) ); ?></option><?php endif; ?>
							<option value="source" <?php selected( $fields['template']['selected'] && $template_value === $template_source ); ?>><?php echo esc_html( sprintf( /* translators: %s: source template display name. */ __( '%s (from ZIP)', 'pageferry' ), $preview['templates'][ $template_source ] ?? ( '' !== $template_source ? $template_source : __( 'Default', 'pageferry' ) ) ) ); ?></option>
							<?php if ( '' !== $template_source ) : ?>
							<option value="none" <?php selected( $fields['template']['selected'] && array_key_exists( 'template', $review['selection']['overrides'] ?? array() ) && '' === $review['selection']['overrides']['template'] ); ?>><?php esc_html_e( 'Default template', 'pageferry' ); ?></option><?php endif; ?>
							<?php
							foreach ( $preview['templates'] ?? array() as $file => $label ) :
								if ( (string) $file === $template_source ) {
									continue;
								}
								?>
								<option value="<?php echo esc_attr( $file ); ?>" <?php selected( $review['selection']['overrides']['template'] ?? null, $file ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?>
						</select><input type="hidden" name="pageferry_template_source" value="<?php echo esc_attr( $fields['template']['source'] ); ?>" /></div><p class="pf-note"><?php esc_html_e( 'Unavailable templates are listed in the compatibility notes.', 'pageferry' ); ?></p><?php endif; ?>
						</section>
						<section class="pf-section" data-choice-group><div class="pf-section-heading"><h3 id="pf-media-heading"><?php esc_html_e( 'Media', 'pageferry' ); ?> <span class="pf-media-count pf-note"><?php printf( /* translators: 1: selected media, 2: total media. */ esc_html__( '%1$d of %2$d selected', 'pageferry' ), count( array_filter( $review['media'], static fn( $item ) => $item['selected'] ) ), count( $review['media'] ) ); ?></span></h3><div class="pf-bulk" hidden><button type="button" class="button-link" data-select="all"><?php esc_html_e( 'Select all', 'pageferry' ); ?></button><button type="button" class="button-link" data-select="none"><?php esc_html_e( 'Select none', 'pageferry' ); ?></button></div></div><p class="pf-note"><?php esc_html_e( 'Reused files are verified by their contents. Existing media stays unchanged.', 'pageferry' ); ?></p>
						<?php
						if ( ! $review['media'] ) :
							?>
							<p class="pf-note"><?php esc_html_e( 'This ZIP contains no media files.', 'pageferry' ); ?></p><?php endif; ?>
						<div class="pf-media-list"><?php foreach ( $review['media'] as $media ) : ?>
							<?php $locked = $media['selected'] && ! empty( $media['unchanged'] ); ?>
							<article class="pf-media-row"><input id="pf-media-<?php echo (int) $media['id']; ?>" type="checkbox" name="pageferry_media[]" value="<?php echo (int) $media['id']; ?>" <?php checked( $media['selected'] ); ?>
							<?php
							if ( $locked ) :
								?>
								disabled data-pf-locked aria-describedby="pf-media-locked-<?php echo (int) $media['id']; ?>"<?php endif; ?> aria-label="<?php echo esc_attr( sprintf( /* translators: %s: media filename. */ __( 'Include %s', 'pageferry' ), $media['filename'] ) ); ?>" /><div class="pf-media-preview">
							<?php
							if ( $locked ) :
								?>
								<input type="hidden" name="pageferry_media[]" value="<?php echo (int) $media['id']; ?>" /><?php endif; ?>
							<?php
							if ( ! $media['missing'] && ( 0 === strpos( $media['mime'], 'image/' ) || 'svg' === strtolower( pathinfo( $media['filename'], PATHINFO_EXTENSION ) ) ) ) :
								?>
								<img data-pf-preview-src="<?php echo esc_url( self::media_url( $context, $media['id'] ) ); ?>" alt="" width="76" height="58" hidden /><noscript><img src="<?php echo esc_url( self::media_url( $context, $media['id'] ) ); ?>" alt="" loading="lazy" width="76" height="58" /></noscript><?php endif; ?></div>
								<div class="pf-media-body"><label class="pf-media-name" for="pf-media-<?php echo (int) $media['id']; ?>"><?php echo esc_html( $media['filename'] ); ?></label><p class="pf-media-meta"><?php echo esc_html( size_format( $media['bytes'] ) ); ?> · <?php printf( /* translators: %d: source attachment ID. */ esc_html__( 'Source #%d', 'pageferry' ), (int) $media['id'] ); ?></p>
									<?php
									if ( $locked ) :
										?>
										<p class="pf-note" id="pf-media-locked-<?php echo (int) $media['id']; ?>"><?php esc_html_e( 'Already points to the same file in your Media Library. Included automatically; no file or image links need changing.', 'pageferry' ); ?></p>
									<?php endif; ?>
									<?php
									if ( ! empty( $media['svg_warning'] ) ) :
										?>
										<p class="pf-caution"><?php echo esc_html( $media['svg_warning'] ); ?></p><?php endif; ?>
									<?php
									if ( $media['likely_false_positive'] && ! $locked ) :
										?>
										<p class="pf-caution"><strong><?php esc_html_e( 'Check this file', 'pageferry' ); ?></strong> <?php esc_html_e( 'PageFerry could not confirm whether this file is used on the page. Deselect it if you do not need it.', 'pageferry' ); ?></p><?php endif; ?>
									<?php
									if ( $media['refs'] ) :
										?>
										<p class="pf-note"><?php esc_html_e( 'Location in the source content', 'pageferry' ); ?></p><ul class="pf-references">
										<?php
										foreach ( $media['refs'] as $ref ) :
											?>
																				<?php
																				if ( is_array( $ref ) && is_string( $ref['path'] ?? null ) && is_string( $ref['key'] ?? null ) ) :
																					?>
	<li><?php echo esc_html( ( is_string( $media['ref_labels'][ $ref['path'] ] ?? null ) ? $media['ref_labels'][ $ref['path'] ] : $ref['path'] ) . ' · ' . $ref['key'] ); ?></li><?php endif; ?><?php endforeach; ?></ul><?php endif; ?>
								</div><span class="pf-status pf-media-action <?php echo esc_attr( 'new' === $media['status'] ? 'add' : $media['status'] ); ?>" data-action="<?php echo esc_attr( $labels[ $media['status'] ] ); ?>"><?php echo esc_html( $labels[ $media['status'] ] ); ?></span><p class="pf-caution pf-excluded-note" <?php echo $media['selected'] ? 'hidden' : ''; ?>><?php esc_html_e( 'This file will not be imported. Images or links that use it may need fixing. The ZIP is prepared before you make these choices.', 'pageferry' ); ?></p>
							</article>
						<?php endforeach; ?></div></section>
						<section class="pf-section"><h3><?php esc_html_e( 'Categories and tags', 'pageferry' ); ?></h3>
						<?php
						if ( ! $taxonomies ) :
							?>
							<p class="pf-note"><?php esc_html_e( 'No categories or tags are included in this ZIP.', 'pageferry' ); ?></p><?php endif; ?>
						<?php
						foreach ( $review['taxonomies'] as $hidden_taxonomy ) {
							if ( in_array( $hidden_taxonomy['slug'], array_column( $taxonomies, 'slug' ), true ) || ! isset( $review['selection']['taxonomies'][ $hidden_taxonomy['slug'] ] ) ) {
								continue;
							}
							?>
							<input type="hidden" name="pageferry_taxonomies[]" data-hidden-taxonomy value="<?php echo esc_attr( $hidden_taxonomy['slug'] ); ?>" />
							<?php if ( 'replace' === $hidden_taxonomy['action'] ) : ?>
								<input type="hidden" name="pageferry_clear[]" value="<?php echo esc_attr( $hidden_taxonomy['slug'] ); ?>" />
							<?php endif; ?>
							<?php
						}
						foreach ( $taxonomies as $taxonomy ) :
							$term_label    = self::taxonomy_label( $taxonomy );
							$assign_object = get_taxonomy( $taxonomy['slug'] );
							$can_assign    = $assign_object instanceof WP_Taxonomy && current_user_can( $assign_object->cap->assign_terms );
							?>
							<div class="pf-taxonomy <?php echo empty( $taxonomy['terms'] ) ? 'pf-taxonomy-empty' : ''; ?>" data-taxonomy="<?php echo esc_attr( $taxonomy['slug'] ); ?>" data-label="<?php echo esc_attr( $term_label ); ?>" data-available="<?php echo $taxonomy['available'] ? '1' : '0'; ?>" data-can-assign="<?php echo $can_assign ? '1' : '0'; ?>" data-current="<?php echo esc_attr( wp_json_encode( $taxonomy['current'] ) ); ?>"><input type="hidden" name="pageferry_taxonomies[]" value="<?php echo esc_attr( $taxonomy['slug'] ); ?>" /><h4><?php echo esc_html( $taxonomy['label'] ); ?></h4>
							<?php
							if ( array_filter( $taxonomy['terms'], static fn( $term ) => $term['assigned'] ) ) :
								?>
								<div class="pf-group-head"><label class="pf-tax-all" hidden><input type="checkbox" data-tax-all aria-label="<?php echo esc_attr( sprintf( /* translators: %s: taxonomy label. */ __( 'All %s', 'pageferry' ), $term_label ) ); ?>" /><?php esc_html_e( 'All', 'pageferry' ); ?></label></div><?php endif; ?>
							<?php
							if ( $update ) :
								?>
								<p class="pf-note pf-current-terms"><?php printf( /* translators: 1: taxonomy label, 2: current names. */ esc_html__( 'Current %1$s: %2$s.', 'pageferry' ), esc_html( $term_label ), esc_html( $taxonomy['current'] ? implode( ', ', array_column( $taxonomy['current'], 'name' ) ) : __( 'None', 'pageferry' ) ) ); ?></p><?php endif; ?>
							<?php
							if ( ! $taxonomy['available'] ) :
								?>
								<p class="pf-caution"><?php esc_html_e( 'These categories or tags are unavailable for the selected content type. Deselect them, or ask an administrator to enable the plugin or theme that provides them. Then prepare the review again.', 'pageferry' ); ?></p><?php endif; ?>
							<div class="pf-term-options">
							<?php
							foreach ( $taxonomy['terms'] as $term ) :
								?>
								<div class="pf-term">
								<?php
								if ( $term['assigned'] ) :
									?>
									<label><input type="checkbox" name="pageferry_terms[<?php echo esc_attr( $taxonomy['slug'] ); ?>][]" value="<?php echo esc_attr( $term['key'] ); ?>" data-id="<?php echo (int) $term['existing_id']; ?>" data-slug="<?php echo esc_attr( $term['destination_slug'] ); ?>" data-name="<?php echo esc_attr( $term['destination_name'] ); ?>" data-status="<?php echo esc_attr( $term['status'] ); ?>" <?php checked( $term['selected'] ); ?> /><?php echo esc_html( $term['name'] ); ?></label>
									<?php
else :
	?>
									<strong><?php echo esc_html( $term['name'] ); ?></strong><?php endif; ?>
								<span class="pf-status <?php echo esc_attr( 'create' === $term['status'] ? 'add' : ( 'existing' === $term['status'] ? '' : 'warning' ) ); ?>"><?php echo esc_html( ! $term['assigned'] || $term['required'] ? __( 'Parent only · included when needed', 'pageferry' ) : $labels[ $term['status'] ] ); ?></span><span class="pf-note pf-term-location"><?php echo esc_html( $term['slug'] . ( '' !== $term['parent'] ? ' · ' . $term['parent'] : '' ) ); ?></span>
							</div><?php endforeach; ?></div>
							<?php
							$taxonomy_object = get_taxonomy( $taxonomy['slug'] );
							if ( $update && $taxonomy['current'] && $taxonomy['available'] && $taxonomy_object instanceof WP_Taxonomy && current_user_can( $taxonomy_object->cap->assign_terms ) ) :
								?>
								<label class="pf-clear"><input type="checkbox" name="pageferry_clear[]" value="<?php echo esc_attr( $taxonomy['slug'] ); ?>" <?php checked( 'replace' === $taxonomy['action'] ); ?> /><?php printf( /* translators: %s: taxonomy label. */ esc_html__( 'Clear current %s', 'pageferry' ), esc_html( $term_label ) ); ?></label><?php elseif ( 'replace' === $taxonomy['action'] ) : ?>
								<input type="hidden" name="pageferry_clear[]" value="<?php echo esc_attr( $taxonomy['slug'] ); ?>" />
							<?php endif; ?>
							<p class="pf-taxonomy-effect"><?php echo esc_html( self::taxonomy_effect( $taxonomy, $update ) ); ?></p></div><?php endforeach; ?></section>
						<section class="pf-section"><h3><?php esc_html_e( 'Compatibility notes', 'pageferry' ); ?></h3>
						<?php
						if ( empty( $preview['warnings'] ) ) :
							?>
							<p class="pf-compatibility-row"><?php echo self::icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?><span><?php esc_html_e( 'No compatibility notes were reported.', 'pageferry' ); ?></span></p>
							<?php
else :
	?>
							<?php
							foreach ( array_unique( $preview['warnings'] ) as $warning ) :
								?>
	<div class="pf-failure-item"><?php echo self::icon( 'warning' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?><div><p><?php echo esc_html( $warning ); ?></p></div></div><?php endforeach; ?><?php endif; ?></section>
						<div class="pf-review-end-actions"><button type="submit" name="pageferry_import_step" value="review" class="button pf-end-refresh"><?php esc_html_e( 'Refresh review', 'pageferry' ); ?></button><button type="submit" name="pageferry_import_step" value="execute" class="button button-primary pf-end-confirm"><?php echo esc_html( $confirm_label ); ?></button><p class="pf-note pf-review-update-note"><?php esc_html_e( 'Changes require refreshing the review before importing.', 'pageferry' ); ?></p></div>
						</div>
					</div>
				</div><input type="hidden" name="pageferry_choices_complete" value="1" />
			</form>
			<div class="pf-working pf-execution-working" hidden><div class="pf-working-destination"><?php echo self::icon( 'page' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?><strong><?php echo esc_html( $preview['title'] ); ?></strong></div><h3><?php esc_html_e( 'Saving content and selected items…', 'pageferry' ); ?></h3><div class="pf-indeterminate" role="progressbar" aria-label="<?php esc_attr_e( 'Importing selected content', 'pageferry' ); ?>"></div><p><?php esc_html_e( 'Keep this page open while the import finishes.', 'pageferry' ); ?></p><p class="pf-note"><?php esc_html_e( 'The import has started. It can no longer be cancelled.', 'pageferry' ); ?></p></div>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Displays a valid export timestamp using the site's date and timezone.
	 *
	 * @param string $date Optional ISO 8601 source timestamp.
	 * @return string Escaped time markup, or empty for older/invalid metadata.
	 */
	private static function source_date( string $date ): string {
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2})$/D', $date ) ) {
			return '';
		}
		try {
			$time   = new DateTimeImmutable( $date );
			$errors = DateTimeImmutable::getLastErrors();
			if ( $errors && ( $errors['warning_count'] || $errors['error_count'] ) ) {
				return '';
			}
		} catch ( Exception $error ) {
			return '';
		}
		$timestamp = $time->getTimestamp();
		$label     = sprintf( /* translators: %s: localized source export date. */ __( 'Exported %s', 'pageferry' ), wp_date( get_option( 'date_format' ), $timestamp ) );
		$full_time = wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) . ' T', $timestamp );
		return ' · <time class="pf-export-date" datetime="' . esc_attr( gmdate( 'c', $timestamp ) ) . '" title="' . esc_attr( $full_time ) . '">' . esc_html( $label ) . '</time>';
	}

	/**
	 * Returns a readable group name for assignment instructions.
	 *
	 * @param array $taxonomy Reviewed group.
	 * @return string
	 */
	private static function taxonomy_label( array $taxonomy ): string {
		return 'category' === $taxonomy['slug'] ? __( 'categories', 'pageferry' ) : ( 'post_tag' === $taxonomy['slug'] ? __( 'tags', 'pageferry' ) : $taxonomy['label'] );
	}

	/**
	 * Identifies assignment problems already known before execution.
	 *
	 * @param array $taxonomy Reviewed group.
	 * @return string Problem type, or an empty string for usable choices.
	 */
	private static function taxonomy_problem( array $taxonomy ): string {
		$selected = array_filter( $taxonomy['terms'], static fn( $term ) => $term['assigned'] && $term['selected'] );
		if ( ! $taxonomy['available'] ) {
			return 'unavailable';
		}
		if ( ! $selected && 'append' === $taxonomy['action'] ) {
			return '';
		}
		$object = get_taxonomy( $taxonomy['slug'] );
		if ( ! $object instanceof WP_Taxonomy || ! current_user_can( $object->cap->assign_terms ) ) {
			return 'assignment';
		}
		return array_filter( $selected, static fn( $term ) => 'forbidden' === $term['status'] ) ? 'creation' : '';
	}

	/**
	 * Describes group-specific choices and the planned resulting set.
	 *
	 * @param array $taxonomy Reviewed group.
	 * @param bool  $update Update mode.
	 * @param bool  $summary Short summary copy.
	 * @return string
	 */
	private static function taxonomy_effect( array $taxonomy, bool $update, bool $summary = false ): string {
		$problem = self::taxonomy_problem( $taxonomy );
		$label   = self::taxonomy_label( $taxonomy );
		if ( '' !== $problem ) {
			$messages = array(
				/* translators: %s: taxonomy label. */
				'unavailable' => __( 'The %s in this ZIP are unavailable on this site. Deselect them, or ask an administrator to enable the plugin or theme that provides them. Then prepare the review again.', 'pageferry' ),
				/* translators: %s: taxonomy label. */
				'assignment'  => __( 'You do not have permission to add %s to this page. Ask an administrator to import them.', 'pageferry' ),
				/* translators: %s: taxonomy label. */
				'creation'    => __( 'Some selected %s cannot be created with your current permissions. Deselect those marked Permission needed or ask an administrator to import them.', 'pageferry' ),
			);
			return sprintf( $messages[ $problem ], $label );
		}
		$append     = 'append' === $taxonomy['action'];
		$final      = $update && $append ? $taxonomy['current'] : array();
		$identities = array();
		foreach ( $final as $term ) {
			$identities[ 'id:' . $term['id'] ] = true;
		}
		foreach ( $taxonomy['terms'] as $term ) {
			if ( ! $term['selected'] ) {
				continue; }
			$key = $term['existing_id'] > 0 ? 'id:' . $term['existing_id'] : ( '' !== $term['destination_slug'] ? 'slug:' . $term['destination_slug'] : 'name:' . $term['destination_name'] . ':' . $term['parent'] );
			if ( ! isset( $identities[ $key ] ) ) {
				$identities[ $key ] = true;
				$final[]            = array( 'name' => $term['destination_name'] );
			}
		}
		$label    = self::taxonomy_label( $taxonomy );
		$selected = array_column( array_filter( $taxonomy['terms'], static fn( $term ) => $term['selected'] ), 'destination_name' );
		if ( $summary ) {
			if ( ! $update || ! $taxonomy['current'] ) {
				return sprintf( /* translators: 1: taxonomy label, 2: selected names. */ __( '%1$s: %2$s', 'pageferry' ), $taxonomy['label'], $selected ? implode( ', ', $selected ) : __( 'None selected', 'pageferry' ) );
			}
			$effect = $append ? /* translators: placeholders are the taxonomy label or selected term names. */ __( 'Keep current %s', 'pageferry' ) : /* translators: placeholders are the taxonomy label or selected term names. */ __( 'Clear current %s', 'pageferry' );
			return sprintf( $effect, $label ) . ( $selected ? sprintf( $append ? /* translators: placeholders are the taxonomy label or selected term names. */ __( '; include %s', 'pageferry' ) : /* translators: placeholders are the taxonomy label or selected term names. */ __( '; add %s', 'pageferry' ), implode( ', ', $selected ) ) : '' );
		}
		if ( ! $update || ! $taxonomy['current'] ) {
			$effect = $selected ? /* translators: placeholders are the taxonomy label or selected term names. */ __( 'Add the selected %s from the ZIP.', 'pageferry' ) : /* translators: placeholders are the taxonomy label or selected term names. */ __( 'No %s selected. None will be added.', 'pageferry' );
		} elseif ( $append ) {
			$effect = $selected ? /* translators: placeholders are the taxonomy label or selected term names. */ __( 'Keep current %1$s and add the selected ZIP %2$s.', 'pageferry' ) : /* translators: placeholders are the taxonomy label or selected term names. */ __( 'No ZIP %1$s selected. Current %2$s will be kept.', 'pageferry' );
		} else {
			$effect = $selected ? /* translators: placeholders are the taxonomy label or selected term names. */ __( 'Clear current %1$s, then add the selected %2$s from the ZIP.', 'pageferry' ) : /* translators: placeholders are the taxonomy label or selected term names. */ __( 'No ZIP %1$s selected. This will clear current %2$s.', 'pageferry' );
		}
		return sprintf( $effect, $label, $label ) . ( $selected || $update ? ' ' . sprintf( /* translators: %s: final term names. */ __( 'After import: %s.', 'pageferry' ), $final ? implode( ', ', array_column( $final, 'name' ) ) : __( 'None', 'pageferry' ) ) : '' );
	}

	/**
	 * Returns the registered display name without changing the transport slug.
	 *
	 * @param string $type Content type slug.
	 * @return string
	 */
	public static function post_type_label( string $type ): string {
		$object = get_post_type_object( $type );
		return $object instanceof WP_Post_Type ? $object->labels->singular_name : $type;
	}

	/**
	 * Returns a readable WordPress status label.
	 *
	 * @param string $status Status slug.
	 * @return string
	 */
	public static function status_label( string $status ): string {
		$object = get_post_status_object( $status );
		return is_object( $object ) ? $object->label : $status;
	}

	/**
	 * Shared completion view, preserving the legacy caller signature.
	 *
	 * @param WP_Post $post Saved post.
	 * @param array   $warnings Notes.
	 * @param array   $outcome This operation's facts.
	 * @return string
	 */
	public static function result( WP_Post $post, array $warnings, array $outcome = array() ): string {
		$outcome['post_id']  = $post->ID;
		$outcome['warnings'] = $warnings;
		return self::outcome( $outcome + array( 'result' => 'success' ) );
	}

	/**
	 * Render saved, partial, failed or unconfirmed outcomes without guessing from logs.
	 *
	 * @param array $outcome Operation-local facts.
	 * @return string
	 */
	public static function outcome( array $outcome ): string {
		if ( ! current_user_can( 'import' ) ) {
			return ''; }
		$post_id     = (int) ( $outcome['post_id'] ?? $outcome['target'] ?? 0 );
		$post        = $post_id > 0 ? get_post( $post_id ) : null;
		$can_edit    = $post instanceof WP_Post && current_user_can( 'edit_post', $post->ID );
		$state       = $outcome['result'] ?? 'failed';
		$notes       = $outcome['warnings'] ?? array();
		$note_titles = array();
		$headings    = array(
			'term_errors'       => __( 'Some categories or tags could not be saved', 'pageferry' ),
			'thumbnail_errors'  => __( 'Featured image was not updated', 'pageferry' ),
			'template_errors'   => __( 'Template could not be set', 'pageferry' ),
			'media_errors'      => __( 'Media needs checking', 'pageferry' ),
			'acf_errors'        => __( 'Custom fields need checking', 'pageferry' ),
			'acf_skipped'       => __( 'Some custom fields were skipped', 'pageferry' ),
			'cleanup_errors'    => __( 'Temporary files need checking', 'pageferry' ),
			'pattern_warnings'  => __( 'Patterns need checking', 'pageferry' ),
			'template_warnings' => __( 'Template needs checking', 'pageferry' ),
			'export_warnings'   => __( 'Check the source export', 'pageferry' ),
		);
		foreach ( array( 'export_warnings', 'pattern_warnings', 'template_warnings', 'acf_skipped', 'term_errors', 'thumbnail_errors', 'template_errors', 'media_errors', 'acf_errors', 'cleanup_errors' ) as $key ) {
			$notes = array_merge( $notes, $outcome[ $key ] ?? array() );
			foreach ( $outcome[ $key ] ?? array() as $note ) {
				$note_titles[ (string) $note ] = $headings[ $key ]; }
		}
		$message     = $outcome['message'] ?? '';
		$post_errors = array_merge( $outcome['term_errors'] ?? array(), $outcome['thumbnail_errors'] ?? array(), $outcome['template_errors'] ?? array(), $outcome['acf_errors'] ?? array() );
		// The generic partial message duplicates the structured failures shown here.
		if ( 'partial' === $state && $post_errors && 0 === strcmp( $message, sprintf( /* translators: 1: post ID, 2: failure notes. */ __( 'Your content and media were saved (ID %1$s), but some details could not be saved. %2$s Open the editor and check these details. See the import log for more information.', 'pageferry' ), (string) $post_id, implode( ' ', $post_errors ) ) ) ) {
			$message = ''; }
		if ( ! empty( $outcome['missing'] ) ) {
			$notes[] = sprintf( /* translators: %s: missing source attachment IDs. */ __( 'Some media files were missing and could not be imported. Check the images and links on the page. Source media IDs: %s.', 'pageferry' ), implode( ', ', $outcome['missing'] ) ); }
		$title = 'partial' === $state ? __( 'Page saved, but some items need attention', 'pageferry' ) : ( 'unconfirmed' === $state ? __( 'We couldn’t confirm the result', 'pageferry' ) : __( 'The page could not be imported', 'pageferry' ) );
		if ( 'success' === $state ) {
			$title = $notes ? __( 'Page imported — review these items', 'pageferry' ) : ( 'update' === ( $outcome['action'] ?? '' ) ? sprintf( /* translators: %s: singular destination post type label. */ __( '%s updated', 'pageferry' ), $post instanceof WP_Post ? self::post_type_label( $post->post_type ) : __( 'Page', 'pageferry' ) ) : ( $post instanceof WP_Post && 'draft' !== $post->post_status ? __( 'Page created', 'pageferry' ) : __( 'Draft created', 'pageferry' ) ) ); }
		$backup       = $outcome['backup'] ?? null;
		$backups      = is_string( $backup ) ? PageFerry_Backups::history() : array();
		$snapshot     = is_array( $backups ) ? ( $backups[ $backup ] ?? null ) : null;
		$recovery_url = $can_edit && is_array( $snapshot ) && (int) ( $snapshot['post_id'] ?? 0 ) === $post->ID && PageFerry_Admin::can_view_backup( $snapshot ) ? PageFerry_Admin::backup_url( $backup ) : '';
		$saved        = in_array( $state, array( 'success', 'partial' ), true );
		$description  = 'partial' === $state ? __( 'Your page content is saved. The items below need checking.', 'pageferry' ) : ( $saved ? __( 'Your content is ready. Open the editor to check the page on this site.', 'pageferry' ) : ( 'unconfirmed' === $state ? __( 'The connection was lost after the import started. The server may have saved the page.', 'pageferry' ) : __( 'Check the details below before preparing another import.', 'pageferry' ) ) );
		ob_start();
		?>
		<div class="pf-import pf-result" tabindex="-1">
			<?php self::steps( 3 ); ?>
			<div class="pf-workspace pf-result-workspace">
				<section class="pf-outcome-top">
					<div class="pf-outcome-heading"><span class="pf-outcome-symbol <?php echo esc_attr( ! $saved && 'unconfirmed' !== $state ? 'error' : ( $notes || 'unconfirmed' === $state ? 'warning' : '' ) ); ?>"><?php echo self::icon( ! $saved && 'unconfirmed' !== $state ? 'close' : ( $notes ? 'warning' : ( 'unconfirmed' === $state ? 'info' : 'check' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?></span><div><h2><?php echo esc_html( $title ); ?></h2><p><?php echo esc_html( $description ); ?></p></div></div>
					<?php if ( $can_edit ) : ?>
						<div class="pf-saved-post"><?php echo self::icon( 'page' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?><div><strong><?php echo esc_html( $post->post_title ); ?></strong><p><?php echo esc_html( $saved ? (string) get_permalink( $post->ID ) : __( 'Intended destination', 'pageferry' ) ); ?></p><p><?php echo esc_html( self::post_type_label( $post->post_type ) . ' · /' . $post->post_name . '/' ); ?></p></div><span class="pf-status"><?php echo esc_html( self::status_label( $post->post_status ) ); ?></span></div>
					<?php endif; ?>
					<?php if ( $saved && isset( $outcome['uploaded'], $outcome['reused'] ) ) : ?>
						<div class="pf-result-stats"><span><?php echo self::icon( 'image' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?><?php printf( /* translators: %d: uploaded files. */ esc_html( _n( '%d new file', '%d new files', (int) $outcome['uploaded'], 'pageferry' ) ), (int) $outcome['uploaded'] ); ?></span><span><?php echo self::icon( 'refresh' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?><?php printf( /* translators: %d: reused files. */ esc_html__( '%d reused', 'pageferry' ), (int) $outcome['reused'] ); ?></span><span><?php echo self::icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?><?php esc_html_e( 'Content saved', 'pageferry' ); ?></span></div>
					<?php endif; ?>
					<div class="pf-result-actions">
						<?php
						if ( $can_edit ) :
							?>
							<a target="_blank" rel="noopener noreferrer" class="button button-primary" href="<?php echo esc_url( (string) get_edit_post_link( $post->ID, 'raw' ) ); ?>"><?php echo esc_html( 'unconfirmed' === $state ? __( 'Check destination', 'pageferry' ) : ( 'partial' === $state ? __( 'Open saved page', 'pageferry' ) : __( 'Open editor', 'pageferry' ) ) ); ?></a>
							<?php
							if ( $saved ) :
								?>
							<a target="_blank" rel="noopener noreferrer" class="button" href="<?php echo esc_url( (string) ( 'publish' === $post->post_status ? get_permalink( $post->ID ) : get_preview_post_link( $post->ID ) ) ); ?>"><?php echo esc_html( 'publish' === $post->post_status ? __( 'View page', 'pageferry' ) : __( 'Preview', 'pageferry' ) ); ?></a><?php endif; ?><?php endif; ?>
						<a target="_blank" rel="noopener noreferrer" class="pf-text-button" href="<?php echo esc_url( admin_url( 'tools.php?page=pageferry-import&tab=logs' ) ); ?>"><?php esc_html_e( 'View import log', 'pageferry' ); ?></a><a target="_blank" rel="noopener noreferrer" class="<?php echo esc_attr( $saved || 'unconfirmed' === $state ? 'pf-text-button' : 'button button-primary' ); ?>" href="<?php echo esc_url( admin_url( 'tools.php?page=pageferry-import' ) ); ?>"><?php echo esc_html( $saved || 'unconfirmed' === $state ? __( 'Import another', 'pageferry' ) : __( 'Return to setup', 'pageferry' ) ); ?></a>
					</div>
				</section>
				<?php if ( 'unconfirmed' === $state ) : ?>
					<section class="pf-result-detail"><h3><?php esc_html_e( 'Check before trying again', 'pageferry' ); ?></h3><p><?php esc_html_e( 'The server may have saved the page after the connection was lost. Check the destination and import log before trying again.', 'pageferry' ); ?></p><ol class="pf-instructions"><li><?php esc_html_e( 'Open the destination and check its title, content, and images.', 'pageferry' ); ?></li><li><?php esc_html_e( 'Look for this import in the import log.', 'pageferry' ); ?></li><li><?php esc_html_e( 'If a new draft was created, use that draft rather than importing a duplicate.', 'pageferry' ); ?></li></ol><p class="pf-note"><?php esc_html_e( 'A missing log entry does not prove the import failed.', 'pageferry' ); ?></p></section>
					<?php
					elseif ( '' !== $message ) :
						?>
					<section class="pf-result-detail"><div class="pf-notice<?php echo ! $saved ? ' error' : ''; ?>"><div class="pf-notice-heading"><?php echo self::icon( 'warning' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?><?php esc_html_e( 'Import details', 'pageferry' ); ?></div><p><?php echo esc_html( $message ); ?></p></div></section><?php endif; ?>
				<?php
				if ( $notes ) :
					?>
					<section class="pf-result-detail"><h3><?php esc_html_e( 'Items that need attention', 'pageferry' ); ?></h3>
					<?php
					foreach ( array_unique( $notes ) as $note ) :
						?>
					<div class="pf-failure-item"><?php echo self::icon( 'warning' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?><div>
						<?php
						if ( isset( $note_titles[ (string) $note ] ) ) :
							?>
						<strong><?php echo esc_html( $note_titles[ (string) $note ] ); ?></strong><?php endif; ?><p><?php echo esc_html( (string) $note ); ?></p></div></div><?php endforeach; ?></section><?php endif; ?>
				<?php
				if ( ! empty( $outcome['remaining_attachment_ids'] ) ) :
					?>
					<section class="pf-result-detail"><p><?php esc_html_e( 'These files could not be removed after the failed import. Check them in the Media Library:', 'pageferry' ); ?>
					<?php
					foreach ( $outcome['remaining_attachment_ids'] as $id ) :
						?>
										<?php
										if ( current_user_can( 'edit_post', (int) $id ) ) :
											?>
	<a target="_blank" rel="noopener noreferrer" href="<?php echo esc_url( (string) get_edit_post_link( (int) $id, 'raw' ) ); ?>"><?php echo (int) $id; ?></a> <?php endif; ?><?php endforeach; ?></p></section><?php endif; ?>
				<?php
				if ( $recovery_url ) :
					?>
					<section class="pf-result-detail"><div class="pf-recovery-info"><?php echo self::icon( 'shield' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup. ?><div><h3><?php esc_html_e( 'Your previous version is available', 'pageferry' ); ?></h3><p><?php esc_html_e( 'A snapshot was saved before this update. You can inspect it and follow the manual recovery instructions.', 'pageferry' ); ?></p><a target="_blank" rel="noopener noreferrer" class="button" href="<?php echo esc_url( $recovery_url ); ?>"><?php esc_html_e( 'View recovery snapshot', 'pageferry' ); ?></a><p class="pf-note"><?php esc_html_e( 'Recovery data is read-only. Restore the fields manually in the editor; no changes are made by opening the snapshot.', 'pageferry' ); ?></p></div></div></section><?php endif; ?>
			</div>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Private image URL; no source-host requests or public workspace URLs.
	 *
	 * @param array $context Owner-bound transport/key.
	 * @param int   $id Source media ID.
	 * @return string
	 */
	private static function media_url( array $context, int $id ): string {
		return add_query_arg(
			array(
				'action'    => 'pageferry_preview_media',
				'transport' => $context['transport'],
				'key'       => $context['key'],
				'media'     => $id,
				'_wpnonce'  => wp_create_nonce( 'pageferry_preview_' . $context['key'] ),
			),
			admin_url( 'admin-post.php' )
		);
	}

	// phpcs:disable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- PHP DOM properties use fixed API names.
	/**
	 * Inspects bounded SVG bytes for image-only display; never changes the imported file.
	 *
	 * @param string $file Verified workspace file.
	 * @return array{bytes: string, warning: string}
	 */
	public static function svg_preview( string $file ): array {
		$unavailable = array(
			'bytes'   => '',
			'warning' => __( 'This SVG cannot be previewed. Have the file checked before using it on your site.', 'pageferry' ),
		);
		if ( ! class_exists( 'DOMDocument' ) || filesize( $file ) > MB_IN_BYTES ) {
			return $unavailable;
		}
		$bytes = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- bounded local workspace read.
		if ( ! is_string( $bytes ) || false !== strpos( $bytes, "\0" ) || preg_match( '/<!DOCTYPE|<!ENTITY/i', $bytes ) ) {
			return $unavailable;
		}
		$previous = libxml_use_internal_errors( true );
		try {
			$document = new DOMDocument();
			if ( ! $document->loadXML( $bytes, LIBXML_NONET ) || $document->doctype || ! $document->documentElement || 'svg' !== $document->documentElement->localName || 'http://www.w3.org/2000/svg' !== $document->documentElement->namespaceURI ) {
				return $unavailable;
			}
			$xpath = new DOMXPath( $document );
			$nodes = $xpath->query( '//* | //processing-instruction()' );
			if ( false === $nodes || $nodes->length > 10000 ) {
				return $unavailable;
			}
			$warning = '';
			foreach ( $nodes as $node ) {
				$risky = $node instanceof DOMProcessingInstruction || in_array( strtolower( $node->localName ?? '' ), array( 'script', 'foreignobject', 'animate', 'animatemotion', 'animatetransform', 'set', 'iframe', 'object', 'embed' ), true );
				if ( $node instanceof DOMElement ) {
					foreach ( $node->attributes as $attribute ) {
						$name  = strtolower( $attribute->localName );
						$value = trim( $attribute->value );
						$risky = $risky || 0 === strpos( $name, 'on' ) || ( in_array( $name, array( 'href', 'src' ), true ) && '' !== $value && '#' !== $value[0] ) || preg_match( '/url\s*\(\s*(?![\s\x22\x27]*#)|@import/i', $value );
					}
					$risky = $risky || ( 'style' === $node->localName && preg_match( '/url\s*\(\s*(?![\s\x22\x27]*#)|@import/i', $node->textContent ) );
				}
				if ( $risky ) {
					$warning = __( 'This SVG contains code or linked content that could be unsafe when used on a page. The preview restricts that content. Have the file checked before using it on your site.', 'pageferry' );
					break;
				}
			}
			return array(
				'bytes'   => $bytes,
				'warning' => $warning,
			);
		} finally {
			libxml_clear_errors();
			libxml_use_internal_errors( $previous );
		}
	}
	// phpcs:enable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase

	/**
	 * Stream a bounded image-only preview under the workspace lease.
	 *
	 * @return void
	 */
	public static function serve_media(): void {
		$key = isset( $_GET['key'] ) && is_string( $_GET['key'] ) ? wp_unslash( $_GET['key'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- strict token regex and nonce checked below.
		if ( ! current_user_can( 'import' ) || ! preg_match( '/\A[A-Za-z0-9-]{1,80}\z/', $key ) ) {
			status_header( 403 );
			exit;
		}
		check_admin_referer( 'pageferry_preview_' . $key );
		$transport = isset( $_GET['transport'] ) && is_string( $_GET['transport'] ) ? sanitize_key( wp_unslash( $_GET['transport'] ) ) : '';
		$id        = isset( $_GET['media'] ) && is_scalar( $_GET['media'] ) ? absint( $_GET['media'] ) : 0;
		if ( ! in_array( $transport, array( 'classic', 'rest' ), true ) ) {
			status_header( 404 );
			exit;
		}
		$prefix = 'classic' === $transport ? PageFerry::TRANSIENT_IMPORT_PREFIX : PageFerry::TRANSIENT_SESSION_PREFIX;
		$stash  = get_transient( $prefix . $key );
		if ( ! is_array( $stash ) || (int) ( $stash['user_id'] ?? 0 ) !== get_current_user_id() || ! is_string( $stash['workspace'] ?? null ) ) {
			status_header( 404 );
			exit;
		}
		$operation = static function () use ( $prefix, $key, $id ) {
				$live = get_transient( $prefix . $key );
			if ( ! is_array( $live ) || (int) ( $live['user_id'] ?? 0 ) !== get_current_user_id() ) {
				return false;
			}
			foreach ( $live['manifest']['media'] ?? array() as $entry ) {
				if ( (int) ( $entry['old_id'] ?? 0 ) !== $id || ! empty( $entry['missing'] ) ) {
					continue;
				}
				$file = PageFerry_Importer::workspace_file( $live['workspace'], $entry['file'] ?? '' );
				if ( ! is_string( $file ) || filesize( $file ) > 16 * MB_IN_BYTES || ! is_string( $entry['sha256'] ?? null ) ) {
					return false;
				}
				$hash = hash_file( 'sha256', $file );
				if ( ! is_string( $hash ) || ! hash_equals( strtolower( $entry['sha256'] ), $hash ) ) {
					return false;
				}
				if ( 'svg' === strtolower( pathinfo( PageFerry_Importer::original_filename( $entry ), PATHINFO_EXTENSION ) ) ) {
					$svg = self::svg_preview( $file );
					return array(
						'bytes' => $svg['bytes'],
						'mime'  => 'image/svg+xml',
					);
				}
				$size = wp_getimagesize( $file );
				if ( ! is_array( $size ) || $size[0] * $size[1] > 8000000 || ! in_array( $size['mime'] ?? '', array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif' ), true ) ) {
					return false;
				}
				$editor = wp_get_image_editor( $file );
				if ( is_wp_error( $editor ) || ( ( $size[0] > 240 || $size[1] > 160 ) && is_wp_error( $editor->resize( 240, 160, false ) ) ) ) {
					return false;
				}
				ob_start();
				$result = $editor->stream( 'image/jpeg' );
				$output = ob_get_clean();
				return is_wp_error( $result ) ? false : array(
					'bytes' => $output,
					'mime'  => 'image/jpeg',
				);
			}
				return false;
		};
		// Thumbnail requests compete with commit for the same lease; keep waits bounded.
		$preview = PageFerry_Workspace::with_lease( $stash['workspace'], $operation, 400 );
		nocache_headers();
		header( 'X-Content-Type-Options: nosniff' );
		header( "Content-Security-Policy: sandbox; default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'" );
		if ( ! is_array( $preview ) || ! is_string( $preview['bytes'] ?? null ) || '' === $preview['bytes'] ) {
			status_header( 404 );
			exit;
		}
		header( 'Content-Type: ' . $preview['mime'] );
		echo $preview['bytes']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- verified image bytes; SVG remains image-only with restrictive CSP, including direct navigation.
		exit;
	}
}
