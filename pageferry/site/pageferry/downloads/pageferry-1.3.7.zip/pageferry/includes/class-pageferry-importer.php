<?php
/**
 * Shared ZIP importer: validation, media reuse, remapping and post persistence.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pre-write failures compensate new media; later failures retain saved content and recovery.
 */
class PageFerry_Importer {

	/**
	 * Option holding the sha256 → attachment ID reuse index.
	 *
	 * @var string
	 */
	const HASH_INDEX_OPTION = 'pageferry_hash_index';

	/**
	 * Option holding plain-language import log rows.
	 *
	 * @var string
	 */
	const LOG_OPTION = 'pageferry_logs';

	/**
	 * Option holding pre-overwrite snapshots, keyed by import ID.
	 *
	 * @var string
	 */
	const BACKUP_OPTION = 'pageferry_backups';

	/**
	 * Maximum pre-overwrite snapshots kept.
	 *
	 * @var int
	 */
	const MAX_BACKUPS = 20;

	/**
	 * Maximum import log rows kept (append_log prunes beyond this).
	 *
	 * @var int
	 */
	const MAX_LOG_ROWS = 200;

	/**
	 * Hash-index size that triggers a stale-row prune in remember_hashes().
	 *
	 * @var int
	 */
	const HASH_PRUNE_THRESHOLD = 2000;

	/**
	 * Hard cap for the hash index; oldest rows are dropped beyond this.
	 *
	 * @var int
	 */
	const MAX_HASH_ROWS = 5000;

	/**
	 * Maximum media files staged from one ZIP (zip-bomb guard).
	 *
	 * @var int
	 */
	const MAX_WORKSPACE_FILES = 500;

	/**
	 * Fallback staged-byte cap when WordPress reports no upload limit.
	 *
	 * @var int
	 */
	const MAX_WORKSPACE_BYTES_FALLBACK = 536870912;

	/**
	 * Only destination choices can authorize create status; publication needs the per-type capability.
	 *
	 * @var array<int, string>
	 */
	const ALLOWED_CREATE_STATUSES = array( 'draft', 'pending', 'private', 'publish' );

	/**
	 * Transient prefix for Path B import sessions (validate→file→commit).
	 *
	 * @var string
	 */
	const SESSION_TRANSIENT_PREFIX = 'pageferry_session_';

	/**
	 * Transient prefix for the Path A two-step form stash.
	 *
	 * @var string
	 */
	const IMPORT_TRANSIENT_PREFIX = 'pageferry_import_';

	/**
	 * Validates a decoded manifest without writing anything.
	 *
	 * @param mixed       $manifest Decoded manifest (json_decode assoc array).
	 * @param string|null $target_post_type Optional destination type override.
	 * @return array|WP_Error Array with manifest + media_index, or WP_Error.
	 */
	public static function validate( $manifest, ?string $target_post_type = null ) {
		if ( ! is_array( $manifest ) ) {
			return new WP_Error(
				'pageferry_manifest_invalid',
				__( 'The page information in this ZIP could not be read. Export the page again and try the new ZIP.', 'pageferry' )
			);
		}

		$limits = PageFerry_Import_Resources::limits();
		if ( isset( $manifest['media'] ) && is_array( $manifest['media'] ) && count( $manifest['media'] ) > $limits['media_records'] ) {
			return PageFerry_Import_Resources::exceeded();
		}
		if ( ! PageFerry_Import_Resources::manifest_fits( $manifest, $limits['manifest_bytes'] ) ) {
			return PageFerry_Import_Resources::exceeded();
		}
		$encoded = wp_json_encode( $manifest );
		if ( ! is_string( $encoded ) || strlen( $encoded ) > $limits['manifest_bytes'] ) {
			return PageFerry_Import_Resources::exceeded();
		}

		if ( isset( $manifest['plugin'] ) && 'pageferry' !== $manifest['plugin'] ) {
			return new WP_Error(
				'pageferry_manifest_plugin',
				__( 'This file was not exported by PageFerry. Choose a ZIP created with PageFerry Export.', 'pageferry' )
			);
		}

		$manifest_version = isset( $manifest['manifest_version'] ) ? (int) $manifest['manifest_version'] : 0;

		if ( 1 !== $manifest_version ) {
			return new WP_Error(
				'pageferry_manifest_version',
				sprintf(
					/* translators: %d: manifest version found in the bundle. */
					__( 'This ZIP uses an unsupported format (version %d). Update PageFerry on this site and try again.', 'pageferry' ),
					$manifest_version
				)
			);
		}

		if ( ! empty( $manifest['builder_detected'] ) && is_string( $manifest['builder_detected'] ) ) {
			return new WP_Error(
				'pageferry_builder_detected',
				sprintf(
					/* translators: %s: builder slug recorded in the manifest. */
					__( 'This page was built with %s. PageFerry supports the WordPress block editor (Gutenberg). Rebuild the page in the block editor, then export it again.', 'pageferry' ),
					$manifest['builder_detected']
				)
			);
		}

		$missing_keys = array();
		foreach ( array( 'post', 'media' ) as $required_key ) {
			if ( ! isset( $manifest[ $required_key ] ) ) {
				$missing_keys[] = $required_key;
			}
		}

		if ( array() !== $missing_keys ) {
			return new WP_Error(
				'pageferry_manifest_keys',
				sprintf(
					/* translators: %s: comma-separated list of missing manifest keys. */
					__( 'Required page information is missing from this ZIP (%s). Export the page again and try the new ZIP.', 'pageferry' ),
					implode( ', ', $missing_keys )
				)
			);
		}

		$post = $manifest['post'];

		if ( ! is_array( $post ) || ! isset( $post['post_type'], $post['slug'], $post['content'] ) ) {
			return new WP_Error(
				'pageferry_manifest_post',
				__( 'The page information in this ZIP is incomplete. Export the page again and try the new ZIP.', 'pageferry' )
			);
		}

		$bundle_post_type = is_string( $post['post_type'] ) ? $post['post_type'] : '';
		if ( null !== $target_post_type && '' !== $bundle_post_type && ! in_array( $bundle_post_type, array( 'attachment', 'revision' ), true ) ) {
			$bundle_post_type = $target_post_type;
		}

		if ( '' === $bundle_post_type || 'attachment' === $bundle_post_type || 'revision' === $bundle_post_type || ! post_type_exists( $bundle_post_type ) ) {
			if ( '' !== $bundle_post_type && ! post_type_exists( $bundle_post_type ) ) {
				return new WP_Error(
					'pageferry_unsupported_post_type',
					sprintf(
						/* translators: %s: post-type slug recorded in the bundle. */
						__( 'Content type “%s” is unavailable on this site. Choose another type or activate the plugin or theme that provides it, then import again.', 'pageferry' ),
						$bundle_post_type
					)
				);
			}

			return new WP_Error(
				'pageferry_unsupported_post_type',
				__( 'PageFerry imports content made with the WordPress block editor (Gutenberg). Choose a supported content type.', 'pageferry' )
			);
		}

		if ( ! in_array( $bundle_post_type, PageFerry_Exporter::ferryable_post_types(), true ) ) {
			return new WP_Error(
				'pageferry_unsupported_post_type',
				__( 'PageFerry imports content made with the WordPress block editor (Gutenberg). Choose a supported content type.', 'pageferry' )
			);
		}

		if ( ! is_string( $post['content'] ) ) {
			return new WP_Error(
				'pageferry_manifest_post',
				__( 'The page content in this ZIP could not be read. Export the page again and try the new ZIP.', 'pageferry' )
			);
		}

		if ( array_key_exists( 'template', $post ) ) {
			if ( ! is_string( $post['template'] ) ) {
				return new WP_Error(
					'pageferry_manifest_post',
					__( 'The page template in this ZIP could not be read. Export the page again and try the new ZIP.', 'pageferry' )
				);
			}

			$template_candidate = trim( $post['template'] );

			if ( 'default' === $template_candidate ) {
				$template_candidate = '';
			}

			if ( '' !== $template_candidate && ! self::template_slug_allowed( $template_candidate ) ) {
				return new WP_Error(
					'pageferry_manifest_post',
					__( 'The page template in this ZIP is invalid. Export the page again and try the new ZIP.', 'pageferry' )
				);
			}
		}

		if ( ! is_array( $manifest['media'] ) ) {
			return new WP_Error(
				'pageferry_manifest_media',
				__( 'The media list in this ZIP could not be read. Export the page again and try the new ZIP.', 'pageferry' )
			);
		}

		$media_index        = array();
		$file_basename_seen = array();
		foreach ( $manifest['media'] as $position => $media_entry ) {
			if ( ! is_array( $media_entry ) || ! isset( $media_entry['old_id'] ) || ! is_numeric( $media_entry['old_id'] ) ) {
				return new WP_Error(
					'pageferry_manifest_media',
					sprintf(
						/* translators: %d: 1-based position of the bad media entry. */
						__( 'A media file in this ZIP has invalid information (item %d). Export the page again and try the new ZIP.', 'pageferry' ),
						(int) $position + 1
					)
				);
			}

			$old_id = (int) $media_entry['old_id'];

			if ( isset( $media_index[ $old_id ] ) ) {
				return new WP_Error(
					'pageferry_manifest_media',
					sprintf(
						/* translators: %d: duplicated old attachment ID. */
						__( 'The media list in this ZIP contains a duplicate (source media ID %d). Export the page again and try the new ZIP.', 'pageferry' ),
						$old_id
					)
				);
			}

			$is_missing = ! empty( $media_entry['missing'] );
			$has_file   = isset( $media_entry['file'] ) && is_string( $media_entry['file'] ) && '' !== $media_entry['file'];
			$has_sha    = isset( $media_entry['sha256'] ) && is_string( $media_entry['sha256'] ) && '' !== $media_entry['sha256'];

			// Only exporter-declared missing assets may skip transport; absent claimed bytes are corruption.
			if ( ! $is_missing && ( ! $has_file || ! $has_sha ) ) {
				return new WP_Error(
					'pageferry_manifest_media',
					sprintf(
						/* translators: %d: 1-based position of the bad media entry. */
						__( 'A media file in this ZIP is missing its name or verification information (item %d). Export the page again and try the new ZIP.', 'pageferry' ),
						(int) $position + 1
					)
				);
			}

			// Basename collisions alias the same workspace file.
			if ( ! $is_missing ) {
				$declared_basename = basename( (string) $media_entry['file'] );

				if ( isset( $file_basename_seen[ $declared_basename ] ) ) {
					return new WP_Error(
						'pageferry_manifest_media',
						sprintf(
							/* translators: %s: duplicated media file name inside the bundle. */
							__( 'More than one media item in this ZIP uses the filename %s. Export the page again and try the new ZIP.', 'pageferry' ),
							$declared_basename
						)
					);
				}

				$file_basename_seen[ $declared_basename ] = true;
				if ( count( $file_basename_seen ) > $limits['required_files'] ) {
					return PageFerry_Import_Resources::exceeded();
				}
				if ( isset( $media_entry['bytes'] ) && is_numeric( $media_entry['bytes'] ) && $media_entry['bytes'] > $limits['media_file_bytes'] ) {
					return PageFerry_Import_Resources::file_exceeded( self::original_filename( $media_entry ) );
				}

				// Gate both names before staging; legacy workspaces may be web-served.
				$original_basename = self::original_filename( $media_entry );

				if ( ! self::media_basename_allowed( $declared_basename ) || ! self::media_basename_allowed( $original_basename ) ) {
					return new WP_Error(
						'pageferry_unsupported_media_type',
						sprintf(
							/* translators: %s: media file name with a disallowed extension. */
							__( 'Media file %s has a file type this site does not allow. Ask an administrator to check the file type before importing.', 'pageferry' ),
							$declared_basename
						)
					);
				}
			}

			$media_index[ $old_id ] = array(
				'entry'   => $media_entry,
				'missing' => $is_missing,
			);
		}

		if ( isset( $manifest['acf_post_meta'] ) ) {
			if ( ! is_array( $manifest['acf_post_meta'] ) ) {
				return new WP_Error(
					'pageferry_manifest_acf',
					__( 'The ACF block field values in this ZIP could not be read. Export the page again and try the new ZIP.', 'pageferry' )
				);
			}

			foreach ( $manifest['acf_post_meta'] as $acf_entry ) {
				if ( ! is_array( $acf_entry ) || ! isset( $acf_entry['block'], $acf_entry['fields'] ) || ! is_string( $acf_entry['block'] ) || ! is_array( $acf_entry['fields'] ) ) {
					return new WP_Error(
						'pageferry_manifest_acf',
						__( 'Some ACF block field values in this ZIP are incomplete. Export the page again and try the new ZIP.', 'pageferry' )
					);
				}
			}
		}

		if ( isset( $manifest['acf_post_fields'] ) ) {
			if ( ! is_array( $manifest['acf_post_fields'] ) ) {
				return new WP_Error(
					'pageferry_manifest_acf',
					__( 'The ACF custom field values in this ZIP could not be read. Export the page again and try the new ZIP.', 'pageferry' )
				);
			}

			foreach ( array_keys( $manifest['acf_post_fields'] ) as $acf_field_name ) {
				if ( ! is_string( $acf_field_name ) || '' === $acf_field_name ) {
					return new WP_Error(
						'pageferry_manifest_acf',
						__( 'An ACF custom field in this ZIP has no valid name. Export the page again and try the new ZIP.', 'pageferry' )
					);
				}
			}
		}

		return array(
			'manifest'    => $manifest,
			'media_index' => $media_index,
		);
	}

	/**
	 * Rejects executable segments even when site MIME filters allow them.
	 *
	 * @param string $basename File basename to check.
	 * @return bool True when the name is stageable media.
	 */
	public static function media_basename_allowed( string $basename ): bool {
		if ( '' === $basename || '.' === $basename || '..' === $basename ) {
			return false;
		}

		if ( basename( $basename ) !== $basename ) {
			return false;
		}

		$lower_basename = strtolower( $basename );

		foreach ( array( '.htaccess', 'user.ini', 'web.config' ) as $server_file ) {
			// A leading dot must also catch executable segments in names such as evil.htaccess.
			$stem = ltrim( $server_file, '.' );

			if ( $lower_basename === $server_file || str_ends_with( $lower_basename, '.' . $stem ) ) {
				return false;
			}
		}

		// Executable segments can hide before an allowed extension, as in shell.php.png.
		if ( 1 === preg_match( '/\.(php\d*|phtml|pht|phar|shtml|shtm|sht|stm|pl|cgi|py|rb|sh|exe|dll|so|dylib)(\.|$)/i', $basename ) ) {
			return false;
		}

		$file_type = wp_check_filetype( $basename );

		// wp_check_filetype() returns false for unknown types; an empty-string check would fail open.
		$allowed_ext  = $file_type['ext'];
		$allowed_type = $file_type['type'];

		return is_string( $allowed_ext ) && '' !== $allowed_ext && is_string( $allowed_type ) && '' !== $allowed_type;
	}

	/**
	 * Probes actual media bytes; an allowed extension alone cannot establish the file type.
	 *
	 * @param string $file_path Absolute path to the staged file.
	 * @param string $basename Claimed file basename.
	 * @return bool True when the name is allowed and the bytes match it.
	 */
	public static function staged_media_file_allowed( string $file_path, string $basename ): bool {
		if ( ! self::media_basename_allowed( $basename ) ) {
			return false;
		}

		if ( ! is_readable( $file_path ) ) {
			return false;
		}

		$checked = wp_check_filetype_and_ext( $file_path, $basename );

		$checked_ext  = $checked['ext'];
		$checked_type = $checked['type'];

		return is_string( $checked_ext ) && '' !== $checked_ext && is_string( $checked_type ) && '' !== $checked_type;
	}

	/**
	 * Only exporter-declared missing media may lack staged bytes.
	 *
	 * @param string $workspace_dir Absolute workspace dir.
	 * @param array  $media_index Validated media index from validate().
	 * @return WP_Error|null Incomplete error naming the first missing file, null when complete.
	 */
	public static function check_required_files( string $workspace_dir, array $media_index ): ?WP_Error {
		foreach ( $media_index as $media_state ) {
			if ( ! is_array( $media_state ) || ! empty( $media_state['missing'] ) ) {
				continue;
			}

			$declared = isset( $media_state['entry'] ) && is_array( $media_state['entry'] ) ? $media_state['entry'] : array();
			$file     = isset( $declared['file'] ) && is_string( $declared['file'] ) ? $declared['file'] : '';

			if ( '' === $file || ! is_string( self::workspace_file( $workspace_dir, $file ) ) ) {
				return new WP_Error(
					'pageferry_file_incomplete',
					sprintf(
						/* translators: %s: media file name not yet uploaded. */
						__( 'Media file %s has not finished uploading. Wait for preparation to finish before importing.', 'pageferry' ),
						self::original_filename( $declared )
					)
				);
			}
		}

		return null;
	}

	/**
	 * Reuses attachments only after hashing current bytes; names and index rows are hints.
	 *
	 * @param string $sha256 Content hash of the workspace file.
	 * @param string $filename Workspace file basename (pre-check only).
	 * @param int    $bytes File size in bytes (pre-check only).
	 * @param bool   $remember Whether to record verified hits in the index.
	 * @param int    $source_id Source ID as a candidate only; bytes must match.
	 * @return int|null Attachment ID on a verified hit, null on miss.
	 */
	public static function dedupe( string $sha256, string $filename, int $bytes, bool $remember = true, int $source_id = 0 ): ?int {
		if ( $source_id > 0 && self::attachment_matches_hash( $source_id, $sha256, $bytes ) ) {
			if ( $remember ) {
				self::remember_hash( $sha256, $source_id );
			}
			return $source_id;
		}

		$hash_index = get_option( self::HASH_INDEX_OPTION, array() );

		if ( is_array( $hash_index ) && isset( $hash_index[ $sha256 ] ) && is_numeric( $hash_index[ $sha256 ] ) ) {
			$candidate_id = (int) $hash_index[ $sha256 ];

			if ( self::attachment_matches_hash( $candidate_id, $sha256 ) ) {
				return $candidate_id;
			}
		}

		$stem              = pathinfo( $filename, PATHINFO_FILENAME );
		$extension         = pathinfo( $filename, PATHINFO_EXTENSION );
		$collision_pattern = '(^|/)' . preg_quote( $stem, '/' ) . '(-[0-9]+)?\\.' . preg_quote( $extension, '/' ) . '$';
		$page              = 1;
		do {
			$precheck_query = new WP_Query(
				array(
					'post_type'      => 'attachment',
					'post_status'    => 'inherit',
					'posts_per_page' => 20,
					'paged'          => $page,
					'orderby'        => 'ID',
					'order'          => 'ASC',
					'no_found_rows'  => true,
					'fields'         => 'ids',
					// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- bounded pre-check before the hash confirm.
					'meta_query'     => array(
						'relation' => 'OR',
						array(
							'key'     => '_wp_attached_file',
							'value'   => $filename,
							'compare' => '=',
						),
						array(
							'key'     => '_wp_attached_file',
							'value'   => '/' . $filename,
							'compare' => 'LIKE',
						),
						array(
							'key'     => '_wp_attached_file',
							'value'   => $collision_pattern,
							'compare' => 'REGEXP',
						),
						array(
							'key'     => '_wp_attachment_metadata',
							'value'   => '"original_image";' . serialize( $filename ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize -- bounded candidate lookup in WordPress's serialized metadata; always hash verified.
							'compare' => 'LIKE',
						),
					),
				)
			);

			$query_posts = $precheck_query->posts; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- WP_Query::$posts is core's own property.

			foreach ( $query_posts as $candidate_id ) {
				if ( ! self::attachment_matches_hash( (int) $candidate_id, $sha256, $bytes ) ) {
					continue;
				}

				if ( $remember ) {
					self::remember_hash( $sha256, (int) $candidate_id );
				}

				return (int) $candidate_id;
			}
			++$page;
			$batch_count = count( $query_posts );
		} while ( 20 === $batch_count );

		return null;
	}

	/**
	 * Reuses verified hash groups; zero marks a planned upload during write-free preview.
	 *
	 * @param string $sha256 Verified actual file hash.
	 * @param string $filename Original media-library basename.
	 * @param int    $bytes Actual staged file size.
	 * @param array  $resolved_hashes Hashes already resolved in this import.
	 * @param int    $source_id Source attachment candidate.
	 * @return int|null Existing attachment ID, 0 for a planned preview group, or null on a new group.
	 */
	private static function resolve_hash( string $sha256, string $filename, int $bytes, array $resolved_hashes, int $source_id = 0 ): ?int {
		if ( array_key_exists( $sha256, $resolved_hashes ) ) {
			return (int) $resolved_hashes[ $sha256 ];
		}

		return self::dedupe( $sha256, $filename, $bytes, false, $source_id );
	}

	/**
	 * Hashes full or explicitly preserved original bytes; metadata and index rows never prove identity.
	 *
	 * @param int    $attachment_id Candidate attachment.
	 * @param string $sha256 Required source hash.
	 * @param int    $bytes Optional size precheck.
	 * @return bool Whether owned source bytes still match.
	 */
	private static function attachment_matches_hash( int $attachment_id, string $sha256, int $bytes = 0 ): bool {
		if ( 'attachment' !== get_post_type( $attachment_id ) ) {
			return false;
		}
		$full = get_attached_file( $attachment_id );
		if ( ! is_string( $full ) || ! is_file( $full ) || ! is_readable( $full ) ) {
			return false;
		}
		$files = array( $full );
		/**
		 * Core's original_image key is absent from the dependency's stub shape.
		 *
		 * @var array<string, mixed>|false $metadata
		 */
		$metadata              = wp_get_attachment_metadata( $attachment_id );
		$original              = is_array( $metadata ) ? ( $metadata['original_image'] ?? '' ) : '';
		$has_original_basename = is_string( $original ) && '' !== $original && wp_basename( $original ) === $original && ! str_contains( $original, '\\' );
		if ( $has_original_basename ) {
			$original_path     = dirname( $full ) . '/' . $original;
			$is_owned_original = ! is_link( $original_path ) && is_file( $original_path ) && is_readable( $original_path ) && dirname( (string) realpath( $original_path ) ) === realpath( dirname( $full ) );
			if ( $is_owned_original ) {
				$files[] = $original_path;
			}
		}
		foreach ( array_unique( $files ) as $file ) {
			if ( 0 < $bytes && filesize( $file ) !== $bytes ) {
				continue;
			}
			$actual_hash = hash_file( 'sha256', $file );
			if ( is_string( $actual_hash ) && hash_equals( $sha256, $actual_hash ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Maximum recursion depth for nested remap structures.
	 *
	 * @var int
	 */
	const MAX_REMAP_DEPTH = 20;

	/**
	 * Maps original IDs once; collector paths constrain generic values and prevent cascading.
	 *
	 * @param array $blocks Parsed blocks (parse_blocks output).
	 * @param array $id_map Map of old attachment ID => new attachment ID.
	 * @param array $block_refs Optional map of block path => list of
	 *                          collected old IDs for that exact block (manifest
	 *                          block_refs). When empty, every attribute value
	 *                          equal to a mapped ID remaps (v1 manifests and
	 *                          direct remap() calls without manifest context).
	 * @return array Remapped blocks.
	 */
	public static function remap( array $blocks, array $id_map, array $block_refs = array() ): array {
		return self::remap_level( $blocks, $id_map, $block_refs, '' );
	}

	/**
	 * Remaps one level of parsed blocks with path-tracked ref gating.
	 *
	 * @param array  $blocks Parsed blocks at this level.
	 * @param array  $id_map Map of old attachment ID => new attachment ID.
	 * @param array  $block_refs Map of block path => collected old IDs.
	 * @param string $path_prefix Dot-notation prefix for this level ('' at the top).
	 * @return array Remapped blocks.
	 */
	private static function remap_level( array $blocks, array $id_map, array $block_refs, string $path_prefix ): array {
		foreach ( $blocks as $index => $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$block_path = '' === $path_prefix ? (string) $index : $path_prefix . '.' . $index;

			if ( isset( $block['attrs'] ) && is_array( $block['attrs'] ) ) {
				$blocks[ $index ]['attrs'] = self::remap_attributes( $block['attrs'], $id_map, self::allowed_ids_for_block( $block_path, $block_refs ), self::core_media_slots( $block['blockName'] ?? '' ) );
			}

			if ( isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$blocks[ $index ]['innerBlocks'] = self::remap_level( $block['innerBlocks'], $id_map, $block_refs, $block_path . '.innerBlocks' );
			}
		}

		return $blocks;
	}

	/**
	 * Only core's declared media attributes receive the known-slot fallback.
	 *
	 * @param string $block_name Registered block name.
	 * @return array Core attachment-ID attribute names.
	 */
	private static function core_media_slots( string $block_name ): array {
		$slots = array(
			'core/image'      => array( 'id' ),
			'core/gallery'    => array( 'ids' ),
			'core/cover'      => array( 'id' ),
			'core/media-text' => array( 'mediaId' ),
			'core/audio'      => array( 'id' ),
			'core/video'      => array( 'id' ),
			'core/file'       => array( 'id' ),
		);
		return $slots[ $block_name ] ?? array();
	}

	/**
	 * Exact block paths authorize generic slots; null retains legacy unrestricted remapping.
	 *
	 * @param string $block_path Dot-notation path of the block.
	 * @param array  $block_refs Map of block path => list of array(path, key, old_id).
	 * @return array|null Map of attribute path => old ID, or null when unrestricted.
	 */
	private static function allowed_ids_for_block( string $block_path, array $block_refs ): ?array {
		if ( array() === $block_refs ) {
			return null;
		}

		if ( ! isset( $block_refs[ $block_path ] ) ) {
			return array();
		}

		$allowed = array();

		foreach ( (array) $block_refs[ $block_path ] as $reference ) {
			if ( ! is_array( $reference ) || ! isset( $reference['key'], $reference['old_id'] ) || ! is_string( $reference['key'] ) ) {
				continue;
			}

			$attr_key = $reference['key'];

			if ( 'html' === $attr_key || str_starts_with( $attr_key, 'meta:' ) ) {
				continue;
			}

			$allowed[ $attr_key ] = (int) $reference['old_id'];
		}

		return $allowed;
	}

	/**
	 * Whether the server can extract ZIPs.
	 *
	 * @return bool True when ZipArchive is available.
	 */
	public static function zip_available(): bool {
		return class_exists( 'ZipArchive' );
	}

	/**
	 * Extracts only declared ZIP media into a fresh workspace, refusing traversal and absolute paths.
	 *
	 * @param string      $zip_path Absolute path to the uploaded export ZIP.
	 * @param string|null $target_post_type Optional destination type override.
	 * @return array|WP_Error Array with workspace + manifest, or WP_Error.
	 */
	public static function prepare_workspace_from_zip( string $zip_path, ?string $target_post_type = null ) {
		if ( ! self::zip_available() ) {
			return new WP_Error(
				'pageferry_no_zip',
				__( 'This site cannot open ZIP files on the server. Enable JavaScript and select the ZIP again to import through your browser, or ask your host to enable the PHP ZIP extension.', 'pageferry' )
			);
		}

		$limits   = PageFerry_Import_Resources::limits();
		$metadata = PageFerry_Import_Resources::check_zip_metadata( $zip_path );
		if ( $metadata instanceof WP_Error ) {
			return $metadata;
		}

		$zip = new ZipArchive();

		if ( true !== $zip->open( $zip_path, ZipArchive::RDONLY ) ) {
			return new WP_Error(
				'pageferry_zip_open',
				__( 'This ZIP could not be opened. It may be damaged. Export the page again and try the new ZIP.', 'pageferry' )
			);
		}

		// ZIP name-based reads cannot disambiguate duplicate entries.
		$seen_names  = array();
		$entry_count = $zip->numFiles; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- extension property.
		if ( $entry_count > $limits['zip_entries'] ) {
			$zip->close();
			return PageFerry_Import_Resources::exceeded();
		}
		for ( $position = 0; $position < $entry_count; $position++ ) {
			$name = $zip->getNameIndex( $position );
			if ( ! is_string( $name ) || strlen( $name ) > $limits['zip_name_bytes'] ) {
				$zip->close();
				return PageFerry_Import_Resources::exceeded();
			}
			$is_canonical = ( 'pageferry-manifest.json' === $name || 1 === preg_match( '#^media/[^/]+$#', $name ) );
			if ( ! $is_canonical ) {
				continue;
			}
			if ( isset( $seen_names[ $name ] ) ) {
				$zip->close();
				return new WP_Error( 'pageferry_zip_duplicate', __( 'This ZIP contains duplicate page information or media files. Export the page again and try the new ZIP.', 'pageferry' ) );
			}
			$seen_names[ $name ] = true;
		}

		$manifest_stat = $zip->statName( 'pageferry-manifest.json' );
		if ( is_array( $manifest_stat ) && $manifest_stat['size'] > $limits['manifest_bytes'] ) {
			$zip->close();
			return PageFerry_Import_Resources::exceeded();
		}
		$manifest_stream = $zip->getStream( 'pageferry-manifest.json' );
		$manifest_json   = false;
		if ( is_resource( $manifest_stream ) ) {
			$manifest_json = PageFerry_Import_Resources::read( $manifest_stream, $limits['manifest_bytes'] );
			if ( ! fclose( $manifest_stream ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions -- owned ZIP stream.
				$manifest_json = PageFerry_Import_Resources::io_error();
			}
		}
		if ( $manifest_json instanceof WP_Error ) {
			$zip->close();
			return $manifest_json;
		}

		if ( ! is_string( $manifest_json ) ) {
			$zip->close();
			return new WP_Error(
				'pageferry_manifest_missing',
				__( 'This ZIP is missing its page information file. Choose a ZIP created with PageFerry Export, or export the page again.', 'pageferry' )
			);
		}

		$manifest = json_decode( $manifest_json, true );

		if ( ! is_array( $manifest ) ) {
			$zip->close();
			return new WP_Error(
				'pageferry_manifest_invalid',
				__( 'The page information in this ZIP could not be read. Export the page again and try the new ZIP.', 'pageferry' )
			);
		}

		$validated = self::validate( $manifest, $target_post_type );

		if ( $validated instanceof WP_Error ) {
			$zip->close();
			return $validated;
		}

		$metadata_error = self::check_zip_media_metadata( $zip, $validated );
		if ( $metadata_error instanceof WP_Error ) {
			$zip->close();
			return $metadata_error;
		}

		$workspace = self::make_workspace();

		if ( $workspace instanceof WP_Error ) {
			$zip->close();
			return $workspace;
		}

		$prepared = PageFerry_Workspace::with_lease(
			$workspace,
			static function () use ( $workspace, $zip, $validated ) {
				return self::extract_zip_leased( $workspace, $zip, $validated );
			}
		);
		if ( is_wp_error( $prepared ) ) {
			self::remove_directory( $workspace );
		}
		return $prepared;
	}

	/**
	 * Validates selected ZIP metadata before workspace allocation.
	 *
	 * @param ZipArchive $zip Open ZIP.
	 * @param array      $validated Validated manifest.
	 * @return WP_Error|null
	 */
	private static function check_zip_media_metadata( ZipArchive $zip, array $validated ): ?WP_Error {
		$limits         = PageFerry_Import_Resources::limits();
		$required       = array();
		$declared_total = 0;
		foreach ( $validated['media_index'] as $state ) {
			if ( ! $state['missing'] ) {
				$required[ basename( (string) $state['entry']['file'] ) ] = true;
				$declared = isset( $state['entry']['bytes'] ) && is_numeric( $state['entry']['bytes'] ) ? max( 0, (int) $state['entry']['bytes'] ) : 0;
				if ( $declared > min( $limits['path_a_bytes'], $limits['core_bytes'] ) - $declared_total ) {
					return PageFerry_Import_Resources::exceeded();
				}
				$declared_total += $declared;
			}
		}
		$total = 0;
		$count = $zip->numFiles; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- ZipArchive API.
		for ( $position = 0; $position < $count; $position++ ) {
			$name = $zip->getNameIndex( $position );
			if ( ! is_string( $name ) || str_ends_with( $name, '/' ) ) {
				continue;
			}
			if ( str_contains( $name, '..' ) || str_starts_with( $name, '/' ) || ( str_starts_with( $name, 'media/' ) && isset( $required[ basename( $name ) ] ) && 'media/' . basename( $name ) !== $name ) ) {
				return new WP_Error(
					'pageferry_zip_unsafe',
					sprintf(
						/* translators: %s: unsafe ZIP entry. */
						__( 'This ZIP contains an unsupported file location (%s). Export the page again and try the new ZIP.', 'pageferry' ),
						$name
					)
				);
			}
			if ( ! str_starts_with( $name, 'media/' ) || ! isset( $required[ basename( $name ) ] ) ) {
				continue;
			}
			$stat = $zip->statIndex( $position );
			if ( ! is_array( $stat ) || 0 > $stat['size'] ) {
				return PageFerry_Import_Resources::io_error();
			}
			if ( $stat['size'] > $limits['media_file_bytes'] ) {
				return PageFerry_Import_Resources::file_exceeded( basename( $name ) );
			}
			if ( $stat['size'] > min( $limits['path_a_bytes'], $limits['core_bytes'] ) - $total ) {
				return PageFerry_Import_Resources::exceeded();
			}
			$total += $stat['size'];
		}
		return null;
	}

	/**
	 * Stages a validated ZIP while GC is excluded for the entire extraction.
	 *
	 * @param string     $workspace Workspace directory.
	 * @param ZipArchive $zip Open archive.
	 * @param array      $validated Validated manifest and media index.
	 * @return array|WP_Error
	 */
	private static function extract_zip_leased( string $workspace, ZipArchive $zip, array $validated ) {
		$declared_files = array();
		$declared_bytes = array();
		foreach ( $validated['media_index'] as $media_state ) {
			if ( $media_state['missing'] ) {
				continue;
			}

			$declared_name = isset( $media_state['entry']['file'] ) ? basename( (string) $media_state['entry']['file'] ) : '';
			if ( '' !== $declared_name ) {
				$declared_files[ $declared_name ] = true;

				if ( isset( $media_state['entry']['bytes'] ) && is_numeric( $media_state['entry']['bytes'] ) ) {
					$declared_bytes[ $declared_name ] = (int) $media_state['entry']['bytes'];
				}
			}
		}

		$resource_limits   = PageFerry_Import_Resources::limits();
		$upload_limit      = $resource_limits['media_file_bytes'];
		$max_staged_bytes  = min( $resource_limits['path_a_bytes'], $resource_limits['core_bytes'] );
		$staged_file_count = 0;
		$staged_byte_total = 0;

		$zip_entry_count = $zip->numFiles; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- ZipArchive::$numFiles is the extension's own property name.

		for ( $position = 0; $position < $zip_entry_count; $position++ ) {
			$entry_name = $zip->getNameIndex( $position );

			if ( ! is_string( $entry_name ) ) {
				continue;
			}

			if ( 'pageferry-manifest.json' === $entry_name || str_ends_with( $entry_name, '/' ) ) {
				continue;
			}

			if ( str_contains( $entry_name, '..' ) || str_starts_with( $entry_name, '/' ) ) {
				$zip->close();
				self::remove_directory( $workspace );
				return new WP_Error(
					'pageferry_zip_unsafe',
					sprintf(
						/* translators: %s: unsafe entry name inside the ZIP. */
						__( 'This ZIP contains an unsafe file location (%s). Choose a ZIP created with PageFerry Export.', 'pageferry' ),
						$entry_name
					)
				);
			}

			if ( ! str_starts_with( $entry_name, 'media/' ) ) {
				continue;
			}

			$entry_basename = basename( $entry_name );
			$media_subpath  = substr( $entry_name, 6 );

			if ( isset( $declared_files[ $entry_basename ] ) && $entry_basename !== $media_subpath ) {
				$zip->close();
				self::remove_directory( $workspace );
				return new WP_Error( 'pageferry_zip_unsafe', __( 'A media file in this ZIP is in the wrong folder. Export the page again and try the new ZIP.', 'pageferry' ) );
			}

			if ( ! isset( $declared_files[ $entry_basename ] ) ) {
				continue;
			}

			if ( 0 < $upload_limit && isset( $declared_bytes[ $entry_basename ] ) && $upload_limit < $declared_bytes[ $entry_basename ] ) {
				$zip->close();
				self::remove_directory( $workspace );
				return new WP_Error(
					'pageferry_media_too_large',
					sprintf(
						/* translators: 1: media file name, 2: human-readable size limit. */
						__( 'Media file %1$s exceeds the file size limit of %2$s. Reduce its size and export again, or ask your host to raise a lower upload limit.', 'pageferry' ),
						$entry_basename,
						size_format( $upload_limit )
					)
				);
			}

			$entry_stream = $zip->getStream( $entry_name );

			if ( ! is_resource( $entry_stream ) ) {
				$zip->close();
				self::remove_directory( $workspace );
				return new WP_Error(
					'pageferry_zip_read',
					sprintf(
						/* translators: %s: media file name inside the ZIP. */
						__( 'Media file %s could not be read from the ZIP. Export the page again and try the new ZIP.', 'pageferry' ),
						$entry_basename
					)
				);
			}

			$dest_handle = fopen( $workspace . '/' . $entry_basename, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- extracting a validated zip entry to our own workspace.

			if ( ! is_resource( $dest_handle ) ) {
				fclose( $entry_stream ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- closing a ZipArchive stream handle.
				$zip->close();
				self::remove_directory( $workspace );
				return new WP_Error(
					'pageferry_workspace_write',
					__( 'The uploaded ZIP could not be saved for review. Try again, or ask your host to check temporary storage permissions.', 'pageferry' )
				);
			}

			$copied        = PageFerry_Import_Resources::copy( $entry_stream, $dest_handle, $upload_limit, $max_staged_bytes - $staged_byte_total );
			$input_closed  = fclose( $entry_stream ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- owned ZIP stream.
			$output_closed = fclose( $dest_handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- owned workspace stream.
			clearstatcache( true, $workspace . '/' . $entry_basename );
			if ( ! $input_closed || ! $output_closed || ( is_int( $copied ) && filesize( $workspace . '/' . $entry_basename ) !== $copied ) ) {
				$copied = PageFerry_Import_Resources::io_error();
			}
			if ( $copied instanceof WP_Error ) {
				if ( 'pageferry_media_too_large' === $copied->get_error_code() ) {
					$copied = PageFerry_Import_Resources::file_exceeded( $entry_basename );
				}
				$zip->close();
				self::remove_directory( $workspace );
				return $copied;
			}

			if ( ! self::staged_media_file_allowed( $workspace . '/' . $entry_basename, $entry_basename ) ) {
				$zip->close();
				self::remove_directory( $workspace );
				return new WP_Error(
					'pageferry_unsupported_media_type',
					sprintf(
						/* translators: %s: media file name with a disallowed or mismatched type. */
						__( 'Media file %s has a file type this site does not allow. Ask an administrator to check the file type before importing.', 'pageferry' ),
						$entry_basename
					)
				);
			}

			// Filterable type probes can alter files; recheck physical bytes afterward.
			$staged_size = PageFerry_Import_Resources::file_size( $workspace . '/' . $entry_basename );
			$error       = null;
			if ( $staged_size instanceof WP_Error ) {
				$error = $staged_size;
			} elseif ( $staged_size > $upload_limit ) {
				$error = PageFerry_Import_Resources::file_exceeded( $entry_basename );
			} elseif ( $staged_file_count >= $resource_limits['required_files'] || $staged_size > $max_staged_bytes - $staged_byte_total ) {
				$error = PageFerry_Import_Resources::exceeded();
			} elseif ( $staged_size !== $copied ) {
				$error = PageFerry_Import_Resources::io_error();
			}
			if ( $error instanceof WP_Error ) {
				$zip->close();
				self::remove_directory( $workspace );
				return $error;
			}
			++$staged_file_count;
			$staged_byte_total += $staged_size;
		}

		$zip->close();

		$zip_completeness = self::check_required_files( $workspace, $validated['media_index'] );

		if ( $zip_completeness instanceof WP_Error ) {
			self::remove_directory( $workspace );
			return $zip_completeness;
		}

		return array(
			'workspace' => $workspace,
			'manifest'  => $validated['manifest'],
		);
	}

	/**
	 * Creates a tracked, private workspace outside the public upload tree.
	 *
	 * @param string $prefix Directory name prefix.
	 * @return string|WP_Error Absolute workspace path, or WP_Error.
	 */
	public static function make_workspace( string $prefix = 'pageferry-import-' ) {
		$root = PageFerry_Workspace::private_root( true );
		if ( is_wp_error( $root ) ) {
			return $root;
		}
		if ( 1 !== preg_match( '/\Apageferry-[A-Za-z0-9-]+\z/', $prefix ) ) {
			return PageFerry_Import_Resources::io_error();
		}
		$workspace = $root . '/' . $prefix . wp_generate_password( 12, false );

		if ( ! mkdir( $workspace, 0700 ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions -- owner-only staging directory beneath the checked private root.
			return new WP_Error(
				'pageferry_workspace',
				__( 'Temporary files could not be saved for this import. Ask your host to check temporary storage permissions.', 'pageferry' )
			);
		}

		file_put_contents( $workspace . '/index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- web-access guard inside our own workspace.
		file_put_contents( $workspace . '/.htaccess', "Require all denied\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- web-access guard inside our own workspace.
		$tracked = PageFerry_Workspace::with_lease(
			$workspace,
			static function () {
				return true;
			}
		);
		if ( is_wp_error( $tracked ) ) {
			self::remove_directory( $workspace );
			return $tracked;
		}

		return $workspace;
	}

	/**
	 * Recursively deletes a workspace directory.
	 *
	 * @param string $workspace_dir Absolute workspace path.
	 * @return void
	 */
	public static function remove_directory( string $workspace_dir ): void {
		$root = PageFerry_Workspace::private_root();
		if ( is_string( $root ) && str_starts_with( $workspace_dir, $root . '/' ) ) {
			PageFerry_Filesystem::remove_directory( $workspace_dir, $root );
		} else {
			PageFerry_Filesystem::remove_directory( $workspace_dir, wp_get_upload_dir()['basedir'] );
		}
	}

	/**
	 * Reclaims idle private or tracked legacy staging; ordinary uploads are never adopted by prefix.
	 *
	 * @param int $max_age_seconds Heartbeat age qualifying for deletion.
	 * @return int Number of workspaces removed.
	 */
	public static function gc_workspaces( int $max_age_seconds = 3600 ): int {
		$root    = PageFerry_Workspace::private_root();
		$removed = is_string( $root ) ? self::gc_workspace_root( $root, $max_age_seconds ) : 0;
		return $removed + self::gc_workspace_root( wp_get_upload_dir()['basedir'], $max_age_seconds, true );
	}

	/**
	 * Sweeps one owned root; public legacy sessions must prepare privately again.
	 *
	 * @param string $basedir Scan boundary.
	 * @param int    $max_age_seconds Idle grace.
	 * @param bool   $legacy Whether this is the old public upload root.
	 * @return int Removed workspaces.
	 */
	private static function gc_workspace_root( string $basedir, int $max_age_seconds, bool $legacy = false ): int {

		if ( '' === $basedir || ! is_dir( $basedir ) ) {
			return 0;
		}

		$entries = scandir( $basedir );

		if ( ! is_array( $entries ) ) {
			return 0;
		}

		$removed = 0;

		foreach ( $entries as $entry ) {
			if ( ! str_starts_with( $entry, 'pageferry-import-' ) && ! str_starts_with( $entry, 'pageferry-session-' ) ) {
				continue;
			}

			$candidate = $basedir . '/' . $entry;

			if ( ! is_dir( $candidate ) || is_link( $candidate ) ) {
				continue;
			}
			// Recreating a retired workspace lock could race with terminal deletion.
			if ( str_starts_with( $entry, 'pageferry-import-retired-' ) ) {
				clearstatcache( true, $candidate );
				$retired_activity = filemtime( $candidate );
				if ( ! is_int( $retired_activity ) || time() - $retired_activity < max( HOUR_IN_SECONDS, $max_age_seconds ) ) {
					continue;
				}
			}

			$lease = PageFerry_Workspace::acquire( $candidate, $legacy );
			if ( is_wp_error( $lease ) ) {
				continue;
			}
			try {
				if ( ( $legacy || PageFerry_Workspace::is_abandoned( $candidate, $max_age_seconds ) ) && PageFerry_Workspace::retire( $candidate ) ) {
					++$removed;
				}
			} finally {
				PageFerry_Workspace::release( $lease );
			}
		}

		return $removed;
	}

	/**
	 * Uses daily admin-traffic GC to avoid activation-time cron scheduling.
	 *
	 * @return void
	 */
	public static function maybe_gc_workspaces(): void {
		$last_run = get_option( PageFerry::OPTION_LAST_GC, 0 );

		if ( is_numeric( $last_run ) && time() - (int) $last_run < DAY_IN_SECONDS ) {
			return;
		}

		update_option( PageFerry::OPTION_LAST_GC, time(), false );
		self::gc_workspaces( PageFerry_Rest_Import::SESSION_TTL );
	}

	/**
	 * Returns the post type’s publication capability with the core fallback.
	 *
	 * @param string $post_type Post-type slug.
	 * @return string Capability required to publish/private this type.
	 */
	public static function publish_capability_for_type( string $post_type ): string {
		$post_type_object = get_post_type_object( $post_type );

		if ( $post_type_object instanceof WP_Post_Type && isset( $post_type_object->cap->publish_posts ) && is_string( $post_type_object->cap->publish_posts ) && '' !== $post_type_object->cap->publish_posts ) {
			return $post_type_object->cap->publish_posts;
		}

		return 'publish_posts';
	}

	/**
	 * Defaults unsafe or unauthorized destination statuses to draft; bundle status grants no authority.
	 *
	 * @param string $post_type Post-type slug being created.
	 * @param array  $args Destination args ({ status?: string }).
	 * @return string Resolved status: draft, pending, private, or publish.
	 */
	public static function resolve_create_status( string $post_type, array $args ): string {
		$requested = isset( $args['status'] ) && is_string( $args['status'] ) ? strtolower( trim( $args['status'] ) ) : 'draft';

		if ( ! in_array( $requested, self::ALLOWED_CREATE_STATUSES, true ) ) {
			return 'draft';
		}

		if ( 'publish' === $requested || 'private' === $requested ) {
			if ( ! current_user_can( self::publish_capability_for_type( $post_type ) ) ) {
				return 'draft';
			}
		}

		return $requested;
	}

	/**
	 * Carries string export warnings as context; they do not control import behavior.
	 *
	 * @param array $manifest Normalized manifest.
	 * @return array List of warning strings (possibly empty).
	 */
	public static function export_warnings( array $manifest ): array {
		if ( ! isset( $manifest['export_warnings'] ) || ! is_array( $manifest['export_warnings'] ) ) {
			return array();
		}

		$warnings = array();

		foreach ( $manifest['export_warnings'] as $warning ) {
			if ( is_string( $warning ) && '' !== trim( $warning ) ) {
				$warnings[] = $warning;
			}
		}

		return $warnings;
	}

	/**
	 * Shares ACF availability checks so preview and restoration describe the same dependency.
	 *
	 * @return bool True when ACF can restore post meta on this site.
	 */
	private static function acf_block_restore_available(): bool {
		if ( ! function_exists( 'acf_block_uses_post_meta' ) || ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
			return false;
		}

		return function_exists( 'acf_update_value' ) || function_exists( 'update_field' );
	}

	/**
	 * Post fields do not need the ACF 6.3 usePostMeta API.
	 *
	 * @return bool True when ACF can restore post fields on this site.
	 */
	private static function acf_post_fields_restore_available(): bool {
		if ( ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
			return false;
		}

		return function_exists( 'acf_update_value' ) || function_exists( 'update_field' );
	}

	/**
	 * Returns a dependency warning naming block values that cannot be restored.
	 *
	 * @param array $manifest Normalized manifest.
	 * @return string|null Note when ACF is unavailable and payload is nonempty, null otherwise.
	 */
	private static function acf_unavailable_note( array $manifest ): ?string {
		if ( self::acf_block_restore_available() ) {
			return null;
		}

		if ( ! isset( $manifest['acf_post_meta'] ) || ! is_array( $manifest['acf_post_meta'] ) || array() === $manifest['acf_post_meta'] ) {
			return null;
		}

		$block_names = array();
		$entry_count = 0;

		foreach ( $manifest['acf_post_meta'] as $acf_entry ) {
			if ( ! is_array( $acf_entry ) ) {
				continue;
			}

			++$entry_count;

			if ( isset( $acf_entry['block'] ) && is_string( $acf_entry['block'] ) && '' !== $acf_entry['block'] ) {
				$block_names[] = $acf_entry['block'];
			}
		}

		$block_names = array_values( array_unique( $block_names ) );
		$group_count = $entry_count;

		if ( array() === $block_names ) {
			return sprintf(
				/* translators: %d: number of ACF entries that were skipped. */
				_n( 'Custom fields in %d block cannot be imported on this site. Ask an administrator to check ACF, then prepare the review again.', 'Custom fields in %d blocks cannot be imported on this site. Ask an administrator to check ACF, then prepare the review again.', $group_count, 'pageferry' ),
				$group_count
			);
		}

		return sprintf(
			/* translators: 1: number of ACF entries skipped, 2: comma-separated block names. */
			_n( 'Custom fields in %1$d block cannot be imported on this site (%2$s). Ask an administrator to check ACF, then prepare the review again.', 'Custom fields in %1$d blocks cannot be imported on this site (%2$s). Ask an administrator to check ACF, then prepare the review again.', $group_count, 'pageferry' ),
			$group_count,
			implode( ', ', $block_names )
		);
	}

	/**
	 * Reports unavailable ACF post fields so omitted restoration cannot look like clean success.
	 *
	 * @param array $manifest Normalized manifest.
	 * @return string|null Note when ACF is unavailable and payload is nonempty, null otherwise.
	 */
	private static function acf_post_fields_unavailable_note( array $manifest ): ?string {
		if ( self::acf_post_fields_restore_available() ) {
			return null;
		}

		$post_fields = isset( $manifest['acf_post_fields'] ) && is_array( $manifest['acf_post_fields'] ) ? $manifest['acf_post_fields'] : array();

		$field_names = array();

		foreach ( array_keys( $post_fields ) as $field_name ) {
			if ( is_string( $field_name ) && '' !== $field_name ) {
				$field_names[] = $field_name;
			}
		}

		if ( array() === $field_names ) {
			return null;
		}

		return sprintf(
			/* translators: 1: number of ACF fields skipped, 2: comma-separated field names. */
			_n( '%1$d ACF custom field cannot be imported on this site (%2$s). Ask an administrator to check ACF, then prepare the review again.', '%1$d ACF custom fields cannot be imported on this site (%2$s). Ask an administrator to check ACF, then prepare the review again.', count( $field_names ), 'pageferry' ),
			count( $field_names ),
			implode( ', ', $field_names )
		);
	}

	/**
	 * Predicts ACF skips using the same destination checks and note order as restoration.
	 *
	 * @param array $manifest           Normalized manifest.
	 * @param array $destination_fields Map of field name => ACF field definition
	 *                                  available on the destination (see
	 *                                  destination_acf_post_fields()).
	 * @return array List of human-readable skip notes (empty when all would restore).
	 */
	public static function preview_acf_warnings( array $manifest, array $destination_fields = array() ): array {
		$warnings = array();

		$dependency_note = self::acf_unavailable_note( $manifest );

		if ( is_string( $dependency_note ) ) {
			$warnings[] = $dependency_note;
		} elseif ( function_exists( 'acf_block_uses_post_meta' ) && isset( $manifest['acf_post_meta'] ) && is_array( $manifest['acf_post_meta'] ) && array() !== $manifest['acf_post_meta'] ) {
			// Explicit guards also let PHPStan narrow optional ACF functions.
			$bundle_content = isset( $manifest['post']['content'] ) && is_string( $manifest['post']['content'] ) ? $manifest['post']['content'] : '';
			/** Bundle blocks as a plain list. @var array $content_blocks Unshaped parse_blocks() result for PHPStan. */
			$content_blocks = '' !== $bundle_content ? parse_blocks( $bundle_content ) : array();
			$content_names  = array();
			self::collect_block_names( $content_blocks, $content_names );

			foreach ( $manifest['acf_post_meta'] as $acf_entry ) {
				if ( ! is_array( $acf_entry ) || ! isset( $acf_entry['block'], $acf_entry['fields'] ) || ! is_string( $acf_entry['block'] ) || ! is_array( $acf_entry['fields'] ) ) {
					continue;
				}

				$block_name = $acf_entry['block'];

				if ( ! in_array( $block_name, $content_names, true ) ) {
					/* translators: %s: ACF block name. */
					$warnings[] = sprintf( __( 'ACF block %s is missing from the page content. Its custom field values were skipped.', 'pageferry' ), $block_name );
					continue;
				}

				if ( ! acf_block_uses_post_meta( array( 'name' => $block_name ) ) ) {
					/* translators: %s: ACF block name. */
					$warnings[] = sprintf( __( 'ACF block %s uses different field storage on this site. Its custom field values were skipped. Ask a developer to match the block settings before importing.', 'pageferry' ), $block_name );
					continue;
				}

				$target_fields = self::get_acf_block_fields( $block_name );

				if ( array() === $target_fields ) {
					/* translators: %s: ACF block name. */
					$warnings[] = sprintf( __( 'ACF block %s has no fields configured on this site. Its values were skipped. Ask a developer to add matching ACF fields before importing.', 'pageferry' ), $block_name );
					continue;
				}

				$fields_by_name = array();

				foreach ( $target_fields as $target_field ) {
					if ( is_array( $target_field ) && isset( $target_field['name'] ) && is_string( $target_field['name'] ) && '' !== $target_field['name'] ) {
						$fields_by_name[ $target_field['name'] ] = $target_field;
					}
				}

				$skipped_fields = array();

				foreach ( $acf_entry['fields'] as $field_name => $old_value ) {
					if ( ! is_string( $field_name ) || '' === $field_name || ! isset( $fields_by_name[ $field_name ] ) ) {
						$skipped_fields[] = is_string( $field_name ) && '' !== $field_name ? $field_name : '(unnamed field)';
					} else {
						$skip_note = self::acf_restore_skip_note( $fields_by_name[ $field_name ], $old_value, $block_name );
						if ( null !== $skip_note ) {
							$warnings[] = $skip_note;
						}
					}
				}
				unset( $old_value );

				if ( array() !== $skipped_fields ) {
					/* translators: 1: ACF block name, 2: unavailable field names. */
					$warnings[] = sprintf( __( 'Some fields for ACF block %1$s are unavailable on this site and were skipped: %2$s. Ask a developer to check the field settings.', 'pageferry' ), $block_name, implode( ', ', $skipped_fields ) );
				}
			}
		}

		$fields_note = self::acf_post_fields_unavailable_note( $manifest );

		if ( is_string( $fields_note ) ) {
			$warnings[] = $fields_note;
		} elseif ( self::acf_post_fields_restore_available() ) {
			$post_fields = isset( $manifest['acf_post_fields'] ) && is_array( $manifest['acf_post_fields'] ) ? $manifest['acf_post_fields'] : array();
			$missing     = self::acf_missing_post_fields( $post_fields, $destination_fields );

			if ( array() !== $missing ) {
				$warnings[] = self::acf_post_fields_skip_note( $missing );
			}
			foreach ( $post_fields as $field_name => $old_value ) {
				if ( is_string( $field_name ) && isset( $destination_fields[ $field_name ] ) ) {
					$skip_note = self::acf_restore_skip_note( $destination_fields[ $field_name ], $old_value );
					if ( null !== $skip_note ) {
						$warnings[] = $skip_note;
					}
				}
			}
		}

		return $warnings;
	}

	/**
	 * Preserves payload order when reporting destination fields that cannot be restored.
	 *
	 * @param array $post_fields        Map of field name => raw value.
	 * @param array $destination_fields Map of field name => field definition.
	 * @return array List of field names with no destination definition.
	 */
	private static function acf_missing_post_fields( array $post_fields, array $destination_fields ): array {
		$missing = array();

		foreach ( array_keys( $post_fields ) as $field_name ) {
			if ( ! is_string( $field_name ) || '' === $field_name ) {
				continue;
			}

			if ( ! isset( $destination_fields[ $field_name ] ) ) {
				$missing[] = $field_name;
			}
		}

		return $missing;
	}

	/**
	 * One note naming the post fields the destination does not expose.
	 *
	 * @param array $field_names Field names with no destination definition.
	 * @return string Human-readable skip note.
	 */
	private static function acf_post_fields_skip_note( array $field_names ): string {
		/* translators: %s: unavailable ACF field names. */
		return sprintf( __( 'These ACF fields are unavailable on this site and were skipped: %s. Ask a developer to add matching fields before importing.', 'pageferry' ), implode( ', ', $field_names ) );
	}

	/**
	 * Pattern IDs stay source-side, so every distinct reference needs a dependency warning.
	 *
	 * @param array $blocks Parsed blocks at this level.
	 * @param array $pattern_ids Distinct pattern IDs found so far (appended to, as map id => true).
	 * @return void
	 */
	private static function collect_pattern_refs( array $blocks, array &$pattern_ids ): void {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$block_name = isset( $block['blockName'] ) && is_string( $block['blockName'] ) ? $block['blockName'] : '';
			$attributes = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();

			if ( 'core/block' === $block_name && isset( $attributes['ref'] ) && is_numeric( $attributes['ref'] ) ) {
				$reference_id = (int) $attributes['ref'];

				if ( 0 < $reference_id && ! isset( $pattern_ids[ $reference_id ] ) ) {
					$pattern_ids[ $reference_id ] = true;
				}
			}

			if ( isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::collect_pattern_refs( $block['innerBlocks'], $pattern_ids );
			}
		}
	}

	/**
	 * Re-derives pattern warnings from content so legacy bundles also disclose the dependency.
	 *
	 * @param array $manifest Normalized manifest.
	 * @return array List of human-readable pattern notes (empty when none referenced).
	 */
	public static function preview_pattern_warnings( array $manifest ): array {
		$bundle_content = isset( $manifest['post']['content'] ) && is_string( $manifest['post']['content'] ) ? $manifest['post']['content'] : '';

		if ( '' === $bundle_content ) {
			return array();
		}

		/** Bundle blocks as a plain list. @var array $content_blocks Unshaped parse_blocks() result for PHPStan. */
		$content_blocks = parse_blocks( $bundle_content );

		if ( array() === $content_blocks ) {
			return array();
		}

		$pattern_ids = array();
		self::collect_pattern_refs( $content_blocks, $pattern_ids );

		if ( array() === $pattern_ids ) {
			return array();
		}

		$warnings = array();

		foreach ( array_keys( $pattern_ids ) as $pattern_id ) {
			$pattern_id     = (int) $pattern_id;
			$destination    = get_post( $pattern_id );
			$destination_ok = $destination instanceof WP_Post && 'wp_block' === $destination->post_type;

			if ( ! $destination_ok ) {
				$warnings[] = sprintf(
					/* translators: %d: source synced-pattern (reusable block) ID. */
					__( 'Synced pattern %d is missing on this site and is not included in the ZIP. That part of the page will be empty. Detach the pattern on the source page and export again, or recreate it on this site before importing.', 'pageferry' ),
					$pattern_id
				);
			} else {
				$warnings[] = sprintf(
					/* translators: 1: source synced-pattern (reusable block) ID, 2: same pattern ID kept as a reference. */
					__( 'Synced pattern %1$d is not included in the ZIP. The imported page will use pattern %2$d from this site, which may have different content. Check it here, or detach the source pattern and export the page again.', 'pageferry' ),
					$pattern_id,
					$pattern_id
				);
			}
		}

		return $warnings;
	}

	/**
	 * Counts requested assignments, excluding ancestors and empty create no-ops.
	 *
	 * @param string $taxonomy_slug Taxonomy slug recorded in the manifest.
	 * @param array  $manifest Normalized manifest.
	 * @return bool True when the bundle requests at least one term.
	 */
	private static function taxonomy_has_nonempty_request( string $taxonomy_slug, array $manifest ): bool {
		$detailed = isset( $manifest['tax_terms'] ) && is_array( $manifest['tax_terms'] ) ? $manifest['tax_terms'] : array();
		$flat     = isset( $manifest['post']['tax'] ) && is_array( $manifest['post']['tax'] ) ? $manifest['post']['tax'] : array();

		if ( array_key_exists( $taxonomy_slug, $detailed ) && is_array( $detailed[ $taxonomy_slug ] ) ) {
			foreach ( $detailed[ $taxonomy_slug ] as $detailed_entry ) {
				if ( ! is_array( $detailed_entry ) ) {
					continue;
				}

				if ( ! array_key_exists( 'assigned', $detailed_entry ) || ! empty( $detailed_entry['assigned'] ) ) {
					if ( isset( $detailed_entry['name'] ) && is_string( $detailed_entry['name'] ) && '' !== trim( $detailed_entry['name'] ) ) {
						return true;
					}

					// An unusable legacy assigned name still represents a requested write.
					return true;
				}
			}
		}

		if ( array_key_exists( $taxonomy_slug, $flat ) && is_array( $flat[ $taxonomy_slug ] ) ) {
			foreach ( $flat[ $taxonomy_slug ] as $term_name ) {
				if ( is_array( $term_name ) || is_object( $term_name ) ) {
					continue;
				}

				$candidate = is_string( $term_name ) ? $term_name : (string) $term_name;

				if ( '' !== trim( $candidate ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Lists requested term names, excluding blanks, ancestors and duplicates.
	 *
	 * @param string $taxonomy_slug Taxonomy slug recorded in the manifest.
	 * @param array  $manifest Normalized manifest.
	 * @return array List of requested term names (possibly empty).
	 */
	private static function requested_taxonomy_term_names( string $taxonomy_slug, array $manifest ): array {
		$detailed = isset( $manifest['tax_terms'] ) && is_array( $manifest['tax_terms'] ) ? $manifest['tax_terms'] : array();
		$flat     = isset( $manifest['post']['tax'] ) && is_array( $manifest['post']['tax'] ) ? $manifest['post']['tax'] : array();
		$names    = array();

		if ( array_key_exists( $taxonomy_slug, $detailed ) && is_array( $detailed[ $taxonomy_slug ] ) ) {
			foreach ( $detailed[ $taxonomy_slug ] as $detailed_entry ) {
				if ( ! is_array( $detailed_entry ) ) {
					continue;
				}

				if ( array_key_exists( 'assigned', $detailed_entry ) && empty( $detailed_entry['assigned'] ) ) {
					continue;
				}

				if ( isset( $detailed_entry['name'] ) && is_string( $detailed_entry['name'] ) && '' !== trim( $detailed_entry['name'] ) ) {
					$names[] = trim( $detailed_entry['name'] );
				}
			}
		}

		if ( array_key_exists( $taxonomy_slug, $flat ) && is_array( $flat[ $taxonomy_slug ] ) ) {
			foreach ( $flat[ $taxonomy_slug ] as $term_name ) {
				if ( is_array( $term_name ) || is_object( $term_name ) ) {
					continue;
				}

				$candidate = is_string( $term_name ) ? trim( $term_name ) : trim( (string) $term_name );

				if ( '' !== $candidate ) {
					$names[] = $candidate;
				}
			}
		}

		$unique = array();

		foreach ( $names as $name ) {
			if ( ! in_array( $name, $unique, true ) ) {
				$unique[] = $name;
			}
		}

		return $unique;
	}

	/**
	 * Warns on unavailable requested taxonomies; v1 core taxonomies ignore the post-type gate.
	 *
	 * @param array $manifest Normalized manifest.
	 * @return array List of human-readable taxonomy notes (empty when all requested taxonomies are available).
	 */
	public static function preview_taxonomy_warnings( array $manifest ): array {
		$detailed = isset( $manifest['tax_terms'] ) && is_array( $manifest['tax_terms'] ) ? $manifest['tax_terms'] : array();
		$flat     = isset( $manifest['post']['tax'] ) && is_array( $manifest['post']['tax'] ) ? $manifest['post']['tax'] : array();

		$recorded = array_unique( array_merge( array_keys( $detailed ), array_keys( $flat ) ) );

		if ( array() === $recorded ) {
			return array();
		}

		$bundle_post_type       = isset( $manifest['post']['post_type'] ) && is_string( $manifest['post']['post_type'] ) ? $manifest['post']['post_type'] : '';
		$destination_taxonomies = '' !== $bundle_post_type ? get_object_taxonomies( $bundle_post_type, 'names' ) : array();

		$warnings = array();

		foreach ( $recorded as $taxonomy_slug ) {
			if ( ! is_string( $taxonomy_slug ) || '' === $taxonomy_slug ) {
				continue;
			}

			if ( ! self::taxonomy_has_nonempty_request( $taxonomy_slug, $manifest ) ) {
				continue;
			}

			$requested_names = self::requested_taxonomy_term_names( $taxonomy_slug, $manifest );
			$term_list       = array() !== $requested_names ? implode( ', ', $requested_names ) : __( '(unnamed categories or tags)', 'pageferry' );

			if ( ! taxonomy_exists( $taxonomy_slug ) ) {
				$warnings[] = sprintf(
					/* translators: 1: taxonomy slug, 2: comma-separated requested term names. */
					__( 'The “%1$s” category or tag group is unavailable on this site. These items will not be added: %2$s. Activate the plugin or theme that provides the group, then import again.', 'pageferry' ),
					$taxonomy_slug,
					$term_list
				);
				continue;
			}

			if ( '' !== $bundle_post_type && ! in_array( $taxonomy_slug, $destination_taxonomies, true ) ) {
				// v1 bundles recorded core taxonomies on every post type; keep them assignable.
				if ( 'category' === $taxonomy_slug || 'post_tag' === $taxonomy_slug ) {
					continue;
				}

				$warnings[] = sprintf(
					/* translators: 1: taxonomy slug, 2: destination post type, 3: comma-separated requested term names. */
					__( 'The “%1$s” category or tag group is unavailable for content type “%2$s”. These items will not be added: %3$s.', 'pageferry' ),
					$taxonomy_slug,
					$bundle_post_type,
					$term_list
				);
			}
		}

		return $warnings;
	}

	/**
	 * Media imports need upload_files independently of the import capability.
	 *
	 * @param array $media_index Validated media index from validate().
	 * @return WP_Error|null WP_Error when media is present but forbidden, null otherwise.
	 */
	public static function check_media_upload_capability( array $media_index ): ?WP_Error {
		foreach ( $media_index as $media_state ) {
			if ( ! is_array( $media_state ) || ! empty( $media_state['missing'] ) ) {
				continue;
			}

			if ( ! current_user_can( 'upload_files' ) ) {
				return new WP_Error(
					'pageferry_upload_cap',
					__( 'PageFerry cannot import media: you do not have permission to upload files on this site.', 'pageferry' )
				);
			}

			break;
		}

		return null;
	}

	/**
	 * Assignments and update clears need assign_terms; empty creates are no-ops.
	 *
	 * @param array $manifest Normalized manifest.
	 * @param bool  $is_update True when overwriting an existing target.
	 * @return WP_Error|null WP_Error when taxonomy writes are forbidden, null otherwise.
	 */
	private static function check_terms_assign_capability( array $manifest, bool $is_update ): ?WP_Error {
		$detailed = isset( $manifest['tax_terms'] ) && is_array( $manifest['tax_terms'] ) ? $manifest['tax_terms'] : array();
		$flat     = isset( $manifest['post']['tax'] ) && is_array( $manifest['post']['tax'] ) ? $manifest['post']['tax'] : array();

		$recorded = array_unique( array_merge( array_keys( $detailed ), array_keys( $flat ) ) );

		foreach ( $recorded as $taxonomy_slug ) {
			if ( ! is_string( $taxonomy_slug ) || '' === $taxonomy_slug || ! taxonomy_exists( $taxonomy_slug ) ) {
				continue;
			}

			$taxonomy_object = get_taxonomy( $taxonomy_slug );

			if ( ! $taxonomy_object instanceof WP_Taxonomy ) {
				continue;
			}

			$would_write_terms = false;

			if ( $is_update ) {
				$has_detailed_key = array_key_exists( $taxonomy_slug, $detailed ) && is_array( $detailed[ $taxonomy_slug ] );
				$has_flat_key     = array_key_exists( $taxonomy_slug, $flat ) && is_array( $flat[ $taxonomy_slug ] );

				$would_write_terms = $has_detailed_key || $has_flat_key;
			} else {
				if ( array_key_exists( $taxonomy_slug, $detailed ) && is_array( $detailed[ $taxonomy_slug ] ) ) {
					foreach ( $detailed[ $taxonomy_slug ] as $detailed_entry ) {
						if ( ! is_array( $detailed_entry ) ) {
							continue;
						}

						if ( ! array_key_exists( 'assigned', $detailed_entry ) || ! empty( $detailed_entry['assigned'] ) ) {
							$would_write_terms = true;
							break;
						}
					}
				}

				if ( ! $would_write_terms && array_key_exists( $taxonomy_slug, $flat ) && is_array( $flat[ $taxonomy_slug ] ) ) {
					foreach ( $flat[ $taxonomy_slug ] as $term_name ) {
						if ( is_array( $term_name ) || is_object( $term_name ) ) {
							continue;
						}

						$candidate = is_string( $term_name ) ? $term_name : (string) $term_name;

						if ( '' !== trim( $candidate ) ) {
							$would_write_terms = true;
							break;
						}
					}
				}
			}

			if ( ! $would_write_terms ) {
				continue;
			}

			$assign_capability = isset( $taxonomy_object->cap->assign_terms ) && is_string( $taxonomy_object->cap->assign_terms ) && '' !== $taxonomy_object->cap->assign_terms
				? $taxonomy_object->cap->assign_terms
				: 'edit_posts';

			if ( ! current_user_can( $assign_capability ) ) {
				return new WP_Error(
					'pageferry_terms_cap',
					sprintf(
						/* translators: %s: taxonomy slug the user may not assign. */
						__( 'You do not have permission to add categories or tags in “%s” to this page. Ask an administrator for help.', 'pageferry' ),
						$taxonomy_slug
					)
				);
			}
		}

		return null;
	}

	/**
	 * Resolves destination existence, type, authority, slug, status and state.
	 *
	 * @param array $manifest Normalized manifest from validate().
	 * @param array $args Import args ({ target?: 'create'|'update', target_post_id?: int, status?: string }).
	 * @return array|WP_Error Plan with target_mode, target_post_id, target_post, final_slug, planned_status, target_modified, or WP_Error.
	 */
	private static function resolve_target_plan( array $manifest, array $args ) {
		$target_mode    = isset( $args['target'] ) && 'update' === $args['target'] ? 'update' : 'create';
		$target_post_id = isset( $args['target_post_id'] ) ? (int) $args['target_post_id'] : 0;
		$bundle_type    = isset( $manifest['post']['post_type'] ) && is_string( $manifest['post']['post_type'] ) ? $manifest['post']['post_type'] : '';

		if ( 'update' === $target_mode ) {
			$target_post = get_post( $target_post_id );

			if ( ! $target_post instanceof WP_Post ) {
				return new WP_Error(
					'pageferry_target_missing',
					__( 'The selected page no longer exists. Choose another destination and review the import again.', 'pageferry' )
				);
			}

			if ( $target_post->post_type !== $bundle_type ) {
				return new WP_Error(
					'pageferry_target_type',
					__( 'The selected page has a different content type from the ZIP. Choose a matching destination and review the import again.', 'pageferry' )
				);
			}

			if ( ! current_user_can( 'edit_post', $target_post->ID ) ) {
				return new WP_Error(
					'pageferry_target_cap',
					__( 'You do not have permission to update the selected page. Choose another destination or ask an administrator for help.', 'pageferry' )
				);
			}

			if ( isset( $args['selection']['overrides']['slug'] ) && '' === $args['selection']['overrides']['slug'] && '' !== $target_post->post_name ) {
				return new WP_Error( 'pageferry_selection_invalid', __( 'Enter a URL slug, or keep the current slug before importing.', 'pageferry' ) );
			}
			return array(
				'target_mode'        => 'update',
				'target_post_id'     => (int) $target_post->ID,
				'target_post'        => $target_post,
				'final_slug'         => isset( $args['selection']['overrides']['slug'] ) && $args['selection']['overrides']['slug'] !== $target_post->post_name ? wp_unique_post_slug( $args['selection']['overrides']['slug'], $target_post->ID, 'publish', $bundle_type, $target_post->post_parent ) : (string) $target_post->post_name,
				'planned_status'     => (string) $target_post->post_status,
				'target_modified'    => (string) $target_post->post_modified_gmt,
				'target_fingerprint' => self::target_fingerprint( $target_post_id ),
			);
		}

		$bundle_post_type_object = get_post_type_object( $bundle_type );
		$create_capability       = ( $bundle_post_type_object instanceof WP_Post_Type && isset( $bundle_post_type_object->cap->create_posts ) )
			? $bundle_post_type_object->cap->create_posts
			: 'edit_posts';

		if ( ! $bundle_post_type_object instanceof WP_Post_Type || ! current_user_can( $create_capability ) ) {
			return new WP_Error(
				'pageferry_target_cap',
				__( 'You do not have permission to create this content type. Choose another type or ask an administrator for help.', 'pageferry' )
			);
		}

		$desired_slug = isset( $manifest['post']['slug'] ) && is_string( $manifest['post']['slug'] ) ? $manifest['post']['slug'] : '';
		$final_slug   = '' !== $desired_slug ? wp_unique_post_slug( $desired_slug, 0, 'publish', $bundle_type, 0 ) : '';

		return array(
			'target_mode'        => 'create',
			'target_post_id'     => 0,
			'target_post'        => null,
			'final_slug'         => $final_slug,
			'planned_status'     => self::resolve_create_status( $bundle_type, $args ),
			'target_modified'    => null,
			'target_fingerprint' => null,
		);
	}

	/**
	 * Verifies staged hashes and types before preview or run can promise or mutate content.
	 *
	 * @param string $workspace_dir Absolute workspace dir.
	 * @param array  $media_index Validated media index from validate().
	 * @return WP_Error|null Error on mismatch, null when all staged bytes verify.
	 */
	private static function verify_staged_hashes( string $workspace_dir, array $media_index ): ?WP_Error {
		foreach ( $media_index as $media_state ) {
			if ( ! is_array( $media_state ) || ! empty( $media_state['missing'] ) ) {
				continue;
			}

			$entry = isset( $media_state['entry'] ) && is_array( $media_state['entry'] ) ? $media_state['entry'] : array();
			$file  = isset( $entry['file'] ) ? self::workspace_file( $workspace_dir, $entry['file'] ) : null;

			if ( ! is_string( $file ) ) {
				return new WP_Error(
					'pageferry_file_incomplete',
					sprintf(
						/* translators: %s: media file name not yet uploaded. */
						__( 'Media file %s has not finished uploading. Wait for preparation to finish before importing.', 'pageferry' ),
						self::original_filename( $entry )
					)
				);
			}

			$actual_hash  = hash_file( 'sha256', $file );
			$claimed_hash = isset( $entry['sha256'] ) && is_string( $entry['sha256'] ) ? (string) $entry['sha256'] : '';

			if ( ! is_string( $actual_hash ) || '' === $claimed_hash || ! hash_equals( strtolower( $claimed_hash ), strtolower( $actual_hash ) ) ) {
				return new WP_Error(
					'pageferry_media_hash',
					sprintf(
						/* translators: %s: media file name inside the bundle. */
						__( 'Media file %s does not match the exported file. Export the page again and try the new ZIP.', 'pageferry' ),
						self::original_filename( $entry )
					)
				);
			}

			if ( ! self::staged_media_file_allowed( $file, self::original_filename( $entry ) ) ) {
				return new WP_Error(
					'pageferry_unsupported_media_type',
					sprintf(
						/* translators: %s: media file name with a disallowed extension. */
						__( 'Media file %s has a file type this site does not allow. Ask an administrator to check the file type before importing.', 'pageferry' ),
						self::original_filename( $entry )
					)
				);
			}
		}

		return null;
	}

	/**
	 * Compensates before post persistence; later failures retain saved content and recovery.
	 *
	 * @param string $workspace_dir Absolute workspace dir with media files.
	 * @param array  $manifest Decoded manifest array.
	 * @param array  $args Optional. { target: 'create'|'update', target_post_id?: int, status?: string, target_post_type?: string, selection?: array }.
	 * @return WP_Post|WP_Error Imported post or error.
	 */
	public static function run( string $workspace_dir, array $manifest, array $args = array() ) {
		return PageFerry_Workspace::with_lease(
			$workspace_dir,
			static function () use ( $workspace_dir, $manifest, $args ) {
				return self::with_target_lock(
					$args,
					static function () use ( $workspace_dir, $manifest, $args ) {
						return self::run_leased( $workspace_dir, $manifest, $args );
					}
				);
			}
		);
	}

	/**
	 * Execute while retaining this operation's outcome independently of log storage.
	 *
	 * @param string $workspace_dir Staged files.
	 * @param array  $manifest Source manifest.
	 * @param array  $args Reviewed arguments.
	 * @return array Import result and operation facts.
	 */
	public static function run_with_outcome( string $workspace_dir, array $manifest, array $args = array() ): array {
		$outcome            = array();
		$args['on_outcome'] = static function ( array $row ) use ( &$outcome ): void {
			$outcome = $row;
		};
		$result             = self::run( $workspace_dir, $manifest, $args );
		if ( is_wp_error( $result ) ) {
			$data               = $result->get_error_data();
			$outcome            = array_merge( $outcome, is_array( $data ) ? $data : array() );
			$outcome['message'] = $result->get_error_message();
			$outcome['code']    = $result->get_error_code();
			$outcome['result']  = $outcome['result'] ?? 'failed';
		} else {
			$outcome['post_id'] = $result->ID;
		}
		return array(
			'result'  => $result,
			'outcome' => $outcome,
		);
	}

	/**
	 * Serializes PageFerry updates; ordinary editor writes retain a final race outside this lock.
	 *
	 * @param array    $args Import arguments.
	 * @param callable $operation Import operation.
	 * @return mixed|WP_Error
	 */
	private static function with_target_lock( array $args, callable $operation ) {
		if ( 'update' !== ( $args['target'] ?? 'create' ) || empty( $args['target_post_id'] ) ) {
			return $operation();
		}
		global $wpdb;
		static $held = array();
		$lock_name   = 'pageferry-' . hash( 'sha256', (string) constant( 'DB_NAME' ) . ':' . $wpdb->posts . ':' . (int) $args['target_post_id'] );
		$lock_name   = substr( $lock_name, 0, 64 );

		$acquired = ! isset( $held[ $lock_name ] ) && '1' === (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 0)', $lock_name ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- noncached synchronization primitive, no content query.
		if ( ! $acquired ) {
			return new WP_Error( 'pageferry_target_busy', __( 'Another import is updating the selected page. Wait for it to finish, then review this import again.', 'pageferry' ), array( 'status' => 409 ) );
		}
		$held[ $lock_name ] = true;
		try {
			return $operation();
		} finally {
			unset( $held[ $lock_name ] );
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- release only this connection's target lock.
		}
	}

	/**
	 * Reads fresh destination data used for both confirmation and recovery.
	 *
	 * @param int $post_id Destination ID.
	 * @return array|null Captured state, or null for a deleted target.
	 */
	private static function capture_target_state( int $post_id ): ?array {
		clean_post_cache( $post_id );
		$post = get_post( $post_id );
		if ( ! $post instanceof WP_Post ) {
			return null;
		}
		$meta  = get_post_meta( $post_id );
		$terms = self::snapshot_post_terms( $post );
		ksort( $meta );
		ksort( $terms );
		return array(
			'post_id'           => $post_id,
			'post_title'        => $post->post_title,
			'post_content'      => $post->post_content,
			'post_excerpt'      => $post->post_excerpt,
			'post_type'         => $post->post_type,
			'post_status'       => $post->post_status,
			'post_name'         => $post->post_name,
			'post_modified_gmt' => $post->post_modified_gmt,
			'thumbnail_id'      => (int) ( $meta['_thumbnail_id'][0] ?? 0 ),
			'terms'             => $terms,
			'post_meta'         => $meta,
		);
	}

	/**
	 * Fingerprints the destination fields, metadata and terms, not editor locks.
	 *
	 * @param array|null $state Captured destination.
	 * @return string|null Fingerprint, or null for a missing target.
	 */
	private static function fingerprint_target_state( ?array $state ): ?string {
		if ( null === $state ) {
			return null;
		}
		unset( $state['post_meta']['_edit_lock'], $state['post_meta']['_edit_last'] );
		return hash( 'sha256', serialize( $state ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize -- deterministic internal hash input, never unserialized.
	}

	/**
	 * Returns a fresh fingerprint for the transports' confirmation binding.
	 *
	 * @param int $post_id Destination ID.
	 * @return string|null Fingerprint, or null for a missing target.
	 */
	public static function target_fingerprint( int $post_id ): ?string {
		return self::fingerprint_target_state( self::capture_target_state( $post_id ) );
	}

	/**
	 * Shared stale-confirmation error, including HTTP status for REST callers.
	 *
	 * @return WP_Error
	 */
	private static function stale_target_error(): WP_Error {
		return new WP_Error( 'pageferry_plan_stale', __( 'The selected page changed after your review. Review the import again before confirming.', 'pageferry' ), array( 'status' => 409 ) );
	}

	/**
	 * Executes the shared core while its caller holds the workspace lease.
	 *
	 * @param string $workspace_dir Workspace directory.
	 * @param array  $manifest Manifest array.
	 * @param array  $args Import arguments.
	 * @return WP_Post|WP_Error
	 */
	private static function run_leased( string $workspace_dir, array $manifest, array $args ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$target_type = $args['target_post_type'] ?? null;
		if ( null !== $target_type && ! is_string( $target_type ) ) {
			return new WP_Error( 'pageferry_unsupported_post_type', __( 'Choose an available content type, such as Page or Post.', 'pageferry' ) );
		}
		$validated = self::validate( $manifest, $target_type );

		if ( $validated instanceof WP_Error ) {
			return $validated;
		}

		$source_manifest = $validated['manifest'];
		$selection       = PageFerry_Import_Selection::normalize( $source_manifest, $args['selection'] ?? null, $target_type ?? $source_manifest['post']['post_type'] );
		if ( is_wp_error( $selection ) ) {
			return $selection;
		}
		if ( isset( $args['selection'] ) ) {
			$args['selection'] = $selection;
		}
		$normalized_manifest = isset( $args['selection'] ) ? PageFerry_Import_Selection::apply( $source_manifest, $selection ) : $source_manifest;
		if ( null !== $target_type ) {
			$normalized_manifest['post']['post_type'] = $target_type;
		}
		$media_index = array_intersect_key( $validated['media_index'], array_flip( $selection['media'] ) );
		$limits      = PageFerry_Import_Resources::limits();
		$usage       = PageFerry_Import_Resources::usage( $workspace_dir, $media_index, $limits['core_bytes'] );
		if ( $usage instanceof WP_Error ) {
			return $usage;
		}
		$limit_bytes = $limits['media_file_bytes'];

		foreach ( $media_index as $media_state ) {
			if ( $media_state['missing'] ) {
				continue;
			}

			$entry_bytes = isset( $media_state['entry']['bytes'] ) && is_numeric( $media_state['entry']['bytes'] )
				? (int) $media_state['entry']['bytes']
				: 0;

			if ( 0 < $limit_bytes && 0 < $entry_bytes && $limit_bytes < $entry_bytes ) {
				return new WP_Error(
					'pageferry_media_too_large',
					sprintf(
						/* translators: 1: media file name, 2: human-readable size limit. */
						__( 'Media file %1$s exceeds the file size limit of %2$s. Reduce its size and export again, or ask your host to raise a lower upload limit.', 'pageferry' ),
						self::original_filename( $media_state['entry'] ),
						size_format( $limit_bytes )
					)
				);
			}

			$staged_file = self::workspace_file( $workspace_dir, $media_state['entry']['file'] ?? '' );

			if ( is_string( $staged_file ) ) {
				$staged_bytes = filesize( $staged_file );

				if ( is_int( $staged_bytes ) && 0 < $limit_bytes && $limit_bytes < $staged_bytes ) {
					return new WP_Error(
						'pageferry_media_too_large',
						sprintf(
							/* translators: 1: media file name, 2: human-readable size limit. */
							__( 'Media file %1$s exceeds the file size limit of %2$s. Reduce its size and export again, or ask your host to raise a lower upload limit.', 'pageferry' ),
							self::original_filename( $media_state['entry'] ),
							size_format( $limit_bytes )
						)
					);
				}
			}
		}

		$required_files = self::check_required_files( $workspace_dir, $media_index );

		if ( $required_files instanceof WP_Error ) {
			return $required_files;
		}

		$target_plan = self::resolve_target_plan( $normalized_manifest, $args );

		if ( $target_plan instanceof WP_Error ) {
			return $target_plan;
		}

		$target_mode        = $target_plan['target_mode'];
		$target_post_id     = $target_plan['target_post_id'];
		$target_post        = $target_plan['target_post'];
		$backup_reference   = null;
		$target_fingerprint = 'update' === $target_mode ? self::target_fingerprint( $target_post_id ) : null;
		if ( 'update' === $target_mode && array_key_exists( 'target_fingerprint', $args ) && $args['target_fingerprint'] !== $target_fingerprint ) {
			return self::stale_target_error();
		}

		$destination_acf_fields = self::destination_acf_post_fields( $normalized_manifest, $target_plan );

		$media_cap_error = self::check_media_upload_capability( $media_index );

		if ( $media_cap_error instanceof WP_Error ) {
			return $media_cap_error;
		}

		$terms_cap_error = self::check_terms_assign_capability( $normalized_manifest, 'update' === $target_mode );

		if ( $terms_cap_error instanceof WP_Error ) {
			return $terms_cap_error;
		}

		$planned_create_status = 'update' === $target_mode ? null : $target_plan['planned_status'];

		$id_map              = array();
		$created_attachments = array();
		$pending_hashes      = array();
		$reused_count        = 0;
		$uploaded_count      = 0;
		$missing_media       = array();

		$preflight_error = self::verify_staged_hashes( $workspace_dir, $media_index );

		if ( $preflight_error instanceof WP_Error ) {
			return $preflight_error;
		}

		foreach ( $media_index as $media_old_id => $media_state ) {
			if ( $media_state['missing'] ) {
				$missing_media[] = $media_old_id;
				continue;
			}

			$media_entry = $media_state['entry'];
			$media_file  = self::workspace_file( $workspace_dir, $media_entry['file'] );

			// A file disappearing after preflight is a race, not exporter-declared missing media.
			if ( ! is_string( $media_file ) ) {
				return self::abort(
					new WP_Error(
						'pageferry_file_incomplete',
						sprintf(
							/* translators: %s: media file name not yet uploaded. */
							__( 'Media file %s has not finished uploading. Wait for preparation to finish before importing.', 'pageferry' ),
							self::original_filename( $media_entry )
						)
					),
					$created_attachments,
					$backup_reference
				);
			}

			$actual_hash = hash_file( 'sha256', $media_file );

			if ( ! is_string( $actual_hash ) || ! hash_equals( strtolower( (string) $media_entry['sha256'] ), strtolower( $actual_hash ) ) ) {
				return self::abort(
					new WP_Error(
						'pageferry_media_hash',
						sprintf(
							/* translators: %s: media file name inside the bundle. */
							__( 'Media file %s does not match the exported file. Export the page again and try the new ZIP.', 'pageferry' ),
							self::original_filename( $media_entry )
						)
					),
					$created_attachments,
					$backup_reference
				);
			}

			$workspace_bytes = (int) filesize( $media_file );
			$original_name   = self::original_filename( $media_entry );

			$new_attachment_id = self::resolve_hash( (string) $actual_hash, $original_name, $workspace_bytes, $pending_hashes, (int) $media_old_id );

			if ( null === $new_attachment_id ) {
				$conflict = self::new_media_conflict( $media_file, $original_name );
				if ( $conflict instanceof WP_Error ) {
					return self::abort( $conflict, $created_attachments, $backup_reference );
				}
				$sideloaded_id = self::sideload_workspace_file( $media_file, $original_name );

				if ( is_wp_error( $sideloaded_id ) ) {
					return self::abort( $sideloaded_id, $created_attachments, $backup_reference );
				}

				$new_attachment_id     = (int) $sideloaded_id;
				$created_attachments[] = $new_attachment_id;
				++$uploaded_count;
			} else {
				++$reused_count;
			}

			$pending_hashes[ (string) $actual_hash ] = $new_attachment_id;
			$id_map[ $media_old_id ]                 = $new_attachment_id;
		}

		// Hash equality grants no edit authority over reused attachment metadata.
		$media_errors           = array();
		$metadata_by_attachment = array();
		foreach ( $id_map as $mapped_old_id => $mapped_new_id ) {
			$mapped_new_id = (int) $mapped_new_id;

			if ( ! in_array( $mapped_new_id, $created_attachments, true ) ) {
				continue;
			}

			$mapped_entry = $media_index[ $mapped_old_id ]['entry'];

			foreach ( array( 'alt', 'caption', 'title', 'description' ) as $field ) {
				if ( isset( $mapped_entry[ $field ] ) && is_string( $mapped_entry[ $field ] ) && '' !== $mapped_entry[ $field ] ) {
					$metadata_by_attachment[ $mapped_new_id ][ $field ] = $mapped_entry[ $field ];
				}
			}
		}
		foreach ( $metadata_by_attachment as $attachment_id => $metadata_entry ) {
			$media_errors = array_merge( $media_errors, self::apply_media_meta( (int) $attachment_id, $metadata_entry ) );
		}

		// Media must be fully initialized before saved content can reference it.
		if ( array() !== $media_errors ) {
			$error = self::abort(
				new WP_Error(
					'pageferry_media_metadata',
					sprintf(
						/* translators: %s: attachment metadata failure notes. */
						__( 'The page was not saved because some media details could not be saved. %s', 'pageferry' ),
						implode( ' ', $media_errors )
					),
					array( 'media_errors' => $media_errors )
				),
				$created_attachments,
				$backup_reference
			);
			$recovery = $error->get_error_data();
			self::append_log(
				array(
					'time'                     => gmdate( 'c' ),
					'action'                   => $target_mode,
					'target'                   => 'update' === $target_mode ? $target_post_id : 0,
					'source'                   => $normalized_manifest['source']['url'] ?? '',
					'result'                   => empty( $recovery['cleanup_errors'] ) ? 'failed' : 'partial',
					'media_errors'             => $media_errors,
					'cleanup_errors'           => $recovery['cleanup_errors'] ?? array(),
					'remaining_attachment_ids' => $recovery['remaining_attachment_ids'] ?? array(),
				)
			);
			return $error;
		}

		foreach ( $id_map as $old_id => $attachment_id ) {
			if ( in_array( (int) $attachment_id, $created_attachments, true ) ) {
				$file = get_attached_file( (int) $attachment_id );
				$hash = is_string( $file ) && is_readable( $file ) ? hash_file( 'sha256', $file ) : false;
				if ( ! is_string( $hash ) || ! hash_equals( strtolower( $media_index[ $old_id ]['entry']['sha256'] ), $hash ) ) {
					return self::abort( self::media_processing_error( self::original_filename( $media_index[ $old_id ]['entry'] ) ), $created_attachments, $backup_reference );
				}
			}
		}

		$source_content   = $normalized_manifest['post']['content'];
		$remapped_blocks  = self::remap( parse_blocks( $source_content ), $id_map, self::build_block_ref_map( $normalized_manifest ) );
		$remapped_content = PageFerry_Content_Remapper::apply( $source_content, $remapped_blocks );
		if ( $remapped_content instanceof WP_Error ) {
			return self::abort( $remapped_content, $created_attachments, $backup_reference );
		}
		$final_content = self::rewrite_media_urls( $remapped_content, $normalized_manifest, $id_map );
		$final_content = self::rewrite_wp_image_classes( $final_content, $id_map );
		$final_content = self::rewrite_source_host( $final_content, $normalized_manifest );

		$final_excerpt = isset( $normalized_manifest['post']['excerpt'] ) && is_string( $normalized_manifest['post']['excerpt'] )
			? self::rewrite_acf_string( $normalized_manifest['post']['excerpt'], $normalized_manifest, $id_map )
			: '';

		$post_title = isset( $normalized_manifest['post']['title'] ) && is_string( $normalized_manifest['post']['title'] )
			? $normalized_manifest['post']['title']
			: '';

		$post_type    = $normalized_manifest['post']['post_type'];
		$desired_slug = isset( $normalized_manifest['post']['slug'] ) && is_string( $normalized_manifest['post']['slug'] ) ? $normalized_manifest['post']['slug'] : '';

		// Delay snapshots until media succeeds so earlier failures cannot evict recovery history.
		if ( 'update' === $target_mode ) {
			$fresh_state = self::capture_target_state( $target_post_id );
			if ( null === $fresh_state || self::fingerprint_target_state( $fresh_state ) !== $target_fingerprint ) {
				return self::abort( self::stale_target_error(), $created_attachments, null );
			}
			$backup_reference = self::snapshot_post( $fresh_state );

			if ( null === $backup_reference ) {
				return self::abort(
					new WP_Error(
						'pageferry_import_failed',
						__( 'The previous version of the selected page could not be saved. The page was not updated. Try again or ask an administrator for help.', 'pageferry' )
					),
					$created_attachments,
					$backup_reference
				);
			}
		}

		if ( 'update' === $target_mode && $target_post instanceof WP_Post ) {
			if ( ! in_array( 'title', $selection['fields'], true ) ) {
				$post_title = $target_post->post_title;
			}
			if ( ! in_array( 'excerpt', $selection['fields'], true ) ) {
				$final_excerpt = $target_post->post_excerpt;
			}
		}
		$pre_update_template = '';

		if ( 'update' === $target_mode ) { // WordPress unslashes post writes. Neutralize its template merge to preserve unavailable templates.
			$pre_update_template_raw = get_post_meta( $target_post->ID, '_wp_page_template', true );
			$pre_update_template     = is_string( $pre_update_template_raw ) ? trim( $pre_update_template_raw ) : '';

			if ( 'default' === $pre_update_template ) {
				$pre_update_template = '';
			}

			$updated_post_id = wp_update_post(
				wp_slash(
					array(
						'ID'            => $target_post->ID,
						'post_title'    => $post_title,
						'post_content'  => $final_content,
						'post_excerpt'  => $final_excerpt,
						'post_name'     => $target_plan['final_slug'],
						'page_template' => 'default',
					)
				),
				true
			);

			if ( is_wp_error( $updated_post_id ) ) {
				return self::abort( $updated_post_id, $created_attachments, $backup_reference );
			}

			$imported_post = get_post( (int) $updated_post_id );

			if ( ! $imported_post instanceof WP_Post ) {
				// The saved post references new media; retain both it and the recovery snapshot on late failure.

				return new WP_Error(
					'pageferry_import_failed',
					__( 'The page was updated, but PageFerry could not read it back. Check the destination page before trying again.', 'pageferry' ),
					array(
						'post_id' => (int) $updated_post_id,
						'backup'  => $backup_reference,
						'result'  => 'partial',
					)
				);
			}
		} else {
			$final_status = is_string( $planned_create_status ) ? $planned_create_status : 'draft';
			// Draft and pending slugs bypass core uniqueness checks.
			$unique_slug = '' !== $desired_slug ? wp_unique_post_slug( $desired_slug, 0, 'publish', $post_type, 0 ) : '';

			$created_post_id = wp_insert_post(
				wp_slash(
					array(
						'post_type'    => $post_type,
						'post_title'   => $post_title,
						'post_name'    => $unique_slug,
						'post_content' => $final_content,
						'post_excerpt' => $final_excerpt,
						'post_status'  => $final_status,
					)
				),
				true
			);

			if ( is_wp_error( $created_post_id ) ) {
				return self::abort( $created_post_id, $created_attachments, null );
			}

			$imported_post = get_post( (int) $created_post_id );

			if ( ! $imported_post instanceof WP_Post ) {
				wp_delete_post( (int) $created_post_id, true );

				return self::abort(
					new WP_Error(
						'pageferry_import_failed',
						__( 'The new page could not be checked after saving. Check the destination and Media Library before trying again.', 'pageferry' )
					),
					$created_attachments,
					null
				);
			}
		}

		$term_errors      = self::assign_terms( $imported_post->ID, $normalized_manifest, 'update' === $target_mode, $selection['taxonomy_actions'] ?? array() );
		$thumbnail_errors = self::assign_thumbnail( $imported_post->ID, $normalized_manifest, $id_map, 'update' === $target_mode );
		$acf_errors       = array();
		$acf_skipped      = self::restore_acf_post_meta( $imported_post->ID, $normalized_manifest, $id_map, $acf_errors, $created_attachments );
		$acf_skipped      = array_merge( $acf_skipped, self::restore_acf_post_fields( $imported_post->ID, $normalized_manifest, $id_map, $acf_errors, $destination_acf_fields, $created_attachments ) );

		// Restore legacy template intent after neutralizing the core update merge.
		if ( 'update' === $target_mode && null === self::normalized_bundle_template( $normalized_manifest ) ) {
			$template_errors = self::write_template_verbatim( $imported_post->ID, $pre_update_template );
		} else {
			$template_errors = self::assign_template( $imported_post->ID, $normalized_manifest );
		}

		$post_write_errors = array_merge( $term_errors, $thumbnail_errors, $acf_errors, $template_errors );

		// Late failures retain the saved post and snapshot, so report partial and do not prune history.
		if ( array() !== $post_write_errors ) {
			self::remember_hashes( $pending_hashes );

			$partial_export_warnings   = self::export_warnings( $normalized_manifest );
			$partial_pattern_warnings  = self::preview_pattern_warnings( $normalized_manifest );
			$partial_template_warnings = self::preview_template_warnings( $normalized_manifest );

			$partial_row = array(
				'time'     => gmdate( 'c' ),
				'action'   => 'update' === $target_mode ? 'update' : 'create',
				'target'   => $imported_post->ID,
				'slug'     => $imported_post->post_name,
				'source'   => isset( $normalized_manifest['source']['url'] ) ? (string) $normalized_manifest['source']['url'] : '',
				'reused'   => $reused_count,
				'uploaded' => $uploaded_count,
				'missing'  => $missing_media,
				'result'   => 'partial',
				'backup'   => $backup_reference,
			);

			if ( array() !== $partial_export_warnings ) {
				$partial_row['export_warnings'] = $partial_export_warnings;
			}

			if ( array() !== $partial_pattern_warnings ) {
				$partial_row['pattern_warnings'] = array_values( $partial_pattern_warnings );
			}

			if ( array() !== $partial_template_warnings ) {
				$partial_row['template_warnings'] = array_values( $partial_template_warnings );
			}

			if ( array() !== $term_errors ) {
				$partial_row['term_errors'] = array_values( $term_errors );
			}

			if ( array() !== $thumbnail_errors ) {
				$partial_row['thumbnail_errors'] = array_values( $thumbnail_errors );
			}

			if ( array() !== $template_errors ) {
				$partial_row['template_errors'] = array_values( $template_errors );
			}

			if ( array() !== $acf_skipped ) {
				$partial_row['acf_skipped'] = array_values( $acf_skipped );
			}
			if ( array() !== $acf_errors ) {
				$partial_row['acf_errors'] = array_values( $acf_errors );
			}

			if ( isset( $args['on_outcome'] ) && is_callable( $args['on_outcome'] ) ) {
				$args['on_outcome']( $partial_row );
			}
			self::append_log( $partial_row );

			$error_code = 'pageferry_term_failure';

			if ( array() !== $acf_errors ) {
				$error_code = 'pageferry_acf_failure';
			} elseif ( array() !== $template_errors ) {
				$error_code = 'pageferry_template_failure';
			}

			return new WP_Error(
				$error_code,
				sprintf(
					/* translators: 1: post ID, 2: comma-separated failure notes. */
					__( 'Your content and media were saved (ID %1$s), but some details could not be saved. %2$s Open the editor and check these details. See the import log for more information.', 'pageferry' ),
					(string) $imported_post->ID,
					implode( ' ', $post_write_errors )
				),
				array(
					'post_id'          => $imported_post->ID,
					'backup'           => $backup_reference,
					'term_errors'      => array_values( $term_errors ),
					'thumbnail_errors' => array_values( $thumbnail_errors ),
					'template_errors'  => array_values( $template_errors ),
					'acf_errors'       => array_values( $acf_errors ),
				)
			);
		}

		self::remember_hashes( $pending_hashes );

		if ( null !== $backup_reference ) {
			self::prune_backups();
		}

		$log_row = array(
			'time'     => gmdate( 'c' ),
			'action'   => 'update' === $target_mode ? 'update' : 'create',
			'target'   => $imported_post->ID,
			'slug'     => $imported_post->post_name,
			'source'   => isset( $normalized_manifest['source']['url'] ) ? (string) $normalized_manifest['source']['url'] : '',
			'reused'   => $reused_count,
			'uploaded' => $uploaded_count,
			'missing'  => $missing_media,
			'result'   => 'success',
			'backup'   => $backup_reference,
		);

		$success_export_warnings   = self::export_warnings( $normalized_manifest );
		$success_pattern_warnings  = self::preview_pattern_warnings( $normalized_manifest );
		$success_template_warnings = self::preview_template_warnings( $normalized_manifest );

		if ( array() !== $success_export_warnings ) {
			$log_row['export_warnings'] = $success_export_warnings;
		}

		if ( array() !== $success_pattern_warnings ) {
			$log_row['pattern_warnings'] = array_values( $success_pattern_warnings );
		}

		if ( array() !== $success_template_warnings ) {
			$log_row['template_warnings'] = array_values( $success_template_warnings );
		}

		if ( array() !== $acf_skipped ) {
			$log_row['acf_skipped'] = array_values( $acf_skipped );
		}

		if ( isset( $args['on_outcome'] ) && is_callable( $args['on_outcome'] ) ) {
			$args['on_outcome']( $log_row );
		}
		self::append_log( $log_row );

		return $imported_post;
	}

	/**
	 * Previews the shared target plan and warnings without writing media or index rows.
	 *
	 * @param string $workspace_dir Absolute workspace dir with media files.
	 * @param array  $manifest Decoded manifest array.
	 * @param array  $args Optional target args ({ target, target_post_id, status }).
	 * @return array|WP_Error Summary array or WP_Error.
	 */
	public static function preview( string $workspace_dir, array $manifest, array $args = array() ) {
		return PageFerry_Workspace::with_lease(
			$workspace_dir,
			static function () use ( $workspace_dir, $manifest, $args ) {
				return self::preview_leased( $workspace_dir, $manifest, $args );
			}
		);
	}

	/**
	 * Plans an import while its caller holds the workspace lease.
	 *
	 * @param string $workspace_dir Workspace directory.
	 * @param array  $manifest Manifest array.
	 * @param array  $args Import arguments.
	 * @return array|WP_Error
	 */
	private static function preview_leased( string $workspace_dir, array $manifest, array $args ) {
		$target_type = $args['target_post_type'] ?? null;
		if ( null !== $target_type && ! is_string( $target_type ) ) {
			return new WP_Error( 'pageferry_unsupported_post_type', __( 'Choose an available content type, such as Page or Post.', 'pageferry' ) );
		}
		$validated = self::validate( $manifest, $target_type );

		if ( $validated instanceof WP_Error ) {
			return $validated;
		}

		$source_manifest = $validated['manifest'];
		$selection       = PageFerry_Import_Selection::normalize( $source_manifest, $args['selection'] ?? null, $target_type ?? $source_manifest['post']['post_type'] );
		if ( is_wp_error( $selection ) ) {
			return $selection;
		}
		if ( isset( $args['selection'] ) ) {
			$args['selection'] = $selection;
		}
		$normalized_manifest = isset( $args['selection'] ) ? PageFerry_Import_Selection::apply( $source_manifest, $selection ) : $source_manifest;
		if ( null !== $target_type ) {
			$normalized_manifest['post']['post_type'] = $target_type;
		}
		$media_index = ! empty( $args['prepare_review'] ) ? $validated['media_index'] : array_intersect_key( $validated['media_index'], array_flip( $selection['media'] ) );
		$limits      = PageFerry_Import_Resources::limits();
		$usage       = PageFerry_Import_Resources::usage( $workspace_dir, $media_index, $limits['core_bytes'] );
		if ( $usage instanceof WP_Error ) {
			return $usage;
		}
		$limit_bytes = $limits['media_file_bytes'];

		foreach ( $media_index as $media_state ) {
			if ( $media_state['missing'] ) {
				continue;
			}

			$entry_bytes = isset( $media_state['entry']['bytes'] ) && is_numeric( $media_state['entry']['bytes'] )
				? (int) $media_state['entry']['bytes']
				: 0;

			if ( 0 < $limit_bytes && 0 < $entry_bytes && $limit_bytes < $entry_bytes ) {
				return new WP_Error(
					'pageferry_media_too_large',
					sprintf(
						/* translators: 1: media file name, 2: human-readable size limit. */
						__( 'Media file %1$s exceeds the file size limit of %2$s. Reduce its size and export again, or ask your host to raise a lower upload limit.', 'pageferry' ),
						self::original_filename( $media_state['entry'] ),
						size_format( $limit_bytes )
					)
				);
			}

			$staged_file = self::workspace_file( $workspace_dir, $media_state['entry']['file'] ?? '' );

			if ( is_string( $staged_file ) ) {
				$staged_bytes = filesize( $staged_file );

				if ( is_int( $staged_bytes ) && 0 < $limit_bytes && $limit_bytes < $staged_bytes ) {
					return new WP_Error(
						'pageferry_media_too_large',
						sprintf(
							/* translators: 1: media file name, 2: human-readable size limit. */
							__( 'Media file %1$s exceeds the file size limit of %2$s. Reduce its size and export again, or ask your host to raise a lower upload limit.', 'pageferry' ),
							self::original_filename( $media_state['entry'] ),
							size_format( $limit_bytes )
						)
					);
				}
			}
		}

		$preview_required = self::check_required_files( $workspace_dir, $media_index );

		if ( $preview_required instanceof WP_Error ) {
			return $preview_required;
		}

		$target_plan = self::resolve_target_plan( $normalized_manifest, $args );

		if ( $target_plan instanceof WP_Error ) {
			return $target_plan;
		}

		$target_mode       = $target_plan['target_mode'];
		$is_update_preview = 'update' === $target_mode;

		$preview_media_cap = self::check_media_upload_capability( $media_index );

		if ( $preview_media_cap instanceof WP_Error ) {
			return $preview_media_cap;
		}

		$preview_terms_cap = self::check_terms_assign_capability( $normalized_manifest, $is_update_preview );

		if ( $preview_terms_cap instanceof WP_Error ) {
			return $preview_terms_cap;
		}

		$preview_preflight = self::verify_staged_hashes( $workspace_dir, $media_index );

		if ( $preview_preflight instanceof WP_Error ) {
			return $preview_preflight;
		}

		$reused_count    = 0;
		$upload_count    = 0;
		$missing_count   = 0;
		$missing_ids     = array();
		$resolved_hashes = array();
		$media_actions   = array();
		$verified_media  = array();

		foreach ( $media_index as $media_old_id => $media_state ) {
			$verified_media[ (int) $media_old_id ] = array( 'missing' => $media_state['missing'] );
			if ( $media_state['missing'] ) {
				if ( in_array( (int) $media_old_id, $selection['media'], true ) ) {
					++$missing_count;
					$missing_ids[] = (int) $media_old_id;
				}
				continue;
			}

			$file_name = isset( $media_state['entry']['file'] ) && is_string( $media_state['entry']['file'] )
				? $media_state['entry']['file']
				: '';

			$media_file = self::workspace_file( $workspace_dir, $file_name );

			// A post-preflight disappearance must fail rather than become skippable missing media.
			if ( ! is_string( $media_file ) ) {
				return new WP_Error(
					'pageferry_file_incomplete',
					sprintf(
						/* translators: %s: media file name not yet uploaded. */
						__( 'Media file %s has not finished uploading. Wait for preparation to finish before importing.', 'pageferry' ),
						self::original_filename( $media_state['entry'] )
					)
				);
			}

			$actual_hash = hash_file( 'sha256', $media_file );

			if ( ! is_string( $actual_hash ) ) {
				return new WP_Error(
					'pageferry_media_hash',
					sprintf(
						/* translators: %s: media file name inside the bundle. */
						__( 'Media file %s does not match the exported file. Export the page again and try the new ZIP.', 'pageferry' ),
						self::original_filename( $media_state['entry'] )
					)
				);
			}

			$claimed_hash = isset( $media_state['entry']['sha256'] ) && is_string( $media_state['entry']['sha256'] ) ? (string) $media_state['entry']['sha256'] : '';

			if ( '' === $claimed_hash || ! hash_equals( strtolower( $claimed_hash ), strtolower( $actual_hash ) ) ) {
				return new WP_Error(
					'pageferry_media_hash',
					sprintf(
						/* translators: %s: media file name inside the bundle. */
						__( 'Media file %s does not match the exported file. Export the page again and try the new ZIP.', 'pageferry' ),
						self::original_filename( $media_state['entry'] )
					)
				);
			}

			$resolved_id = self::resolve_hash( $actual_hash, self::original_filename( $media_state['entry'] ), (int) filesize( $media_file ), $resolved_hashes, (int) $media_old_id );
			if ( null === $resolved_id && in_array( (int) $media_old_id, $selection['media'], true ) ) {
				$conflict = self::new_media_conflict( $media_file, self::original_filename( $media_state['entry'] ) );
				if ( $conflict instanceof WP_Error ) {
					return $conflict;
				}
			}
			$source_url                             = $media_state['entry']['url'] ?? '';
			$identity_manifest                      = $source_manifest;
			$identity_manifest['media']             = array( $media_state['entry'] );
			$destination_url                        = $resolved_id ? wp_get_attachment_url( $resolved_id ) : false;
			$unchanged                              = is_string( $destination_url ) && is_string( $source_url ) && wp_parse_url( $source_url, PHP_URL_PATH ) === wp_parse_url( $destination_url, PHP_URL_PATH ) && $resolved_id === (int) $media_old_id && '' !== $source_url
				&& self::rewrite_acf_string( $source_url, $identity_manifest, array( (int) $media_old_id => $resolved_id ) ) === self::rewrite_acf_string( $source_url, $identity_manifest, array() );
			$svg                                    = 'svg' === strtolower( pathinfo( self::original_filename( $media_state['entry'] ), PATHINFO_EXTENSION ) ) ? PageFerry_Import_Review::svg_preview( $media_file ) : null;
			$verified_media[ (int) $media_old_id ] += array(
				'unchanged'   => $unchanged,
				'svg_warning' => $svg['warning'] ?? '',
				'hash'        => $actual_hash,
				'library'     => null !== $resolved_id && $resolved_id > 0,
			);

			if ( null !== $resolved_id ) {
				++$reused_count;
			} else {
				++$upload_count;
				$resolved_id = 0;
			}

			$media_actions[ (int) $media_old_id ] = isset( $resolved_hashes[ $actual_hash ] ) || $resolved_id > 0 ? 'reuse' : 'new';
			$resolved_hashes[ $actual_hash ]      = $resolved_id;
		}

		$flat_tax      = isset( $normalized_manifest['post']['tax'] ) && is_array( $normalized_manifest['post']['tax'] )
			? $normalized_manifest['post']['tax']
			: array();
		$preview_terms = array();

		foreach ( $flat_tax as $taxonomy_slug => $term_names ) {
			if ( ! is_string( $taxonomy_slug ) || '' === $taxonomy_slug || ! is_array( $term_names ) ) {
				continue;
			}

			$preview_names = array();

			foreach ( $term_names as $term_name ) {
				if ( is_array( $term_name ) || is_object( $term_name ) ) {
					continue;
				}

				$preview_names[] = is_string( $term_name ) ? $term_name : (string) $term_name;
			}

			$preview_terms[ $taxonomy_slug ] = $preview_names;
		}

		$terms_clear = array();

		if ( $is_update_preview ) {
			$detailed_tax = isset( $normalized_manifest['tax_terms'] ) && is_array( $normalized_manifest['tax_terms'] )
				? $normalized_manifest['tax_terms']
				: array();
			$recorded_tax = array_unique( array_merge( array_keys( $detailed_tax ), array_keys( $flat_tax ) ) );

			foreach ( $recorded_tax as $taxonomy_slug ) {
				if ( ! is_string( $taxonomy_slug ) || '' === $taxonomy_slug || ! taxonomy_exists( $taxonomy_slug ) ) {
					continue;
				}

				$has_detailed = array_key_exists( $taxonomy_slug, $detailed_tax ) && is_array( $detailed_tax[ $taxonomy_slug ] );
				$has_flat     = array_key_exists( $taxonomy_slug, $flat_tax ) && is_array( $flat_tax[ $taxonomy_slug ] );

				if ( ! $has_detailed && ! $has_flat ) {
					continue;
				}

				$detailed_list = $has_detailed ? $detailed_tax[ $taxonomy_slug ] : array();

				// Ancestors rebuild hierarchy but do not count as direct assignments.
				$has_assigned_detail = false;

				foreach ( $detailed_list as $detailed_entry ) {
					if ( ! is_array( $detailed_entry ) ) {
						continue;
					}

					if ( ! array_key_exists( 'assigned', $detailed_entry ) || ! empty( $detailed_entry['assigned'] ) ) {
						$has_assigned_detail = true;
						break;
					}
				}

				if ( $has_assigned_detail ) {
					continue;
				}

				$flat_list = $has_flat ? $flat_tax[ $taxonomy_slug ] : array();

				if ( array() === $flat_list ) {
					$terms_clear[] = $taxonomy_slug;
				}
			}
		}

		$thumbnail_action     = 'none';
		$thumbnail_unresolved = false;
		$post_section         = isset( $normalized_manifest['post'] ) && is_array( $normalized_manifest['post'] )
			? $normalized_manifest['post']
			: array();
		$has_thumbnail_key    = array_key_exists( 'thumbnail_old_id', $post_section );

		if ( ! $is_update_preview ) {
			if ( $has_thumbnail_key && is_numeric( $post_section['thumbnail_old_id'] ) && 0 < (int) $post_section['thumbnail_old_id'] ) {
				$thumb_old = (int) $post_section['thumbnail_old_id'];

				if ( isset( $media_index[ $thumb_old ] ) && ! $media_index[ $thumb_old ]['missing'] ) {
					$thumb_file = self::workspace_file( $workspace_dir, $media_index[ $thumb_old ]['entry']['file'] ?? '' );

					if ( is_string( $thumb_file ) ) {
						$thumbnail_action = 'set';
					}
				}
			}
		} elseif ( ! $has_thumbnail_key ) {
			$thumbnail_action = 'retain';
		} elseif ( null === $post_section['thumbnail_old_id'] || ! is_numeric( $post_section['thumbnail_old_id'] ) || 0 >= (int) $post_section['thumbnail_old_id'] ) {
			$thumbnail_action = 'remove';
		} else {
			$thumb_old = (int) $post_section['thumbnail_old_id'];

			if ( isset( $media_index[ $thumb_old ] ) && ! $media_index[ $thumb_old ]['missing'] ) {
				$thumb_file = self::workspace_file( $workspace_dir, $media_index[ $thumb_old ]['entry']['file'] ?? '' );

				if ( is_string( $thumb_file ) ) {
					$thumbnail_action = 'set';
				} else {
					$thumbnail_action     = 'retain';
					$thumbnail_unresolved = true;
				}
			} else {
				$thumbnail_action     = 'retain';
				$thumbnail_unresolved = true;
			}
		}

		$planned_status = $target_plan['planned_status'];
		$final_slug     = $target_plan['final_slug'];

		$preview_export_warnings   = self::export_warnings( $normalized_manifest );
		$preview_acf_warnings      = self::preview_acf_warnings( $normalized_manifest, self::destination_acf_post_fields( $normalized_manifest, $target_plan ) );
		$preview_pattern_warnings  = self::preview_pattern_warnings( $normalized_manifest );
		$preview_taxonomy_warnings = self::preview_taxonomy_warnings( $normalized_manifest );
		$preview_template_warnings = self::preview_template_warnings( $normalized_manifest );
		$preview_warnings          = array_values( $preview_export_warnings );

		$bundle_template     = self::normalized_bundle_template( $normalized_manifest );
		$template_action     = $is_update_preview ? 'retain' : 'none';
		$template_unresolved = false;

		if ( null !== $bundle_template ) {
			if ( '' === $bundle_template ) {
				$template_action = $is_update_preview ? 'default' : 'none';
			} else {
				$template_action     = 'set';
				$template_unresolved = array() !== $preview_template_warnings;
			}
		}

		if ( array() !== $missing_ids ) {
			$preview_warnings[] = sprintf(
				/* translators: 1: count of media entries with no file, 2: comma-separated source attachment IDs. */
				_n( '%1$d media file is missing and will be skipped. Check the page after importing. Source media ID: %2$s.', '%1$d media files are missing and will be skipped. Check the page after importing. Source media IDs: %2$s.', $missing_count, 'pageferry' ),
				count( $missing_ids ),
				implode( ', ', array_map( 'strval', $missing_ids ) )
			);
		}

		foreach ( $preview_acf_warnings as $acf_warning ) {
			$preview_warnings[] = $acf_warning;
		}

		foreach ( $preview_pattern_warnings as $pattern_warning ) {
			$preview_warnings[] = $pattern_warning;
		}

		foreach ( $preview_taxonomy_warnings as $taxonomy_warning ) {
			$preview_warnings[] = $taxonomy_warning;
		}

		foreach ( $preview_template_warnings as $template_warning ) {
			$preview_warnings[] = $template_warning;
		}

		if ( $thumbnail_unresolved ) {
			$preview_warnings[] = __( 'The selected featured image is unavailable. The current featured image will be kept.', 'pageferry' );
		}

		if ( $source_manifest['post']['post_type'] !== $normalized_manifest['post']['post_type'] ) {
			$preview_warnings[] = sprintf(
				/* translators: 1: source post type, 2: destination post type. */
				__( 'This ZIP contains content of type “%1$s”. You chose “%2$s” for the import. Check that its categories, tags and page template are available on this site.', 'pageferry' ),
				$source_manifest['post']['post_type'],
				$normalized_manifest['post']['post_type']
			);
		}
		if ( count( $selection['media'] ) < count( $source_manifest['media'] ) ) {
			$preview_warnings[] = __( 'Files you deselect will not be imported. Images and links that use them may still point to the source site or stop working. Check them in the editor after importing.', 'pageferry' );
		}
		foreach ( $source_manifest['media'] as $source_media ) {
			if ( ! empty( $source_media['likely_false_positive'] ) && ! ( in_array( (int) $source_media['old_id'], $selection['media'], true ) && ! empty( $verified_media[ (int) $source_media['old_id'] ]['unchanged'] ) ) ) {
				$preview_warnings[] = __( 'Some files in this ZIP may not be used on the page. Review the files marked “Check this file” and deselect any you do not need.', 'pageferry' );
				break;
			}
		}
		$review_title = isset( $normalized_manifest['post']['title'] ) ? (string) $normalized_manifest['post']['title'] : '';
		if ( $is_update_preview && ! in_array( 'title', $selection['fields'], true ) ) {
			$review_title = $target_plan['target_post']->post_title;
		}
		$review = PageFerry_Import_Selection::review( $source_manifest, $selection, $normalized_manifest['post']['post_type'], $media_actions, (int) $target_plan['target_post_id'] );
		foreach ( $review['media'] as &$review_media ) {
			$review_media += $verified_media[ $review_media['id'] ] ?? array();
			if ( ! empty( $review_media['svg_warning'] ) ) {
				$preview_warnings[] = $review_media['filename'] . ': ' . $review_media['svg_warning'];
			}
		}
		unset( $review_media );
		foreach ( $review['taxonomies'] as $review_taxonomy ) {
			foreach ( $review_taxonomy['terms'] as $review_term ) {
				if ( $review_term['included'] && 'forbidden' === $review_term['status'] ) {
					$preview_warnings[] = sprintf(
						/* translators: 1: term name, 2: taxonomy label. */
						__( 'You do not have permission to create “%1$s” in %2$s. Deselect it or ask an administrator to create it first.', 'pageferry' ),
						$review_term['name'],
						$review_taxonomy['label']
					);
				}
			}
		}
		$preview = array(
			'templates'            => wp_get_theme()->get_page_templates( $target_plan['target_post'], $normalized_manifest['post']['post_type'] ),
			'source_title'         => (string) ( $source_manifest['post']['title'] ?? '' ),
			'source_url'           => (string) ( $source_manifest['source']['url'] ?? '' ),
			'source_date'          => is_string( $source_manifest['source']['date'] ?? null ) ? $source_manifest['source']['date'] : '',
			'target'               => $target_mode,
			'target_post_id'       => (int) $target_plan['target_post_id'],
			'target_slug'          => $target_plan['target_post'] instanceof WP_Post ? $target_plan['target_post']->post_name : '',
			'target_url'           => $target_plan['target_post'] instanceof WP_Post ? get_permalink( $target_plan['target_post'] ) : '',
			'target_title'         => $target_plan['target_post'] instanceof WP_Post ? $target_plan['target_post']->post_title : null,
			'target_modified'      => $target_plan['target_modified'],
			'target_fingerprint'   => $target_plan['target_fingerprint'],
			'slug'                 => (string) $final_slug,
			'title'                => $review_title,
			'source_post_type'     => $source_manifest['post']['post_type'],
			'review'               => $review,
			'post_type'            => $normalized_manifest['post']['post_type'],
			'status'               => $planned_status,
			'media_new'            => $upload_count,
			'reused'               => $reused_count,
			'missing'              => $missing_count,
			'missing_ids'          => array_map( 'intval', $missing_ids ),
			'export_warnings'      => $preview_export_warnings,
			'acf_warnings'         => $preview_acf_warnings,
			'pattern_warnings'     => $preview_pattern_warnings,
			'taxonomy_warnings'    => $preview_taxonomy_warnings,
			'template'             => $bundle_template,
			'template_action'      => $template_action,
			'template_unresolved'  => $template_unresolved,
			'template_warnings'    => $preview_template_warnings,
			'warnings'             => $preview_warnings,
			'terms'                => $preview_terms,
			'terms_clear'          => $terms_clear,
			'thumbnail_action'     => $thumbnail_action,
			'thumbnail_unresolved' => $thumbnail_unresolved,
		);
		if ( ! empty( $args['prepare_review'] ) ) {
			$warning_source                      = $source_manifest;
			$warning_source['post']['post_type'] = $normalized_manifest['post']['post_type'];
			$preview['review_taxonomy_warnings'] = array();
			foreach ( PageFerry_Import_Selection::taxonomies( $source_manifest ) as $taxonomy => $rows ) {
				$taxonomy_source                                  = $warning_source;
				$taxonomy_source['post']['tax']                   = array_intersect_key( $warning_source['post']['tax'] ?? array(), array( $taxonomy => true ) );
				$taxonomy_source['tax_terms']                     = array_intersect_key( $warning_source['tax_terms'] ?? array(), array( $taxonomy => true ) );
				$preview['review_taxonomy_warnings'][ $taxonomy ] = self::preview_taxonomy_warnings( $taxonomy_source );
			}
			$preview['review_template_warnings'] = self::preview_template_warnings( $warning_source );
			$preview['review_model']             = PageFerry_Review_Model::build( $source_manifest, $preview, $verified_media );
			$counts                              = PageFerry_Review_Model::media_plan( $preview['review_model'], $selection );
			$preview['media_new']                = $counts['new'];
			$preview['reused']                   = $counts['reuse'];
			$preview['missing']                  = count( $counts['missing_ids'] );
			$preview['missing_ids']              = $counts['missing_ids'];
			$preview['warnings']                 = PageFerry_Review_Model::warnings( $preview['review_model'], $selection, $normalized_manifest );
			foreach ( $preview['review']['media'] as &$entry ) {
				$entry['status'] = $counts['actions'][ $entry['id'] ];
			}
			unset( $entry );
		}
		return $preview;
	}

	/**
	 * Checks choices and destination authority against a server-owned preparation.
	 *
	 * @param array $manifest Original manifest from the owner-bound session.
	 * @param array $model Prepared review model.
	 * @param array $args Bound destination and submitted choices.
	 * @return array|WP_Error
	 */
	public static function check_review( array $manifest, array $model, array $args ) {
		if ( ! PageFerry_Review_Model::valid( $manifest, $model ) ) {
			return new WP_Error( 'pageferry_review_stale', __( 'The prepared review is no longer current. Select the ZIP and prepare again.', 'pageferry' ), array( 'status' => 409 ) );
		}
		$type = $model['post_type'];
		if ( ! in_array( $type, PageFerry_Exporter::ferryable_post_types(), true ) ) {
			return new WP_Error( 'pageferry_unsupported_post_type', __( 'Choose an available content type, such as Page or Post.', 'pageferry' ), array( 'status' => 400 ) );
		}
		$selection = PageFerry_Import_Selection::normalize( $manifest, $args['selection'] ?? null, $type, $model );
		if ( is_wp_error( $selection ) ) {
			return $selection;
		}
		$effective                      = PageFerry_Import_Selection::apply( $manifest, $selection, $model['groups'] );
		$effective['post']['post_type'] = $type;
		$args['selection']              = $selection;
		$target                         = self::resolve_target_plan( $effective, $args );
		if ( is_wp_error( $target ) ) {
			$target->add_data( array( 'status' => 'pageferry_target_cap' === $target->get_error_code() ? 403 : 400 ) );
			return $target;
		}
		if ( $target['target_mode'] !== $model['target'] || $target['target_post_id'] !== $model['target_post_id'] || $target['target_fingerprint'] !== $model['target_fingerprint'] ) {
			return self::stale_target_error();
		}
		$media = array_intersect_key( $model['media'], array_flip( $selection['media'] ) );
		$error = self::check_media_upload_capability( $media ) ?? self::check_terms_assign_capability( $effective, 'update' === $target['target_mode'] );
		if ( is_wp_error( $error ) ) {
			$error->add_data( array( 'status' => 403 ) );
			return $error;
		}
		return array(
			'selection'          => $selection,
			'warnings'           => PageFerry_Review_Model::warnings( $model, $selection, $effective ),
			'title'              => 'update' === $target['target_mode'] && ! in_array( 'title', $selection['fields'], true ) ? $target['target_post']->post_title : (string) $effective['post']['title'],
			'slug'               => $target['final_slug'],
			'target_modified'    => $target['target_modified'],
			'target_fingerprint' => $target['target_fingerprint'],
		);
	}

	/**
	 * Resolves only exact basenames inside the workspace to prevent path escape.
	 *
	 * @param string $workspace_dir Absolute workspace dir.
	 * @param mixed  $file Manifest file value.
	 * @return string|null Absolute path on success, null when rejected/missing.
	 */
	public static function workspace_file( string $workspace_dir, $file ): ?string {
		if ( ! is_string( $file ) || '' === $file ) {
			return null;
		}

		$basename = basename( $file );

		if ( '' === $basename || '.' === $basename || '..' === $basename || $basename !== $file ) {
			return null;
		}

		$candidate = $workspace_dir . '/' . $basename;
		$real_base = realpath( $workspace_dir );

		if ( ! is_string( $real_base ) ) {
			return null;
		}

		$real_candidate = realpath( $candidate );

		if ( ! is_string( $real_candidate ) || ! is_readable( $real_candidate ) ) {
			return null;
		}

		if ( 0 !== strpos( $real_candidate, trailingslashit( $real_base ) ) ) {
			return null;
		}

		return $real_candidate;
	}

	/**
	 * Keeps ZIP collision names out of the media library; legacy names use best-effort prefix removal.
	 *
	 * @param array $media_entry Manifest media entry.
	 * @return string Original file basename.
	 */
	public static function original_filename( array $media_entry ): string {
		if ( isset( $media_entry['filename'] ) && is_string( $media_entry['filename'] ) ) {
			$declared_base = basename( $media_entry['filename'] );

			if ( '' !== $declared_base && '.' !== $declared_base && '..' !== $declared_base && '' !== trim( $declared_base ) ) {
				return $declared_base;
			}
		}

		$zip_basename = isset( $media_entry['file'] ) && is_string( $media_entry['file'] ) ? basename( $media_entry['file'] ) : '';
		$old_id       = isset( $media_entry['old_id'] ) && is_numeric( $media_entry['old_id'] ) ? (int) $media_entry['old_id'] : 0;
		$old_prefix   = 0 < $old_id ? $old_id . '-' : '';

		if ( '' !== $old_prefix && str_starts_with( $zip_basename, $old_prefix ) ) {
			$stripped = substr( $zip_basename, strlen( $old_prefix ) );

			if ( '' !== $stripped ) {
				return $stripped;
			}
		}

		return $zip_basename;
	}

	/**
	 * Refuses automatic extension corrections only when a new file is required.
	 *
	 * @param string $file Staged media file.
	 * @param string $basename Source filename.
	 * @return WP_Error|null Filename conflict or null.
	 */
	private static function new_media_conflict( string $file, string $basename ): ?WP_Error {
		$checked = wp_check_filetype_and_ext( $file, $basename );
		if ( ! empty( $checked['proper_filename'] ) && $checked['proper_filename'] !== $basename ) {
			return new WP_Error(
				'pageferry_media_filename',
				sprintf(
					/* translators: 1: source filename, 2: filename matching the actual file type. */
					__( 'The file %1$s needs the filename %2$s because of its file type. Upload it with that name on the source site, update the page to use it, and export again.', 'pageferry' ),
					$basename,
					$checked['proper_filename']
				)
			);
		}
		return null;
	}

	/**
	 * Reports processing that broke exact main-file preservation.
	 *
	 * @param string $basename Source filename.
	 * @return WP_Error Processing conflict.
	 */
	public static function media_processing_error( string $basename ): WP_Error {
		return new WP_Error(
			'pageferry_media_changed',
			sprintf(
				/* translators: %s: media filename changed by destination processing. */
				__( 'This site changed %s during upload, so the page was not saved. Ask an administrator to check image optimization or SVG upload settings. Review the file on the source site and export it again.', 'pageferry' ),
				$basename
			)
		);
	}

	/**
	 * Sideloads under the original basename so WordPress owns library filename collisions.
	 *
	 * @param string $media_file Absolute workspace file path (hash-verified).
	 * @param string $basename File name recorded in the media library.
	 * @return int|WP_Error New attachment ID, or WP_Error.
	 */
	private static function sideload_workspace_file( string $media_file, string $basename ) {
		if ( ! self::media_basename_allowed( $basename ) ) {
			return new WP_Error(
				'pageferry_unsupported_media_type',
				sprintf(
					/* translators: %s: media file name with a disallowed extension. */
					__( 'Media file %s has a file type this site does not allow. Ask an administrator to check the file type before importing.', 'pageferry' ),
					$basename
				)
			);
		}

		if ( ! self::staged_media_file_allowed( $media_file, $basename ) ) {
			return new WP_Error(
				'pageferry_unsupported_media_type',
				sprintf(
					/* translators: %s: media file name with a disallowed or mismatched type. */
					__( 'Media file %s has a file type this site does not allow. Ask an administrator to check the file type before importing.', 'pageferry' ),
					$basename
				)
			);
		}

		$file_type = wp_check_filetype( $basename );

		if ( ! is_string( $file_type['type'] ) || '' === $file_type['type'] ) {
			return new WP_Error(
				'pageferry_unsupported_media_type',
				sprintf(
					/* translators: %s: media file name with a disallowed extension. */
					__( 'Media file %s has a file type this site does not allow. Ask an administrator to check the file type before importing.', 'pageferry' ),
					$basename
				)
			);
		}

		$mime_type  = $file_type['type'];
		$temp_stage = wp_tempnam( $basename );

		if ( ! copy( $media_file, $temp_stage ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions -- staging an already-validated workspace file for sideloading.
			wp_delete_file( $temp_stage );

			return new WP_Error(
				'pageferry_media_sideload',
				sprintf(
					/* translators: %s: media file name inside the bundle. */
					__( 'PageFerry could not import media file %s.', 'pageferry' ),
					$basename
				)
			);
		}

		$copy_path = $temp_stage;

		$file_array = array(
			'name'     => $basename,
			'type'     => $mime_type,
			'tmp_name' => $copy_path,
			'error'    => '0',
			'size'     => (string) filesize( $media_file ),
		);

		$uploaded_file = '';
		$capture       = static function ( $move, array $file, string $destination ) use ( &$uploaded_file, $copy_path ) {
			if ( isset( $file['tmp_name'] ) && $copy_path === $file['tmp_name'] ) {
				$uploaded_file = $destination;
			}
			return $move;
		};
		$threshold     = static function ( $value, $size, $file ) use ( &$uploaded_file ) {
			return $file === $uploaded_file ? false : $value;
		};
		$orientation   = static function ( $value, $file ) use ( &$uploaded_file ) {
			return $file === $uploaded_file ? 1 : $value;
		};
		$format        = static function ( $formats, $file, $mime ) use ( &$uploaded_file ) {
			if ( $file === $uploaded_file ) {
				$formats          = is_array( $formats ) ? $formats : array();
				$formats[ $mime ] = $mime;
			}
			return $formats;
		};
		add_filter( 'pre_move_uploaded_file', $capture, PHP_INT_MAX, 3 );
		add_filter( 'big_image_size_threshold', $threshold, PHP_INT_MAX, 3 );
		add_filter( 'wp_image_maybe_exif_rotate', $orientation, PHP_INT_MAX, 2 );
		add_filter( 'image_editor_output_format', $format, PHP_INT_MAX, 3 );
		try {
			$sideloaded_id = media_handle_sideload( $file_array, 0 );
		} finally {
			remove_filter( 'pre_move_uploaded_file', $capture, PHP_INT_MAX );
			remove_filter( 'big_image_size_threshold', $threshold, PHP_INT_MAX );
			remove_filter( 'wp_image_maybe_exif_rotate', $orientation, PHP_INT_MAX );
			remove_filter( 'image_editor_output_format', $format, PHP_INT_MAX );
		}

		if ( is_wp_error( $sideloaded_id ) ) {
			if ( file_exists( $copy_path ) ) {
				wp_delete_file( $copy_path );
			}

			return new WP_Error(
				'pageferry_media_sideload',
				sprintf(
					/* translators: %s: sideload failure message. */
					__( 'PageFerry could not import media: %s', 'pageferry' ),
					$sideloaded_id->get_error_message()
				)
			);
		}

		return (int) $sideloaded_id;
	}

	/**
	 * Compensates only this import’s uploads before overwrite; reused attachments remain untouched.
	 *
	 * @param WP_Error    $error Error to return.
	 * @param array       $created_attachment_ids Attachments sideloaded so far.
	 * @param string|null $backup_reference Snapshot key or null.
	 * @return WP_Error Original failure, augmented when compensation is incomplete.
	 */
	private static function abort( WP_Error $error, array $created_attachment_ids, ?string $backup_reference ): WP_Error {
		$cleanup_errors = array();
		$remaining_ids  = array();
		foreach ( $created_attachment_ids as $attachment_id ) {
			$attachment_id = (int) $attachment_id;
			$local_files   = self::attachment_cleanup_files( $attachment_id );
			wp_delete_attachment( (int) $attachment_id, true );
			if ( get_post( $attachment_id ) instanceof WP_Post ) {
				$remaining_ids[]  = $attachment_id;
				$cleanup_errors[] = sprintf(
					/* translators: %d: retained attachment ID. */
					__( 'Media file %d could not be removed after the failed import. Check it in the Media Library and remove it if it is no longer needed.', 'pageferry' ),
					$attachment_id
				);
				continue;
			}
			foreach ( $local_files as $local_file ) {
				if ( file_exists( $local_file ) ) {
					$cleanup_errors[] = sprintf(
						/* translators: 1: deleted attachment ID, 2: remaining file basename. */
						__( 'Media item %1$d was removed from the Media Library, but its file remains (%2$s). Ask an administrator to remove the leftover file.', 'pageferry' ),
						$attachment_id,
						wp_basename( $local_file )
					);
				}
			}
		}

		if ( array() !== $created_attachment_ids ) {
			self::mutate_shared_option(
				self::HASH_INDEX_OPTION,
				static function ( array $hash_index ) use ( $created_attachment_ids ): array {
					foreach ( $hash_index as $hash => $indexed_id ) {
						if ( in_array( (int) $indexed_id, $created_attachment_ids, true ) ) {
							unset( $hash_index[ $hash ] );
						}
					}
					return $hash_index;
				}
			);
		}

		self::forget_backup( $backup_reference );

		if ( array() !== $cleanup_errors ) {
			$data                             = $error->get_error_data();
			$data                             = is_array( $data ) ? $data : array();
			$data['cleanup_errors']           = $cleanup_errors;
			$data['remaining_attachment_ids'] = $remaining_ids;
			return new WP_Error( $error->get_error_code(), $error->get_error_message() . ' ' . implode( ' ', $cleanup_errors ), $data );
		}

		return $error;
	}

	/**
	 * Lists existing local files WordPress should remove with an attachment.
	 *
	 * @param int $attachment_id Attachment this run created.
	 * @return array Local full/original/size/edited-backup paths present before cleanup.
	 */
	private static function attachment_cleanup_files( int $attachment_id ): array {
		$attached = get_attached_file( $attachment_id, true );
		if ( ! is_string( $attached ) || '' === $attached ) {
			return array();
		}
		$files = array( $attached );
		/**
		 * Filters and scaled images extend the stub's shape.
		 *
		 * @var array|false $metadata
		 */
		$metadata = wp_get_attachment_metadata( $attachment_id );
		$backups  = get_post_meta( $attachment_id, '_wp_attachment_backup_sizes', true );
		$sizes    = is_array( $metadata ) && isset( $metadata['sizes'] ) && is_array( $metadata['sizes'] ) ? $metadata['sizes'] : array();
		$sizes    = array_merge( $sizes, is_array( $backups ) ? $backups : array() );
		if ( is_array( $metadata ) && isset( $metadata['original_image'] ) ) {
			$sizes[] = array( 'file' => $metadata['original_image'] );
		}
		foreach ( $sizes as $size ) {
			if ( is_array( $size ) && isset( $size['file'] ) && is_string( $size['file'] ) && wp_basename( $size['file'] ) === $size['file'] ) {
				$files[] = dirname( $attached ) . '/' . $size['file'];
			}
		}
		return array_values( array_filter( array_unique( $files ), 'is_file' ) );
	}

	/**
	 * Remaps known slots and exact collector paths once; numeric strings keep their type.
	 *
	 * @param array      $attributes Block delimiter attributes.
	 * @param array      $id_map Map of old attachment ID => new attachment ID.
	 * @param array|null $allowed_paths Map of attribute path => old ID allowed there, or null when unrestricted.
	 * @param array      $known_slots Declared core media attribute names.
	 * @return array Remapped attributes.
	 */
	private static function remap_attributes( array $attributes, array $id_map, ?array $allowed_paths, array $known_slots ): array {
		$normalized = array();

		foreach ( $id_map as $map_old => $map_new ) {
			if ( ! is_numeric( $map_old ) || ! is_numeric( $map_new ) ) {
				continue;
			}

			$normalized[ (int) $map_old ] = (int) $map_new;
		}

		if ( array() === $normalized ) {
			return $attributes;
		}

		if ( null === $allowed_paths ) {
			$original = $attributes;
			$mapped   = self::remap_generic_value_with_map( $original, $normalized, 0 );
			$result   = is_array( $mapped ) ? $mapped : $original;

			foreach ( array( 'id', 'mediaId' ) as $single_key ) {
				if ( isset( $original[ $single_key ] ) && is_numeric( $original[ $single_key ] ) && isset( $normalized[ (int) $original[ $single_key ] ] ) ) {
					$new_value             = $normalized[ (int) $original[ $single_key ] ];
					$result[ $single_key ] = is_string( $original[ $single_key ] ) ? (string) $new_value : $new_value;
				}
			}

			if ( isset( $original['ids'] ) && is_array( $original['ids'] ) ) {
				if ( ! isset( $result['ids'] ) || ! is_array( $result['ids'] ) ) {
					$result['ids'] = $original['ids'];
				}

				foreach ( $original['ids'] as $position => $gallery_id ) {
					if ( is_numeric( $gallery_id ) && isset( $normalized[ (int) $gallery_id ] ) ) {
						$new_value                  = $normalized[ (int) $gallery_id ];
						$result['ids'][ $position ] = is_string( $gallery_id ) ? (string) $new_value : $new_value;
					}
				}
			}

			return $result;
		}

		$original = $attributes;

		foreach ( array_intersect( array( 'id', 'mediaId' ), $known_slots ) as $single_key ) {
			if ( isset( $attributes[ $single_key ] ) && is_numeric( $attributes[ $single_key ] ) && isset( $normalized[ (int) $attributes[ $single_key ] ] ) ) {
				$old_value                 = $attributes[ $single_key ];
				$new_value                 = $normalized[ (int) $old_value ];
				$attributes[ $single_key ] = is_string( $old_value ) ? (string) $new_value : $new_value;
			}
		}

		if ( in_array( 'ids', $known_slots, true ) && isset( $attributes['ids'] ) && is_array( $attributes['ids'] ) ) {
			foreach ( $attributes['ids'] as $position => $gallery_id ) {
				if ( is_numeric( $gallery_id ) && isset( $normalized[ (int) $gallery_id ] ) ) {
					$new_value                      = $normalized[ (int) $gallery_id ];
					$attributes['ids'][ $position ] = is_string( $gallery_id ) ? (string) $new_value : $new_value;
				}
			}
		}

		foreach ( $allowed_paths as $attr_path => $old_id ) {
			$old_id = (int) $old_id;

			if ( ! isset( $normalized[ $old_id ] ) ) {
				continue;
			}

			$original_at_path = self::value_at_path( $original, (string) $attr_path );
			$original_matches = $original_at_path['found'] && (
				( is_int( $original_at_path['value'] ) && $old_id === $original_at_path['value'] ) ||
				( is_string( $original_at_path['value'] ) && ctype_digit( $original_at_path['value'] ) && $old_id === (int) $original_at_path['value'] )
			);

			if ( ! $original_matches ) {
				continue;
			}

			$attributes = self::remap_value_at_path( $attributes, (string) $attr_path, $old_id, $normalized[ $old_id ] );
		}

		return $attributes;
	}

	/**
	 * Swaps one collected attachment ID at one attribute path.
	 *
	 * @param array  $attributes Block delimiter attributes.
	 * @param string $attr_path Dot-notation attribute path.
	 * @param int    $old_id Old attachment ID to replace.
	 * @param int    $new_id New attachment ID replacing it.
	 * @return array Remapped attributes.
	 */
	private static function remap_value_at_path( array $attributes, string $attr_path, int $old_id, int $new_id ): array {
		$segments = explode( '.', $attr_path );

		if ( '' === $attr_path ) {
			return $attributes;
		}

		$first = (string) array_shift( $segments );

		if ( '' === $first || ! array_key_exists( $first, $attributes ) ) {
			return $attributes;
		}

		if ( array() === $segments ) {
			$current = $attributes[ $first ];

			if ( is_int( $current ) && $old_id === $current ) {
				$attributes[ $first ] = $new_id;
			} elseif ( is_string( $current ) && ctype_digit( $current ) && $old_id === (int) $current ) {
				$attributes[ $first ] = (string) $new_id;
			}

			return $attributes;
		}

		$attributes[ $first ] = self::remap_nested_value( $attributes[ $first ], $segments, $old_id, $new_id, 0 );

		return $attributes;
	}

	/**
	 * Swaps one collected attachment ID inside a nested attribute value.
	 *
	 * @param mixed $value Attribute value (any JSON-decoded shape).
	 * @param array $segments Remaining dot-notation path segments.
	 * @param int   $old_id Old attachment ID to replace.
	 * @param int   $new_id New attachment ID replacing it.
	 * @param int   $depth Current recursion depth (guard).
	 * @return mixed Remapped value.
	 */
	private static function remap_nested_value( $value, array $segments, int $old_id, int $new_id, int $depth ) {
		if ( self::MAX_REMAP_DEPTH < $depth || array() === $segments ) {
			return $value;
		}

		$segment = array_shift( $segments );

		if ( ! is_string( $segment ) && ! is_int( $segment ) ) {
			return $value;
		}

		$segment = (string) $segment;

		if ( ! is_array( $value ) ) {
			return $value;
		}

		$key = ctype_digit( $segment ) && array_key_exists( (int) $segment, $value ) ? (int) $segment : $segment;

		if ( ! array_key_exists( $key, $value ) ) {
			return $value;
		}

		if ( array() === $segments ) {
			$current = $value[ $key ];

			if ( is_int( $current ) && $old_id === $current ) {
				$value[ $key ] = $new_id;
			} elseif ( is_string( $current ) && ctype_digit( $current ) && $old_id === (int) $current ) {
				$value[ $key ] = (string) $new_id;
			}

			return $value;
		}

		$value[ $key ] = self::remap_nested_value( $value[ $key ], $segments, $old_id, $new_id, $depth + 1 );

		return $value;
	}

	/**
	 * Maps each original value once so overlapping IDs cannot cascade.
	 *
	 * @param mixed $value Attribute value (any JSON-decoded shape).
	 * @param array $id_map Normalized map of old ID => new ID.
	 * @param int   $depth Current recursion depth (guard).
	 * @return mixed Remapped value.
	 */
	private static function remap_generic_value_with_map( $value, array $id_map, int $depth ) {
		if ( self::MAX_REMAP_DEPTH < $depth ) {
			return $value;
		}

		if ( is_array( $value ) ) {
			foreach ( $value as $key => $nested ) {
				$value[ $key ] = self::remap_generic_value_with_map( $nested, $id_map, $depth + 1 );
			}

			return $value;
		}

		if ( is_int( $value ) && isset( $id_map[ $value ] ) ) {
			return $id_map[ $value ];
		}

		if ( is_string( $value ) && ctype_digit( $value ) && isset( $id_map[ (int) $value ] ) ) {
			return (string) $id_map[ (int) $value ];
		}

		if ( is_string( $value ) && '' !== $value ) {
			$trimmed = ltrim( $value );

			if ( str_starts_with( $trimmed, '{' ) || str_starts_with( $trimmed, '[' ) ) {
				$decoded = json_decode( $value, true );

				if ( is_array( $decoded ) ) {
					$remapped = self::remap_generic_value_with_map( $decoded, $id_map, $depth + 1 );

					if ( $remapped !== $decoded ) {
						$encoded = wp_json_encode( $remapped );

						if ( is_string( $encoded ) ) {
							return $encoded;
						}
					}
				}
			}
		}

		return $value;
	}

	/**
	 * Reads pre-mutation values so known-slot updates cannot feed another remap.
	 *
	 * @param array  $attributes Block delimiter attributes.
	 * @param string $attr_path Dot-notation attribute path.
	 * @return array Array with 'found' bool and 'value' mixed.
	 */
	private static function value_at_path( array $attributes, string $attr_path ): array {
		if ( '' === $attr_path ) {
			return array(
				'found' => false,
				'value' => null,
			);
		}

		$segments = explode( '.', $attr_path );
		$current  = $attributes;

		foreach ( $segments as $segment ) {
			if ( ! is_array( $current ) ) {
				return array(
					'found' => false,
					'value' => null,
				);
			}

			$segment = (string) $segment;
			$key     = ctype_digit( $segment ) && array_key_exists( (int) $segment, $current ) ? (int) $segment : $segment;

			if ( ! array_key_exists( $key, $current ) ) {
				return array(
					'found' => false,
					'value' => null,
				);
			}

			$current = $current[ $key ];
		}

		return array(
			'found' => true,
			'value' => $current,
		);
	}

	/**
	 * Keeps exact attribute paths; HTML, meta and expanded-pattern refs authorize no delimiter slot.
	 *
	 * @param array $manifest Normalized manifest.
	 * @return array Map of block path => list of array(key, old_id).
	 */
	private static function build_block_ref_map( array $manifest ): array {
		$map                   = array();
		$has_reference_context = false;

		if ( ! isset( $manifest['media'] ) || ! is_array( $manifest['media'] ) ) {
			return $map;
		}

		$seen_slots = array();

		foreach ( $manifest['media'] as $media_entry ) {
			if ( ! is_array( $media_entry ) || ! isset( $media_entry['old_id'] ) || ! is_numeric( $media_entry['old_id'] ) ) {
				continue;
			}

			$old_id = (int) $media_entry['old_id'];

			if ( array_key_exists( 'block_refs', $media_entry ) ) {
				$has_reference_context = true;
			}
			if ( ! isset( $media_entry['block_refs'] ) || ! is_array( $media_entry['block_refs'] ) ) {
				continue;
			}

			foreach ( $media_entry['block_refs'] as $reference ) {
				if ( ! is_array( $reference ) || ! isset( $reference['path'], $reference['key'] ) || ! is_string( $reference['path'] ) || '' === $reference['path'] || ! is_string( $reference['key'] ) ) {
					continue;
				}

				$ref_path = $reference['path'];
				$slot     = $ref_path . "\0" . $reference['key'];

				if ( isset( $seen_slots[ $slot ] ) ) {
					continue;
				}

				$seen_slots[ $slot ] = true;

				if ( ! isset( $map[ $ref_path ] ) ) {
					$map[ $ref_path ] = array();
				}

				$map[ $ref_path ][] = array(
					'key'    => $reference['key'],
					'old_id' => $old_id,
				);
			}
		}

		// Explicit empty references still constrain modern exports; omission retains legacy behavior.
		return $has_reference_context && array() === $map ? array( '' => array() ) : $map;
	}

	/**
	 * Rewrites URL-shaped media references once; unverified derivatives fall back to the imported full.
	 *
	 * @param string $content Serialized post content with remapped IDs.
	 * @param array  $manifest Normalized manifest (old URLs).
	 * @param array  $id_map Map of old attachment ID => new attachment ID.
	 * @return string Content with media URLs rewritten.
	 */
	private static function rewrite_media_urls( string $content, array $manifest, array $id_map ): string {
		$entries = self::build_media_url_entries( $manifest, $id_map );

		if ( array() === $entries ) {
			return $content;
		}

		foreach ( self::url_slash_encodings( $content ) as $slash ) {
			$content = self::rewrite_media_urls_for_slash( $content, $entries, $slash );
		}

		return $content;
	}

	/**
	 * Recognizes the source's slash escaping without normalizing surrounding JSON.
	 *
	 * @param string $content Source text.
	 * @return array Distinct slash encodings.
	 */
	private static function url_slash_encodings( string $content ): array {
		preg_match_all( '#(?:\\\\u005[cC]|\\\\)+/#', $content, $matches );
		return array_merge( array( '/' ), array_values( array_unique( $matches[0] ) ) );
	}

	/**
	 * Builds all URL mappings first so replacements cannot cascade.
	 *
	 * @param array $manifest Normalized manifest (old URLs).
	 * @param array $id_map Map of old attachment ID => new attachment ID.
	 * @return array List of {old, new, new_id} parsed URL records.
	 */
	private static function build_media_url_entries( array $manifest, array $id_map ): array {
		if ( ! isset( $manifest['media'] ) || ! is_array( $manifest['media'] ) ) {
			return array();
		}

		$entries = array();

		foreach ( $manifest['media'] as $media_entry ) {
			if ( ! is_array( $media_entry ) || ! isset( $media_entry['old_id'] ) || ! is_numeric( $media_entry['old_id'] ) ) {
				continue;
			}

			$media_old_id = (int) $media_entry['old_id'];

			if ( ! isset( $id_map[ $media_old_id ] ) ) {
				continue;
			}

			if ( ! isset( $media_entry['url'] ) || ! is_string( $media_entry['url'] ) || '' === $media_entry['url'] ) {
				continue;
			}

			$new_url = wp_get_attachment_url( (int) $id_map[ $media_old_id ] );

			if ( ! is_string( $new_url ) || '' === $new_url ) {
				continue;
			}

			$old_parsed = self::parse_media_rewrite_url( $media_entry['url'] );
			$new_parsed = self::parse_media_rewrite_url( $new_url );

			if ( null === $old_parsed || null === $new_parsed ) {
				continue;
			}

			if ( $old_parsed['host_lower'] === $new_parsed['host_lower'] && $old_parsed['norm_port'] === $new_parsed['norm_port'] && $old_parsed['path'] === $new_parsed['path'] ) {
				continue;
			}

			$entries[] = array(
				'old'    => $old_parsed,
				'new'    => $new_parsed,
				'new_id' => (int) $id_map[ $media_old_id ],
			);
		}

		return $entries;
	}

	/**
	 * Finds the shared family of scaled originals and subsizes without absorbing sibling filenames.
	 *
	 * @param string $stem Filename stem without dot extension.
	 * @return string Family base with all recognized size suffixes removed.
	 */
	private static function family_stem( string $stem ): string {
		$family = $stem;

		for ( $depth = 0; $depth < 5; ++$depth ) {
			if ( 1 !== preg_match( '/(-(?:\d+x\d+|scaled|rotated|edited))$/', $family, $family_matches ) ) {
				break;
			}

			$family_suffix = (string) $family_matches[1];

			if ( strlen( $family_suffix ) >= strlen( $family ) ) {
				break;
			}

			$family_candidate = (string) substr( $family, 0, -strlen( $family_suffix ) );

			if ( '' === $family_candidate ) {
				break;
			}

			$family = $family_candidate;
		}

		return $family;
	}

	/**
	 * Separates URL suffixes before parsing file parts; only hosted URLs qualify.
	 *
	 * @param string $url Attachment URL.
	 * @return array|null Parsed parts, or null when not a comparable file URL.
	 */
	private static function parse_media_rewrite_url( string $url ): ?array {
		$fragment      = '';
		$hash_position = strpos( $url, '#' );

		if ( false !== $hash_position ) {
			$fragment = (string) substr( $url, (int) $hash_position );
			$url      = (string) substr( $url, 0, (int) $hash_position );
		}

		$query          = '';
		$query_position = strpos( $url, '?' );

		if ( false !== $query_position ) {
			$query = (string) substr( $url, (int) $query_position );
			$url   = (string) substr( $url, 0, (int) $query_position );
		}

		$parts = wp_parse_url( $url );

		if ( ! is_array( $parts ) ) {
			return null;
		}

		$host = isset( $parts['host'] ) ? (string) $parts['host'] : '';

		if ( '' === $host ) {
			return null;
		}

		$path = isset( $parts['path'] ) ? (string) $parts['path'] : '';

		if ( '' === $path ) {
			return null;
		}

		$scheme = isset( $parts['scheme'] ) ? strtolower( (string) $parts['scheme'] ) : '';
		$port   = isset( $parts['port'] ) ? (int) $parts['port'] : null;

		if ( null !== $port && self::default_port_for_scheme( $scheme ) === $port ) {
			$norm_port = null;
		} elseif ( '' === $scheme && ( 80 === $port || 443 === $port ) ) {
			// Protocol-relative default ports are equivalent; custom ports must still distinguish hosts.
			$norm_port = null;
		} else {
			$norm_port = $port;
		}

		$user = isset( $parts['user'] ) ? (string) $parts['user'] : '';
		$pass = isset( $parts['pass'] ) ? (string) $parts['pass'] : '';

		$slash_position = strrpos( $path, '/' );

		if ( false === $slash_position ) {
			$path_dir = '';
			$filename = $path;
		} else {
			$path_dir = (string) substr( $path, 0, (int) $slash_position );
			$filename = (string) substr( $path, (int) $slash_position + 1 );
		}

		if ( '' === $filename ) {
			return null;
		}

		$dot_position = strrpos( $filename, '.' );

		if ( false === $dot_position ) {
			$stem = $filename;
			$ext  = '';
		} else {
			$stem = (string) substr( $filename, 0, (int) $dot_position );
			$ext  = (string) substr( $filename, (int) $dot_position );
		}

		$suffix   = '';
		$stripped = $stem;

		if ( '' !== $stem && 1 === preg_match( '/(-(?:\d+x\d+|scaled|rotated|edited))$/', $stem, $suffix_matches ) ) {
			$candidate_suffix   = (string) $suffix_matches[1];
			$candidate_stripped = (string) substr( $stem, 0, -strlen( $candidate_suffix ) );

			if ( '' !== $candidate_stripped ) {
				$suffix   = $candidate_suffix;
				$stripped = $candidate_stripped;
			}
		}

		return array(
			'scheme'     => $scheme,
			'host'       => $host,
			'host_lower' => strtolower( $host ),
			'port'       => $port,
			'norm_port'  => $norm_port,
			'user'       => $user,
			'pass'       => $pass,
			'path'       => $path,
			'path_dir'   => $path_dir,
			'filename'   => $filename,
			'stem'       => $stem,
			'ext'        => $ext,
			'stripped'   => $stripped,
			'suffix'     => $suffix,
			'family'     => self::family_stem( $stem ),
			'query'      => $query,
			'fragment'   => $fragment,
		);
	}

	/**
	 * Encoded HTML delimiters terminate URL matches so neighboring markup remains unchanged.
	 *
	 * @param string $slash Slash encoding for this pass.
	 * @return string Regular expression.
	 */
	private static function url_token_pattern( string $slash ): string {
		$quoted = preg_quote( $slash, '#' );
		return '#(?:(?<=\\\\u[0-9a-fA-F]{4})|(?<![A-Za-z0-9]))(?:(?P<scheme>https?):)?' . $quoted . $quoted . '(?:' . $quoted . '|(?!\\\\u[0-9a-fA-F]{4})[^\s\x22\x27\x3c\x3e\x60])+#i';
	}

	/**
	 * Separates trailing prose and JSON-escape backslashes from a URL token.
	 *
	 * @param string $token Matched token.
	 * @return array URL and untouched trailing bytes.
	 */
	private static function split_url_token( string $token ): array {
		$trailing = '';
		while ( '' !== $token ) {
			$last = substr( $token, -1 );
			if ( ! str_contains( '\\.,;:!?)]}', $last ) ) {
				break;
			}
			$trailing = $last . $trailing;
			$token    = (string) substr( $token, 0, -1 );
		}
		return array( $token, $trailing );
	}

	/**
	 * Maps each original URL once; exact files beat verified derivatives and slash encoding is
	 * preserved.
	 *
	 * @param string $content Page content or excerpt.
	 * @param array  $entries Mappings from build_media_url_entries().
	 * @param string $slash Slash encoding used by this pass.
	 * @return string Content with this encoding rewritten.
	 */
	private static function rewrite_media_urls_for_slash( string $content, array $entries, string $slash ): string {
		$pattern = self::url_token_pattern( $slash );

		$rewritten = preg_replace_callback(
			$pattern,
			function ( array $matches ) use ( $entries, $slash ): string {
				$full = $matches[0];

				list( $url_part, $trailing ) = self::split_url_token( $full );

				if ( '' === $url_part ) {
					return $full;
				}

				$plain = str_replace( $slash, '/', $url_part );
				$token = self::parse_media_rewrite_url( $plain );

				if ( null === $token ) {
					return $full;
				}

				// Exact filenames must beat derivative rules regardless of manifest order.
				foreach ( $entries as $entry ) {
					if ( ! is_array( $entry ) || ! isset( $entry['old'], $entry['new'] ) || ! is_array( $entry['old'] ) || ! is_array( $entry['new'] ) ) {
						continue;
					}

					$old = $entry['old'];

					if ( $token['host_lower'] !== $old['host_lower'] || $token['norm_port'] !== $old['norm_port'] ) {
						continue;
					}

					if ( $token['path'] !== $old['path'] ) {
						continue;
					}

					return self::build_media_replacement( $token, $entry['new'], true, $trailing, $slash );
				}

				foreach ( $entries as $entry ) {
					if ( ! is_array( $entry ) || ! isset( $entry['old'], $entry['new'] ) || ! is_array( $entry['old'] ) || ! is_array( $entry['new'] ) ) {
						continue;
					}

					$old = $entry['old'];

					if ( $token['host_lower'] !== $old['host_lower'] || $token['norm_port'] !== $old['norm_port'] ) {
						continue;
					}

					if ( '' === $token['suffix'] ) {
						continue;
					}

					if ( $token['path_dir'] !== $old['path_dir'] || $token['ext'] !== $old['ext'] || $token['stripped'] !== $old['stem'] ) {
						continue;
					}

					// Unverified derivative suffixes would invent broken destination URLs.
					$verified_basename = self::destination_verified_derivative( $entry, $token );

					if ( null !== $verified_basename ) {
						return self::build_media_replacement( $token, $entry['new'], false, $trailing, $slash, $verified_basename );
					}

					return self::build_media_replacement( $token, $entry['new'], true, $trailing, $slash );
				}

				// Scaled fulls and original-based subsizes share a family; direct matches retain priority.
				foreach ( $entries as $entry ) {
					if ( ! is_array( $entry ) || ! isset( $entry['old'], $entry['new'] ) || ! is_array( $entry['old'] ) || ! is_array( $entry['new'] ) ) {
						continue;
					}

					$old = $entry['old'];

					if ( $token['host_lower'] !== $old['host_lower'] || $token['norm_port'] !== $old['norm_port'] ) {
						continue;
					}

					if ( '' === $token['suffix'] ) {
						continue;
					}

					$token_family = isset( $token['family'] ) && is_string( $token['family'] ) ? $token['family'] : self::family_stem( (string) $token['stem'] );
					$old_family   = isset( $old['family'] ) && is_string( $old['family'] ) ? $old['family'] : self::family_stem( (string) $old['stem'] );

					if ( '' === $token_family ) {
						continue;
					}

					if ( $token['path_dir'] !== $old['path_dir'] || $token['ext'] !== $old['ext'] || $token_family !== $old_family ) {
						continue;
					}

					$verified_basename = self::destination_verified_derivative( $entry, $token );

					if ( null !== $verified_basename ) {
						return self::build_media_replacement( $token, $entry['new'], false, $trailing, $slash, $verified_basename );
					}

					return self::build_media_replacement( $token, $entry['new'], true, $trailing, $slash );
				}

				return $full;
			},
			$content
		);

		return is_string( $rewritten ) ? $rewritten : $content;
	}

	/**
	 * Keeps verified destination filenames, query/fragment suffixes and the original slash encoding.
	 *
	 * @param array       $token Parsed token from parse_media_rewrite_url().
	 * @param array       $new_file Parsed new file from parse_media_rewrite_url().
	 * @param bool        $is_exact True for exact files (or verified-missing fallback), false for verified derivatives.
	 * @param string      $trailing Trailing JSON/punctuation bytes to preserve.
	 * @param string      $slash Slash token of the current pass.
	 * @param string|null $verified_basename Verified destination basename for kept derivatives, null for fallback.
	 * @return string Replacement URL in the pass encoding.
	 */
	private static function build_media_replacement( array $token, array $new_file, bool $is_exact, string $trailing, string $slash, ?string $verified_basename = null ): string {
		$new_host = (string) $new_file['host'];
		$new_port = '';

		if ( null !== $new_file['port'] && self::default_port_for_scheme( (string) $new_file['scheme'] ) !== $new_file['port'] ) {
			$new_port = ':' . (int) $new_file['port'];
		}

		$userinfo = '';

		if ( '' !== (string) $token['user'] ) {
			$userinfo = (string) $token['user'];

			if ( '' !== (string) $token['pass'] ) {
				$userinfo .= ':' . (string) $token['pass'];
			}

			$userinfo .= '@';
		}

		$new_path_dir = (string) $new_file['path_dir'];

		if ( $is_exact ) {
			$new_filename = (string) $new_file['filename'];
		} elseif ( is_string( $verified_basename ) && '' !== $verified_basename && ! str_contains( $verified_basename, '/' ) && ! str_contains( $verified_basename, '\\' ) && ! str_contains( $verified_basename, "\0" ) ) {
			$new_filename = $verified_basename;
		} else {
			$new_filename = (string) $new_file['stem'] . (string) $token['suffix'] . (string) $new_file['ext'];
		}

		$new_path = '' !== $new_path_dir ? $new_path_dir . '/' . $new_filename : '/' . $new_filename;

		if ( '' === (string) $token['scheme'] ) {
			$new_plain = '//' . $userinfo . $new_host . $new_port . $new_path . (string) $token['query'] . (string) $token['fragment'];
		} else {
			$new_scheme = (string) $new_file['scheme'];

			if ( '' === $new_scheme ) {
				$new_scheme = strtolower( (string) $token['scheme'] );
			}

			$new_plain = $new_scheme . '://' . $userinfo . $new_host . $new_port . $new_path . (string) $token['query'] . (string) $token['fragment'];
		}

		return str_replace( '/', $slash, $new_plain ) . $trailing;
	}

	/**
	 * Requires a local derivative when the full is local; offloaded fulls may trust listed metadata.
	 *
	 * @param array $entry URL entry from build_media_url_entries() with new_id.
	 * @param array $token Parsed token from parse_media_rewrite_url().
	 * @return string|null Verified destination basename, or null to fall back to the full image.
	 */
	private static function destination_verified_derivative( array $entry, array $token ): ?string {
		$new_id = isset( $entry['new_id'] ) ? (int) $entry['new_id'] : 0;

		if ( 0 >= $new_id ) {
			return null;
		}

		if ( ! isset( $entry['new'] ) || ! is_array( $entry['new'] ) ) {
			return null;
		}

		$suffix = isset( $token['suffix'] ) && is_string( $token['suffix'] ) ? $token['suffix'] : '';

		if ( '' === $suffix ) {
			return null;
		}

		$new_file = $entry['new'];

		if ( ! isset( $new_file['stem'], $new_file['ext'] ) || ! is_string( $new_file['stem'] ) || ! is_string( $new_file['ext'] ) ) {
			return null;
		}

		$new_stem = (string) $new_file['stem'];
		$new_ext  = (string) $new_file['ext'];

		if ( '' === $new_stem ) {
			return null;
		}

		$new_family = isset( $new_file['family'] ) && is_string( $new_file['family'] ) && '' !== $new_file['family']
			? (string) $new_file['family']
			: self::family_stem( $new_stem );

		if ( '' === $new_family ) {
			$new_family = $new_stem;
		}

		$candidates = array( $new_stem . $suffix . $new_ext );

		$family_candidate = $new_family . $suffix . $new_ext;

		if ( $family_candidate !== $candidates[0] ) {
			$candidates[] = $family_candidate;
		}

		$available     = self::destination_attachment_filenames( $new_id );
		$attached_file = get_attached_file( $new_id );
		$attached_path = is_string( $attached_file ) && '' !== $attached_file ? $attached_file : '';
		$attached_dir  = '' !== $attached_path ? dirname( $attached_path ) : '';

		$local_authoritative = '' !== $attached_path && file_exists( $attached_path ); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.file_ops_file_exists -- the full-file gate for derivative verification.

		foreach ( $candidates as $candidate ) {
			if ( str_contains( $candidate, '/' ) ) {
				continue;
			}

			$listed = isset( $available[ $candidate ] );

			if ( '' !== $attached_dir ) {
				$candidate_path   = $attached_dir . '/' . $candidate;
				$candidate_exists = file_exists( $candidate_path ); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.file_ops_file_exists -- checking our own uploads file before rewriting a URL to it.

				if ( $candidate_exists ) {
					return $candidate;
				}

				if ( $listed && ! $local_authoritative ) {
					return $candidate;
				}

				continue;
			}

			if ( $listed ) {
				return $candidate;
			}
		}

		return null;
	}

	/**
	 * Memoizes owned media basenames, including filtered CDN URLs.
	 *
	 * @param int $attachment_id Imported attachment ID.
	 * @return array<string, bool> Set of basenames owned by the attachment.
	 */
	private static function destination_attachment_filenames( int $attachment_id ): array {
		static $filename_cache = array();

		if ( isset( $filename_cache[ $attachment_id ] ) ) {
			return $filename_cache[ $attachment_id ];
		}

		$files = array();

		$attached_file = get_attached_file( $attachment_id );

		if ( is_string( $attached_file ) && '' !== $attached_file ) {
			$files[ basename( $attached_file ) ] = true;
		}

		$metadata = wp_get_attachment_metadata( $attachment_id );

		if ( is_array( $metadata ) ) {
			// Real media metadata lacks image keys that the stubs assume are present.
			$metadata_file = array_key_exists( 'file', $metadata ) ? $metadata['file'] : ''; // @phpstan-ignore function.alreadyNarrowedType

			if ( '' !== $metadata_file ) {
				$files[ basename( (string) $metadata_file ) ] = true;
			}

			$metadata_sizes = array_key_exists( 'sizes', $metadata ) ? $metadata['sizes'] : array(); // @phpstan-ignore function.alreadyNarrowedType

			foreach ( (array) $metadata_sizes as $size ) {
				$size_file = is_array( $size ) && array_key_exists( 'file', $size ) ? $size['file'] : '';

				if ( ! is_string( $size_file ) || '' === $size_file ) {
					continue;
				}

				$files[ basename( $size_file ) ] = true;
			}

			foreach ( array_diff_key( $metadata, array_flip( array( 'width', 'height', 'file', 'sizes', 'image_meta', 'filesize' ) ) ) as $extra_value ) {
				if ( ! is_string( $extra_value ) || '' === $extra_value ) {
					continue;
				}

				$files[ basename( $extra_value ) ] = true;
			}
		}

		$attachment_url = wp_get_attachment_url( $attachment_id );

		if ( is_string( $attachment_url ) && '' !== $attachment_url ) {
			$url_path = wp_parse_url( $attachment_url, PHP_URL_PATH );

			if ( is_string( $url_path ) && '' !== $url_path ) {
				$files[ basename( $url_path ) ] = true;
			}
		}

		$filename_cache[ $attachment_id ] = $files;

		return $files;
	}

	/**
	 * Rewrites only wp-image class tokens once so saved markup agrees with delimiter IDs.
	 *
	 * @param string $content Serialized post content with remapped IDs.
	 * @param array  $id_map Map of old attachment ID => new attachment ID.
	 * @return string Content with wp-image classes remapped.
	 */
	private static function rewrite_wp_image_classes( string $content, array $id_map ): string {
		$normalized = array();

		foreach ( $id_map as $map_old => $map_new ) {
			if ( ! is_numeric( $map_old ) || ! is_numeric( $map_new ) ) {
				continue;
			}

			$normalized[ (int) $map_old ] = (int) $map_new;
		}

		if ( array() === $normalized ) {
			return $content;
		}

		if ( ! str_contains( $content, 'wp-image-' ) ) {
			return $content;
		}

		if ( ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
			return $content;
		}

		$processor = new WP_HTML_Tag_Processor( $content );
		$changed   = false;

		while ( $processor->next_tag() ) {
			$class_value = $processor->get_attribute( 'class' );

			if ( ! is_string( $class_value ) || '' === $class_value || ! str_contains( $class_value, 'wp-image-' ) ) {
				continue;
			}

			$rewritten_class = preg_replace_callback(
				'/\bwp-image-(\d+)\b/',
				static function ( array $matches ) use ( $normalized ): string {
					$old_id = (int) $matches[1];

					if ( ! isset( $normalized[ $old_id ] ) ) {
						return $matches[0];
					}

					return 'wp-image-' . $normalized[ $old_id ];
				},
				$class_value
			);

			if ( is_string( $rewritten_class ) && $rewritten_class !== $class_value ) {
				$processor->set_attribute( 'class', $rewritten_class );
				$changed = true;
			}
		}

		if ( ! $changed ) {
			return $content;
		}

		return $processor->get_updated_html();
	}

	/**
	 * Uses home_url() because site_url() may address a core subdirectory rather than the public site.
	 *
	 * @param string $content Content or excerpt.
	 * @param array  $manifest Normalized manifest.
	 * @return string Content with genuine source-site links rewritten.
	 */
	private static function rewrite_source_host( string $content, array $manifest ): string {
		$source_url = isset( $manifest['source']['url'] ) ? (string) $manifest['source']['url'] : '';

		if ( '' === $source_url ) {
			return $content;
		}

		$source_base = self::parse_home_base( $source_url );
		$dest_base   = self::parse_home_base( home_url() );

		if ( null === $source_base || null === $dest_base ) {
			return $content;
		}

		if ( '' === $dest_base['scheme'] ) {
			return $content;
		}

		if ( self::home_bases_equal( $source_base, $dest_base ) ) {
			return $content;
		}

		foreach ( self::url_slash_encodings( $content ) as $slash ) {
			$content = self::rewrite_source_host_for_slash( $content, $source_base, $dest_base, $slash );
		}

		return $content;
	}

	/**
	 * Normalizes the home base path for boundary-aware URL comparisons.
	 *
	 * @param string $url Home URL.
	 * @return array|null Base with scheme/host/host_lower/port/path, or null when hostless.
	 */
	private static function parse_home_base( string $url ): ?array {
		$parts = wp_parse_url( $url );

		if ( ! is_array( $parts ) ) {
			return null;
		}

		$host = isset( $parts['host'] ) ? (string) $parts['host'] : '';

		if ( '' === $host ) {
			return null;
		}

		$scheme   = isset( $parts['scheme'] ) ? strtolower( (string) $parts['scheme'] ) : '';
		$port     = isset( $parts['port'] ) ? (int) $parts['port'] : null;
		$raw_path = isset( $parts['path'] ) ? (string) $parts['path'] : '';
		$path     = rtrim( $raw_path, '/' );

		if ( '' !== $path && ! str_starts_with( $path, '/' ) ) {
			$path = '/' . $path;
		}

		return array(
			'scheme'     => $scheme,
			'host'       => $host,
			'host_lower' => strtolower( $host ),
			'port'       => $port,
			'path'       => $path,
		);
	}

	/**
	 * Returns the default port for a URL scheme.
	 *
	 * @param string $scheme Lowercase scheme without colon.
	 * @return int|null 80/443 for http/https, null otherwise.
	 */
	private static function default_port_for_scheme( string $scheme ): ?int {
		if ( 'http' === $scheme ) {
			return 80;
		}

		if ( 'https' === $scheme ) {
			return 443;
		}

		return null;
	}

	/**
	 * Compares hosts case-insensitively, ports effectively and paths byte-for-byte.
	 *
	 * @param array $a Source base from parse_home_base().
	 * @param array $b Destination base from parse_home_base().
	 * @return bool True when both bases address the same origin and path.
	 */
	private static function home_bases_equal( array $a, array $b ): bool {
		if ( $a['scheme'] !== $b['scheme'] ) {
			return false;
		}

		if ( $a['host_lower'] !== $b['host_lower'] ) {
			return false;
		}

		$a_effective = null !== $a['port'] ? $a['port'] : self::default_port_for_scheme( $a['scheme'] );
		$b_effective = null !== $b['port'] ? $b['port'] : self::default_port_for_scheme( $b['scheme'] );

		if ( $a_effective !== $b_effective ) {
			return false;
		}

		return $a['path'] === $b['path'];
	}

	/**
	 * Requires complete authority and path boundaries while preserving encoded HTML delimiters.
	 *
	 * @param string $content Page content or excerpt.
	 * @param array  $source Source base from parse_home_base().
	 * @param array  $dest Destination base from parse_home_base().
	 * @param string $slash Slash encoding used by this pass.
	 * @return string Content with this encoding rewritten.
	 */
	private static function rewrite_source_host_for_slash( string $content, array $source, array $dest, string $slash ): string {
		$pattern = self::url_token_pattern( $slash );

		$rewritten = preg_replace_callback(
			$pattern,
			function ( array $matches ) use ( $source, $dest, $slash ): string {
				$full = $matches[0];

				list( $url_part, $trailing ) = self::split_url_token( $full );

				if ( '' === $url_part ) {
					return $full;
				}

				$plain = str_replace( $slash, '/', $url_part );
				$parts = wp_parse_url( $plain );

				if ( ! is_array( $parts ) ) {
					return $full;
				}

				$url_host = isset( $parts['host'] ) ? (string) $parts['host'] : '';

				if ( '' === $url_host || strtolower( $url_host ) !== $source['host_lower'] ) {
					return $full;
				}

				$url_scheme          = isset( $parts['scheme'] ) ? strtolower( (string) $parts['scheme'] ) : '';
				$url_explicit_port   = isset( $parts['port'] ) ? (int) $parts['port'] : null;
				$url_scheme_fallback = '' !== $url_scheme ? $url_scheme : $source['scheme'];
				$url_has_custom_port = null !== $url_explicit_port && self::default_port_for_scheme( $url_scheme_fallback ) !== $url_explicit_port;
				$src_has_custom_port = null !== $source['port'] && self::default_port_for_scheme( $source['scheme'] ) !== $source['port'];

				if ( ! $url_has_custom_port && ! $src_has_custom_port ) {
					$ports_match = true;
				} else {
					$url_effective = null !== $url_explicit_port ? $url_explicit_port : self::default_port_for_scheme( $url_scheme_fallback );
					$src_effective = null !== $source['port'] ? $source['port'] : self::default_port_for_scheme( $source['scheme'] );
					$ports_match   = $url_effective === $src_effective;
				}

				if ( ! $ports_match ) {
					return $full;
				}

				$url_path = isset( $parts['path'] ) ? (string) $parts['path'] : '';
				$src_base = (string) $source['path'];

				if ( '' !== $src_base && $url_path !== $src_base && ! str_starts_with( $url_path, $src_base . '/' ) ) {
					return $full;
				}

				$is_relative = '' === $url_scheme;
				$userinfo    = '';

				if ( isset( $parts['user'] ) && '' !== (string) $parts['user'] ) {
					$userinfo = (string) $parts['user'];

					if ( isset( $parts['pass'] ) && '' !== (string) $parts['pass'] ) {
						$userinfo .= ':' . (string) $parts['pass'];
					}

					$userinfo .= '@';
				}

				$dest_host = (string) $dest['host'];
				$dest_port = '';

				if ( null !== $dest['port'] && self::default_port_for_scheme( $dest['scheme'] ) !== $dest['port'] ) {
					$dest_port = ':' . (int) $dest['port'];
				}

				$new_path = $url_path;
				$query    = isset( $parts['query'] ) ? '?' . (string) $parts['query'] : '';
				$fragment = isset( $parts['fragment'] ) ? '#' . (string) $parts['fragment'] : '';

				if ( $is_relative ) {
					$new_plain = '//' . $userinfo . $dest_host . $dest_port . $new_path . $query . $fragment;
				} else {
					$new_plain = (string) $dest['scheme'] . '://' . $userinfo . $dest_host . $dest_port . $new_path . $query . $fragment;
				}

				return str_replace( '/', $slash, $new_plain ) . $trailing;
			},
			$content
		);

		return is_string( $rewritten ) ? $rewritten : $content;
	}

	/**
	 * Absent terms preserve, empty updates clear, and unresolved nonempty requests preserve with errors.
	 *
	 * @param int   $post_id Post ID just created or updated.
	 * @param array $manifest Normalized manifest.
	 * @param bool  $is_update True when overwriting an existing target.
	 * @param array $actions Reviewed append/replace actions; absence preserves legacy replacement.
	 * @return array List of human-readable term failure notes (empty on success).
	 */
	private static function assign_terms( int $post_id, array $manifest, bool $is_update = false, array $actions = array() ): array {
		$detailed = isset( $manifest['tax_terms'] ) && is_array( $manifest['tax_terms'] ) ? $manifest['tax_terms'] : array();
		$flat     = isset( $manifest['post']['tax'] ) && is_array( $manifest['post']['tax'] ) ? $manifest['post']['tax'] : array();

		$recorded = array_unique( array_merge( array_keys( $detailed ), array_keys( $flat ) ) );
		$errors   = array();

		$destination_post       = get_post( $post_id );
		$destination_type       = $destination_post instanceof WP_Post && '' !== $destination_post->post_type
			? $destination_post->post_type
			: ( isset( $manifest['post']['post_type'] ) && is_string( $manifest['post']['post_type'] ) ? $manifest['post']['post_type'] : '' );
		$destination_taxonomies = '' !== $destination_type ? get_object_taxonomies( $destination_type, 'names' ) : array();

		foreach ( $recorded as $taxonomy ) {
			$append = isset( $actions[ $taxonomy ] ) && 'append' === $actions[ $taxonomy ];
			if ( ! is_string( $taxonomy ) || '' === $taxonomy ) {
				continue;
			}

			if ( ! taxonomy_exists( $taxonomy ) ) {
				if ( self::taxonomy_has_nonempty_request( $taxonomy, $manifest ) ) {
					$requested_names = self::requested_taxonomy_term_names( $taxonomy, $manifest );
					$term_list       = array() !== $requested_names ? implode( ', ', $requested_names ) : __( '(unnamed categories or tags)', 'pageferry' );

					$errors[] = sprintf(
						/* translators: 1: taxonomy slug, 2: comma-separated requested term names. */
						__( 'The “%1$s” category or tag group is unavailable on this site. These items were skipped: %2$s. Activate the plugin or theme that provides the group, then import again.', 'pageferry' ),
						$taxonomy,
						$term_list
					);
				}

				continue;
			}

			// v1 core taxonomies stay assignable; empty updates must still clear stray relationships.
			if ( '' !== $destination_type && 'category' !== $taxonomy && 'post_tag' !== $taxonomy && ! in_array( $taxonomy, $destination_taxonomies, true ) && self::taxonomy_has_nonempty_request( $taxonomy, $manifest ) ) {
				$requested_names = self::requested_taxonomy_term_names( $taxonomy, $manifest );
				$term_list       = array() !== $requested_names ? implode( ', ', $requested_names ) : __( '(unnamed categories or tags)', 'pageferry' );

				$errors[] = sprintf(
					/* translators: 1: taxonomy slug, 2: destination post type, 3: comma-separated requested term names. */
					__( 'The “%1$s” category or tag group is unavailable for content type “%2$s”. These items were skipped: %3$s.', 'pageferry' ),
					$taxonomy,
					$destination_type,
					$term_list
				);

				continue;
			}

			$has_detailed_key = array_key_exists( $taxonomy, $detailed ) && is_array( $detailed[ $taxonomy ] );
			$has_flat_key     = array_key_exists( $taxonomy, $flat ) && is_array( $flat[ $taxonomy ] );

			if ( ! $has_detailed_key && ! $has_flat_key ) {
				continue;
			}

			$detailed_terms = $has_detailed_key ? $detailed[ $taxonomy ] : array();

			$has_assigned_detail = false;

			foreach ( $detailed_terms as $detailed_entry ) {
				if ( ! is_array( $detailed_entry ) ) {
					continue;
				}

				if ( ! array_key_exists( 'assigned', $detailed_entry ) || ! empty( $detailed_entry['assigned'] ) ) {
					$has_assigned_detail = true;
					break;
				}
			}

			if ( $has_assigned_detail ) {
				foreach ( self::assign_detailed_terms( $post_id, $taxonomy, $detailed_terms, $append ) as $detail_error ) {
					$errors[] = $detail_error;
				}
				continue;
			}

			$flat_names = $has_flat_key ? $flat[ $taxonomy ] : array();
			$term_ids   = array();

			$errors_before = count( $errors );

			foreach ( $flat_names as $term_name ) {
				if ( is_array( $term_name ) || is_object( $term_name ) ) {
					continue;
				}

				if ( ! is_string( $term_name ) ) {
					$term_name = (string) $term_name;
				}

				if ( '' === trim( $term_name ) ) {
					continue;
				}

				$term_id = self::ensure_term( $term_name, $taxonomy, '', 0 );

				if ( is_wp_error( $term_id ) ) {
					$errors[] = sprintf(
						/* translators: 1: taxonomy slug, 2: term name, 3: error message. */
						__( 'Could not create “%2$s” in %1$s: %3$s.', 'pageferry' ),
						$taxonomy,
						$term_name,
						$term_id->get_error_message()
					);
					continue;
				}

				if ( null !== $term_id ) {
					$term_ids[] = $term_id;
				}
			}

			if ( array() !== $term_ids ) {
				$set_result = wp_set_object_terms( $post_id, $term_ids, $taxonomy, $append );

				if ( is_wp_error( $set_result ) ) {
					$errors[] = sprintf(
						/* translators: 1: taxonomy slug, 2: error message. */
						__( 'Could not add the selected categories or tags in “%1$s” to the page: %2$s.', 'pageferry' ),
						$taxonomy,
						$set_result->get_error_message()
					);
				}
			} elseif ( $is_update && array() === $flat_names && ! $append ) {
				$clear_result = wp_set_object_terms( $post_id, array(), $taxonomy );

				if ( is_wp_error( $clear_result ) ) {
					$errors[] = sprintf(
						/* translators: 1: taxonomy slug, 2: error message. */
						__( 'Could not remove the current categories or tags in “%1$s” from the page: %2$s.', 'pageferry' ),
						$taxonomy,
						$clear_result->get_error_message()
					);
				}
			} elseif ( array() !== $flat_names ) {
				// An unresolved nonempty request must preserve the target and report failure.
				$has_nonempty_request = false;

				foreach ( $flat_names as $flat_candidate ) {
					if ( is_array( $flat_candidate ) || is_object( $flat_candidate ) ) {
						continue;
					}

					$candidate_string = is_string( $flat_candidate ) ? $flat_candidate : (string) $flat_candidate;

					if ( '' !== trim( $candidate_string ) ) {
						$has_nonempty_request = true;
						break;
					}
				}

				if ( $has_nonempty_request && count( $errors ) === $errors_before ) {
					$errors[] = sprintf(
						/* translators: %s: taxonomy slug. */
						__( 'None of the selected categories or tags in “%s” could be found or created. The page keeps its current choices.', 'pageferry' ),
						$taxonomy
					);
				}
			}
		}

		return $errors;
	}

	/**
	 * Ensures ancestors without directly assigning them; unresolved requested terms never clear a
	 * target.
	 *
	 * @param int    $post_id Post ID just created or updated.
	 * @param string $taxonomy Taxonomy slug.
	 * @param array  $detailed_terms List of {name, slug, parent, parent_slug, assigned} (parents first).
	 * @param bool   $append Keep current assignments and add selected terms.
	 * @return array List of human-readable failure notes (empty on success).
	 */
	private static function assign_detailed_terms( int $post_id, string $taxonomy, array $detailed_terms, bool $append = false ): array {
		$is_hierarchical = is_taxonomy_hierarchical( $taxonomy );
		$assigned_ids    = array();
		$slug_to_id      = array();
		$errors          = array();

		foreach ( $detailed_terms as $term ) {
			if ( ! is_array( $term ) || ! isset( $term['name'] ) || ! is_string( $term['name'] ) || '' === trim( $term['name'] ) ) {
				continue;
			}

			$slug        = isset( $term['slug'] ) && is_string( $term['slug'] ) ? $term['slug'] : '';
			$parent_slug = $is_hierarchical && isset( $term['parent_slug'] ) && is_string( $term['parent_slug'] ) ? $term['parent_slug'] : '';
			$parent_name = $is_hierarchical && isset( $term['parent'] ) && is_string( $term['parent'] ) ? $term['parent'] : '';
			$is_assigned = ! array_key_exists( 'assigned', $term ) || ! empty( $term['assigned'] );

			$parent_term_id = 0;

			if ( $is_hierarchical && ( '' !== $parent_slug || '' !== $parent_name ) ) {
				if ( '' !== $parent_slug && isset( $slug_to_id[ $parent_slug ] ) ) {
					$parent_term_id = (int) $slug_to_id[ $parent_slug ];
				} else {
					$parent_term = false;

					if ( '' !== $parent_slug ) {
						$parent_term = get_term_by( 'slug', $parent_slug, $taxonomy );
					}

					if ( ! $parent_term instanceof WP_Term && '' !== $parent_name ) {
						// Term name queries unslash input.
						$parent_term = get_term_by( 'name', wp_slash( $parent_name ), $taxonomy );
					}

					$parent_term_id = $parent_term instanceof WP_Term ? (int) $parent_term->term_id : 0;

					// Report explicitly missing parents even when the child can be created at the root.
				}
			}

			$term_id = self::ensure_term( $term['name'], $taxonomy, $slug, $parent_term_id );

			if ( is_wp_error( $term_id ) ) {
				$errors[] = sprintf(
					/* translators: 1: taxonomy slug, 2: term name, 3: error message. */
					__( 'Could not create “%2$s” in %1$s: %3$s.', 'pageferry' ),
					$taxonomy,
					$term['name'],
					$term_id->get_error_message()
				);
				continue;
			}

			if ( null === $term_id ) {
				continue;
			}

			if ( '' !== $slug && ! isset( $slug_to_id[ $slug ] ) ) {
				$slug_to_id[ $slug ] = $term_id;
			}

			if ( $is_assigned ) {
				$assigned_ids[] = $term_id;
			}
		}

		if ( array() !== $assigned_ids ) {
			$set_result = wp_set_object_terms( $post_id, $assigned_ids, $taxonomy, $append );

			if ( is_wp_error( $set_result ) ) {
				$errors[] = sprintf(
					/* translators: 1: taxonomy slug, 2: error message. */
					__( 'Could not add the selected categories or tags in “%1$s” to the page: %2$s.', 'pageferry' ),
					$taxonomy,
					$set_result->get_error_message()
				);
			}
		}

		return $errors;
	}

	/**
	 * Reuses terms by slug or matching ancestry; existing parents stay unchanged and creation needs
	 * rights.
	 *
	 * @param string $name Term name.
	 * @param string $taxonomy Taxonomy slug.
	 * @param string $slug Desired slug (creation only).
	 * @param int    $parent_term_id Parent term ID (hierarchical only).
	 * @return int|WP_Error|null Term ID, WP_Error on creation failure, or null when the name is empty.
	 */
	private static function ensure_term( string $name, string $taxonomy, string $slug, int $parent_term_id ) {
		if ( '' === trim( $name ) ) {
			return null;
		}

		$existing_id = self::existing_term_id( $name, $taxonomy, $slug, $parent_term_id );
		if ( null !== $existing_id ) {
			return $existing_id;
		}

		$insert_args = array( 'parent' => $parent_term_id );

		if ( '' !== $slug ) {
			$insert_args['slug'] = $slug;
		}

		$taxonomy_object = get_taxonomy( $taxonomy );

		if ( $taxonomy_object instanceof WP_Taxonomy ) {
			$manage_capability = isset( $taxonomy_object->cap->manage_terms ) && is_string( $taxonomy_object->cap->manage_terms ) && '' !== $taxonomy_object->cap->manage_terms
				? $taxonomy_object->cap->manage_terms
				: null;

			if ( is_string( $manage_capability ) && ! current_user_can( $manage_capability ) ) {
				return new WP_Error(
					'pageferry_terms_cap',
					sprintf(
						/* translators: 1: taxonomy slug, 2: term name. */
						__( 'You do not have permission to create “%2$s” in %1$s. Deselect it or ask an administrator to create it first.', 'pageferry' ),
						$taxonomy,
						$name
					)
				);
			}
		}

		// Core unslashes term names but stores slugs raw.
		$created_term = wp_insert_term( wp_slash( $name ), $taxonomy, $insert_args );

		if ( is_wp_error( $created_term ) ) {
			if ( 'term_exists' === $created_term->get_error_code() ) {
				return (int) $created_term->get_error_data();
			}

			return $created_term;
		}

		return (int) $created_term['term_id'];
	}

	/**
	 * Resolve an existing term using the same identity rules as execution.
	 *
	 * @param string $name Raw term name.
	 * @param string $taxonomy Taxonomy slug.
	 * @param string $slug Source slug, or empty for legacy name-only terms.
	 * @param int    $parent_term_id Parent ID; -1 means a not-yet-created parent in preview.
	 * @return int|null Existing ID, or null when creation is needed.
	 */
	public static function existing_term_id( string $name, string $taxonomy, string $slug, int $parent_term_id ): ?int {
		if ( '' !== $slug ) {
			$by_slug = get_term_by( 'slug', $slug, $taxonomy );

			if ( $by_slug instanceof WP_Term ) {
				return (int) $by_slug->term_id;
			}
		}

		// Term name queries unslash input; protect literal backslashes.
		$existing_term = get_term_by( 'name', wp_slash( $name ), $taxonomy );

		if ( $existing_term instanceof WP_Term ) {
			if ( '' === $slug || (int) $existing_term->parent === $parent_term_id || ! is_taxonomy_hierarchical( $taxonomy ) ) {
				return (int) $existing_term->term_id;
			}

			// A same-named term in another branch must not collapse the requested hierarchy.
			$sibling_id = self::find_sibling_term_id( $name, $taxonomy, $parent_term_id );

			if ( null !== $sibling_id ) {
				return $sibling_id;
			}
		}

		return null;
	}

	/**
	 * Finds a same-named term in the requested branch instead of reusing another parent’s child.
	 *
	 * @param string $name Term name (raw, unslashed; slashed for the query).
	 * @param string $taxonomy Taxonomy slug.
	 * @param int    $parent_term_id Desired parent term ID.
	 * @return int|null Matching term ID, or null when none matches.
	 */
	private static function find_sibling_term_id( string $name, string $taxonomy, int $parent_term_id ): ?int {
		$candidates = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'name'       => wp_slash( $name ),
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $candidates ) ) {
			return null;
		}

		foreach ( $candidates as $candidate ) {
			if ( (int) $candidate->parent === $parent_term_id ) {
				return (int) $candidate->term_id;
			}
		}

		return null;
	}

	/**
	 * Null preserves legacy template intent; an empty string means the default template.
	 *
	 * @param array $manifest Normalized manifest.
	 * @return string|null Normalized template, or null when absent.
	 */
	public static function normalized_bundle_template( array $manifest ): ?string {
		if ( ! isset( $manifest['post'] ) || ! is_array( $manifest['post'] ) || ! array_key_exists( 'template', $manifest['post'] ) ) {
			return null;
		}

		$raw = $manifest['post']['template'];

		if ( ! is_string( $raw ) ) {
			return null;
		}

		$template = trim( $raw );

		if ( 'default' === $template ) {
			$template = '';
		}

		return $template;
	}

	/**
	 * Checks path safety only; unavailable theme templates remain valid stored intent.
	 *
	 * @param string $template Template slug or file from the manifest.
	 * @return bool True when the value is a safe relative slug/path.
	 */
	public static function template_slug_allowed( string $template ): bool {
		if ( '' === $template ) {
			return true;
		}

		if ( 200 < strlen( $template ) ) {
			return false;
		}

		if ( str_contains( $template, '..' ) || str_contains( $template, '\\' ) || str_starts_with( $template, '/' ) ) {
			return false;
		}

		if ( str_contains( $template, "\0" ) ) {
			return false;
		}

		return 1 === preg_match( '/\A[A-Za-z0-9._\-\/]+\z/', $template );
	}

	/**
	 * Unavailable templates warn without refusing the stored choice.
	 *
	 * @param array $manifest Normalized manifest.
	 * @return array List of human-readable template notes (empty when none).
	 */
	public static function preview_template_warnings( array $manifest ): array {
		$template = self::normalized_bundle_template( $manifest );

		if ( null === $template || '' === $template ) {
			return array();
		}

		if ( function_exists( 'wp_get_theme' ) ) {
			$bundle_post_type = isset( $manifest['post']['post_type'] ) && is_string( $manifest['post']['post_type'] ) ? $manifest['post']['post_type'] : 'page';
			$available        = wp_get_theme()->get_page_templates( null, '' !== $bundle_post_type ? $bundle_post_type : 'page' );

			// Filename keys distinguish templates that share a display name.
			if ( array_key_exists( $template, $available ) ) {
				return array();
			}
		}

		return array(
			sprintf(
				/* translators: %s: page template file recorded in the bundle. */
				__( 'Page template "%s" is unavailable on this site. Its name will be saved, but the page will use the default layout until a theme provides that template. Check the page after importing.', 'pageferry' ),
				$template
			),
		);
	}

	/**
	 * Writes template intent directly so a later theme sync can restore unavailable layouts.
	 *
	 * @param int    $post_id Post ID to write.
	 * @param string $template Normalized template ('...' file or '' for default).
	 * @return array List of human-readable failure notes (empty on success).
	 */
	private static function write_template_verbatim( int $post_id, string $template ): array {
		if ( '' === $template ) {
			if ( ! metadata_exists( 'post', $post_id, '_wp_page_template' ) ) {
				return array();
			}

			if ( ! delete_post_meta( $post_id, '_wp_page_template' ) ) {
				return array( __( 'PageFerry could not reset the page template on the imported page.', 'pageferry' ) );
			}

			return array();
		}

		$current_raw = get_post_meta( $post_id, '_wp_page_template', true );
		$current     = is_string( $current_raw ) ? $current_raw : '';

		if ( 'default' === $current ) {
			$current = '';
		}

		if ( $current === $template ) {
			return array();
		}

		// WordPress unslashes metadata writes.
		$updated = update_post_meta( $post_id, '_wp_page_template', wp_slash( $template ) );

		if ( false === $updated ) {
			return array( __( 'PageFerry could not set the page template on the imported page.', 'pageferry' ) );
		}

		if ( get_post_meta( $post_id, '_wp_page_template', true ) !== $template ) {
			return array( __( 'PageFerry could not set the page template on the imported page.', 'pageferry' ) );
		}

		return array();
	}

	/**
	 * Applies explicit template intent; omitted legacy keys preserve the destination.
	 *
	 * @param int   $post_id Post ID just created or updated.
	 * @param array $manifest Normalized manifest.
	 * @return array List of human-readable failure notes (empty on success).
	 */
	private static function assign_template( int $post_id, array $manifest ): array {
		$template = self::normalized_bundle_template( $manifest );

		if ( null === $template ) {
			return array();
		}

		return self::write_template_verbatim( $post_id, $template );
	}

	/**
	 * Absent thumbnails preserve; explicit empty clears; unresolved source media preserves the target.
	 *
	 * @param int   $post_id Post ID just created or updated.
	 * @param array $manifest Normalized manifest.
	 * @param array $id_map Map of old attachment ID => new attachment ID.
	 * @param bool  $is_update True when overwriting an existing target.
	 * @return array List of human-readable failure notes (empty on success).
	 */
	private static function assign_thumbnail( int $post_id, array $manifest, array $id_map, bool $is_update = false ): array {
		if ( ! isset( $manifest['post'] ) || ! is_array( $manifest['post'] ) || ! array_key_exists( 'thumbnail_old_id', $manifest['post'] ) ) {
			return array();
		}

		$thumbnail_raw = $manifest['post']['thumbnail_old_id'];

		if ( null === $thumbnail_raw ) {
			if ( $is_update ) {
				if ( '' !== get_post_meta( $post_id, '_thumbnail_id', true ) && ! delete_post_thumbnail( $post_id ) ) {
					return array( __( 'The current featured image could not be removed. Open the page in the editor and check it.', 'pageferry' ) );
				}
			}

			return array();
		}

		$thumbnail_old_id = is_numeric( $thumbnail_raw ) ? (int) $thumbnail_raw : 0;

		if ( 0 >= $thumbnail_old_id ) {
			if ( $is_update ) {
				if ( '' !== get_post_meta( $post_id, '_thumbnail_id', true ) && ! delete_post_thumbnail( $post_id ) ) {
					return array( __( 'The current featured image could not be removed. Open the page in the editor and check it.', 'pageferry' ) );
				}
			}

			return array();
		}

		if ( isset( $id_map[ $thumbnail_old_id ] ) ) {
			$new_thumb     = (int) $id_map[ $thumbnail_old_id ];
			$current_thumb = (int) get_post_meta( $post_id, '_thumbnail_id', true );

			if ( $current_thumb !== $new_thumb && ! set_post_thumbnail( $post_id, $new_thumb ) ) {
				return array( __( 'PageFerry could not set the featured image on the imported page.', 'pageferry' ) );
			}
		}

		return array();
	}

	/**
	 * Restores only supplied fields belonging to present usePostMeta blocks; skips remain visible.
	 *
	 * @param int   $new_post_id Post ID just created or updated.
	 * @param array $manifest    Normalized manifest.
	 * @param array $id_map      Map of old attachment ID => new attachment ID.
	 * @param array $errors      Failed provider writes (appended to).
	 * @param array $created_attachments Attachment IDs created by this import.
	 * @return array List of human-readable skip notes (empty when all restored).
	 */
	private static function restore_acf_post_meta( int $new_post_id, array $manifest, array $id_map, array &$errors = array(), array $created_attachments = array() ): array {
		$dependency_note = self::acf_unavailable_note( $manifest );

		if ( is_string( $dependency_note ) ) {
			return array( $dependency_note );
		}

		// Explicit guards also let PHPStan narrow optional ACF functions.
		if ( ! function_exists( 'acf_block_uses_post_meta' ) || ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
			return array();
		}

		if ( ! function_exists( 'acf_update_value' ) && ! function_exists( 'update_field' ) ) {
			return array();
		}

		if ( ! isset( $manifest['acf_post_meta'] ) || ! is_array( $manifest['acf_post_meta'] ) || array() === $manifest['acf_post_meta'] ) {
			return array();
		}

		$skipped        = array();
		$bundle_content = isset( $manifest['post']['content'] ) && is_string( $manifest['post']['content'] ) ? $manifest['post']['content'] : '';
		/** Bundle blocks as a plain list. @var array $content_blocks Unshaped parse_blocks() result for PHPStan. */
		$content_blocks = '' !== $bundle_content ? parse_blocks( $bundle_content ) : array();
		$content_names  = array();
		self::collect_block_names( $content_blocks, $content_names );

		foreach ( $manifest['acf_post_meta'] as $acf_entry ) {
			if ( ! is_array( $acf_entry ) || ! isset( $acf_entry['block'], $acf_entry['fields'] ) || ! is_string( $acf_entry['block'] ) || ! is_array( $acf_entry['fields'] ) ) {
				continue;
			}

			$block_name = $acf_entry['block'];

			if ( ! in_array( $block_name, $content_names, true ) ) {
				/* translators: %s: ACF block name. */
				$skipped[] = sprintf( __( 'ACF block %s is missing from the page content. Its custom field values were skipped.', 'pageferry' ), $block_name );
				continue;
			}

			if ( ! acf_block_uses_post_meta( array( 'name' => $block_name ) ) ) {
				/* translators: %s: ACF block name. */
				$skipped[] = sprintf( __( 'ACF block %s uses different field storage on this site. Its custom field values were skipped. Ask a developer to match the block settings before importing.', 'pageferry' ), $block_name );
				continue;
			}

			$target_fields = self::get_acf_block_fields( $block_name );

			if ( array() === $target_fields ) {
				/* translators: %s: ACF block name. */
				$skipped[] = sprintf( __( 'ACF block %s has no fields configured on this site. Its values were skipped. Ask a developer to add matching ACF fields before importing.', 'pageferry' ), $block_name );
				continue;
			}

			$fields_by_name = array();

			foreach ( $target_fields as $target_field ) {
				if ( is_array( $target_field ) && isset( $target_field['name'] ) && is_string( $target_field['name'] ) && '' !== $target_field['name'] ) {
					$fields_by_name[ $target_field['name'] ] = $target_field;
				}
			}

			$skipped_fields = array();

			foreach ( $acf_entry['fields'] as $field_name => $old_value ) {
				if ( ! is_string( $field_name ) || '' === $field_name || ! isset( $fields_by_name[ $field_name ] ) ) {
					$skipped_fields[] = is_string( $field_name ) && '' !== $field_name ? $field_name : '(unnamed field)';
					continue;
				}

				$field_definition = $fields_by_name[ $field_name ];
				$skip_note        = self::acf_restore_skip_note( $field_definition, $old_value, $block_name );
				if ( null !== $skip_note ) {
					$skipped[] = $skip_note;
					continue;
				}
				$remapped_value = self::remap_acf_field_value( $old_value, $field_definition, $id_map, $manifest, 0 );

				if ( ! self::write_acf_value( $new_post_id, $field_definition, $remapped_value, $created_attachments ) ) {
					$errors[] = sprintf(
						/* translators: 1: ACF block name, 2: field name. */
						__( 'ACF block %1$s: field %2$s was not completely saved; check the field and its subfields on the destination page.', 'pageferry' ),
						$block_name,
						$field_name
					);
				}
			}

			if ( array() !== $skipped_fields ) {
				/* translators: 1: ACF block name, 2: unavailable field names. */
				$skipped[] = sprintf( __( 'Some fields for ACF block %1$s are unavailable on this site and were skipped: %2$s. Ask a developer to check the field settings.', 'pageferry' ), $block_name, implode( ', ', $skipped_fields ) );
			}
		}

		return $skipped;
	}

	/**
	 * Restores only fields the pre-write destination exposes, matching preview skips.
	 *
	 * @param int   $new_post_id        Destination post ID.
	 * @param array $manifest           Normalized manifest.
	 * @param array $id_map             Map of old attachment ID => new attachment ID.
	 * @param array $errors             Partial-failure notes (appended to).
	 * @param array $destination_fields Map of field name => destination field definition.
	 * @param array $created_attachments Attachment IDs created by this import.
	 * @return array Skip notes for the run log.
	 */
	private static function restore_acf_post_fields( int $new_post_id, array $manifest, array $id_map, array &$errors, array $destination_fields, array $created_attachments = array() ): array {
		$dependency_note = self::acf_post_fields_unavailable_note( $manifest );

		if ( is_string( $dependency_note ) ) {
			return array( $dependency_note );
		}

		$post_fields = isset( $manifest['acf_post_fields'] ) && is_array( $manifest['acf_post_fields'] ) ? $manifest['acf_post_fields'] : array();

		if ( array() === $post_fields ) {
			return array();
		}

		$skipped = array();
		$missing = self::acf_missing_post_fields( $post_fields, $destination_fields );

		if ( array() !== $missing ) {
			$skipped[] = self::acf_post_fields_skip_note( $missing );
		}

		foreach ( $post_fields as $field_name => $old_value ) {
			if ( ! is_string( $field_name ) || '' === $field_name || ! isset( $destination_fields[ $field_name ] ) ) {
				continue;
			}

			$field_definition = $destination_fields[ $field_name ];
			$skip_note        = self::acf_restore_skip_note( $field_definition, $old_value );
			if ( null !== $skip_note ) {
				$skipped[] = $skip_note;
				continue;
			}
			$remapped_value = self::remap_acf_field_value( $old_value, $field_definition, $id_map, $manifest, 0 );

			if ( ! self::write_acf_value( $new_post_id, $field_definition, $remapped_value, $created_attachments ) ) {
				$errors[] = sprintf(
					/* translators: %s: ACF field name. */
					__( 'ACF field %s was not completely saved; check the field and its subfields on the destination page.', 'pageferry' ),
					$field_name
				);
			}
		}

		return $skipped;
	}

	/**
	 * Shares definition safety and supplied-container preflight between both payloads.
	 *
	 * @param array  $field Destination definition.
	 * @param mixed  $value Raw supplied value, before remapping.
	 * @param string $block_name Optional owning block.
	 * @return string|null Whole-field skip note, or null when compatible.
	 */
	private static function acf_restore_skip_note( array $field, $value, string $block_name = '' ): ?string {
		$note = self::acf_side_effect_skip_note( $field, $block_name );
		if ( null !== $note ) {
			return $note;
		}
		$name = isset( $field['name'] ) && is_string( $field['name'] ) ? $field['name'] : '(unnamed field)';
		$path = self::acf_incompatible_value_path( $value, $field, $name, 0 );
		if ( null === $path ) {
			return null;
		}
		return sprintf(
			/* translators: 1: ACF block prefix, 2: field name, 3: incompatible nested value path. */
			__( '%1$sACF field %2$s was skipped because its structure does not match the field settings on this site. Ask a developer to match the ACF field settings before importing. The existing value was kept. Location: %3$s.', 'pageferry' ),
			/* translators: %s: ACF block name. */
			'' !== $block_name ? sprintf( __( 'Block %s: ', 'pageferry' ), $block_name ) : '',
			$name,
			$path
		);
	}

	/**
	 * Rejects incompatible supplied containers before parent writes can alter siblings or row counts.
	 *
	 * @param mixed  $value Supplied value.
	 * @param array  $field Destination definition, already inspected for safety.
	 * @param string $path Human-readable value path.
	 * @param int    $depth Current container depth.
	 * @return string|null First incompatible path, or null when compatible.
	 */
	private static function acf_incompatible_value_path( $value, array $field, string $path, int $depth ): ?string {
		$type = $field['type'] ?? '';
		if ( ! in_array( $type, array( 'group', 'clone', 'repeater', 'flexible_content' ), true ) ) {
			return null;
		}
		if ( self::MAX_REMAP_DEPTH < $depth ) {
			return $path;
		}
		// Legacy empty row sets may be false or an empty string.
		if ( in_array( $type, array( 'repeater', 'flexible_content' ), true ) && in_array( $value, array( null, false, '' ), true ) ) {
			return null;
		}
		if ( ! is_array( $value ) ) {
			return $path;
		}
		if ( in_array( $type, array( 'group', 'clone' ), true ) ) {
			return self::acf_incompatible_row_path( $value, self::acf_sub_fields( $field ), $path, $depth, true );
		}
		// Disabled layouts can leave row gaps; editor patch keys are not portable data.
		foreach ( array_keys( $value ) as $index ) {
			if ( ! is_int( $index ) || 0 > $index ) {
				return $path;
			}
		}
		$children = self::acf_sub_fields( $field );
		$layouts  = array();
		if ( 'flexible_content' === $type ) {
			foreach ( $field['layouts'] as $layout ) {
				if ( isset( $layout['name'] ) && is_string( $layout['name'] ) && '' !== $layout['name'] ) {
					if ( array_key_exists( $layout['name'], $layouts ) ) {
						return $path . '.acf_fc_layout';
					}
					$layouts[ $layout['name'] ] = $layout['sub_fields'];
				}
			}
		}
		foreach ( $value as $index => $row ) {
			$row_path = $path . '.' . $index;
			if ( ! is_array( $row ) ) {
				return $row_path;
			}
			if ( 'flexible_content' === $type ) {
				$layout_name = $row['acf_fc_layout'] ?? null;
				if ( ! is_string( $layout_name ) || ! isset( $layouts[ $layout_name ] ) ) {
					return $row_path . '.acf_fc_layout';
				}
				$children = $layouts[ $layout_name ];
				unset( $row['acf_fc_layout'] );
			}
			$invalid = self::acf_incompatible_row_path( $row, $children, $row_path, $depth, false );
			if ( null !== $invalid ) {
				return $invalid;
			}
		}
		return null;
	}

	/**
	 * Rejects duplicate key/name aliases and null children ACF would silently ignore.
	 *
	 * @param array  $row Supplied children, with layout discriminator removed.
	 * @param array  $children Destination child definitions.
	 * @param string $path Parent value path.
	 * @param int    $depth Parent container depth.
	 * @param bool   $ignores_null Whether this provider ignores null child values.
	 * @return string|null First incompatible member, or null when compatible.
	 */
	private static function acf_incompatible_row_path( array $row, array $children, string $path, int $depth, bool $ignores_null ): ?string {
		$members = array();
		foreach ( $children as $index => $child ) {
			foreach ( array( 'key', 'name' ) as $attribute ) {
				$alias = 'name' === $attribute && $ignores_null ? ( $child['_name'] ?? $child['name'] ?? '' ) : ( $child[ $attribute ] ?? '' );
				if ( is_string( $alias ) && '' !== $alias ) {
					if ( array_key_exists( $alias, $members ) && ( null === $members[ $alias ] || $members[ $alias ][0] !== $index ) ) {
						$members[ $alias ] = null;
					} else {
						$members[ $alias ] = array( $index, $child );
					}
				}
			}
		}
		$seen = array();
		foreach ( $row as $member => $child_value ) {
			$member_path = $path . '.' . $member;
			if ( ! isset( $members[ $member ] ) || ( $ignores_null && null === $child_value ) ) {
				return $member_path;
			}
			list( $index, $child ) = $members[ $member ];
			if ( isset( $seen[ $index ] ) ) {
				return $member_path;
			}
			$seen[ $index ] = true;
			$invalid        = self::acf_incompatible_value_path( $child_value, $child, $member_path, $depth + 1 );
			if ( null !== $invalid ) {
				return $invalid;
			}
		}
		return null;
	}

	/**
	 * Explains why a whole field must be preserved instead of invoking ACF.
	 *
	 * @param array  $field Destination definition.
	 * @param string $block_name Optional owning block.
	 * @return string|null Identical preview and execution note, or null when safe.
	 */
	private static function acf_side_effect_skip_note( array $field, string $block_name = '' ): ?string {
		$name      = isset( $field['name'] ) && is_string( $field['name'] ) ? $field['name'] : '(unnamed field)';
		$remaining = 1024;
		$reason    = self::acf_side_effect_reason( $field, $name, 0, array(), $remaining );
		if ( null === $reason ) {
			return null;
		}
		return sprintf(
			/* translators: 1: ACF block prefix, 2: field name, 3: unsafe setting or inspection limit. */
			__( '%1$sACF field %2$s was skipped: %3$s. The existing value was kept.', 'pageferry' ),
			/* translators: %s: ACF block name. */
			'' !== $block_name ? sprintf( __( 'Block %s: ', 'pageferry' ), $block_name ) : '',
			$name,
			$reason
		);
	}

	/**
	 * Checks absent children and unused layouts because parent writes can delete them.
	 *
	 * @param array  $field Destination field.
	 * @param string $path Human-readable definition path.
	 * @param int    $depth Current depth.
	 * @param array  $ancestors Field keys on this branch, for cycle detection.
	 * @param int    $remaining Remaining definition visits in this field.
	 * @return string|null First unsafe setting or inspection limit.
	 */
	private static function acf_side_effect_reason( array $field, string $path, int $depth, array $ancestors, int &$remaining ): ?string {
		$key = isset( $field['key'] ) && is_string( $field['key'] ) ? $field['key'] : '';
		if ( 0 >= $remaining-- || self::MAX_REMAP_DEPTH < $depth || ( '' !== $key && isset( $ancestors[ $key ] ) ) ) {
			/* translators: %s: ACF field definition path. */
			return sprintf( __( 'the field settings at %s could not be checked', 'pageferry' ), $path );
		}
		if ( '' !== $key ) {
			$ancestors[ $key ] = true;
		}
		if ( ! empty( $field['bidirectional'] ) ) {
			/* translators: %s: ACF field definition path. */
			return sprintf( __( '%s is set to update related content automatically (ACF bidirectional updates)', 'pageferry' ), $path );
		}
		$type = isset( $field['type'] ) && is_string( $field['type'] ) ? $field['type'] : '';
		if ( 'taxonomy' === $type && ! empty( $field['save_terms'] ) ) {
			/* translators: %s: ACF field definition path. */
			return sprintf( __( '%s is set to update categories or tags automatically (ACF Save Terms)', 'pageferry' ), $path );
		}
		if ( ! in_array( $type, array( 'group', 'repeater', 'clone', 'flexible_content' ), true ) ) {
			return null;
		}
		$children = array();
		if ( 'flexible_content' === $type ) {
			if ( ! isset( $field['layouts'] ) || ! is_array( $field['layouts'] ) ) {
				/* translators: %s: ACF field definition path. */
				return sprintf( __( 'the field settings at %s could not be checked', 'pageferry' ), $path );
			}
			foreach ( $field['layouts'] as $layout ) {
				if ( ! is_array( $layout ) || ! isset( $layout['sub_fields'] ) || ! is_array( $layout['sub_fields'] ) ) {
					/* translators: %s: ACF field definition path. */
					return sprintf( __( 'the field settings at %s could not be checked', 'pageferry' ), $path );
				}
				foreach ( $layout['sub_fields'] as $child ) {
					$children[] = $child;
				}
			}
		} else {
			$children = self::acf_sub_fields( $field );
			if ( array() === $children && ( ! isset( $field['sub_fields'] ) || ! is_array( $field['sub_fields'] ) || ( 'clone' === $type && ! empty( $field['clone'] ) ) ) ) {
				/* translators: %s: ACF field definition path. */
				return sprintf( __( 'the field settings at %s could not be checked', 'pageferry' ), $path );
			}
		}
		foreach ( $children as $child ) {
			if ( ! is_array( $child ) ) {
				/* translators: %s: ACF field definition path. */
				return sprintf( __( 'the field settings at %s could not be checked', 'pageferry' ), $path );
			}
			$child_name = isset( $child['name'] ) && is_string( $child['name'] ) ? $child['name'] : '(unnamed field)';
			$reason     = self::acf_side_effect_reason( $child, $path . '.' . $child_name, $depth + 1, $ancestors, $remaining );
			if ( null !== $reason ) {
				return $reason;
			}
		}
		return null;
	}

	/**
	 * Verifies normalized ACF storage, including nested writes and references; parent booleans are
	 * insufficient.
	 *
	 * @param int   $post_id Destination post ID.
	 * @param array $field ACF field definition.
	 * @param mixed $value Remapped raw value.
	 * @param array $created_attachments Attachment IDs created by this import.
	 * @return bool Whether all observed values/references were persisted.
	 */
	private static function write_acf_value( int $post_id, array $field, $value, array $created_attachments = array() ): bool {
		$slash_value        = static function ( $normalized_value, $object_id ) use ( $post_id ) {
			return (string) $post_id === (string) $object_id ? wp_slash( $normalized_value ) : $normalized_value;
		};
		$connect_attachment = static function ( $allowed, $attachment_id, $parent_id ) use ( $post_id, $created_attachments ) {
			return $allowed && (string) $post_id === (string) $parent_id && in_array( (int) $attachment_id, $created_attachments, true );
		};
		$expected_meta      = array();
		$short_values       = array();
		$observe_meta       = static function ( $check, $object_id, $name, $meta_value, $hidden ) use ( $post_id, &$expected_meta ) {
			if ( (string) $post_id === (string) $object_id ) {
				// ACF reference writes bypass the value filter and require raw field keys.
				$expected_meta[ ( $hidden ? '_' : '' ) . $name ] = $hidden ? $meta_value : wp_unslash( $meta_value );
			}
			return $check;
		};
		$observe_delete     = static function ( $check, $object_id, $name, $hidden ) use ( $post_id, &$expected_meta ) {
			if ( (string) $post_id === (string) $object_id ) {
				$expected_meta[ ( $hidden ? '_' : '' ) . $name ] = null;
			}
			return $check;
		};
		$observe_short      = static function ( $check, $raw_value, $object_id, $definition ) use ( $post_id, &$short_values ) {
			if ( null !== $check && (string) $post_id === (string) $object_id ) {
				$short_values[] = array(
					'field' => $definition,
					'value' => $raw_value,
				);
			}
			return $check;
		};
		add_filter( 'acf/pre_update_metadata', $observe_meta, PHP_INT_MAX, 5 );
		add_filter( 'acf/pre_delete_metadata', $observe_delete, PHP_INT_MAX, 4 );
		add_filter( 'acf/pre_update_value', $observe_short, PHP_INT_MAX, 4 );
		add_filter( 'acf/connect_attachment_to_post', $connect_attachment, PHP_INT_MAX, 3 );
		add_filter( 'acf/update_value', $slash_value, PHP_INT_MAX, 2 );
		try {
			if ( function_exists( 'acf_update_value' ) ) {
				$result = acf_update_value( $value, $post_id, $field );
			} elseif ( function_exists( 'update_field' ) ) {
				$selector = isset( $field['key'] ) && is_string( $field['key'] ) && '' !== $field['key'] ? $field['key'] : $field['name'];
				$result   = update_field( $selector, $value, $post_id );
			} else {
				return false;
			}
		} finally {
			remove_filter( 'acf/update_value', $slash_value, PHP_INT_MAX );
			remove_filter( 'acf/connect_attachment_to_post', $connect_attachment, PHP_INT_MAX );
			remove_filter( 'acf/pre_update_metadata', $observe_meta, PHP_INT_MAX );
			remove_filter( 'acf/pre_delete_metadata', $observe_delete, PHP_INT_MAX );
			remove_filter( 'acf/pre_update_value', $observe_short, PHP_INT_MAX );
		}
		if ( is_wp_error( $result ) ) {
			return false;
		}
		foreach ( $expected_meta as $name => $expected ) {
			if ( null === $expected ) {
				if ( metadata_exists( 'post', $post_id, $name ) ) {
					return false;
				}
			} elseif ( ! metadata_exists( 'post', $post_id, $name ) || ! self::metadata_values_match( $expected, get_post_meta( $post_id, $name, true ) ) ) {
				return false;
			}
		}
		if ( array() === $expected_meta && array() === $short_values ) {
			$short_values[] = array(
				'field' => $field,
				'value' => $value,
			);
		}
		foreach ( $short_values as $short_value ) {
			if ( ! function_exists( 'acf_get_value' ) ) {
				return false;
			}
			$definition = $short_value['field'];
			// An equal value can hide a missing ACF field-key reference after a provider short-circuit.
			if ( function_exists( 'acf_get_metadata' ) && isset( $definition['key'] ) ) {
				$reference = '_' . $definition['name'];
				if ( null === $short_value['value'] ) {
					if ( metadata_exists( 'post', $post_id, $definition['name'] ) || metadata_exists( 'post', $post_id, $reference ) ) {
						return false;
					}
					continue;
				}
				if ( get_post_meta( $post_id, $reference, true ) !== $definition['key'] ) {
					return false;
				}
			}
			if ( function_exists( 'acf_flush_value_cache' ) ) {
				acf_flush_value_cache( $post_id, $definition['name'] );
			}
			if ( ! self::metadata_values_match( $short_value['value'], acf_get_value( $post_id, $definition ) ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * WordPress stores nonserialized scalars as strings, arrays as-is.
	 *
	 * @param mixed $expected Expected provider storage value.
	 * @param mixed $stored Persisted value.
	 * @return bool Whether values match under the metadata storage contract.
	 */
	private static function metadata_values_match( $expected, $stored ): bool {
		if ( is_scalar( $expected ) && is_scalar( $stored ) ) {
			return (string) $expected === (string) $stored;
		}
		return $expected === $stored;
	}

	/**
	 * Collects every block name in a parsed tree, at any depth.
	 *
	 * @param array $blocks Parsed blocks at this level.
	 * @param array $names  Block names found so far (appended to).
	 * @return void
	 */
	private static function collect_block_names( array $blocks, array &$names ): void {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			if ( isset( $block['blockName'] ) && is_string( $block['blockName'] ) ) {
				$names[] = $block['blockName'];
			}

			if ( isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::collect_block_names( $block['innerBlocks'], $names );
			}
		}
	}

	/**
	 * Uses the collector’s ACF lookup so inactive field groups cannot accept meta writes.
	 *
	 * @param string $block_name Full ACF block name.
	 * @return array List of ACF field arrays.
	 */
	private static function get_acf_block_fields( string $block_name ): array {
		static $field_cache = array();

		if ( isset( $field_cache[ $block_name ] ) ) {
			return $field_cache[ $block_name ];
		}

		$field_cache[ $block_name ] = array();

		if ( ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
			return $field_cache[ $block_name ];
		}

		$field_groups = acf_get_field_groups( array( 'block' => $block_name ) );

		if ( ! is_array( $field_groups ) ) {
			return $field_cache[ $block_name ];
		}

		foreach ( $field_groups as $field_group ) {
			if ( ! is_array( $field_group ) ) {
				continue;
			}

			$group_fields = acf_get_fields( $field_group );

			if ( ! is_array( $group_fields ) ) {
				continue;
			}

			foreach ( $group_fields as $group_field ) {
				if ( is_array( $group_field ) ) {
					$field_cache[ $block_name ][] = $group_field;
				}
			}
		}

		return $field_cache[ $block_name ];
	}

	/**
	 * Uses destination location rules and first-name resolution so restore and preview agree.
	 *
	 * @param string $post_type Destination post type (create mode).
	 * @param int    $post_id   Destination post ID for update imports, 0 for create.
	 * @return array<string, array> Map of field name => field definition.
	 */
	private static function get_destination_acf_post_fields( string $post_type, int $post_id ): array {
		if ( ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
			return array();
		}

		$field_groups = $post_id > 0
			? acf_get_field_groups( array( 'post_id' => $post_id ) )
			: acf_get_field_groups( array( 'post_type' => $post_type ) );

		if ( ! is_array( $field_groups ) ) {
			return array();
		}

		$fields_by_name = array();

		foreach ( $field_groups as $field_group ) {
			if ( ! is_array( $field_group ) ) {
				continue;
			}

			$group_fields = acf_get_fields( $field_group );

			if ( ! is_array( $group_fields ) ) {
				continue;
			}

			foreach ( $group_fields as $group_field ) {
				if ( ! is_array( $group_field ) || ! isset( $group_field['name'] ) || ! is_string( $group_field['name'] ) || '' === $group_field['name'] ) {
					continue;
				}

				if ( ! isset( $fields_by_name[ $group_field['name'] ] ) ) {
					$fields_by_name[ $group_field['name'] ] = $group_field;
				}
			}
		}

		return $fields_by_name;
	}

	/**
	 * Resolves ACF destination fields from the same pre-write target plan as preview.
	 *
	 * @param array $manifest    Normalized manifest.
	 * @param array $target_plan Resolved target plan from resolve_target_plan().
	 * @return array<string, array> Map of field name => field definition.
	 */
	private static function destination_acf_post_fields( array $manifest, array $target_plan ): array {
		if ( ! isset( $manifest['acf_post_fields'] ) || ! is_array( $manifest['acf_post_fields'] ) || array() === $manifest['acf_post_fields'] ) {
			return array();
		}

		$target_post = isset( $target_plan['target_post'] ) && $target_plan['target_post'] instanceof WP_Post ? $target_plan['target_post'] : null;

		if ( $target_post instanceof WP_Post ) {
			return self::get_destination_acf_post_fields( $target_post->post_type, $target_post->ID );
		}

		$post_type = isset( $manifest['post']['post_type'] ) && is_string( $manifest['post']['post_type'] ) ? $manifest['post']['post_type'] : '';

		return self::get_destination_acf_post_fields( $post_type, 0 );
	}

	/**
	 * Remaps only typed ACF media and URL values; other field data passes through unchanged.
	 *
	 * @param mixed $value      Raw field value from the manifest.
	 * @param array $field      Target-site ACF field definition.
	 * @param array $id_map     Map of old attachment ID => new attachment ID.
	 * @param array $manifest   Normalized manifest (old URLs, source host).
	 * @param int   $depth      Current recursion depth (guard).
	 * @return mixed Remapped value.
	 */
	private static function remap_acf_field_value( $value, array $field, array $id_map, array $manifest, int $depth ) {
		if ( self::MAX_REMAP_DEPTH < $depth ) {
			return $value;
		}

		$field_type = isset( $field['type'] ) && is_string( $field['type'] ) ? $field['type'] : '';

		switch ( $field_type ) {
			case 'image':
			case 'file':
				if ( is_int( $value ) || ( is_string( $value ) && ctype_digit( $value ) ) ) {
					$old_id = (int) $value;

					if ( isset( $id_map[ $old_id ] ) ) {
						return is_string( $value ) ? (string) $id_map[ $old_id ] : $id_map[ $old_id ];
					}

					return $value;
				}

				if ( is_float( $value ) && floor( $value ) === $value ) {
					$old_id = (int) $value;

					if ( isset( $id_map[ $old_id ] ) ) {
						return $id_map[ $old_id ];
					}

					return $value;
				}

				if ( is_string( $value ) ) {
					return self::rewrite_acf_string( $value, $manifest, $id_map );
				}

				if ( is_array( $value ) ) {
					$value = self::remap_acf_attachment_array_id( $value, $id_map );

					return self::remap_acf_url_value( $value, $manifest, $id_map, $depth + 1 );
				}

				return $value;
			case 'gallery':
				if ( is_int( $value ) || ( is_string( $value ) && ctype_digit( $value ) ) ) {
					$old_id = (int) $value;

					if ( isset( $id_map[ $old_id ] ) ) {
						return is_string( $value ) ? (string) $id_map[ $old_id ] : $id_map[ $old_id ];
					}

					return $value;
				}

				if ( is_float( $value ) && floor( $value ) === $value ) {
					$old_id = (int) $value;

					if ( isset( $id_map[ $old_id ] ) ) {
						return $id_map[ $old_id ];
					}

					return $value;
				}

				if ( is_string( $value ) ) {
					return self::rewrite_acf_string( $value, $manifest, $id_map );
				}

				if ( ! is_array( $value ) ) {
					return $value;
				}

				foreach ( $value as $position => $gallery_item ) {
					if ( is_int( $gallery_item ) || ( is_string( $gallery_item ) && ctype_digit( $gallery_item ) ) ) {
						$old_id = (int) $gallery_item;

						if ( isset( $id_map[ $old_id ] ) ) {
							$value[ $position ] = is_string( $gallery_item ) ? (string) $id_map[ $old_id ] : $id_map[ $old_id ];
						}
					} elseif ( is_float( $gallery_item ) && floor( $gallery_item ) === $gallery_item ) {
						$old_id = (int) $gallery_item;

						if ( isset( $id_map[ $old_id ] ) ) {
							$value[ $position ] = $id_map[ $old_id ];
						}
					} elseif ( is_string( $gallery_item ) ) {
						$value[ $position ] = self::rewrite_acf_string( $gallery_item, $manifest, $id_map );
					} elseif ( is_array( $gallery_item ) ) {
						$value[ $position ] = self::remap_acf_url_value( self::remap_acf_attachment_array_id( $gallery_item, $id_map ), $manifest, $id_map, $depth + 1 );
					}
				}

				return $value;
			case 'icon_picker':
				if ( ! is_array( $value ) ) {
					if ( is_string( $value ) ) {
						return self::rewrite_acf_string( $value, $manifest, $id_map );
					}

					return $value;
				}

				$icon_type  = isset( $value['type'] ) && is_string( $value['type'] ) ? $value['type'] : '';
				$icon_value = array_key_exists( 'value', $value ) ? $value['value'] : null;

				if ( 'media_library' === $icon_type ) {
					if ( is_int( $icon_value ) || ( is_string( $icon_value ) && ctype_digit( $icon_value ) ) ) {
						$old_id = (int) $icon_value;

						if ( isset( $id_map[ $old_id ] ) ) {
							$value['value'] = is_string( $icon_value ) ? (string) $id_map[ $old_id ] : $id_map[ $old_id ];
						}
					} elseif ( is_float( $icon_value ) && floor( $icon_value ) === $icon_value ) {
						$old_id = (int) $icon_value;

						if ( isset( $id_map[ $old_id ] ) ) {
							$value['value'] = $id_map[ $old_id ];
						}
					} elseif ( is_string( $icon_value ) ) {
						$value['value'] = self::rewrite_acf_string( $icon_value, $manifest, $id_map );
					}
				} elseif ( 'url' === $icon_type && is_string( $icon_value ) ) {
					$value['value'] = self::rewrite_acf_string( $icon_value, $manifest, $id_map );
				} else {
					return self::remap_acf_url_value( $value, $manifest, $id_map, $depth + 1 );
				}

				return $value;
			case 'group':
			case 'clone':
				$sub_fields = self::acf_sub_fields( $field );

				if ( array() === $sub_fields || ! is_array( $value ) ) {
					return $value;
				}

				foreach ( $sub_fields as $sub_field ) {
					if ( ! is_array( $sub_field ) ) {
						continue;
					}

					$used_key = self::acf_matching_value_key( $value, $sub_field, true );

					if ( null === $used_key ) {
						continue;
					}

					$value[ $used_key ] = self::remap_acf_field_value( $value[ $used_key ], $sub_field, $id_map, $manifest, $depth + 1 );
				}

				return $value;
			case 'repeater':
				$sub_fields = self::acf_sub_fields( $field );

				if ( array() === $sub_fields || ! is_array( $value ) ) {
					return $value;
				}

				foreach ( $value as $row_index => $row ) {
					if ( ! is_array( $row ) ) {
						continue;
					}

					foreach ( $sub_fields as $sub_field ) {
						if ( ! is_array( $sub_field ) ) {
							continue;
						}

						$used_key = self::acf_matching_value_key( $row, $sub_field );

						if ( null === $used_key ) {
							continue;
						}

						$row[ $used_key ] = self::remap_acf_field_value( $row[ $used_key ], $sub_field, $id_map, $manifest, $depth + 1 );
					}

					$value[ $row_index ] = $row;
				}

				return $value;
			case 'flexible_content':
				if ( ! is_array( $value ) ) {
					return $value;
				}

				$layouts = isset( $field['layouts'] ) && is_array( $field['layouts'] ) ? $field['layouts'] : array();

				foreach ( $value as $row_index => $row ) {
					if ( ! is_array( $row ) ) {
						continue;
					}

					$layout_name = isset( $row['acf_fc_layout'] ) && is_string( $row['acf_fc_layout'] ) ? $row['acf_fc_layout'] : '';

					if ( '' === $layout_name ) {
						$value[ $row_index ] = self::remap_acf_url_value( $row, $manifest, $id_map, $depth + 1 );
						continue;
					}

					$layout_fields = null;

					foreach ( $layouts as $layout ) {
						if ( is_array( $layout ) && isset( $layout['name'] ) && $layout_name === $layout['name'] && isset( $layout['sub_fields'] ) && is_array( $layout['sub_fields'] ) ) {
							$layout_fields = $layout['sub_fields'];
							break;
						}
					}

					if ( ! is_array( $layout_fields ) ) {
						continue;
					}

					foreach ( $layout_fields as $sub_field ) {
						if ( ! is_array( $sub_field ) ) {
							continue;
						}

						$used_key = self::acf_matching_value_key( $row, $sub_field );

						if ( null === $used_key ) {
							continue;
						}

						$row[ $used_key ] = self::remap_acf_field_value( $row[ $used_key ], $sub_field, $id_map, $manifest, $depth + 1 );
					}

					$value[ $row_index ] = $row;
				}

				return $value;
			case 'text':
			case 'textarea':
			case 'wysiwyg':
			case 'url':
			case 'link':
			case 'oembed':
			case 'email':
			case 'page_link':
				return self::remap_acf_url_value( $value, $manifest, $id_map, $depth + 1 );
			default:
				return $value;
		}
	}

	/**
	 * ACF normalizes array media through uppercase ID, which must also be remapped.
	 *
	 * @param array $value  Array-shaped field value or gallery item.
	 * @param array $id_map Map of old attachment ID => new attachment ID.
	 * @return array Value with the ID key remapped.
	 */
	private static function remap_acf_attachment_array_id( array $value, array $id_map ): array {
		if ( isset( $value['ID'] ) && ( is_int( $value['ID'] ) || ( is_string( $value['ID'] ) && ctype_digit( $value['ID'] ) ) ) ) {
			$old_id = (int) $value['ID'];

			if ( isset( $id_map[ $old_id ] ) ) {
				$value['ID'] = is_string( $value['ID'] ) ? (string) $id_map[ $old_id ] : $id_map[ $old_id ];
			}
		}

		return $value;
	}

	/**
	 * Rewrites URL strings without treating post, term or user IDs as media.
	 *
	 * @param mixed $value    Field value of any shape.
	 * @param array $manifest Normalized manifest (old URLs, source host).
	 * @param array $id_map   Map of old attachment ID => new attachment ID.
	 * @param int   $depth    Current recursion depth (guard).
	 * @return mixed Value with URLs rewritten.
	 */
	private static function remap_acf_url_value( $value, array $manifest, array $id_map, int $depth ) {
		if ( self::MAX_REMAP_DEPTH < $depth ) {
			return $value;
		}

		if ( is_string( $value ) ) {
			return self::rewrite_acf_string( $value, $manifest, $id_map );
		}

		if ( ! is_array( $value ) ) {
			return $value;
		}

		foreach ( $value as $key => $nested ) {
			$value[ $key ] = self::remap_acf_url_value( $nested, $manifest, $id_map, $depth + 1 );
		}

		return $value;
	}

	/**
	 * Applies the media-URL, wp-image-class, and source-host rewrites to one string.
	 *
	 * @param string $text     String possibly containing upload URLs.
	 * @param array  $manifest Normalized manifest (old URLs, source host).
	 * @param array  $id_map   Map of old attachment ID => new attachment ID.
	 * @return string Rewritten string.
	 */
	private static function rewrite_acf_string( string $text, array $manifest, array $id_map ): string {
		if ( '' === $text ) {
			return $text;
		}

		$rewritten = self::rewrite_media_urls( $text, $manifest, $id_map );
		$rewritten = self::rewrite_wp_image_classes( $rewritten, $id_map );

		return self::rewrite_source_host( $rewritten, $manifest );
	}

	/**
	 * Returns a container field's sub-fields, loading them when needed.
	 *
	 * @param array $field ACF field definition.
	 * @return array List of sub-field arrays.
	 */
	private static function acf_sub_fields( array $field ): array {
		if ( isset( $field['sub_fields'] ) && is_array( $field['sub_fields'] ) && array() !== $field['sub_fields'] ) {
			return $field['sub_fields'];
		}

		if ( function_exists( 'acf_get_fields' ) ) {
			$loaded = acf_get_fields( $field );

			if ( is_array( $loaded ) ) {
				return $loaded;
			}
		}

		return array();
	}

	/**
	 * Finds the array key holding a sub-field's value (key first, then name).
	 *
	 * @param array $values    Container value array.
	 * @param array $sub_field Sub-field definition.
	 * @param bool  $original_name Group/clone providers use the unprefixed name.
	 * @return string|null Matching key, or null when absent.
	 */
	private static function acf_matching_value_key( array $values, array $sub_field, bool $original_name = false ): ?string {
		$sub_key  = isset( $sub_field['key'] ) && is_string( $sub_field['key'] ) ? $sub_field['key'] : '';
		$name     = $original_name ? ( $sub_field['_name'] ?? $sub_field['name'] ?? '' ) : ( $sub_field['name'] ?? '' );
		$sub_name = is_string( $name ) ? $name : '';

		if ( '' !== $sub_key && array_key_exists( $sub_key, $values ) ) {
			return $sub_key;
		}

		if ( '' !== $sub_name && array_key_exists( $sub_name, $values ) ) {
			return $sub_name;
		}

		return null;
	}

	/**
	 * Writes metadata only on new attachments; omitted values retain sideload defaults.
	 *
	 * @param int   $attachment_id Newly created attachment ID.
	 * @param array $media_entry Manifest media entry.
	 * @return array List of failed writes; unchanged values are successful.
	 */
	private static function apply_media_meta( int $attachment_id, array $media_entry ): array {
		$errors = array();
		// WordPress unslashes these writes; ACF has a separate persistence contract.
		if ( isset( $media_entry['alt'] ) && is_string( $media_entry['alt'] ) && '' !== $media_entry['alt'] ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', wp_slash( $media_entry['alt'] ) );
			// Write booleans cannot distinguish unchanged values or filtered success; verify storage.
			if ( get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) !== $media_entry['alt'] ) {
				$errors[] = sprintf(
					/* translators: %d: attachment ID. */
					__( 'Media file %d: alt text could not be saved.', 'pageferry' ),
					$attachment_id
				);
			}
		}

		$post_update = array( 'ID' => $attachment_id );

		if ( isset( $media_entry['caption'] ) && is_string( $media_entry['caption'] ) && '' !== $media_entry['caption'] ) {
			$post_update['post_excerpt'] = $media_entry['caption'];
		}

		if ( isset( $media_entry['title'] ) && is_string( $media_entry['title'] ) && '' !== $media_entry['title'] ) {
			$post_update['post_title'] = $media_entry['title'];
		}

		if ( isset( $media_entry['description'] ) && is_string( $media_entry['description'] ) && '' !== $media_entry['description'] ) {
			$post_update['post_content'] = $media_entry['description'];
		}

		if ( 1 < count( $post_update ) ) {
			$result = wp_update_post( wp_slash( $post_update ), true );
			if ( is_wp_error( $result ) ) {
				$errors[] = sprintf(
					/* translators: 1: attachment ID, 2: WordPress failure message. */
					__( 'Media file %1$d: its details could not be saved: %2$s', 'pageferry' ),
					$attachment_id,
					$result->get_error_message()
				);
			} else {
				$stored_post = get_post( $attachment_id );
				foreach ( $post_update as $field => $expected ) {
					if ( 'ID' !== $field && ( ! $stored_post instanceof WP_Post || $stored_post->$field !== $expected ) ) {
						$errors[] = sprintf(
							/* translators: 1: attachment ID, 2: post field name. */
							__( 'Media file %1$d: %2$s was not saved as requested.', 'pageferry' ),
							$attachment_id,
							$field
						);
					}
				}
			}
		}
		return $errors;
	}

	/**
	 * Keeps pre-overwrite snapshots without pruning so failures cannot evict existing recovery.
	 *
	 * @param array $state Fresh state that passed the confirmation check.
	 * @return string|null Verified backup reference, or null on lock/write failure.
	 */
	private static function snapshot_post( array $state ): ?string {
		$backup_key = 'pf-' . gmdate( 'YmdHis' ) . '-' . $state['post_id'] . '-' . wp_generate_password( 6, false );
		$saved      = PageFerry_Backups::save( $backup_key, array_merge( array( 'time' => gmdate( 'c' ) ), $state ) );
		return $saved ? $backup_key : null;
	}

	/**
	 * Captures every term relationship the import can overwrite, with readable IDs, names and slugs.
	 *
	 * @param WP_Post $target_post Post about to be overwritten.
	 * @return array<string, array<int, array{id: int, name: string, slug: string}>> Terms per taxonomy.
	 */
	private static function snapshot_post_terms( WP_Post $target_post ): array {
		$taxonomy_slugs = array_unique(
			array_merge(
				array( 'category', 'post_tag' ),
				get_object_taxonomies( $target_post->post_type, 'names' )
			)
		);

		$captured = array();

		foreach ( $taxonomy_slugs as $taxonomy_slug ) {
			if ( '' === $taxonomy_slug || ! taxonomy_exists( $taxonomy_slug ) ) {
				continue;
			}

			$object_terms = wp_get_object_terms( $target_post->ID, $taxonomy_slug );

			if ( is_wp_error( $object_terms ) ) {
				$captured[ $taxonomy_slug ] = array();
				continue;
			}

			$described = array();

			foreach ( $object_terms as $object_term ) {
				if ( ! $object_term instanceof WP_Term ) { // @phpstan-ignore instanceof.alwaysTrue
					continue;
				}

				$described[] = array(
					'id'   => (int) $object_term->term_id,
					'name' => $object_term->name,
					'slug' => $object_term->slug,
				);
			}

			$captured[ $taxonomy_slug ] = $described;
		}

		return $captured;
	}

	/**
	 * Caps backup history at MAX_BACKUPS, oldest first.
	 *
	 * @return void
	 */
	private static function prune_backups(): void {
		PageFerry_Backups::remove();
	}

	/**
	 * Drops a snapshot when import aborts before overwrite.
	 *
	 * @param string|null $backup_reference Backup key or null.
	 * @return void
	 */
	private static function forget_backup( ?string $backup_reference ): void {
		if ( null === $backup_reference ) {
			return;
		}

		PageFerry_Backups::remove( $backup_reference );
	}

	/**
	 * Coordinates authoritative option updates; auxiliary-store failures do not roll back the saved
	 * page.
	 *
	 * @param string   $option Option name.
	 * @param callable $mutation Transformation of the current array.
	 * @return bool Whether the intended array is persisted.
	 */
	private static function mutate_shared_option( string $option, callable $mutation ): bool {
		global $wpdb;
		static $held = array();
		$lock_name   = 'pageferry-option-' . substr( hash( 'sha256', (string) constant( 'DB_NAME' ) . ':' . $wpdb->options . ':' . $option ), 0, 47 );
		$acquired    = ! isset( $held[ $lock_name ] ) && '1' === (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $lock_name ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- connection-owned synchronization primitive.
		if ( ! $acquired ) {
			return false;
		}
		$held[ $lock_name ] = true;
		try {
			$current = self::read_stored_shared_option( $option );
			if ( null === $current ) {
				return false;
			}
			$updated = $mutation( $current );
			if ( $updated === $current ) {
				return true;
			}
			self::clear_shared_option_cache( $option );
			update_option( $option, $updated, false );
			return self::read_stored_shared_option( $option ) === $updated;
		} finally {
			self::clear_shared_option_cache( $option );
			unset( $held[ $lock_name ] );
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- release only this connection's option lock.
		}
	}

	/**
	 * Reads actual stored log/hash arrays, bypassing option caches and filters.
	 *
	 * @param string $option Option name.
	 * @return array|null Stored array, or null on database read failure.
	 */
	private static function read_stored_shared_option( string $option ): ?array {
		global $wpdb;
		$value = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $option ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- authoritative mutation read, not a cached display query.
		if ( '' !== $wpdb->last_error ) {
			return null;
		}
		$value = maybe_unserialize( $value );
		return is_array( $value ) ? $value : array();
	}

	/**
	 * Invalidates individual, legacy autoloaded and negative option caches.
	 *
	 * @param string $option Option name.
	 */
	private static function clear_shared_option_cache( string $option ): void {
		wp_cache_delete( $option, 'options' );
		wp_cache_delete( 'alloptions', 'options' );
		wp_cache_delete( 'notoptions', 'options' );
	}

	/**
	 * Appends one plain-language row to the import log option.
	 *
	 * @param array $row Log row.
	 * @return bool Whether the row is persisted.
	 */
	private static function append_log( array $row ): bool {
		return self::mutate_shared_option(
			self::LOG_OPTION,
			static function ( array $log_rows ) use ( $row ): array {
				$log_rows[] = $row;
				return self::MAX_LOG_ROWS < count( $log_rows ) ? array_slice( $log_rows, -self::MAX_LOG_ROWS ) : $log_rows;
			}
		);
	}

	/**
	 * Records one verified sha256 → attachment ID mapping.
	 *
	 * @param string $sha256 Content hash.
	 * @param int    $attachment_id Attachment ID.
	 * @return bool Whether the mapping is persisted.
	 */
	private static function remember_hash( string $sha256, int $attachment_id ): bool {
		return self::remember_hashes( array( $sha256 => $attachment_id ) );
	}

	/**
	 * Flushes hashes once, pruning unreadable rows and then the oldest excess entries.
	 *
	 * @param array<string, int> $hashes Verified mappings.
	 * @return bool Whether the pruned merged array is persisted.
	 */
	private static function remember_hashes( array $hashes ): bool {
		if ( array() === $hashes ) {
			return true;
		}
		return self::mutate_shared_option(
			self::HASH_INDEX_OPTION,
			static function ( array $hash_index ) use ( $hashes ): array {
				foreach ( $hashes as $sha256 => $attachment_id ) {
					$hash_index[ $sha256 ] = $attachment_id;
				}
				if ( self::HASH_PRUNE_THRESHOLD < count( $hash_index ) ) {
					foreach ( $hash_index as $indexed_hash => $indexed_id ) {
						if ( isset( $hashes[ $indexed_hash ] ) ) {
							continue;
						}
						$indexed_file = get_attached_file( (int) $indexed_id );
						if ( ! is_string( $indexed_file ) || ! is_readable( $indexed_file ) ) {
							unset( $hash_index[ $indexed_hash ] );
						}
					}
					if ( self::MAX_HASH_ROWS < count( $hash_index ) ) {
						$hash_index = array_slice( $hash_index, -self::MAX_HASH_ROWS, null, true );
					}
				}
				return $hash_index;
			}
		);
	}
}
