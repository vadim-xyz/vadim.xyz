=== PageFerry – Move a Page from Staging to Production ===
Contributors: pageferry
Tags: staging, migration, export, import, gutenberg
Requires at least: 6.5
Tested up to: 6.8
Requires PHP: 8.1
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Ferry a page from staging to production — media included.

== Description ==

PageFerry exports a single Gutenberg page, post, or custom post type (content + manifest + media) to a ZIP file on staging, then imports it on production with correct block-level attachment remapping, slug + taxonomy preservation (categories, tags, and custom taxonomies), domain rewrite, hash-based media dedup, and update-in-place.

Free scope (Gutenberg-only): export/import via ZIP for pages, posts, and block-editor custom post types; featured + inline images; slug + categories/tags/custom taxonomies; basic staging→prod domain rewrite; existing-media reuse; create-new or update-selected; land-as-draft option; pre-import backup of overwritten content + plain-language log.

Explicit v1 non-goals: builders (detect + refuse with a clear message), ACF/SEO meta beyond pass-through (exception: ACF blocks that store their fields in post meta via `usePostMeta` ferry their values with media-ID remap — see FAQ), bulk, direct push-without-ZIP, multisite.

Small ZIPs import in one upload. Larger bundles (over your host's per-upload limit) import file-by-file through an in-browser worker (bundled JavaScript, no extra service): the same dedupe/remap/create result either way. A single asset larger than the limit cannot import — the error names the file.

== Installation ==

1. Upload `pageferry` to `/wp-content/plugins/`, activate.
2. Staging: open a page → PageFerry Export → Ferry this page → download ZIP.
3. Production: Tools → PageFerry Import → upload ZIP → choose create-new or update-selected → Upload and preview → Confirm import.
4. Completed imports record one row each under Tools → PageFerry Import → Logs; pre-overwrite snapshots list under Backups.

Requires: WordPress 6.5+, PHP 8.1+, PHP zip extension (for the export side).

== Frequently Asked Questions ==

= Why was my Elementor page refused? =

PageFerry v1 imports Gutenberg pages only. The exporter detects page-builder meta (Elementor, Divi, Beaver Builder, Bricks, WPBakery) and records it in the bundle; the importer refuses the bundle with a message naming the builder instead of silently corrupting the layout. Export your content as Gutenberg blocks (or rebuild the page in the block editor) and ferry again. Builder support is planned after v1.

= How does media dedup work? =

Every media file is hashed (SHA-256) at export. On import, PageFerry looks the hash up in its reuse index and verifies the match by re-hashing the existing attachment — a stale index row never reuses a deleted file. Identical bytes reuse the existing attachment; same filename with different bytes uploads separately. The confirmation screen reports reused-vs-new counts, and the Logs tab records them per import.

= Update vs create — which is used? =

You choose on the import screen. Create-new (default) inserts the content as a draft with a unique slug (a clash gets a `-2` suffix plus a notice). Update-selected overwrites the target's content, excerpt, terms, and featured image after snapshotting the prior content + meta into Backups and writing a log row. Terms (categories, tags, and custom taxonomies) match by name: existing terms are reused as-is (their current parents are kept, never restructured); only new terms are created with their exported hierarchy. The imported post type must be registered on the production site (activate the plugin or theme that provides the custom post type first). There is no one-click rollback in v1 — restore from the Backups tab by pasting the stored content back.

= Where is my pre-import backup? =

Tools → PageFerry Import → Backups. Each update-selected import stores the target's prior content and meta under a `pf-*` key before writing anything (kept: last 20). The Logs tab links each update row to its backup key.

= The import says a file is too large. What now? =

Your host caps each upload (`upload_max_filesize`). Bundles over that cap import file-by-file automatically — but one single asset over the cap cannot. Raise the PHP upload limit, or drop that asset from the page and re-export. The error names the file.

= Does PageFerry ferry ACF block data? =

Blocks that keep their field data in the block comment (the ACF default) ferry like any other blocks: media IDs remap, everything else passes through. Blocks that store their fields in post meta (`usePostMeta`, ACF PRO 6.3+) ferry their field values too: image/file/gallery IDs remap to the new attachments, upload URLs rewrite, all other values restore verbatim through the ACF API. Two limits apply: reference fields (post/relationship/taxonomy/user/page-link IDs) point at source-site content and ferry verbatim — the export warns when they hold values — and on update-selected imports, fields unset on the source keep the target's existing values.

= Does PageFerry phone home or load remote code? =

No. v1 makes no outbound requests, loads no CDN scripts, and runs with no account or license key. All JavaScript (including the large-bundle worker dependency fflate 0.8.3, MIT) ships inside the plugin. Import/export handlers require the `import` / `edit_post` capabilities plus nonces.

== Changelog ==

= 1.1.0 =
* Custom post types (block-editor) and custom taxonomies: the export metabox appears on every Gutenberg-edited post type, bundles carry all attached taxonomies, and the importer recreates the post type + term hierarchy on production (the post type must be registered there first).
* ACF `usePostMeta` blocks: field values stored in post meta now ferry in the bundle (`acf_post_meta`) and restore on import with media-ID remap and URL rewrite, written back through the ACF API. Skipped values are reported in the import log row (`acf_skipped`); reference-type IDs ferry verbatim (export warns).

= 1.0.0 =
* First release: ferry a Gutenberg page or post with its media as a single ZIP bundle — export with manifest, import with block-level attachment remap, URL + domain rewrite, SHA-256 media dedup, slug + category/tag preservation, create-new or update-selected, land-as-draft, pre-import backup plus plain-language log. Builder-marked bundles refuse with a clear message.
