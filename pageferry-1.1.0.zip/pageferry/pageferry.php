<?php
/**
 * Plugin Name: PageFerry – Move a Page from Staging to Production
 * Plugin URI:  https://example.com/pageferry
 * Description: Ferry a page from staging to production — media included. Export a single Gutenberg page, post, or custom post type to ZIP, import it elsewhere with correct attachment remapping.
 * Version:     1.1.0
 * Requires at least: 6.5
 * Requires PHP: 8.1
 * Author:      PageFerry
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: pageferry
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

define( 'PAGEFERRY_VERSION', '1.1.0' );
define( 'PAGEFERRY_FILE', __FILE__ );
define( 'PAGEFERRY_DIR', plugin_dir_path( __FILE__ ) );

require_once PAGEFERRY_DIR . 'includes/class-pageferry.php';

add_action( 'plugins_loaded', array( 'PageFerry', 'init' ) );
register_activation_hook( __FILE__, array( 'PageFerry', 'activate' ) );
