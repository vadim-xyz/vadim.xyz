/**
 * PageFerry import Web Worker (Path B, large bundles).
 *
 * Runs off the main thread. Receives the ZIP File via structured clone,
 * extracts it with the vendored fflate (importScripts — no build step; the
 * async unzip APIs offload inflate to their own workers), and posts the
 * manifest plus each media file's bytes back. The main thread owns all REST
 * traffic (retry, resume via the received-map, progress UI).
 *
 * Relies on ../vendor/fflate.min.js exposing the global `fflate`.
 */

/* global fflate, self */

self.onmessage = function (event) {
	var file = event.data && event.data.file;

	if (!(file instanceof Blob)) {
		self.postMessage({ type: 'error', message: 'The worker needs the ZIP file.' });
		return;
	}

	file.arrayBuffer().then(function (buffer) {
		var entries;
		var filter = function (entry) {
			if (entry.name === 'pageferry-manifest.json') {
				return true;
			}
			return entry.name.indexOf('media/') === 0;
		};

		try {
			// fflate 0.8.3: unzipSync(data, { filter }) returns name → Uint8Array.
			entries = fflate.unzipSync(new Uint8Array(buffer), { filter: filter });
		} catch (error) {
			self.postMessage({ type: 'error', message: 'That ZIP could not be extracted in the browser. It may be corrupt.' });
			return;
		}

		var manifestBytes = entries['pageferry-manifest.json'];

		if (!manifestBytes) {
			self.postMessage({ type: 'error', message: 'pageferry-manifest.json is missing from that ZIP.' });
			return;
		}

		var manifest;
		try {
			manifest = JSON.parse(fflate.strFromU8(manifestBytes));
		} catch (error) {
			self.postMessage({ type: 'error', message: 'The manifest in that ZIP is not valid JSON.' });
			return;
		}

		var names = Object.keys(entries).filter(function (name) {
			return name !== 'pageferry-manifest.json';
		});

		var files = names.map(function (name) {
			// Basename only: the server accepts manifest-declared basenames,
			// so zip-slip is impossible server-side even for hostile entries.
			var basename = name.split('/').pop();
			return { name: basename, data: entries[name].buffer };
		});

		// The main thread listens for 'manifest'.
		self.postMessage({ type: 'manifest', manifest: manifest, files: files });

		names.forEach(function (name, index) {
			self.postMessage({ type: 'progress', done: index + 1, total: names.length });
		});
	});
};
