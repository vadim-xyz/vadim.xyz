/**
 * PageFerry large-bundle import handoff (Path B).
 *
 * Vanilla JS, no build step. When the chosen ZIP exceeds pageferryImport.maxBytes,
 * this script reveals the worker UI, extracts the archive inside a Web Worker
 * (vendored fflate, structured-clone File — FormData is NOT cloneable), and
 * uploads each media file individually through the pageferry/v1 REST session:
 * validate (manifest JSON only) → per-file uploads → commit (dry-run preview,
 * then confirmed execute). Per-file progress + retry via postMessage.
 *
 * Path A (ZIP within the limit) never reaches this script: the server-rendered
 * form posts the ZIP directly and works with JS disabled.
 */
(function () {
	'use strict';

	var form = document.querySelector('form input[name="pageferry_zip"]');
	var workerUI = document.getElementById('pageferry-worker-ui');
	var progress = document.getElementById('pageferry-worker-progress');
	var status = document.getElementById('pageferry-worker-status');

	if (!form || !workerUI || !progress || !status) {
		return;
	}

	var fileInput = form;
	var uploadForm = fileInput.closest('form');

	if (!uploadForm) {
		return;
	}

	function setStatus(message) {
		status.textContent = message;
	}

	function setProgress(done, total) {
		progress.max = total > 0 ? total : 100;
		progress.value = done;
	}

	function restUrl(path) {
		var root = window.pageferryImport.restRoot || '/wp-json/';
		if (root.charAt(root.length - 1) !== '/') {
			root += '/';
		}
		var namespace = window.pageferryImport.namespace || 'pageferry/v1';
		return root + namespace + path;
	}

	function restHeaders(extra) {
		var headers = { 'X-WP-Nonce': window.pageferryImport.nonce };
		if (extra) {
			for (var key in extra) {
				if (Object.prototype.hasOwnProperty.call(extra, key)) {
					headers[key] = extra[key];
				}
			}
		}
		return headers;
	}

	// Commit confirmation via wp.i18n when available (the script declares
	// the wp-i18n dependency and PHP loads its translations), with an
	// English fallback so Path B still works without it.
	function confirmImport(preview) {
		var i18n = window.wp && window.wp.i18n ? window.wp.i18n : null;

		if (i18n && typeof i18n.__ === 'function' && typeof i18n.sprintf === 'function') {
			return window.confirm(
				i18n.sprintf(
					i18n.__('Will %1$s "%2$s" (slug %3$s) with %4$d new media (%5$d reused). Proceed?', 'pageferry'),
					'update' === preview.target ? i18n.__('update', 'pageferry') : i18n.__('create', 'pageferry'),
					preview.title,
					preview.slug,
					preview.media_new,
					preview.reused
				)
			);
		}

		return window.confirm(
			'Will ' + ('update' === preview.target ? 'update' : 'create') + ' "' + preview.title + '" (slug ' + preview.slug + ') with ' +
			preview.media_new + ' new media (' + preview.reused + ' reused). Proceed?'
		);
	}

	function uploadOneFile(sessionId, name, buffer, attempt, displayName) {
		var blob = new Blob([buffer]);
		var data = new FormData();
		data.append('session_id', sessionId);
		data.append('file', blob, name);

		return fetch(restUrl('/import/file'), {
			method: 'POST',
			credentials: 'same-origin',
			headers: restHeaders(),
			body: data
		}).then(function (response) {
			if (!response.ok) {
				if (response.status >= 500 && attempt < 3) {
					return uploadOneFile(sessionId, name, buffer, attempt + 1, displayName);
				}
				throw new Error('Upload failed for ' + (displayName || name) + ' (HTTP ' + response.status + ').');
			}
			return response.json();
		});
	}

	function runWorkerPath(zipFile) {
		workerUI.hidden = false;
		setStatus('Extracting the ZIP in the browser…');

		var worker;
		try {
			worker = new Worker(window.pageferryImport.workerUrl);
		} catch (error) {
			setStatus('This browser blocked the import worker. Use a smaller ZIP or raise the upload limit.');
			return;
		}

		worker.onmessage = function (event) {
			var message = event.data || {};

			if (message.type === 'manifest') {
				setStatus('Manifest validated. Uploading media files…');
				startSession(message.manifest, message.files, worker);
			} else if (message.type === 'progress') {
				setProgress(message.done || 0, message.total || 1);
				setStatus('Extracted ' + (message.done || 0) + ' of ' + (message.total || 0) + ' files…');
			} else if (message.type === 'error') {
				setStatus(message.message || 'The worker could not read that ZIP.');
				worker.terminate();
			}
		};

		worker.onerror = function () {
			setStatus('The worker could not read that ZIP.');
			worker.terminate();
		};

		// Structured clone carries the File; FormData is NOT cloneable.
		worker.postMessage({ file: zipFile });
	}

	function startSession(manifest, files, worker) {
		fetch(restUrl('/import/validate'), {
			method: 'POST',
			credentials: 'same-origin',
			headers: restHeaders({ 'Content-Type': 'application/json' }),
			body: JSON.stringify({ manifest: manifest })
		})
			.then(function (response) {
				return response.json().then(function (body) {
					return { ok: response.ok, status: response.status, body: body };
				});
			})
			.then(function (result) {
				if (!result.ok) {
					throw new Error((result.body && result.body.message) || 'The server refused the manifest (HTTP ' + result.status + ').');
				}

			var sessionId = result.body.session_id;
			var received = {};
			(result.body.received || []).forEach(function (name) {
				received[name] = true;
			});

			// Transport keys stay zip basenames; the status line shows the
			// original media-library name from the manifest when known.
			var displayNames = {};
			(manifest.media || []).forEach(function (entry) {
				if (entry && typeof entry.file === 'string') {
					var zipBase = entry.file.split('/').pop();
					displayNames[zipBase] = (typeof entry.filename === 'string' && entry.filename)
						? entry.filename.split('/').pop()
						: zipBase;
				}
			});
			files.forEach(function (entry) {
				entry.display = displayNames[entry.name] || entry.name;
			});

			var queue = files.filter(function (entry) {
				return !received[entry.name];
			});

				setProgress(files.length - queue.length, files.length);
				uploadQueue(sessionId, queue, files.length, worker);
			})
			.catch(function (error) {
				setStatus(error.message);
				worker.terminate();
			});
	}

	function uploadQueue(sessionId, queue, total, worker) {
		var next = queue.shift();

		if (!next) {
			setStatus('All files uploaded. Confirming import…');
			commitSession(sessionId, worker, false);
			return;
		}

		setStatus('Uploading ' + (next.display || next.name) + '…');

		uploadOneFile(sessionId, next.name, next.data, 1, next.display || next.name)
			.then(function () {
				setProgress(total - queue.length, total);
				uploadQueue(sessionId, queue, total, worker);
			})
			.catch(function (error) {
				setStatus(error.message + ' Resolve it, then re-pick the same ZIP to resume — received files are skipped.');
				worker.terminate();
			});
	}

	function commitSession(sessionId, worker, confirmed) {
		var target = uploadForm.querySelector('input[name="pageferry_target"]:checked');
		var targetPost = uploadForm.querySelector('select[name="pageferry_target_post"]');

		fetch(restUrl('/import/commit'), {
			method: 'POST',
			credentials: 'same-origin',
			headers: restHeaders({ 'Content-Type': 'application/json' }),
			body: JSON.stringify({
				session_id: sessionId,
				target: target && target.value === 'update' ? 'update' : 'create',
				target_post_id: targetPost ? targetPost.value : 0,
				confirm: confirmed
			})
		})
			.then(function (response) {
				return response.json().then(function (body) {
					return { ok: response.ok, status: response.status, body: body };
				});
			})
			.then(function (result) {
				if (!result.ok) {
					throw new Error((result.body && result.body.message) || 'Commit failed (HTTP ' + result.status + ').');
				}

			if (result.body.preview && !result.body.post_id) {
				var preview = result.body.preview;
				var ok = confirmImport(preview);

					if (ok) {
						commitSession(sessionId, worker, true);
					} else {
						setStatus('Import cancelled before any page was written.');
						worker.terminate();
					}
					return;
				}

				setProgress(1, 1);
				setStatus('Imported. Opening the result…');
				worker.terminate();

				if (result.body.edit_url) {
					window.location.href = result.body.edit_url;
				} else {
					window.location.reload();
				}
			})
			.catch(function (error) {
				setStatus(error.message);
				worker.terminate();
			});
	}

	fileInput.addEventListener('change', function () {
		var picked = fileInput.files && fileInput.files[0];

		if (!picked) {
			return;
		}

		if (picked.size <= window.pageferryImport.maxBytes) {
			workerUI.hidden = true;
			return;
		}

		if (typeof Worker === 'undefined' || typeof window.fflate === 'undefined') {
			setStatus('Large-bundle path needs Web Workers + the bundled fflate. Use a smaller ZIP or raise the upload limit.');
			workerUI.hidden = false;
			return;
		}

		runWorkerPath(picked);
	});

	uploadForm.addEventListener('submit', function (event) {
		var picked = fileInput.files && fileInput.files[0];

		if (picked && picked.size > window.pageferryImport.maxBytes) {
			// Path B handles the upload via REST; the classic POST would 413.
			event.preventDefault();
			runWorkerPath(picked);
		}
	});
})();
