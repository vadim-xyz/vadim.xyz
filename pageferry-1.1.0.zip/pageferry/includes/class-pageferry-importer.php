<?php
/**
 * Shared importer core for PageFerry.
 *
 * One dedupe/remap/create pipeline consumed by both transports: the classic
 * single-POST flow and the REST per-file flow each prepare a workspace (temp
 * dir with media files + a validated manifest array) and hand it to run().
 * Validate runs before ANY write; a failed or refused import cleans up
 * everything it created, leaving the database untouched.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/**
 * Validates manifests, dedupes media by content hash, remaps block IDs and
 * old URLs, and creates or updates the target page.
 *
 * Own option names live on PageFerry (OPTION_*); the constants below alias
 * them so existing call sites keep working unchanged.
 */
class PageFerry_Importer {

	/**
	 * Option holding the sha256 → attachment ID reuse index.
	 *
	 * Alias of PageFerry::OPTION_HASH_INDEX (canonical store).
	 *
	 * @var string
	 */
	const HASH_INDEX_OPTION = 'pageferry_hash_index';

	/**
	 * Option holding plain-language import log rows.
	 *
	 * Alias of PageFerry::OPTION_LOGS (canonical store).
	 *
	 * @var string
	 */
	const LOG_OPTION = 'pageferry_logs';

	/**
	 * Option holding pre-overwrite snapshots, keyed by import ID.
	 *
	 * Alias of PageFerry::OPTION_BACKUPS (canonical store).
	 *
	 * @var string
	 */
	const BACKUP_OPTION = 'pageferry_backups';

	/**
	 * Maximum pre-overwrite snapshots kept.
	 *
	 * @var int
	 */
	const MAX_BACKUPS = 20;

	/**
	 * Maximum import log rows kept (append_log prunes beyond this).
	 *
	 * @var int
	 */
	const MAX_LOG_ROWS = 200;

	/**
	 * Hash-index size that triggers a stale-row prune in remember_hash().
	 *
	 * @var int
	 */
	const HASH_PRUNE_THRESHOLD = 2000;

	/**
	 * Hard cap for the hash index; oldest rows are dropped beyond this.
	 *
	 * @var int
	 */
	const MAX_HASH_ROWS = 5000;

	/**
	 * Maximum media files staged from one ZIP (zip-bomb guard).
	 *
	 * @var int
	 */
	const MAX_WORKSPACE_FILES = 500;

	/**
	 * Fallback cap for total staged bytes when wp_max_upload_size() is 0
	 * (unlimited). Otherwise the cap is 2x the upload limit.
	 *
	 * @var int
	 */
	const MAX_WORKSPACE_BYTES_FALLBACK = 536870912;

	/**
	 * Transient prefix for Path B import sessions (validate→file→commit).
	 *
	 * Alias of PageFerry::TRANSIENT_SESSION_PREFIX (canonical store).
	 *
	 * @var string
	 */
	const SESSION_TRANSIENT_PREFIX = 'pageferry_session_';

	/**
	 * Transient prefix for the Path A two-step form stash.
	 *
	 * Alias of PageFerry::TRANSIENT_IMPORT_PREFIX (canonical store).
	 *
	 * @var string
	 */
	const IMPORT_TRANSIENT_PREFIX = 'pageferry_import_';

	/**
	 * Validates a decoded manifest without writing anything.
	 *
	 * @param mixed $manifest Decoded manifest (json_decode assoc array).
	 * @return array|WP_Error Array with manifest + media_index, or WP_Error.
	 */
	public static function validate( $manifest ) {
		if ( ! is_array( $manifest ) ) {
			return new WP_Error(
				'pageferry_manifest_invalid',
				__( 'PageFerry could not read the export manifest: expected a JSON object.', 'pageferry' )
			);
		}

		if ( isset( $manifest['plugin'] ) && 'pageferry' !== $manifest['plugin'] ) {
			return new WP_Error(
				'pageferry_manifest_plugin',
				__( 'PageFerry cannot import this bundle: it was not made by PageFerry.', 'pageferry' )
			);
		}

		$manifest_version = isset( $manifest['manifest_version'] ) ? (int) $manifest['manifest_version'] : 0;

		if ( 1 !== $manifest_version ) {
			return new WP_Error(
				'pageferry_manifest_version',
				sprintf(
					/* translators: %d: manifest version found in the bundle. */
					__( 'PageFerry cannot import this bundle (manifest version %d). It was made by a newer PageFerry — update this site first.', 'pageferry' ),
					$manifest_version
				)
			);
		}

		if ( ! empty( $manifest['builder_detected'] ) && is_string( $manifest['builder_detected'] ) ) {
			return new WP_Error(
				'pageferry_builder_detected',
				sprintf(
					/* translators: %s: builder slug recorded in the manifest. */
					__( 'PageFerry v1 imports Gutenberg pages only — this bundle was built with %s. See the readme FAQ "Why was my page refused?" for options.', 'pageferry' ),
					$manifest['builder_detected']
				)
			);
		}

		$missing_keys = array();
		foreach ( array( 'post', 'media' ) as $required_key ) {
			if ( ! isset( $manifest[ $required_key ] ) ) {
				$missing_keys[] = $required_key;
			}
		}

		if ( array() !== $missing_keys ) {
			return new WP_Error(
				'pageferry_manifest_keys',
				sprintf(
					/* translators: %s: comma-separated list of missing manifest keys. */
					__( 'PageFerry cannot import this bundle: the manifest is missing %s.', 'pageferry' ),
					implode( ', ', $missing_keys )
				)
			);
		}

		$post = $manifest['post'];

		if ( ! is_array( $post ) || ! isset( $post['post_type'], $post['slug'], $post['content'] ) ) {
			return new WP_Error(
				'pageferry_manifest_post',
				__( 'PageFerry cannot import this bundle: the manifest post section is incomplete.', 'pageferry' )
			);
		}

		// post_type existence is proven by the guard above; only its shape
		// is still open (a crafted manifest may send a non-string).
		$bundle_post_type = is_string( $post['post_type'] ) ? $post['post_type'] : '';

		// Attachments ride as bundle cargo and revisions are
		// WordPress-managed history — neither is ever an import target.
		// Anything else must be registered on this site; a custom post type
		// whose plugin or theme is inactive here fails closed with an
		// actionable message instead of a core invalid-post-type error.
		if ( '' === $bundle_post_type || 'attachment' === $bundle_post_type || 'revision' === $bundle_post_type || ! post_type_exists( $bundle_post_type ) ) {
			if ( '' !== $bundle_post_type && ! post_type_exists( $bundle_post_type ) ) {
				return new WP_Error(
					'pageferry_unsupported_post_type',
					sprintf(
						/* translators: %s: post-type slug recorded in the bundle. */
						__( 'PageFerry cannot import this bundle: the %s post type is not registered on this site. Activate the plugin or theme that provides it, then import again.', 'pageferry' ),
						$bundle_post_type
					)
				);
			}

			return new WP_Error(
				'pageferry_unsupported_post_type',
				__( 'PageFerry imports Gutenberg content only (pages, posts, and block-editor custom post types).', 'pageferry' )
			);
		}

		// Export only produces ferryable post types (pages, posts, block-editor
		// CPTs); import must accept the same set so a crafted manifest cannot
		// smuggle content into arbitrary types (shop orders, reusable blocks…).
		if ( ! in_array( $bundle_post_type, PageFerry_Exporter::ferryable_post_types(), true ) ) {
			return new WP_Error(
				'pageferry_unsupported_post_type',
				__( 'PageFerry imports Gutenberg content only (pages, posts, and block-editor custom post types).', 'pageferry' )
			);
		}

		if ( ! is_string( $post['content'] ) ) {
			return new WP_Error(
				'pageferry_manifest_post',
				__( 'PageFerry cannot import this bundle: the manifest post content is not a string.', 'pageferry' )
			);
		}

		if ( ! is_array( $manifest['media'] ) ) {
			return new WP_Error(
				'pageferry_manifest_media',
				__( 'PageFerry cannot import this bundle: the manifest media list is not an array.', 'pageferry' )
			);
		}

		$media_index        = array();
		$file_basename_seen = array();
		foreach ( $manifest['media'] as $position => $media_entry ) {
			if ( ! is_array( $media_entry ) || ! isset( $media_entry['old_id'] ) || ! is_numeric( $media_entry['old_id'] ) ) {
				return new WP_Error(
					'pageferry_manifest_media',
					sprintf(
						/* translators: %d: 1-based position of the bad media entry. */
						__( 'PageFerry cannot import this bundle: media entry %d has no numeric old_id.', 'pageferry' ),
						(int) $position + 1
					)
				);
			}

			$old_id = (int) $media_entry['old_id'];

			if ( isset( $media_index[ $old_id ] ) ) {
				return new WP_Error(
					'pageferry_manifest_media',
					sprintf(
						/* translators: %d: duplicated old attachment ID. */
						__( 'PageFerry cannot import this bundle: duplicate media entry for attachment %d.', 'pageferry' ),
						$old_id
					)
				);
			}

			$is_missing = ! empty( $media_entry['missing'] );
			$has_file   = isset( $media_entry['file'] ) && is_string( $media_entry['file'] ) && '' !== $media_entry['file'];
			$has_sha    = isset( $media_entry['sha256'] ) && is_string( $media_entry['sha256'] ) && '' !== $media_entry['sha256'];

			// Basename-colliding file values alias in the workspace (later entries
			// overwrite earlier ones; a05 finding F1), so fail closed here.
			if ( ! $is_missing && $has_file && $has_sha ) {
				$declared_basename = basename( (string) $media_entry['file'] );

				if ( isset( $file_basename_seen[ $declared_basename ] ) ) {
					return new WP_Error(
						'pageferry_manifest_media',
						sprintf(
							/* translators: %s: duplicated media file name inside the bundle. */
							__( 'PageFerry cannot import this bundle: two media entries claim the file %s.', 'pageferry' ),
							$declared_basename
						)
					);
				}

				$file_basename_seen[ $declared_basename ] = true;

				// The workspace lives under uploads (web-served on nginx, where
				// .htaccess is ignored), so non-media extensions must be refused
				// here — before any bytes are staged — not just at sideload.
				// Both names are checked: `file` is staged verbatim, `filename`
				// is what reaches the media library.
				$original_basename = self::original_filename( $media_entry );

				if ( ! self::media_basename_allowed( $declared_basename ) || ! self::media_basename_allowed( $original_basename ) ) {
					return new WP_Error(
						'pageferry_unsupported_media_type',
						sprintf(
							/* translators: %s: media file name with a disallowed extension. */
							__( 'PageFerry cannot import this bundle: media file %s has a file type this site does not allow.', 'pageferry' ),
							$declared_basename
						)
					);
				}
			}

			$media_index[ $old_id ] = array(
				'entry'   => $media_entry,
				'missing' => $is_missing || ! $has_file || ! $has_sha,
			);
		}

		if ( isset( $manifest['acf_post_meta'] ) ) {
			if ( ! is_array( $manifest['acf_post_meta'] ) ) {
				return new WP_Error(
					'pageferry_manifest_acf',
					__( 'PageFerry cannot import this bundle: the ACF post-meta section is not an array.', 'pageferry' )
				);
			}

			foreach ( $manifest['acf_post_meta'] as $acf_entry ) {
				if ( ! is_array( $acf_entry ) || ! isset( $acf_entry['block'], $acf_entry['fields'] ) || ! is_string( $acf_entry['block'] ) || ! is_array( $acf_entry['fields'] ) ) {
					return new WP_Error(
						'pageferry_manifest_acf',
						__( 'PageFerry cannot import this bundle: an ACF post-meta entry is incomplete.', 'pageferry' )
					);
				}
			}
		}

		return array(
			'manifest'    => $manifest,
			'media_index' => $media_index,
		);
	}

	/**
	 * Whether a media basename may be staged into an import workspace.
	 *
	 * The check mirrors the policy media_handle_sideload() enforces
	 * downstream (allowed mime types), plus an explicit executable-name deny
	 * that survives mime-allow filters: workspaces sit under uploads, which
	 * nginx serves without honouring .htaccess.
	 *
	 * @param string $basename File basename to check.
	 * @return bool True when the name is stageable media.
	 */
	public static function media_basename_allowed( string $basename ): bool {
		if ( '' === $basename || '.' === $basename || '..' === $basename ) {
			return false;
		}

		$lower_basename = strtolower( $basename );

		foreach ( array( '.htaccess', 'user.ini', 'web.config' ) as $server_file ) {
			if ( $lower_basename === $server_file || str_ends_with( $lower_basename, '/' . $server_file ) ) {
				return false;
			}
		}

		if ( 1 === preg_match( '/\.(php\d*|phtml|pht|phar|shtml|shtm|pl|cgi|py|rb|sh|exe|dll|so|dylib)$/i', $basename ) ) {
			return false;
		}

		$file_type = wp_check_filetype( $basename );

		return '' !== $file_type['type'];
	}

	/**
	 * Finds an existing attachment with identical content.
	 *
	 * The hash index is always VERIFIED (stale rows after deletions must not
	 * reuse a wrong attachment); on an index miss a filename+filesize
	 * pre-check narrows candidates and each candidate is CONFIRMED by hashing
	 * before reuse — same filename never means same content. The filename
	 * must be the original media-library basename (see original_filename()),
	 * never the zip-internal collision-safe name.
	 *
	 * @param string $sha256 Content hash of the workspace file.
	 * @param string $filename Workspace file basename (pre-check only).
	 * @param int    $bytes File size in bytes (pre-check only).
	 * @param bool   $remember Whether to record verified hits in the index.
	 * @return int|null Attachment ID on a verified hit, null on miss.
	 */
	public static function dedupe( string $sha256, string $filename, int $bytes, bool $remember = true ): ?int {
		$hash_index = get_option( self::HASH_INDEX_OPTION, array() );

		if ( is_array( $hash_index ) && isset( $hash_index[ $sha256 ] ) && is_numeric( $hash_index[ $sha256 ] ) ) {
			$candidate_id   = (int) $hash_index[ $sha256 ];
			$candidate_file = get_attached_file( $candidate_id );

			if ( is_string( $candidate_file ) && is_readable( $candidate_file ) && hash_equals( (string) hash_file( 'sha256', $candidate_file ), $sha256 ) ) {
				return $candidate_id;
			}
		}

		$precheck_query = new WP_Query(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => 20,
				'fields'         => 'ids',
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- bounded pre-check before the hash confirm.
				'meta_query'     => array(
					array(
						'key'     => '_wp_attached_file',
						'value'   => '/' . $filename,
						'compare' => 'LIKE',
					),
				),
			)
		);

		$query_posts = $precheck_query->posts; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- WP_Query::$posts is core's own property.

		foreach ( $query_posts as $candidate_id ) {
			$candidate_file = get_attached_file( (int) $candidate_id );

			if ( ! is_string( $candidate_file ) || ! is_readable( $candidate_file ) ) {
				continue;
			}

			$candidate_size = (int) filesize( $candidate_file );

			if ( 0 < $bytes && $bytes !== $candidate_size ) {
				continue;
			}

			if ( ! hash_equals( (string) hash_file( 'sha256', $candidate_file ), $sha256 ) ) {
				continue;
			}

			if ( $remember ) {
				self::remember_hash( $sha256, (int) $candidate_id );
			}

			return (int) $candidate_id;
		}

		return null;
	}

	/**
	 * Maximum recursion depth for nested remap structures.
	 *
	 * @var int
	 */
	const MAX_REMAP_DEPTH = 20;

	/**
	 * Remaps attachment IDs inside parsed blocks.
	 *
	 * Known slots (id / ids[] / mediaId) swap unconditionally when listed
	 * in the id map — exactly the v1 behavior, so missing-media IDs never
	 * leak through. Generic custom-block values swap only when the value
	 * was collected (collector-verified per block); plain-text numerals,
	 * external URLs, and ids with no new attachment are untouched.
	 * Full-URL string replacement happens separately — never numeric.
	 *
	 * @param array $blocks Parsed blocks (parse_blocks output).
	 * @param array $id_map Map of old attachment ID => new attachment ID.
	 * @param array $block_refs Optional map of block path prefix => list of
	 *                          collected old IDs for that block (manifest
	 *                          block_refs). When empty, every attribute value
	 *                          equal to a mapped ID remaps (v1 manifests and
	 *                          direct remap() calls without manifest context).
	 * @return array Remapped blocks.
	 */
	public static function remap( array $blocks, array $id_map, array $block_refs = array() ): array {
		return self::remap_level( $blocks, $id_map, $block_refs, '' );
	}

	/**
	 * Remaps one level of parsed blocks with path-tracked ref gating.
	 *
	 * @param array  $blocks Parsed blocks at this level.
	 * @param array  $id_map Map of old attachment ID => new attachment ID.
	 * @param array  $block_refs Map of block path prefix => collected old IDs.
	 * @param string $path_prefix Dot-notation prefix for this level ('' at the top).
	 * @return array Remapped blocks.
	 */
	private static function remap_level( array $blocks, array $id_map, array $block_refs, string $path_prefix ): array {
		foreach ( $blocks as $index => $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$block_path = '' === $path_prefix ? (string) $index : $path_prefix . '.' . $index;

			if ( isset( $block['attrs'] ) && is_array( $block['attrs'] ) ) {
				$blocks[ $index ]['attrs'] = self::remap_attributes( $block['attrs'], $id_map, self::allowed_ids_for_block( $block_path, $block_refs ) );
			}

			if ( isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$blocks[ $index ]['innerBlocks'] = self::remap_level( $block['innerBlocks'], $id_map, $block_refs, $block_path . '.innerBlocks' );
			}
		}

		return $blocks;
	}

	/**
	 * Returns the collector-recorded attribute paths for one block.
	 *
	 * A null return means "no manifest context": every mapped ID may swap
	 * anywhere (v1 manifests without generic refs, direct remap() callers).
	 * Otherwise the map holds attribute path => old ID pairs recorded for
	 * this block path ("data.hero_image" => 5), so only those slots swap.
	 * Known slots (id/mediaId/ids) swap unconditionally regardless.
	 *
	 * Paths are compared segment-wise: "1" covers "1.innerBlocks.0" but
	 * never "10". Reusable-block refs ("2.ref45.0") match their referrer
	 * ("2") and everything beneath it.
	 *
	 * @param string $block_path Dot-notation path of the block.
	 * @param array  $block_refs Map of block path prefix => list of array(path, key, old_id).
	 * @return array|null Map of attribute path => old ID, or null when unrestricted.
	 */
	private static function allowed_ids_for_block( string $block_path, array $block_refs ): ?array {
		if ( array() === $block_refs ) {
			return null;
		}

		$allowed = array();

		foreach ( $block_refs as $ref_path => $refs ) {
			$ref_path = (string) $ref_path;

			if ( ! self::path_covers( $block_path, $ref_path ) && ! self::path_covers( $ref_path, $block_path ) ) {
				continue;
			}

			foreach ( (array) $refs as $reference ) {
				if ( ! is_array( $reference ) || ! isset( $reference['key'], $reference['old_id'] ) || ! is_string( $reference['key'] ) ) {
					continue;
				}

				$attr_key = $reference['key'];

				if ( 'html' === $attr_key || str_starts_with( $attr_key, 'meta:' ) ) {
					continue;
				}

				$allowed[ $attr_key ] = (int) $reference['old_id'];
			}
		}

		return $allowed;
	}

	/**
	 * Checks whether one block path covers another segment-wise.
	 *
	 * "1" covers "1" and "1.innerBlocks.0"; "1" never covers "10".
	 * A reusable-block "ref" segment (ref + digits, e.g. ref45) is
	 * transparent: "2" covers "2.ref45.0" and vice versa.
	 *
	 * @param string $outer Candidate covering path.
	 * @param string $inner Candidate covered path.
	 * @return bool Whether outer covers inner.
	 */
	private static function path_covers( string $outer, string $inner ): bool {
		$outer_segments = explode( '.', $outer );
		$inner_segments = explode( '.', $inner );

		foreach ( $outer_segments as $position => $segment ) {
			if ( ! isset( $inner_segments[ $position ] ) ) {
				return false;
			}

			if ( $segment === $inner_segments[ $position ] ) {
				continue;
			}

			if ( 'innerBlocks' === $segment || 'innerBlocks' === $inner_segments[ $position ] ) {
				return false;
			}

			$segment_is_ref = 1 === preg_match( '/\Aref\d+\z/', (string) $segment );
			$inner_is_ref   = 1 === preg_match( '/\Aref\d+\z/', (string) $inner_segments[ $position ] );

			if ( $segment_is_ref || $inner_is_ref ) {
				continue;
			}

			return false;
		}

		return true;
	}

	/**
	 * Extracts an export ZIP into a fresh workspace (Path A transport).
	 *
	 * Only pageferry-manifest.json plus media basenames DECLARED in the
	 * manifest are extracted. Absolute paths and ".." entries fail closed
	 * (zip-slip guard); other undeclared entries are ignored.
	 *
	 * @param string $zip_path Absolute path to the uploaded export ZIP.
	 * @return array|WP_Error Array with workspace + manifest, or WP_Error.
	 */
	public static function prepare_workspace_from_zip( string $zip_path ) {
		$zip = new ZipArchive();

		if ( true !== $zip->open( $zip_path, ZipArchive::RDONLY ) ) {
			return new WP_Error(
				'pageferry_zip_open',
				__( 'PageFerry could not open the uploaded ZIP. It may be corrupt — try exporting again.', 'pageferry' )
			);
		}

		$manifest_json = $zip->getFromName( 'pageferry-manifest.json' );

		if ( ! is_string( $manifest_json ) ) {
			$zip->close();
			return new WP_Error(
				'pageferry_manifest_missing',
				__( 'PageFerry cannot import this ZIP: pageferry-manifest.json is missing. It was not made by PageFerry export.', 'pageferry' )
			);
		}

		$manifest = json_decode( $manifest_json, true );

		if ( ! is_array( $manifest ) ) {
			$zip->close();
			return new WP_Error(
				'pageferry_manifest_invalid',
				__( 'PageFerry cannot import this ZIP: the manifest is not valid JSON.', 'pageferry' )
			);
		}

		$validated = self::validate( $manifest );

		if ( $validated instanceof WP_Error ) {
			$zip->close();
			return $validated;
		}

		$workspace = self::make_workspace();

		if ( $workspace instanceof WP_Error ) {
			$zip->close();
			return $workspace;
		}

		$declared_files = array();
		$declared_bytes = array();
		foreach ( $validated['media_index'] as $media_state ) {
			if ( $media_state['missing'] ) {
				continue;
			}

			$declared_name = isset( $media_state['entry']['file'] ) ? basename( (string) $media_state['entry']['file'] ) : '';
			if ( '' !== $declared_name ) {
				$declared_files[ $declared_name ] = true;

				if ( isset( $media_state['entry']['bytes'] ) && is_numeric( $media_state['entry']['bytes'] ) ) {
					$declared_bytes[ $declared_name ] = (int) $media_state['entry']['bytes'];
				}
			}
		}

		// Zip-bomb guard: a tiny archive can inflate to gigabytes. Bound the
		// staged file count and the total inflated bytes before writing.
		$upload_limit      = (int) wp_max_upload_size();
		$max_staged_bytes  = 0 < $upload_limit ? 2 * $upload_limit : self::MAX_WORKSPACE_BYTES_FALLBACK;
		$staged_file_count = 0;
		$staged_byte_total = 0;

		$zip_entry_count = $zip->numFiles; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- ZipArchive::$numFiles is the extension's own property name.

		for ( $position = 0; $position < $zip_entry_count; $position++ ) {
			$entry_name = $zip->getNameIndex( $position );

			if ( ! is_string( $entry_name ) ) {
				continue;
			}

			if ( 'pageferry-manifest.json' === $entry_name || str_ends_with( $entry_name, '/' ) ) {
				continue;
			}

			if ( str_contains( $entry_name, '..' ) || str_starts_with( $entry_name, '/' ) ) {
				$zip->close();
				self::remove_directory( $workspace );
				return new WP_Error(
					'pageferry_zip_unsafe',
					sprintf(
						/* translators: %s: unsafe entry name inside the ZIP. */
						__( 'PageFerry refused ZIP entry %s: archives must not contain paths outside the bundle.', 'pageferry' ),
						$entry_name
					)
				);
			}

			if ( ! str_starts_with( $entry_name, 'media/' ) ) {
				continue;
			}

			$entry_basename = basename( $entry_name );
			$media_subpath  = substr( $entry_name, 6 );

			if ( $entry_basename !== $media_subpath || ! isset( $declared_files[ $entry_basename ] ) ) {
				continue;
			}

			// Fail before staging when the manifest itself declares more than
			// the site allows — the inflated bytes are checked below as well
			// in case the declaration understates them.
			if ( 0 < $upload_limit && isset( $declared_bytes[ $entry_basename ] ) && $upload_limit < $declared_bytes[ $entry_basename ] ) {
				$zip->close();
				self::remove_directory( $workspace );
				return new WP_Error(
					'pageferry_media_too_large',
					sprintf(
						/* translators: 1: media file name, 2: human-readable size limit. */
						__( 'PageFerry cannot import media file %1$s: it is larger than this site allows (%2$s). Raise the upload limit or drop the asset and re-export.', 'pageferry' ),
						$entry_basename,
						size_format( $upload_limit )
					)
				);
			}

			$entry_stream = $zip->getStream( $entry_name );

			if ( ! is_resource( $entry_stream ) ) {
				$zip->close();
				self::remove_directory( $workspace );
				return new WP_Error(
					'pageferry_zip_read',
					sprintf(
						/* translators: %s: media file name inside the ZIP. */
						__( 'PageFerry could not read media file %s from the ZIP.', 'pageferry' ),
						$entry_basename
					)
				);
			}

			$dest_handle = fopen( $workspace . '/' . $entry_basename, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- extracting a validated zip entry to our own workspace.

			if ( ! is_resource( $dest_handle ) ) {
				fclose( $entry_stream ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- closing a ZipArchive stream handle.
				$zip->close();
				self::remove_directory( $workspace );
				return new WP_Error(
					'pageferry_workspace_write',
					__( 'PageFerry could not stage the uploaded ZIP for import.', 'pageferry' )
				);
			}

			stream_copy_to_stream( $entry_stream, $dest_handle );
			fclose( $entry_stream ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- closing a ZipArchive stream handle.
			fclose( $dest_handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- closing our own workspace file handle.

			++$staged_file_count;
			$staged_size        = filesize( $workspace . '/' . $entry_basename );
			$staged_byte_total += is_int( $staged_size ) ? $staged_size : 0;

			if ( self::MAX_WORKSPACE_FILES < $staged_file_count || $max_staged_bytes < $staged_byte_total ) {
				$zip->close();
				self::remove_directory( $workspace );
				return new WP_Error(
					'pageferry_zip_too_large',
					sprintf(
						/* translators: %s: human-readable size limit. */
						__( 'PageFerry cannot stage this ZIP: it expands to more than this site allows (%s). Split the bundle or raise the upload limit.', 'pageferry' ),
						size_format( $max_staged_bytes )
					)
				);
			}
		}

		$zip->close();

		return array(
			'workspace' => $workspace,
			'manifest'  => $validated['manifest'],
		);
	}

	/**
	 * Creates a fresh workspace dir under uploads, denied to web access.
	 *
	 * @param string $prefix Directory name prefix.
	 * @return string|WP_Error Absolute workspace path, or WP_Error.
	 */
	public static function make_workspace( string $prefix = 'pageferry-import-' ) {
		$upload_dir = wp_get_upload_dir();
		$workspace  = trailingslashit( $upload_dir['basedir'] ) . $prefix . wp_generate_password( 12, false );

		if ( ! wp_mkdir_p( $workspace ) ) {
			return new WP_Error(
				'pageferry_workspace',
				__( 'PageFerry could not create a temporary import workspace.', 'pageferry' )
			);
		}

		file_put_contents( $workspace . '/index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- web-access guard inside our own workspace.
		file_put_contents( $workspace . '/.htaccess', "Require all denied\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- web-access guard inside our own workspace.

		return $workspace;
	}

	/**
	 * Recursively deletes a workspace directory.
	 *
	 * @param string $workspace_dir Absolute workspace path.
	 * @return void
	 */
	public static function remove_directory( string $workspace_dir ): void {
		$real_base = realpath( wp_get_upload_dir()['basedir'] );
		$real_dir  = realpath( $workspace_dir );

		if ( ! is_string( $real_base ) || ! is_string( $real_dir ) || 0 !== strpos( $real_dir, trailingslashit( $real_base ) ) ) {
			return;
		}

		$entries = scandir( $real_dir );

		if ( ! is_array( $entries ) ) {
			return;
		}

		foreach ( $entries as $entry ) {
			if ( '.' === $entry || '..' === $entry ) {
				continue;
			}

			$entry_path = $real_dir . '/' . $entry;

			if ( is_dir( $entry_path ) ) {
				self::remove_directory( $entry_path );
			} else {
				wp_delete_file( $entry_path );
			}
		}

		rmdir( $real_dir ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- removing our own workspace dir after emptying it.
	}

	/**
	 * Deletes abandoned import workspaces older than the session TTL.
	 *
	 * Workspaces whose transient expired (abandoned upload, closed browser,
	 * PHP fatal mid-run) are otherwise never removed — transient expiry is
	 * passive. Only directories with our own prefixes directly under the
	 * uploads basedir are considered; anything else is left alone.
	 *
	 * @param int $max_age_seconds Directory age qualifying for deletion.
	 * @return int Number of workspaces removed.
	 */
	public static function gc_workspaces( int $max_age_seconds = 3600 ): int {
		$upload_dir = wp_get_upload_dir();
		$basedir    = isset( $upload_dir['basedir'] ) && is_string( $upload_dir['basedir'] ) ? $upload_dir['basedir'] : '';

		if ( '' === $basedir || ! is_dir( $basedir ) ) {
			return 0;
		}

		$entries = scandir( $basedir );

		if ( ! is_array( $entries ) ) {
			return 0;
		}

		$removed = 0;

		foreach ( $entries as $entry ) {
			if ( ! str_starts_with( $entry, 'pageferry-import-' ) && ! str_starts_with( $entry, 'pageferry-session-' ) ) {
				continue;
			}

			$candidate = $basedir . '/' . $entry;

			if ( ! is_dir( $candidate ) ) {
				continue;
			}

			$modified = filemtime( $candidate );

			if ( ! is_int( $modified ) || time() - $modified < $max_age_seconds ) {
				continue;
			}

			self::remove_directory( $candidate );
			++$removed;
		}

		return $removed;
	}

	/**
	 * Runs the workspace GC at most once per day (piggybacked on admin_init).
	 *
	 * A dedicated cron would need activation scheduling; a timestamp-guarded
	 * sweep on admin traffic is enough for hourly-TTL staging directories.
	 *
	 * @return void
	 */
	public static function maybe_gc_workspaces(): void {
		$last_run = get_option( PageFerry::OPTION_LAST_GC, 0 );

		if ( is_numeric( $last_run ) && time() - (int) $last_run < DAY_IN_SECONDS ) {
			return;
		}

		update_option( PageFerry::OPTION_LAST_GC, time(), false );
		self::gc_workspaces( PageFerry_Rest_Import::SESSION_TTL );
	}

	/**
	 * Runs the full import pipeline on a prepared workspace.
	 *
	 * Validates first, then writes; any refusal or failure cleans up what it
	 * created (sideloaded attachments, hash rows, update snapshot) so the
	 * database is left untouched. The caller removes the workspace.
	 *
	 * @param string $workspace_dir Absolute workspace dir with media files.
	 * @param array  $manifest Decoded manifest array.
	 * @param array  $args Optional. { target: 'create'|'update', target_post_id?: int }.
	 * @return WP_Post|WP_Error Imported post or error.
	 */
	public static function run( string $workspace_dir, array $manifest, array $args = array() ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$validated = self::validate( $manifest );

		if ( $validated instanceof WP_Error ) {
			return $validated;
		}

		$normalized_manifest = $validated['manifest'];
		$media_index         = $validated['media_index'];
		$limit_bytes         = (int) wp_max_upload_size();

		foreach ( $media_index as $media_state ) {
			if ( $media_state['missing'] ) {
				continue;
			}

			$entry_bytes = isset( $media_state['entry']['bytes'] ) && is_numeric( $media_state['entry']['bytes'] )
				? (int) $media_state['entry']['bytes']
				: 0;

			if ( 0 < $limit_bytes && 0 < $entry_bytes && $limit_bytes < $entry_bytes ) {
				return new WP_Error(
					'pageferry_media_too_large',
					sprintf(
						/* translators: 1: media file name, 2: human-readable size limit. */
						__( 'PageFerry cannot import media file %1$s: it is larger than this site allows (%2$s). Raise the upload limit or drop the asset and re-export.', 'pageferry' ),
						self::original_filename( $media_state['entry'] ),
						size_format( $limit_bytes )
					)
				);
			}

			// The declared count is exporter metadata and may under-state the
			// real file; the staged bytes on disk are authoritative.
			$staged_file = self::workspace_file( $workspace_dir, $media_state['entry']['file'] ?? '' );

			if ( is_string( $staged_file ) ) {
				$staged_bytes = filesize( $staged_file );

				if ( is_int( $staged_bytes ) && 0 < $limit_bytes && $limit_bytes < $staged_bytes ) {
					return new WP_Error(
						'pageferry_media_too_large',
						sprintf(
							/* translators: 1: media file name, 2: human-readable size limit. */
							__( 'PageFerry cannot import media file %1$s: it is larger than this site allows (%2$s). Raise the upload limit or drop the asset and re-export.', 'pageferry' ),
							self::original_filename( $media_state['entry'] ),
							size_format( $limit_bytes )
						)
					);
				}
			}
		}

		$target_mode      = isset( $args['target'] ) && 'update' === $args['target'] ? 'update' : 'create';
		$target_post_id   = isset( $args['target_post_id'] ) ? (int) $args['target_post_id'] : 0;
		$target_post      = null;
		$backup_reference = null;

		if ( 'update' === $target_mode ) {
			$target_post = get_post( $target_post_id );

			if ( ! $target_post instanceof WP_Post ) {
				return new WP_Error(
					'pageferry_target_missing',
					__( 'PageFerry cannot update: the selected target page no longer exists.', 'pageferry' )
				);
			}

			if ( $target_post->post_type !== $normalized_manifest['post']['post_type'] ) {
				return new WP_Error(
					'pageferry_target_type',
					__( 'PageFerry cannot update: the target is a different post type than the bundle.', 'pageferry' )
				);
			}

			// The global `import` gate is not enough: overwriting a post must
			// require the same per-post right as editing it in the editor.
			if ( ! current_user_can( 'edit_post', $target_post->ID ) ) {
				return new WP_Error(
					'pageferry_target_cap',
					__( 'PageFerry cannot update: you do not have permission to edit the selected target page.', 'pageferry' )
				);
			}

			$backup_reference = self::snapshot_post( $target_post );
		} else {
			// Creating must require the per-type creation right, so a crafted
			// manifest cannot mint posts of a type the user may not create.
			$bundle_post_type_object = get_post_type_object( $normalized_manifest['post']['post_type'] );
			$create_capability       = ( $bundle_post_type_object instanceof WP_Post_Type && isset( $bundle_post_type_object->cap->create_posts ) )
				? $bundle_post_type_object->cap->create_posts
				: 'edit_posts';

			if ( ! $bundle_post_type_object instanceof WP_Post_Type || ! current_user_can( $create_capability ) ) {
				return new WP_Error(
					'pageferry_target_cap',
					__( 'PageFerry cannot import: you do not have permission to create posts of this type.', 'pageferry' )
				);
			}
		}

		$id_map              = array();
		$created_attachments = array();
		$reused_count        = 0;
		$uploaded_count      = 0;
		$missing_media       = array();

		foreach ( $media_index as $media_old_id => $media_state ) {
			if ( $media_state['missing'] ) {
				$missing_media[] = $media_old_id;
				continue;
			}

			$media_entry = $media_state['entry'];
			$media_file  = self::workspace_file( $workspace_dir, $media_entry['file'] );

			if ( ! is_string( $media_file ) ) {
				$missing_media[] = $media_old_id;
				continue;
			}

			$actual_hash = hash_file( 'sha256', $media_file );

			if ( ! is_string( $actual_hash ) || ! hash_equals( strtolower( (string) $media_entry['sha256'] ), strtolower( $actual_hash ) ) ) {
				return self::abort(
					new WP_Error(
						'pageferry_media_hash',
						sprintf(
							/* translators: %s: media file name inside the bundle. */
							__( 'PageFerry cannot import this bundle: media file %s does not match the manifest hash.', 'pageferry' ),
							self::original_filename( $media_entry )
						)
					),
					$created_attachments,
					$backup_reference
				);
			}

			$workspace_bytes   = (int) filesize( $media_file );
			$original_name     = self::original_filename( $media_entry );
			$new_attachment_id = self::dedupe( (string) $actual_hash, $original_name, $workspace_bytes );

			if ( null === $new_attachment_id ) {
				$sideloaded_id = self::sideload_workspace_file( $media_file, $original_name );

				if ( is_wp_error( $sideloaded_id ) ) {
					return self::abort( $sideloaded_id, $created_attachments, $backup_reference );
				}

				$new_attachment_id     = (int) $sideloaded_id;
				$created_attachments[] = $new_attachment_id;
				self::remember_hash( (string) $actual_hash, $new_attachment_id );
				++$uploaded_count;
			} else {
				++$reused_count;
			}

			self::apply_media_meta( $new_attachment_id, $media_entry );
			$id_map[ $media_old_id ] = $new_attachment_id;
		}

		$remapped_blocks  = self::remap( parse_blocks( $normalized_manifest['post']['content'] ), $id_map, self::build_block_ref_map( $normalized_manifest ) );
		$remapped_content = serialize_blocks( $remapped_blocks );
		$final_content    = self::rewrite_media_urls( $remapped_content, $normalized_manifest, $id_map );
		$final_content    = self::rewrite_source_host( $final_content, $normalized_manifest );

		$final_excerpt = isset( $normalized_manifest['post']['excerpt'] ) && is_string( $normalized_manifest['post']['excerpt'] )
			? self::rewrite_source_host( $normalized_manifest['post']['excerpt'], $normalized_manifest )
			: '';

		$post_title = isset( $normalized_manifest['post']['title'] ) && is_string( $normalized_manifest['post']['title'] )
			? $normalized_manifest['post']['title']
			: '';

		$post_type     = $normalized_manifest['post']['post_type'];
		$desired_slug  = isset( $normalized_manifest['post']['slug'] ) && is_string( $normalized_manifest['post']['slug'] ) ? $normalized_manifest['post']['slug'] : '';
		$land_as_draft = ! isset( $normalized_manifest['options']['land_as_draft'] ) || ! empty( $normalized_manifest['options']['land_as_draft'] );

		if ( 'update' === $target_mode ) { // Target nullability already guarded above: update mode returns early unless $target_post is a WP_Post.
			$updated_post_id = wp_update_post(
				array(
					'ID'           => $target_post->ID,
					'post_title'   => $post_title,
					'post_content' => $final_content,
					'post_excerpt' => $final_excerpt,
				),
				true
			);

			if ( is_wp_error( $updated_post_id ) ) {
				return self::abort( $updated_post_id, $created_attachments, $backup_reference );
			}

			$imported_post = get_post( (int) $updated_post_id );

			if ( ! $imported_post instanceof WP_Post ) {
				return self::abort(
					new WP_Error(
						'pageferry_import_failed',
						__( 'PageFerry updated the target page but could not reload it.', 'pageferry' )
					),
					$created_attachments,
					$backup_reference
				);
			}
		} else {
			$desired_status = isset( $normalized_manifest['post']['status'] ) && is_string( $normalized_manifest['post']['status'] ) ? $normalized_manifest['post']['status'] : 'draft';
			$final_status   = $land_as_draft ? 'draft' : $desired_status;
			// Draft/pending posts are excluded from slug uniqueness checks, so a
			// published clash still needs an explicit suffix for the notice.
			$unique_slug = '' !== $desired_slug ? wp_unique_post_slug( $desired_slug, 0, 'publish', $post_type, 0 ) : '';

			$created_post_id = wp_insert_post(
				array(
					'post_type'    => $post_type,
					'post_title'   => $post_title,
					'post_name'    => $unique_slug,
					'post_content' => $final_content,
					'post_excerpt' => $final_excerpt,
					'post_status'  => $final_status,
				),
				true
			);

			if ( is_wp_error( $created_post_id ) ) {
				return self::abort( $created_post_id, $created_attachments, $backup_reference );
			}

			$imported_post = get_post( (int) $created_post_id );

			if ( ! $imported_post instanceof WP_Post ) {
				return self::abort(
					new WP_Error(
						'pageferry_import_failed',
						__( 'PageFerry created the page but could not reload it.', 'pageferry' )
					),
					$created_attachments,
					$backup_reference
				);
			}
		}

		self::assign_terms( $imported_post->ID, $normalized_manifest );
		self::assign_thumbnail( $imported_post->ID, $normalized_manifest, $id_map );
		$acf_skipped = self::restore_acf_post_meta( $imported_post->ID, $normalized_manifest, $id_map );
		$log_row     = array(
			'time'     => gmdate( 'c' ),
			'action'   => 'update' === $target_mode ? 'update' : 'create',
			'target'   => $imported_post->ID,
			'slug'     => $imported_post->post_name,
			'source'   => isset( $normalized_manifest['source']['url'] ) ? (string) $normalized_manifest['source']['url'] : '',
			'reused'   => $reused_count,
			'uploaded' => $uploaded_count,
			'missing'  => $missing_media,
			'result'   => 'success',
			'backup'   => $backup_reference,
		);

		if ( array() !== $acf_skipped ) {
			$log_row['acf_skipped'] = array_values( $acf_skipped );
		}

		self::append_log( $log_row );

		return $imported_post;
	}

	/**
	 * Summarizes what an import would do, without writing anything.
	 *
	 * Reads workspace files and hashes them for the dedupe pre-check but
	 * never records index rows, so the confirmation step stays write-free.
	 * Mirrors run()'s per-entry bytes-limit guard so the confirmation can
	 * never promise an import run() would refuse.
	 *
	 * @param string $workspace_dir Absolute workspace dir with media files.
	 * @param array  $manifest Decoded manifest array.
	 * @param array  $args Optional target args ({ target, target_post_id }).
	 * @return array|WP_Error Summary array or WP_Error.
	 */
	public static function preview( string $workspace_dir, array $manifest, array $args = array() ) {
		$validated = self::validate( $manifest );

		if ( $validated instanceof WP_Error ) {
			return $validated;
		}

		$normalized_manifest = $validated['manifest'];
		$media_index         = $validated['media_index'];
		$limit_bytes         = (int) wp_max_upload_size();

		foreach ( $media_index as $media_state ) {
			if ( $media_state['missing'] ) {
				continue;
			}

			$entry_bytes = isset( $media_state['entry']['bytes'] ) && is_numeric( $media_state['entry']['bytes'] )
				? (int) $media_state['entry']['bytes']
				: 0;

			if ( 0 < $limit_bytes && 0 < $entry_bytes && $limit_bytes < $entry_bytes ) {
				return new WP_Error(
					'pageferry_media_too_large',
					sprintf(
						/* translators: 1: media file name, 2: human-readable size limit. */
						__( 'PageFerry cannot import media file %1$s: it is larger than this site allows (%2$s). Raise the upload limit or drop the asset and re-export.', 'pageferry' ),
						self::original_filename( $media_state['entry'] ),
						size_format( $limit_bytes )
					)
				);
			}

			// Authoritative size is the staged file, not the declared count.
			$staged_file = self::workspace_file( $workspace_dir, $media_state['entry']['file'] ?? '' );

			if ( is_string( $staged_file ) ) {
				$staged_bytes = filesize( $staged_file );

				if ( is_int( $staged_bytes ) && 0 < $limit_bytes && $limit_bytes < $staged_bytes ) {
					return new WP_Error(
						'pageferry_media_too_large',
						sprintf(
							/* translators: 1: media file name, 2: human-readable size limit. */
							__( 'PageFerry cannot import media file %1$s: it is larger than this site allows (%2$s). Raise the upload limit or drop the asset and re-export.', 'pageferry' ),
							self::original_filename( $media_state['entry'] ),
							size_format( $limit_bytes )
						)
					);
				}
			}
		}

		$reused_count  = 0;
		$upload_count  = 0;
		$missing_count = 0;

		foreach ( $media_index as $media_state ) {
			if ( $media_state['missing'] ) {
				++$missing_count;
				continue;
			}

			$file_name = isset( $media_state['entry']['file'] ) && is_string( $media_state['entry']['file'] )
				? $media_state['entry']['file']
				: '';

			$media_file = self::workspace_file( $workspace_dir, $file_name );

			if ( ! is_string( $media_file ) ) {
				++$missing_count;
				continue;
			}

			$actual_hash = hash_file( 'sha256', $media_file );

			if ( ! is_string( $actual_hash ) ) {
				++$missing_count;
				continue;
			}

			if ( null !== self::dedupe( $actual_hash, self::original_filename( $media_state['entry'] ), (int) filesize( $media_file ), false ) ) {
				++$reused_count;
			} else {
				++$upload_count;
			}
		}

		$flat_tax      = isset( $normalized_manifest['post']['tax'] ) && is_array( $normalized_manifest['post']['tax'] )
			? $normalized_manifest['post']['tax']
			: array();
		$preview_terms = array();

		foreach ( $flat_tax as $taxonomy_slug => $term_names ) {
			if ( ! is_string( $taxonomy_slug ) || '' === $taxonomy_slug || ! is_array( $term_names ) ) {
				continue;
			}

			$preview_terms[ $taxonomy_slug ] = array_values( array_map( 'strval', $term_names ) );
		}

		return array(
			'target'    => isset( $args['target'] ) && 'update' === $args['target'] ? 'update' : 'create',
			'slug'      => isset( $normalized_manifest['post']['slug'] ) ? (string) $normalized_manifest['post']['slug'] : '',
			'title'     => isset( $normalized_manifest['post']['title'] ) ? (string) $normalized_manifest['post']['title'] : '',
			'post_type' => $normalized_manifest['post']['post_type'],
			'media_new' => $upload_count,
			'reused'    => $reused_count,
			'missing'   => $missing_count,
			'terms'     => $preview_terms,
		);
	}

	/**
	 * Resolves a manifest media file name to a real path inside the workspace.
	 *
	 * Only exact basenames resolve, so a crafted entry like "../../evil.php"
	 * can never escape the workspace (zip-slip guard).
	 *
	 * @param string $workspace_dir Absolute workspace dir.
	 * @param mixed  $file Manifest file value.
	 * @return string|null Absolute path on success, null when rejected/missing.
	 */
	public static function workspace_file( string $workspace_dir, $file ): ?string {
		if ( ! is_string( $file ) || '' === $file ) {
			return null;
		}

		$basename = basename( $file );

		if ( '' === $basename || '.' === $basename || '..' === $basename || $basename !== $file ) {
			return null;
		}

		$candidate = $workspace_dir . '/' . $basename;
		$real_base = realpath( $workspace_dir );

		if ( ! is_string( $real_base ) ) {
			return null;
		}

		$real_candidate = realpath( $candidate );

		if ( ! is_string( $real_candidate ) || ! is_readable( $real_candidate ) ) {
			return null;
		}

		if ( 0 !== strpos( $real_candidate, trailingslashit( $real_base ) ) ) {
			return null;
		}

		return $real_candidate;
	}

	/**
	 * Returns the original media-library file name for a manifest entry.
	 *
	 * The zip-internal `file` value is transport-only (sanitized, suffixed
	 * on collision) and must never reach the media library: dedupe and
	 * sideload use this original name instead, so WordPress applies its
	 * standard wp_unique_filename suffixing when the name is taken. Bundles
	 * predating the `filename` key fall back to stripping the `<old_id>-`
	 * prefix on a best-effort basis (sanitization and collision infixes
	 * cannot be inverted, but the hash still gates reuse).
	 *
	 * @param array $media_entry Manifest media entry.
	 * @return string Original file basename.
	 */
	public static function original_filename( array $media_entry ): string {
		if ( isset( $media_entry['filename'] ) && is_string( $media_entry['filename'] ) ) {
			$declared_base = basename( $media_entry['filename'] );

			if ( '' !== $declared_base && '.' !== $declared_base && '..' !== $declared_base && '' !== trim( $declared_base ) ) {
				return $declared_base;
			}
		}

		$zip_basename = isset( $media_entry['file'] ) && is_string( $media_entry['file'] ) ? basename( $media_entry['file'] ) : '';
		$old_id       = isset( $media_entry['old_id'] ) && is_numeric( $media_entry['old_id'] ) ? (int) $media_entry['old_id'] : 0;
		$old_prefix   = 0 < $old_id ? $old_id . '-' : '';

		if ( '' !== $old_prefix && str_starts_with( $zip_basename, $old_prefix ) ) {
			$stripped = substr( $zip_basename, strlen( $old_prefix ) );

			if ( '' !== $stripped ) {
				return $stripped;
			}
		}

		return $zip_basename;
	}

	/**
	 * Sideloads one workspace file into the media library.
	 *
	 * The basename is the original media-library name; WordPress applies its
	 * standard wp_unique_filename suffixing when the name is taken.
	 *
	 * @param string $media_file Absolute workspace file path (hash-verified).
	 * @param string $basename File name recorded in the media library.
	 * @return int|WP_Error New attachment ID, or WP_Error.
	 */
	private static function sideload_workspace_file( string $media_file, string $basename ) {
		$file_type  = wp_check_filetype( $basename );
		$temp_stage = wp_tempnam( $basename );
		$mime_type  = '' !== $file_type['type'] ? $file_type['type'] : 'application/octet-stream';

		if ( ! copy( $media_file, $temp_stage ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions -- staging an already-validated workspace file for sideloading.
			wp_delete_file( $temp_stage );

			return new WP_Error(
				'pageferry_media_sideload',
				sprintf(
					/* translators: %s: media file name inside the bundle. */
					__( 'PageFerry could not import media file %s.', 'pageferry' ),
					$basename
				)
			);
		}

		$copy_path = $temp_stage;

		$file_array = array(
			'name'     => $basename,
			'type'     => $mime_type,
			'tmp_name' => $copy_path,
			'error'    => '0',
			'size'     => (string) filesize( $media_file ),
		);

		$sideloaded_id = media_handle_sideload( $file_array, 0 );

		if ( is_wp_error( $sideloaded_id ) ) {
			if ( file_exists( $copy_path ) ) {
				wp_delete_file( $copy_path );
			}

			return new WP_Error(
				'pageferry_media_sideload',
				sprintf(
					/* translators: %s: sideload failure message. */
					__( 'PageFerry could not import media: %s', 'pageferry' ),
					$sideloaded_id->get_error_message()
				)
			);
		}

		return (int) $sideloaded_id;
	}

	/**
	 * Rolls back a failed import: deletes attachments it sideloaded, purges
	 * their hash rows, and drops the update snapshot.
	 *
	 * @param WP_Error    $error Error to return.
	 * @param array       $created_attachment_ids Attachments sideloaded so far.
	 * @param string|null $backup_reference Snapshot key or null.
	 * @return WP_Error The original error.
	 */
	private static function abort( WP_Error $error, array $created_attachment_ids, ?string $backup_reference ): WP_Error {
		foreach ( $created_attachment_ids as $attachment_id ) {
			wp_delete_attachment( (int) $attachment_id, true );
		}

		if ( array() !== $created_attachment_ids ) {
			$hash_index = get_option( self::HASH_INDEX_OPTION, array() );

			if ( is_array( $hash_index ) ) {
				foreach ( $hash_index as $hash => $indexed_id ) {
					if ( in_array( (int) $indexed_id, $created_attachment_ids, true ) ) {
						unset( $hash_index[ $hash ] );
					}
				}

				update_option( self::HASH_INDEX_OPTION, $hash_index, false );
			}
		}

		self::forget_backup( $backup_reference );

		return $error;
	}

	/**
	 * Remaps id / ids[] / mediaId slots plus collector-verified generic
	 * attributes inside one block's attributes.
	 *
	 * Known slots swap unconditionally (v1 behavior). Generic values swap
	 * only at collector-recorded attribute paths: each manifest block_ref
	 * key addresses its slot ("data.hero_image", "images.0.id", nested
	 * paths). A sibling slot holding a coincidentally equal number
	 * ("columns" vs "hero_image") keeps its value. "html"/"meta:*" refs
	 * prove the block cites the attachment but address no delimiter slot,
	 * so they allow nothing by themselves.
	 *
	 * @param array      $attributes Block delimiter attributes.
	 * @param array      $id_map Map of old attachment ID => new attachment ID.
	 * @param array|null $allowed_paths Map of attribute path => old ID allowed there, or null when unrestricted.
	 * @return array Remapped attributes.
	 */
	private static function remap_attributes( array $attributes, array $id_map, ?array $allowed_paths ): array {
		foreach ( array( 'id', 'mediaId' ) as $single_key ) {
			if ( isset( $attributes[ $single_key ] ) && is_numeric( $attributes[ $single_key ] ) && isset( $id_map[ (int) $attributes[ $single_key ] ] ) ) {
				$old_value                 = $attributes[ $single_key ];
				$new_value                 = $id_map[ (int) $old_value ];
				$attributes[ $single_key ] = is_string( $old_value ) ? (string) $new_value : $new_value;
			}
		}

		if ( isset( $attributes['ids'] ) && is_array( $attributes['ids'] ) ) {
			foreach ( $attributes['ids'] as $position => $gallery_id ) {
				if ( is_numeric( $gallery_id ) && isset( $id_map[ (int) $gallery_id ] ) ) {
					$new_value                      = $id_map[ (int) $gallery_id ];
					$attributes['ids'][ $position ] = is_string( $gallery_id ) ? (string) $new_value : $new_value;
				}
			}
		}

		if ( null === $allowed_paths ) {
			foreach ( array_keys( $id_map ) as $old_id ) {
				$old_id = (int) $old_id;

				if ( ! isset( $id_map[ $old_id ] ) ) {
					continue;
				}

				$attributes = self::remap_generic_value( $attributes, $old_id, $id_map[ $old_id ], 0 );
			}

			return $attributes;
		}

		foreach ( $allowed_paths as $attr_path => $old_id ) {
			$old_id = (int) $old_id;

			if ( ! isset( $id_map[ $old_id ] ) ) {
				continue;
			}

			$attributes = self::remap_value_at_path( $attributes, (string) $attr_path, $old_id, $id_map[ $old_id ] );
		}

		return $attributes;
	}

	/**
	 * Swaps one collected attachment ID at one attribute path.
	 *
	 * Numeric segments address list positions. Missing segments or type
	 * mismatches leave the attributes untouched.
	 *
	 * @param array  $attributes Block delimiter attributes.
	 * @param string $attr_path Dot-notation attribute path.
	 * @param int    $old_id Old attachment ID to replace.
	 * @param int    $new_id New attachment ID replacing it.
	 * @return array Remapped attributes.
	 */
	private static function remap_value_at_path( array $attributes, string $attr_path, int $old_id, int $new_id ): array {
		$segments = explode( '.', $attr_path );

		if ( '' === $attr_path ) {
			return $attributes;
		}

		$first = (string) array_shift( $segments );

		if ( '' === $first || ! array_key_exists( $first, $attributes ) ) {
			return $attributes;
		}

		if ( array() === $segments ) {
			$current = $attributes[ $first ];

			if ( is_int( $current ) && $old_id === $current ) {
				$attributes[ $first ] = $new_id;
			} elseif ( is_string( $current ) && ctype_digit( $current ) && $old_id === (int) $current ) {
				$attributes[ $first ] = (string) $new_id;
			}

			return $attributes;
		}

		$attributes[ $first ] = self::remap_nested_value( $attributes[ $first ], $segments, $old_id, $new_id, 0 );

		return $attributes;
	}

	/**
	 * Swaps one collected attachment ID inside a nested attribute value.
	 *
	 * Numeric segments address list positions.
	 *
	 * @param mixed $value Attribute value (any JSON-decoded shape).
	 * @param array $segments Remaining dot-notation path segments.
	 * @param int   $old_id Old attachment ID to replace.
	 * @param int   $new_id New attachment ID replacing it.
	 * @param int   $depth Current recursion depth (guard).
	 * @return mixed Remapped value.
	 */
	private static function remap_nested_value( $value, array $segments, int $old_id, int $new_id, int $depth ) {
		if ( self::MAX_REMAP_DEPTH < $depth || array() === $segments ) {
			return $value;
		}

		$segment = array_shift( $segments );

		if ( ! is_string( $segment ) && ! is_int( $segment ) ) {
			return $value;
		}

		$segment = (string) $segment;

		if ( ! is_array( $value ) ) {
			return $value;
		}

		$key = ctype_digit( $segment ) && array_key_exists( (int) $segment, $value ) ? (int) $segment : $segment;

		if ( ! array_key_exists( $key, $value ) ) {
			return $value;
		}

		if ( array() === $segments ) {
			$current = $value[ $key ];

			if ( is_int( $current ) && $old_id === $current ) {
				$value[ $key ] = $new_id;
			} elseif ( is_string( $current ) && ctype_digit( $current ) && $old_id === (int) $current ) {
				$value[ $key ] = (string) $new_id;
			}

			return $value;
		}

		$value[ $key ] = self::remap_nested_value( $value[ $key ], $segments, $old_id, $new_id, $depth + 1 );

		return $value;
	}

	/**
	 * Swaps one collected attachment ID inside an arbitrary attribute value.
	 *
	 * Recurses arrays, swaps matching integers and equal-valued digit
	 * strings (preserving the string type), and rewrites matching integers
	 * inside JSON-encoded strings. Other scalars (external URLs, unrelated
	 * numerals such as prices or years) are never touched.
	 *
	 * @param mixed $value Attribute value (any JSON-decoded shape).
	 * @param int   $old_id Old attachment ID to replace.
	 * @param int   $new_id New attachment ID replacing it.
	 * @param int   $depth Current recursion depth (guard).
	 * @return mixed Remapped value.
	 */
	private static function remap_generic_value( $value, int $old_id, int $new_id, int $depth ) {
		if ( self::MAX_REMAP_DEPTH < $depth ) {
			return $value;
		}

		if ( is_array( $value ) ) {
			foreach ( $value as $key => $nested ) {
				$value[ $key ] = self::remap_generic_value( $nested, $old_id, $new_id, $depth + 1 );
			}

			return $value;
		}

		if ( is_int( $value ) && $old_id === $value ) {
			return $new_id;
		}

		if ( is_string( $value ) && ctype_digit( $value ) && $old_id === (int) $value ) {
			return (string) $new_id;
		}

		if ( is_string( $value ) && '' !== $value ) {
			$trimmed = ltrim( $value );

			if ( str_starts_with( $trimmed, '{' ) || str_starts_with( $trimmed, '[' ) ) {
				$decoded = json_decode( $value, true );

				if ( is_array( $decoded ) ) {
					$remapped = self::remap_generic_value( $decoded, $old_id, $new_id, $depth + 1 );

					if ( $remapped !== $decoded ) {
						$encoded = wp_json_encode( $remapped );

						if ( is_string( $encoded ) ) {
							return $encoded;
						}
					}
				}
			}
		}

		return $value;
	}

	/**
	 * Builds the per-block ref map from manifest block_refs.
	 *
	 * Each entry keeps its attribute key, so the remap can address the
	 * exact slot ("data.hero_image") instead of swapping every equal
	 * number in the block. "html"/"meta:*" refs are kept too (they prove
	 * citation but address no delimiter slot). "ref" segments (expanded
	 * reusable blocks) stay in the path; path_covers() treats them as
	 * transparent when matching.
	 *
	 * @param array $manifest Normalized manifest.
	 * @return array Map of block path => list of array(key, old_id).
	 */
	private static function build_block_ref_map( array $manifest ): array {
		$map = array();

		if ( ! isset( $manifest['media'] ) || ! is_array( $manifest['media'] ) ) {
			return $map;
		}

		// Two attachments can never share one path+key slot: a crafted
		// manifest claiming the same slot twice keeps the first claim.
		$seen_slots = array();

		foreach ( $manifest['media'] as $media_entry ) {
			if ( ! is_array( $media_entry ) || ! isset( $media_entry['old_id'] ) || ! is_numeric( $media_entry['old_id'] ) ) {
				continue;
			}

			$old_id = (int) $media_entry['old_id'];

			if ( ! isset( $media_entry['block_refs'] ) || ! is_array( $media_entry['block_refs'] ) ) {
				continue;
			}

			foreach ( $media_entry['block_refs'] as $reference ) {
				if ( ! is_array( $reference ) || ! isset( $reference['path'], $reference['key'] ) || ! is_string( $reference['path'] ) || '' === $reference['path'] || ! is_string( $reference['key'] ) ) {
					continue;
				}

				$ref_path = $reference['path'];
				$slot     = $ref_path . "\0" . $reference['key'];

				if ( isset( $seen_slots[ $slot ] ) ) {
					continue;
				}

				$seen_slots[ $slot ] = true;

				if ( ! isset( $map[ $ref_path ] ) ) {
					$map[ $ref_path ] = array();
				}

				$map[ $ref_path ][] = array(
					'key'    => $reference['key'],
					'old_id' => $old_id,
				);
			}
		}

		return $map;
	}

	/**
	 * Rewrites old attachment URLs to new ones at file-BASE level.
	 *
	 * Static blocks render from saved HTML (src/href/srcset), so attribute
	 * remap alone leaves stale URLs. Stripping the extension plus any size
	 * suffix (".../uploads/2026/09/foo") matches every size variant
	 * (-150x150 etc.). Full-URL string replacement only — never numeric.
	 *
	 * @param string $content Serialized post content with remapped IDs.
	 * @param array  $manifest Normalized manifest (old URLs).
	 * @param array  $id_map Map of old attachment ID => new attachment ID.
	 * @return string Content with media URLs rewritten.
	 */
	private static function rewrite_media_urls( string $content, array $manifest, array $id_map ): string {
		$old_urls = array();

		foreach ( $manifest['media'] as $media_entry ) {
			if ( ! is_array( $media_entry ) || ! isset( $media_entry['old_id'] ) || ! is_numeric( $media_entry['old_id'] ) ) {
				continue;
			}

			$media_old_id = (int) $media_entry['old_id'];

			if ( isset( $id_map[ $media_old_id ] ) && isset( $media_entry['url'] ) && is_string( $media_entry['url'] ) && '' !== $media_entry['url'] ) {
				$old_urls[ $media_old_id ] = $media_entry['url'];
			}
		}

		foreach ( $old_urls as $media_old_id => $old_url ) {
			$new_url = wp_get_attachment_url( $id_map[ $media_old_id ] );

			if ( ! is_string( $new_url ) || '' === $new_url ) {
				continue;
			}

			$old_base = self::url_file_base( $old_url );
			$new_base = self::url_file_base( $new_url );

			if ( '' !== $old_base && '' !== $new_base && $old_base !== $new_base ) {
				$content = str_replace( $old_base, $new_base, $content );
				// Media URLs inside nested JSON-encoded strings are
				// double-escaped once serialize_blocks() doubles their
				// backslashes, so the raw base never matches those bytes —
				// rewrite the double-escaped form too.
				$old_double = str_replace( '/', '\\\\/', $old_base );
				$new_double = str_replace( '/', '\\\\/', $new_base );
				$content    = str_replace( $old_double, $new_double, $content );
			}
		}

		return $content;
	}

	/**
	 * Strips the extension and any -WIDTHxHEIGHT / -scaled / -rotated suffix
	 * from an attachment URL, yielding the file base shared by all size
	 * variants.
	 *
	 * @param string $url Attachment URL.
	 * @return string File base (URL without extension and size suffix).
	 */
	private static function url_file_base( string $url ): string {
		$path_end = strrpos( $url, '.' );

		if ( false === $path_end ) {
			return $url;
		}

		$without_extension = substr( $url, 0, $path_end );
		$stripped_base     = (string) preg_replace( '/-(?:\d+x\d+|scaled|rotated)$/', '', $without_extension );

		return '' !== $stripped_base ? $stripped_base : $without_extension;
	}

	/**
	 * Replaces the manifest source host with this site's host.
	 *
	 * Only URL-shaped occurrences (scheme://host or protocol-relative
	 * //host) are swapped, and only when both URLs parse and the hosts
	 * actually differ — bare textual mentions of the staging domain and
	 * same-host ferries are left byte-identical. The block serializer
	 * never slash-escapes top-level attrs (JSON_UNESCAPED_SLASHES), so
	 * plain //host covers those; nested JSON-encoded strings gain one
	 * backslash per level once re-serialized (double-escaped), and raw
	 * unserialized input such as excerpts may carry single-escaped (\/)
	 * snippets — each form needs its own pass.
	 *
	 * @param string $content Content or excerpt.
	 * @param array  $manifest Normalized manifest.
	 * @return string Content with the source host swapped.
	 */
	private static function rewrite_source_host( string $content, array $manifest ): string {
		$source_url = isset( $manifest['source']['url'] ) ? (string) $manifest['source']['url'] : '';

		if ( '' === $source_url ) {
			return $content;
		}

		$source_parts = wp_parse_url( $source_url );
		$site_parts   = wp_parse_url( site_url() );

		if ( ! is_array( $source_parts ) || ! is_array( $site_parts ) ) {
			return $content;
		}

		$source_host = isset( $source_parts['host'] ) ? (string) $source_parts['host'] : '';
		$site_host   = isset( $site_parts['host'] ) ? (string) $site_parts['host'] : '';

		if ( '' === $source_host || '' === $site_host || $source_host === $site_host ) {
			return $content;
		}

		$content = str_replace( '//' . $source_host, '//' . $site_host, $content );
		// Neither escaped form contains the plain //host bytes: the
		// single-escaped pass covers raw/unserialized input (excerpts),
		// the double-escaped pass covers nested JSON strings after
		// serialize_blocks() doubles their backslashes.
		$content = str_replace( '\\/\\/' . $source_host, '\\/\\/' . $site_host, $content );
		$content = str_replace( '\\\\/\\\\/' . $source_host, '\\\\/\\\\/' . $site_host, $content );

		return $content;
	}

	/**
	 * Creates missing terms and assigns them to the post.
	 *
	 * Prefers the manifest's tax_terms detail (name/slug/parent, parents
	 * first) to rebuild hierarchy; falls back to flat post.tax names for
	 * bundles predating that key. Terms match by NAME; existing terms keep
	 * their current parents — imports never restructure a site's taxonomy.
	 *
	 * Walks every taxonomy recorded in the bundle (core or custom) and
	 * assigns each one that exists on this site — matching v1 semantics,
	 * where category/post_tag terms ferry even onto page bundles. Unknown
	 * taxonomies are skipped.
	 *
	 * @param int   $post_id Post ID just created or updated.
	 * @param array $manifest Normalized manifest.
	 * @return void
	 */
	private static function assign_terms( int $post_id, array $manifest ): void {
		$detailed = isset( $manifest['tax_terms'] ) && is_array( $manifest['tax_terms'] ) ? $manifest['tax_terms'] : array();
		$flat     = isset( $manifest['post']['tax'] ) && is_array( $manifest['post']['tax'] ) ? $manifest['post']['tax'] : array();

		$recorded = array_unique( array_merge( array_keys( $detailed ), array_keys( $flat ) ) );

		foreach ( $recorded as $taxonomy ) {
			if ( ! is_string( $taxonomy ) || '' === $taxonomy || ! taxonomy_exists( $taxonomy ) ) {
				continue;
			}

			$detailed_terms = isset( $detailed[ $taxonomy ] ) && is_array( $detailed[ $taxonomy ] ) ? $detailed[ $taxonomy ] : array();

			if ( array() !== $detailed_terms ) {
				self::assign_detailed_terms( $post_id, $taxonomy, $detailed_terms );
				continue;
			}

			$flat_names = isset( $flat[ $taxonomy ] ) && is_array( $flat[ $taxonomy ] ) ? $flat[ $taxonomy ] : array();
			$term_ids   = array();

			foreach ( $flat_names as $term_name ) {
				$term_id = self::ensure_term( (string) $term_name, $taxonomy, '', 0 );

				if ( null !== $term_id ) {
					$term_ids[] = $term_id;
				}
			}

			if ( array() !== $term_ids ) {
				wp_set_object_terms( $post_id, $term_ids, $taxonomy );
			}
		}
	}

	/**
	 * Assigns detailed (hierarchy-aware) terms to the post.
	 *
	 * @param int    $post_id Post ID just created or updated.
	 * @param string $taxonomy Taxonomy slug.
	 * @param array  $detailed_terms List of {name, slug, parent} (parents first).
	 * @return void
	 */
	private static function assign_detailed_terms( int $post_id, string $taxonomy, array $detailed_terms ): void {
		$is_hierarchical = is_taxonomy_hierarchical( $taxonomy );
		$term_ids        = array();

		foreach ( $detailed_terms as $term ) {
			if ( ! is_array( $term ) || ! isset( $term['name'] ) || ! is_string( $term['name'] ) || '' === trim( $term['name'] ) ) {
				continue;
			}

			$slug           = isset( $term['slug'] ) && is_string( $term['slug'] ) ? $term['slug'] : '';
			$parent_name    = $is_hierarchical && isset( $term['parent'] ) && is_string( $term['parent'] ) ? $term['parent'] : '';
			$parent_term    = '' !== $parent_name ? get_term_by( 'name', $parent_name, $taxonomy ) : false;
			$parent_term_id = $parent_term instanceof WP_Term ? (int) $parent_term->term_id : 0;
			$term_id        = self::ensure_term( $term['name'], $taxonomy, $slug, $parent_term_id );

			if ( null !== $term_id ) {
				$term_ids[] = $term_id;
			}
		}

		if ( array() !== $term_ids ) {
			wp_set_object_terms( $post_id, $term_ids, $taxonomy );
		}
	}

	/**
	 * Finds a term by name or creates it.
	 *
	 * @param string $name Term name.
	 * @param string $taxonomy Taxonomy slug.
	 * @param string $slug Desired slug (creation only).
	 * @param int    $parent_term_id Parent term ID (hierarchical only).
	 * @return int|null Term ID, or null when the name is empty.
	 */
	private static function ensure_term( string $name, string $taxonomy, string $slug, int $parent_term_id ): ?int {
		if ( '' === trim( $name ) ) {
			return null;
		}

		$existing_term = get_term_by( 'name', $name, $taxonomy );

		if ( $existing_term instanceof WP_Term ) {
			return (int) $existing_term->term_id;
		}

		$insert_args = array( 'parent' => $parent_term_id );

		if ( '' !== $slug ) {
			$insert_args['slug'] = $slug;
		}

		$created_term = wp_insert_term( $name, $taxonomy, $insert_args );

		if ( is_wp_error( $created_term ) ) {
			if ( 'term_exists' === $created_term->get_error_code() ) {
				return (int) $created_term->get_error_data();
			}

			return null;
		}

		return (int) $created_term['term_id'];
	}

	/**
	 * Points _thumbnail_id at the new featured attachment.
	 *
	 * @param int   $post_id Post ID just created or updated.
	 * @param array $manifest Normalized manifest.
	 * @param array $id_map Map of old attachment ID => new attachment ID.
	 * @return void
	 */
	private static function assign_thumbnail( int $post_id, array $manifest, array $id_map ): void {
		$thumbnail_old_id = isset( $manifest['post']['thumbnail_old_id'] ) ? (int) $manifest['post']['thumbnail_old_id'] : 0;

		if ( 0 < $thumbnail_old_id && isset( $id_map[ $thumbnail_old_id ] ) ) {
			set_post_thumbnail( $post_id, $id_map[ $thumbnail_old_id ] );
		}
	}

	/**
	 * Restores ACF usePostMeta field values onto the imported post.
	 *
	 * Since ACF 6.3 a block may set usePostMeta (block.json `acf.usePostMeta`),
	 * in which case its values live in post meta instead of the block comment.
	 * The exporter ferries those raw values in top-level `acf_post_meta`;
	 * here each value is remapped (media IDs via the sideload id_map, upload
	 * URLs via the media/host rewrite passes) and written back through ACF
	 * APIs only — acf_update_value() preferred, update_field() fallback —
	 * never via direct database access. Only fields present in the entry are
	 * written: source-unset fields are omitted, so an update-selected import
	 * keeps the target's existing value for those (keep-target semantics —
	 * imports never delete meta they cannot see). Fields unknown on this
	 * site (ACF or the field group inactive) are skipped; entries for blocks
	 * absent from the bundle content (any depth — PHP-registered blocks may
	 * nest) are skipped so a crafted manifest cannot smuggle unrelated meta.
	 * Every skip is reported in the returned notes; run() records them in
	 * the import log row under `acf_skipped` so a partial ferry is visible
	 * in the Logs tab.
	 *
	 * @param int   $new_post_id Post ID just created or updated.
	 * @param array $manifest    Normalized manifest.
	 * @param array $id_map      Map of old attachment ID => new attachment ID.
	 * @return array List of human-readable skip notes (empty when all restored).
	 */
	private static function restore_acf_post_meta( int $new_post_id, array $manifest, array $id_map ): array {
		if ( ! function_exists( 'acf_block_uses_post_meta' ) || ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
			return array();
		}

		if ( ! function_exists( 'acf_update_value' ) && ! function_exists( 'update_field' ) ) {
			return array();
		}

		if ( ! isset( $manifest['acf_post_meta'] ) || ! is_array( $manifest['acf_post_meta'] ) || array() === $manifest['acf_post_meta'] ) {
			return array();
		}

		$skipped        = array();
		$bundle_content = isset( $manifest['post']['content'] ) && is_string( $manifest['post']['content'] ) ? $manifest['post']['content'] : '';
		/** Bundle blocks as a plain list. @var array $content_blocks Unshaped parse_blocks() result for PHPStan. */
		$content_blocks = '' !== $bundle_content ? parse_blocks( $bundle_content ) : array();
		$content_names  = array();
		self::collect_block_names( $content_blocks, $content_names );

		foreach ( $manifest['acf_post_meta'] as $acf_entry ) {
			if ( ! is_array( $acf_entry ) || ! isset( $acf_entry['block'], $acf_entry['fields'] ) || ! is_string( $acf_entry['block'] ) || ! is_array( $acf_entry['fields'] ) ) {
				continue;
			}

			$block_name = $acf_entry['block'];

			if ( ! in_array( $block_name, $content_names, true ) ) {
				$skipped[] = sprintf( 'ACF block %s is not in the bundle content; its post meta was skipped.', $block_name );
				continue;
			}

			if ( ! acf_block_uses_post_meta( array( 'name' => $block_name ) ) ) {
				$skipped[] = sprintf( 'ACF block %s does not use post meta on this site; its values were skipped.', $block_name );
				continue;
			}

			$target_fields = self::get_acf_block_fields( $block_name );

			if ( array() === $target_fields ) {
				$skipped[] = sprintf( 'ACF block %s has no field group on this site; its values were skipped.', $block_name );
				continue;
			}

			$fields_by_name = array();

			foreach ( $target_fields as $target_field ) {
				if ( is_array( $target_field ) && isset( $target_field['name'] ) && is_string( $target_field['name'] ) && '' !== $target_field['name'] ) {
					$fields_by_name[ $target_field['name'] ] = $target_field;
				}
			}

			$skipped_fields = array();

			foreach ( $acf_entry['fields'] as $field_name => $old_value ) {
				if ( ! is_string( $field_name ) || '' === $field_name || ! isset( $fields_by_name[ $field_name ] ) ) {
					$skipped_fields[] = is_string( $field_name ) && '' !== $field_name ? $field_name : '(unnamed field)';
					continue;
				}

				$field_definition = $fields_by_name[ $field_name ];
				$remapped_value   = self::remap_acf_field_value( $old_value, $field_definition, $id_map, $manifest, 0 );

				if ( function_exists( 'acf_update_value' ) ) {
					acf_update_value( $remapped_value, $new_post_id, $field_definition );
				} elseif ( function_exists( 'update_field' ) ) {
					$field_selector = isset( $field_definition['key'] ) && is_string( $field_definition['key'] ) && '' !== $field_definition['key'] ? $field_definition['key'] : $field_name;
					update_field( $field_selector, $remapped_value, $new_post_id );
				}
			}

			if ( array() !== $skipped_fields ) {
				$skipped[] = sprintf( 'ACF block %s skipped unknown field(s): %s.', $block_name, implode( ', ', $skipped_fields ) );
			}
		}

		return $skipped;
	}

	/**
	 * Collects every block name in a parsed tree, at any depth.
	 *
	 * @param array $blocks Parsed blocks at this level.
	 * @param array $names  Block names found so far (appended to).
	 * @return void
	 */
	private static function collect_block_names( array $blocks, array &$names ): void {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			if ( isset( $block['blockName'] ) && is_string( $block['blockName'] ) ) {
				$names[] = $block['blockName'];
			}

			if ( isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::collect_block_names( $block['innerBlocks'], $names );
			}
		}
	}

	/**
	 * Returns the top-level ACF fields for a block, memoized per request.
	 *
	 * Mirrors the collector's lookup so the importer resolves the same field
	 * definitions on this site; a block whose field group is inactive here
	 * yields an empty list and its meta entry is skipped.
	 *
	 * @param string $block_name Full ACF block name.
	 * @return array List of ACF field arrays.
	 */
	private static function get_acf_block_fields( string $block_name ): array {
		static $field_cache = array();

		if ( isset( $field_cache[ $block_name ] ) ) {
			return $field_cache[ $block_name ];
		}

		$field_cache[ $block_name ] = array();

		if ( ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
			return $field_cache[ $block_name ];
		}

		$field_groups = acf_get_field_groups( array( 'block' => $block_name ) );

		if ( ! is_array( $field_groups ) ) {
			return $field_cache[ $block_name ];
		}

		foreach ( $field_groups as $field_group ) {
			if ( ! is_array( $field_group ) ) {
				continue;
			}

			$group_fields = acf_get_fields( $field_group );

			if ( ! is_array( $group_fields ) ) {
				continue;
			}

			foreach ( $group_fields as $group_field ) {
				if ( is_array( $group_field ) ) {
					$field_cache[ $block_name ][] = $group_field;
				}
			}
		}

		return $field_cache[ $block_name ];
	}

	/**
	 * Remaps one ACF field value for the new site.
	 *
	 * Attachment IDs stored verbatim (image, file, gallery, media-library
	 * icon_picker) swap via the sideload id_map with the source string type
	 * preserved; missing-media IDs stay untouched. URL-capable text fields
	 * are rewritten (media file-base + source-host passes) without ever
	 * treating integers as IDs. Containers recurse into their sub-fields;
	 * every other type passes through verbatim so non-media block data
	 * (text, numbers, choices) ferries intact.
	 *
	 * @param mixed $value      Raw field value from the manifest.
	 * @param array $field      Target-site ACF field definition.
	 * @param array $id_map     Map of old attachment ID => new attachment ID.
	 * @param array $manifest   Normalized manifest (old URLs, source host).
	 * @param int   $depth      Current recursion depth (guard).
	 * @return mixed Remapped value.
	 */
	private static function remap_acf_field_value( $value, array $field, array $id_map, array $manifest, int $depth ) {
		if ( self::MAX_REMAP_DEPTH < $depth ) {
			return $value;
		}

		$field_type = isset( $field['type'] ) && is_string( $field['type'] ) ? $field['type'] : '';

		switch ( $field_type ) {
			case 'image':
			case 'file':
				if ( is_int( $value ) || ( is_string( $value ) && ctype_digit( $value ) ) ) {
					$old_id = (int) $value;

					if ( isset( $id_map[ $old_id ] ) ) {
						return is_string( $value ) ? (string) $id_map[ $old_id ] : $id_map[ $old_id ];
					}

					return $value;
				}

				if ( is_float( $value ) && floor( $value ) === $value ) {
					$old_id = (int) $value;

					if ( isset( $id_map[ $old_id ] ) ) {
						return $id_map[ $old_id ];
					}

					return $value;
				}

				if ( is_string( $value ) ) {
					return self::rewrite_acf_string( $value, $manifest, $id_map );
				}

				if ( is_array( $value ) ) {
					$value = self::remap_acf_attachment_array_id( $value, $id_map );

					return self::remap_acf_url_value( $value, $manifest, $id_map, $depth + 1 );
				}

				return $value;
			case 'gallery':
				if ( is_int( $value ) || ( is_string( $value ) && ctype_digit( $value ) ) ) {
					$old_id = (int) $value;

					if ( isset( $id_map[ $old_id ] ) ) {
						return is_string( $value ) ? (string) $id_map[ $old_id ] : $id_map[ $old_id ];
					}

					return $value;
				}

				if ( is_float( $value ) && floor( $value ) === $value ) {
					$old_id = (int) $value;

					if ( isset( $id_map[ $old_id ] ) ) {
						return $id_map[ $old_id ];
					}

					return $value;
				}

				if ( is_string( $value ) ) {
					return self::rewrite_acf_string( $value, $manifest, $id_map );
				}

				if ( ! is_array( $value ) ) {
					return $value;
				}

				foreach ( $value as $position => $gallery_item ) {
					if ( is_int( $gallery_item ) || ( is_string( $gallery_item ) && ctype_digit( $gallery_item ) ) ) {
						$old_id = (int) $gallery_item;

						if ( isset( $id_map[ $old_id ] ) ) {
							$value[ $position ] = is_string( $gallery_item ) ? (string) $id_map[ $old_id ] : $id_map[ $old_id ];
						}
					} elseif ( is_float( $gallery_item ) && floor( $gallery_item ) === $gallery_item ) {
						$old_id = (int) $gallery_item;

						if ( isset( $id_map[ $old_id ] ) ) {
							$value[ $position ] = $id_map[ $old_id ];
						}
					} elseif ( is_string( $gallery_item ) ) {
						$value[ $position ] = self::rewrite_acf_string( $gallery_item, $manifest, $id_map );
					} elseif ( is_array( $gallery_item ) ) {
						$value[ $position ] = self::remap_acf_url_value( self::remap_acf_attachment_array_id( $gallery_item, $id_map ), $manifest, $id_map, $depth + 1 );
					}
				}

				return $value;
			case 'icon_picker':
				if ( ! is_array( $value ) ) {
					if ( is_string( $value ) ) {
						return self::rewrite_acf_string( $value, $manifest, $id_map );
					}

					return $value;
				}

				$icon_type  = isset( $value['type'] ) && is_string( $value['type'] ) ? $value['type'] : '';
				$icon_value = array_key_exists( 'value', $value ) ? $value['value'] : null;

				if ( 'media_library' === $icon_type ) {
					if ( is_int( $icon_value ) || ( is_string( $icon_value ) && ctype_digit( $icon_value ) ) ) {
						$old_id = (int) $icon_value;

						if ( isset( $id_map[ $old_id ] ) ) {
							$value['value'] = is_string( $icon_value ) ? (string) $id_map[ $old_id ] : $id_map[ $old_id ];
						}
					} elseif ( is_float( $icon_value ) && floor( $icon_value ) === $icon_value ) {
						$old_id = (int) $icon_value;

						if ( isset( $id_map[ $old_id ] ) ) {
							$value['value'] = $id_map[ $old_id ];
						}
					} elseif ( is_string( $icon_value ) ) {
						$value['value'] = self::rewrite_acf_string( $icon_value, $manifest, $id_map );
					}
				} elseif ( 'url' === $icon_type && is_string( $icon_value ) ) {
					$value['value'] = self::rewrite_acf_string( $icon_value, $manifest, $id_map );
				} else {
					return self::remap_acf_url_value( $value, $manifest, $id_map, $depth + 1 );
				}

				return $value;
			case 'group':
			case 'clone':
				$sub_fields = self::acf_sub_fields( $field );

				if ( array() === $sub_fields || ! is_array( $value ) ) {
					return $value;
				}

				foreach ( $sub_fields as $sub_field ) {
					if ( ! is_array( $sub_field ) ) {
						continue;
					}

					$used_key = self::acf_matching_value_key( $value, $sub_field );

					if ( null === $used_key ) {
						continue;
					}

					$value[ $used_key ] = self::remap_acf_field_value( $value[ $used_key ], $sub_field, $id_map, $manifest, $depth + 1 );
				}

				return $value;
			case 'repeater':
				$sub_fields = self::acf_sub_fields( $field );

				if ( array() === $sub_fields || ! is_array( $value ) ) {
					return $value;
				}

				foreach ( $value as $row_index => $row ) {
					if ( ! is_array( $row ) ) {
						continue;
					}

					foreach ( $sub_fields as $sub_field ) {
						if ( ! is_array( $sub_field ) ) {
							continue;
						}

						$used_key = self::acf_matching_value_key( $row, $sub_field );

						if ( null === $used_key ) {
							continue;
						}

						$row[ $used_key ] = self::remap_acf_field_value( $row[ $used_key ], $sub_field, $id_map, $manifest, $depth + 1 );
					}

					$value[ $row_index ] = $row;
				}

				return $value;
			case 'flexible_content':
				if ( ! is_array( $value ) ) {
					return $value;
				}

				$layouts = isset( $field['layouts'] ) && is_array( $field['layouts'] ) ? $field['layouts'] : array();

				foreach ( $value as $row_index => $row ) {
					if ( ! is_array( $row ) ) {
						continue;
					}

					$layout_name = isset( $row['acf_fc_layout'] ) && is_string( $row['acf_fc_layout'] ) ? $row['acf_fc_layout'] : '';

					if ( '' === $layout_name ) {
						$value[ $row_index ] = self::remap_acf_url_value( $row, $manifest, $id_map, $depth + 1 );
						continue;
					}

					$layout_fields = null;

					foreach ( $layouts as $layout ) {
						if ( is_array( $layout ) && isset( $layout['name'] ) && $layout_name === $layout['name'] && isset( $layout['sub_fields'] ) && is_array( $layout['sub_fields'] ) ) {
							$layout_fields = $layout['sub_fields'];
							break;
						}
					}

					if ( ! is_array( $layout_fields ) ) {
						continue;
					}

					foreach ( $layout_fields as $sub_field ) {
						if ( ! is_array( $sub_field ) ) {
							continue;
						}

						$used_key = self::acf_matching_value_key( $row, $sub_field );

						if ( null === $used_key ) {
							continue;
						}

						$row[ $used_key ] = self::remap_acf_field_value( $row[ $used_key ], $sub_field, $id_map, $manifest, $depth + 1 );
					}

					$value[ $row_index ] = $row;
				}

				return $value;
			case 'text':
			case 'textarea':
			case 'wysiwyg':
			case 'url':
			case 'link':
			case 'oembed':
			case 'email':
			case 'page_link':
				return self::remap_acf_url_value( $value, $manifest, $id_map, $depth + 1 );
			default:
				return $value;
		}
	}

	/**
	 * Remaps the attachment ID inside an array-shaped media value.
	 *
	 * Raw image/file/gallery values are IDs, but a stored array shape is
	 * handled defensively: ACF's file/image update_value() normalizes any
	 * value through acf_idval(), which reads only the uppercase `ID` key —
	 * so a stale source ID there would survive the URL rewrite and persist.
	 * The key is swapped type-preserving when mapped, then the remaining
	 * URL strings are rewritten by the caller.
	 *
	 * @param array $value  Array-shaped field value or gallery item.
	 * @param array $id_map Map of old attachment ID => new attachment ID.
	 * @return array Value with the ID key remapped.
	 */
	private static function remap_acf_attachment_array_id( array $value, array $id_map ): array {
		if ( isset( $value['ID'] ) && ( is_int( $value['ID'] ) || ( is_string( $value['ID'] ) && ctype_digit( $value['ID'] ) ) ) ) {
			$old_id = (int) $value['ID'];

			if ( isset( $id_map[ $old_id ] ) ) {
				$value['ID'] = is_string( $value['ID'] ) ? (string) $id_map[ $old_id ] : $id_map[ $old_id ];
			}
		}

		return $value;
	}

	/**
	 * Rewrites upload URLs inside a URL-capable ACF value.
	 *
	 * Strings pass through the same media file-base and source-host rewrites
	 * as post content; arrays recurse. Integers and other scalars pass
	 * through untouched so post/term/user IDs stored by page_link and
	 * relationship-style fields are never remapped.
	 *
	 * @param mixed $value    Field value of any shape.
	 * @param array $manifest Normalized manifest (old URLs, source host).
	 * @param array $id_map   Map of old attachment ID => new attachment ID.
	 * @param int   $depth    Current recursion depth (guard).
	 * @return mixed Value with URLs rewritten.
	 */
	private static function remap_acf_url_value( $value, array $manifest, array $id_map, int $depth ) {
		if ( self::MAX_REMAP_DEPTH < $depth ) {
			return $value;
		}

		if ( is_string( $value ) ) {
			return self::rewrite_acf_string( $value, $manifest, $id_map );
		}

		if ( ! is_array( $value ) ) {
			return $value;
		}

		foreach ( $value as $key => $nested ) {
			$value[ $key ] = self::remap_acf_url_value( $nested, $manifest, $id_map, $depth + 1 );
		}

		return $value;
	}

	/**
	 * Applies the media-URL and source-host rewrites to one string.
	 *
	 * @param string $text     String possibly containing upload URLs.
	 * @param array  $manifest Normalized manifest (old URLs, source host).
	 * @param array  $id_map   Map of old attachment ID => new attachment ID.
	 * @return string Rewritten string.
	 */
	private static function rewrite_acf_string( string $text, array $manifest, array $id_map ): string {
		if ( '' === $text ) {
			return $text;
		}

		$rewritten = self::rewrite_media_urls( $text, $manifest, $id_map );

		return self::rewrite_source_host( $rewritten, $manifest );
	}

	/**
	 * Returns a container field's sub-fields, loading them when needed.
	 *
	 * @param array $field ACF field definition.
	 * @return array List of sub-field arrays.
	 */
	private static function acf_sub_fields( array $field ): array {
		if ( isset( $field['sub_fields'] ) && is_array( $field['sub_fields'] ) && array() !== $field['sub_fields'] ) {
			return $field['sub_fields'];
		}

		if ( function_exists( 'acf_get_fields' ) ) {
			$loaded = acf_get_fields( $field );

			if ( is_array( $loaded ) ) {
				return $loaded;
			}
		}

		return array();
	}

	/**
	 * Finds the array key holding a sub-field's value (key first, then name).
	 *
	 * @param array $values    Container value array.
	 * @param array $sub_field Sub-field definition.
	 * @return string|null Matching key, or null when absent.
	 */
	private static function acf_matching_value_key( array $values, array $sub_field ): ?string {
		$sub_key  = isset( $sub_field['key'] ) && is_string( $sub_field['key'] ) ? $sub_field['key'] : '';
		$sub_name = isset( $sub_field['name'] ) && is_string( $sub_field['name'] ) ? $sub_field['name'] : '';

		if ( '' !== $sub_key && array_key_exists( $sub_key, $values ) ) {
			return $sub_key;
		}

		if ( '' !== $sub_name && array_key_exists( $sub_name, $values ) ) {
			return $sub_name;
		}

		return null;
	}

	/**
	 * Applies alt text, caption, title, and description from the manifest to
	 * an attachment.
	 *
	 * Only non-empty manifest values overwrite, so reusing an attachment
	 * never blanks fields the source left unset; new attachments keep the
	 * WordPress sideload defaults for unset fields.
	 *
	 * @param int   $attachment_id Attachment ID (reused or new).
	 * @param array $media_entry Manifest media entry.
	 * @return void
	 */
	private static function apply_media_meta( int $attachment_id, array $media_entry ): void {
		if ( isset( $media_entry['alt'] ) && is_string( $media_entry['alt'] ) && '' !== $media_entry['alt'] ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', $media_entry['alt'] );
		}

		$post_update = array( 'ID' => $attachment_id );

		if ( isset( $media_entry['caption'] ) && is_string( $media_entry['caption'] ) && '' !== $media_entry['caption'] ) {
			$post_update['post_excerpt'] = $media_entry['caption'];
		}

		if ( isset( $media_entry['title'] ) && is_string( $media_entry['title'] ) && '' !== $media_entry['title'] ) {
			$post_update['post_title'] = $media_entry['title'];
		}

		if ( isset( $media_entry['description'] ) && is_string( $media_entry['description'] ) && '' !== $media_entry['description'] ) {
			$post_update['post_content'] = $media_entry['description'];
		}

		if ( 1 < count( $post_update ) ) {
			wp_update_post( $post_update );
		}
	}

	/**
	 * Snapshots a post's content + meta before overwrite (capped at MAX_BACKUPS).
	 *
	 * @param WP_Post $target_post Post about to be overwritten.
	 * @return string Backup reference key.
	 */
	private static function snapshot_post( WP_Post $target_post ): string {
		$backups = get_option( self::BACKUP_OPTION, array() );

		if ( ! is_array( $backups ) ) {
			$backups = array();
		}

		$backup_key             = 'pf-' . gmdate( 'YmdHis' ) . '-' . $target_post->ID . '-' . wp_generate_password( 6, false );
		$backups[ $backup_key ] = array(
			'time'         => gmdate( 'c' ),
			'post_id'      => $target_post->ID,
			'post_content' => $target_post->post_content,
			'post_meta'    => get_post_meta( $target_post->ID ),
		);

		$backup_count = count( $backups );

		while ( self::MAX_BACKUPS < $backup_count ) {
			array_shift( $backups );
			--$backup_count;
		}

		update_option( self::BACKUP_OPTION, $backups, false );

		return $backup_key;
	}

	/**
	 * Drops a backup snapshot (called when the import aborts after snapshotting).
	 *
	 * @param string|null $backup_reference Backup key or null.
	 * @return void
	 */
	private static function forget_backup( ?string $backup_reference ): void {
		if ( null === $backup_reference ) {
			return;
		}

		$backups = get_option( self::BACKUP_OPTION, array() );

		if ( is_array( $backups ) && isset( $backups[ $backup_reference ] ) ) {
			unset( $backups[ $backup_reference ] );
			update_option( self::BACKUP_OPTION, $backups, false );
		}
	}

	/**
	 * Appends one plain-language row to the import log option.
	 *
	 * @param array $row Log row.
	 * @return void
	 */
	private static function append_log( array $row ): void {
		$log_rows = get_option( self::LOG_OPTION, array() );

		if ( ! is_array( $log_rows ) ) {
			$log_rows = array();
		}

		$log_rows[] = $row;

		if ( self::MAX_LOG_ROWS < count( $log_rows ) ) {
			$log_rows = array_slice( $log_rows, -self::MAX_LOG_ROWS );
		}

		update_option( self::LOG_OPTION, $log_rows, false );
	}

	/**
	 * Records a verified sha256 → attachment ID mapping.
	 *
	 * The index is pruned when it grows past HASH_PRUNE_THRESHOLD: rows whose
	 * attachment file is gone are dropped, and the tail is kept when the
	 * index still exceeds MAX_HASH_ROWS.
	 *
	 * @param string $sha256 Content hash.
	 * @param int    $attachment_id Attachment ID.
	 * @return void
	 */
	private static function remember_hash( string $sha256, int $attachment_id ): void {
		$hash_index = get_option( self::HASH_INDEX_OPTION, array() );

		if ( ! is_array( $hash_index ) ) {
			$hash_index = array();
		}

		$hash_index[ $sha256 ] = $attachment_id;

		if ( self::HASH_PRUNE_THRESHOLD < count( $hash_index ) ) {
			foreach ( $hash_index as $indexed_hash => $indexed_id ) {
				if ( $sha256 === (string) $indexed_hash ) {
					continue;
				}

				$indexed_file = get_attached_file( (int) $indexed_id );

				if ( ! is_string( $indexed_file ) || ! is_readable( $indexed_file ) ) {
					unset( $hash_index[ $indexed_hash ] );
				}
			}

			if ( self::MAX_HASH_ROWS < count( $hash_index ) ) {
				$hash_index = array_slice( $hash_index, -self::MAX_HASH_ROWS, null, true );
			}
		}

		update_option( self::HASH_INDEX_OPTION, $hash_index, false );
	}
}
