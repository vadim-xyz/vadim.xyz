<?php
/**
 * Core loader for PageFerry.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/**
 * Bootstraps the plugin and owns all hook wiring.
 *
 * Canonical store for the plugin's own option and transient names: every
 * class reads these constants (directly or through aliases) so uninstall.php
 * cannot drift from the code that writes them.
 */
class PageFerry {

	/**
	 * Option holding the sha256 → attachment ID reuse index.
	 *
	 * @var string
	 */
	const OPTION_HASH_INDEX = 'pageferry_hash_index';

	/**
	 * Option holding plain-language import log rows.
	 *
	 * @var string
	 */
	const OPTION_LOGS = 'pageferry_logs';

	/**
	 * Option holding pre-overwrite snapshots, keyed by import ID.
	 *
	 * @var string
	 */
	const OPTION_BACKUPS = 'pageferry_backups';

	/**
	 * Transient prefix for Path B import sessions (validate→file→commit).
	 *
	 * @var string
	 */
	const TRANSIENT_SESSION_PREFIX = 'pageferry_session_';

	/**
	 * Transient prefix for the Path A two-step form stash.
	 *
	 * @var string
	 */
	const TRANSIENT_IMPORT_PREFIX = 'pageferry_import_';

	/**
	 * Transient prefix for the post-import success notice.
	 *
	 * @var string
	 */
	const TRANSIENT_RESULT_PREFIX = 'pageferry_import_result_';

	/**
	 * Option holding the last workspace GC run timestamp.
	 *
	 * @var string
	 */
	const OPTION_LAST_GC = 'pageferry_last_gc';

	/**
	 * Transient prefix for the per-user Path B session-creation quota.
	 *
	 * @var string
	 */
	const TRANSIENT_QUOTA_PREFIX = 'pageferry_quota_';

	/**
	 * Registers the plugin's hooks.
	 *
	 * Hooks-only wiring with no side effects at file load; all admin UI goes
	 * through PageFerry_Admin, import/export logic stays in its own classes.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'load_textdomain' ) );

		require_once dirname( __DIR__ ) . '/includes/class-pageferry-media-collector.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-builder-guard.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-exporter.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-importer.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-import-admin.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-rest-import.php';
		require_once dirname( __DIR__ ) . '/includes/class-pageferry-admin.php';

		add_action( 'add_meta_boxes', array( 'PageFerry_Admin', 'register_export_metabox' ) );
		add_action( 'admin_post_pageferry_export', array( 'PageFerry_Exporter', 'handle_export_request' ) );
		add_action( 'admin_menu', array( 'PageFerry_Admin', 'register_menu' ) );
		add_action( 'rest_api_init', array( 'PageFerry_Rest_Import', 'register_routes' ) );
		add_action( 'admin_init', array( 'PageFerry_Importer', 'maybe_gc_workspaces' ) );
	}

	/**
	 * Loads the plugin textdomain.
	 *
	 * @return void
	 */
	public static function load_textdomain() {
		load_plugin_textdomain( 'pageferry', false, dirname( plugin_basename( PAGEFERRY_FILE ) ) . '/languages' );
	}

	/**
	 * Activation guard: requires PHP 8.1+ and primes rewrite rules.
	 *
	 * Options intentionally survive deactivation; only uninstall.php deletes
	 * them. Reactivation is therefore a no-op beyond the capability checks.
	 *
	 * @return void
	 */
	public static function activate() {
		if ( version_compare( PHP_VERSION, '8.1', '<' ) ) {
			deactivate_plugins( plugin_basename( PAGEFERRY_FILE ) );
			wp_die( esc_html__( 'PageFerry requires PHP 8.1 or higher.', 'pageferry' ) );
		}
		flush_rewrite_rules();
	}
}
