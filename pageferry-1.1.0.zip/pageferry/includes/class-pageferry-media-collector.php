<?php
/**
 * Block-attribute media collector for PageFerry.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/**
 * Collects media references from a post's block structure.
 *
 * Pure function of post state: performs no writes and no network requests,
 * so the result is deterministic for a given post state.
 *
 * Known core slots (id/mediaId/ids) are collected exactly, even when the
 * attachment is missing (so the manifest can warn). Every other block
 * attribute is scanned conservatively: any integer that resolves to an
 * attachment is collected, and any URL that resolves to an attachment file
 * (original or generated size) is collected from delimiter attributes or
 * saved HTML. The one exception is ACF block field data with known field
 * definitions: only field types designated to store media (image, file,
 * gallery, media-library icon_picker) collect IDs, while URL-capable text
 * fields contribute URL candidates only and all other types (numbers,
 * choices, post selectors, relationships, taxonomy, users, dates) are
 * ignored. Text numerals are never IDs. Blocks are never rendered and
 * queries, relationships, post selectors, other posts' featured images, and
 * Block Bindings are never resolved — only data explicitly persisted by the
 * editor is inspected, so false positives are possible but misses are not.
 */
class PageFerry_Media_Collector {

	/**
	 * Maximum recursion depth for nested attribute structures.
	 *
	 * @var int
	 */
	const MAX_SCAN_DEPTH = 20;

	/**
	 * Collects the media referenced by a post.
	 *
	 * Schema contract (owned by this class; the exporter embeds it in the
	 * manifest and the importer re-walks the same tree with it):
	 *
	 * array(
	 *   'items'    => array(
	 *     array(
	 *       'old_id'     => (int) attachment ID on the source site,
	 *       'file_path'  => (?string) absolute path on the source site,
	 *                        null when the attachment or its file is missing,
	 *       'sha256'     => (?string) hash of file_path, null when missing,
	 *       'url'        => (?string) source-site attachment URL, null when missing,
	 *       'alt'        => (?string) _wp_attachment_image_alt meta ('' when
	 *                        unset), null when the attachment is missing,
	 *       'caption'    => (?string) attachment caption (post_excerpt, '' when
	 *                        unset), null when the attachment is missing,
	 *       'title'      => (?string) attachment title (post_title, '' when
	 *                        unset), null when the attachment is missing,
	 *       'description' => (?string) attachment description (post_content, ''
	 *                        when unset), null when the attachment is missing,
	 *       'featured'   => (bool) true when old_id is the post's _thumbnail_id,
	 *       'likely_false_positive' => (bool) true when every block_ref comes
	 *                        from a bare media ID with no designated media slot
	 *                        or URL evidence behind it (generic integer
	 *                        attributes on any block, including ACF data keys
	 *                        with no field definition). False for featured-only
	 *                        items (no refs), known core slots, designated ACF
	 *                        media fields, and URL-derived refs. Advisory only:
	 *                        collection and remap behave the same either way.
	 *       'block_refs' => array of array(
	 *         'path' => (string) dot-notation walk from the top-level parsed
	 *                   block array, e.g. "0.innerBlocks.1" addresses the
	 *                   second inner block of the first top-level block.
	 *                   Refs inside an expanded reusable block are rooted at
	 *                   the referring block, e.g. "2.ref45.0".
	 *         'key'  => (string) attribute slot within that block: "id",
	 *                   "mediaId", or "ids.N" (N = 0-based gallery position)
	 *                   for known slots; a dot-notation attribute path such
	 *                   as "data.hero_image" for generic attributes; "html"
	 *                   for saved-HTML URL or wp-image-class refs;
	 *                   "meta:<field>" for ACF post-meta values.
	 *       ),
	 *     ),
	 *   ),
	 *   'warnings' => array of (string): missing file, missing attachment,
	 *                 URL-only reference, blockless content, query loops,
	 *                 unresolved reusable blocks.
	 *                 Collected as strings, never thrown as exceptions.
	 * )
	 *
	 * Items are sorted by old_id ascending; block_refs keep encounter order.
	 *
	 * @param int $post_id Post ID to collect from.
	 * @return array{items: array<int, array<string, mixed>>, warnings: array<int, string>} Collection result.
	 */
	public static function collect( int $post_id ): array {
		$source_post = get_post( $post_id );

		if ( ! $source_post instanceof WP_Post ) {
			return array(
				'items'    => array(),
				'warnings' => array( sprintf( 'Post %d does not exist.', $post_id ) ),
			);
		}

		$references        = array();
		$url_candidates    = array();
		$warnings          = array();
		$found_named_block = false;
		$found_query_loop  = false;
		$visited_patterns  = array();
		$parsed_blocks     = parse_blocks( $source_post->post_content );

		self::walk_blocks( $parsed_blocks, '', $post_id, $references, $url_candidates, $warnings, $found_named_block, $found_query_loop, $visited_patterns );
		self::resolve_url_candidates( $url_candidates, $references );

		if ( ! $found_named_block ) {
			$warnings[] = sprintf( 'Post %d has no blocks; only the featured image was collected.', $post_id );
		}

		if ( $found_query_loop ) {
			$warnings[] = 'Post contains a query loop; core/post-featured-image inside loops is not resolved, featured media comes from the post thumbnail only.';
		}

		$thumbnail_raw = get_post_meta( $post_id, '_thumbnail_id', true );
		$thumbnail_id  = is_numeric( $thumbnail_raw ) ? (int) $thumbnail_raw : 0;

		if ( 0 < $thumbnail_id && 'attachment' !== get_post_type( $thumbnail_id ) ) {
			$warnings[]   = sprintf( 'Post %d has a featured image reference (%d) that is not an attachment; it was ignored.', $post_id, $thumbnail_id );
			$thumbnail_id = 0;
		}

		$attachment_ids = array_keys( $references );
		if ( 0 < $thumbnail_id && ! isset( $references[ $thumbnail_id ] ) ) {
			$attachment_ids[] = $thumbnail_id;
		}
		sort( $attachment_ids, SORT_NUMERIC );

		$items = array();
		foreach ( $attachment_ids as $attachment_id ) {
			$block_refs  = isset( $references[ $attachment_id ] ) ? $references[ $attachment_id ] : array();
			$is_featured = $attachment_id === $thumbnail_id;
			$items[]     = self::build_item( (int) $attachment_id, $block_refs, $is_featured, $warnings );
		}

		return array(
			'items'    => $items,
			'warnings' => $warnings,
		);
	}

	/**
	 * Walks a parsed block tree and records attachment ID references.
	 *
	 * Known core slots are recorded exactly; every attribute is additionally
	 * scanned generically and every block's saved HTML is scanned for media
	 * URLs. Reusable blocks are expanded with cycle protection; ACF blocks
	 * are detected via their registration (any namespace, not just "acf/")
	 * and their field data is scanned with field-type awareness, while ACF
	 * blocks that store fields in post meta contribute their own fields'
	 * values.
	 *
	 * @param array  $blocks            Parsed blocks at this level.
	 * @param string $path_prefix      Dot-notation prefix for this level ('' at the top).
	 * @param int    $post_id           Post being collected (ACF post-meta reads).
	 * @param array  $references        Map of attachment ID to block references (appended to).
	 * @param array  $url_candidates    Map of URL string to block paths (appended to).
	 * @param array  $warnings          Collected warnings (appended to).
	 * @param bool   $found_named_block Whether any named block was seen (set by reference).
	 * @param bool   $found_query_loop  Whether a core/query block was seen (set by reference).
	 * @param array  $visited_patterns  Reusable-block IDs already expanded (cycle guard).
	 * @return void
	 */
	private static function walk_blocks( array $blocks, string $path_prefix, int $post_id, array &$references, array &$url_candidates, array &$warnings, bool &$found_named_block, bool &$found_query_loop, array &$visited_patterns ): void {
		foreach ( $blocks as $index => $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$block_path = '' === $path_prefix ? (string) $index : $path_prefix . '.' . $index;
			$block_name = isset( $block['blockName'] ) && is_string( $block['blockName'] ) ? $block['blockName'] : null;
			$attributes = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();

			if ( null !== $block_name ) {
				$found_named_block = true;
			}

			switch ( $block_name ) {
				case 'core/image':
					self::add_id_reference( $attributes, 'id', $block_path, 'id', $references );
					break;
				case 'core/gallery':
					self::add_gallery_references( $attributes, $block_path, $references );
					break;
				case 'core/cover':
					self::add_cover_reference( $attributes, $block_path, $references, $warnings );
					break;
				case 'core/media-text':
					self::add_id_reference( $attributes, 'mediaId', $block_path, 'mediaId', $references );
					break;
				case 'core/audio':
				case 'core/video':
				case 'core/file':
					self::add_id_reference( $attributes, 'id', $block_path, 'id', $references );
					break;
				case 'core/query':
					$found_query_loop = true;
					break;
				case 'core/post-featured-image':
					break;
				default:
					break;
			}

			$is_acf_block = is_string( $block_name ) && self::is_acf_block( $block_name );

			if ( $is_acf_block ) {
				// Field-aware scan consumes attrs['data']; the generic scan covers
				// everything else so known non-media fields stop contributing
				// false-positive IDs while unknown keys keep recall-first cover.
				$data_typed = self::scan_acf_data_block( $block_name, $attributes, $block_path, $references, $url_candidates );

				if ( $data_typed ) {
					$non_data_attrs = $attributes;
					unset( $non_data_attrs['data'] );
					self::scan_attr_value( $non_data_attrs, $block_path, '', $references, $url_candidates, 0 );
				} else {
					self::scan_attr_value( $attributes, $block_path, '', $references, $url_candidates, 0 );
				}
			} else {
				self::scan_attr_value( $attributes, $block_path, '', $references, $url_candidates, 0 );
			}

			if ( isset( $block['innerHTML'] ) && is_string( $block['innerHTML'] ) && '' !== $block['innerHTML'] ) {
				self::scan_html( $block['innerHTML'], $block_path, $references, $url_candidates );
			}

			if ( 'core/block' === $block_name ) {
				self::expand_pattern_block( $attributes, $post_id, $block_path, $references, $url_candidates, $warnings, $found_named_block, $found_query_loop, $visited_patterns );
			}

			if ( is_string( $block_name ) && $is_acf_block ) {
				self::scan_acf_meta_block( $block_name, $attributes, $post_id, $block_path, $references, $url_candidates, $warnings );
			}

			if ( isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::walk_blocks( $block['innerBlocks'], $block_path . '.innerBlocks', $post_id, $references, $url_candidates, $warnings, $found_named_block, $found_query_loop, $visited_patterns );
			}
		}
	}

	/**
	 * Scans one attribute value of any shape for media references.
	 *
	 * Arrays recurse with dot-notation paths. Integers and digit strings
	 * are collected when they resolve to an attachment. JSON-encoded
	 * strings stay opaque here: the raw string cannot be addressed by the
	 * importer, so decoding it would emit block_refs that can never
	 * remap — the string still contributes URL candidates below.
	 * Everything else is ignored, so text numerals outside attributes can
	 * never become references here.
	 *
	 * @param mixed  $value          Attribute value (any JSON-decoded shape).
	 * @param string $block_path     Dot-notation path of the block.
	 * @param string $attr_path      Dot-notation path within the block attrs ('' at the root).
	 * @param array  $references     Map of attachment ID to block references (appended to).
	 * @param array  $url_candidates Map of URL string to block paths (appended to).
	 * @param int    $depth          Current recursion depth (guard).
	 * @return void
	 */
	private static function scan_attr_value( $value, string $block_path, string $attr_path, array &$references, array &$url_candidates, int $depth ): void {
		if ( self::MAX_SCAN_DEPTH < $depth ) {
			return;
		}

		if ( is_array( $value ) ) {
			foreach ( $value as $key => $nested ) {
				$child_path = '' === $attr_path ? (string) $key : $attr_path . '.' . (string) $key;
				self::scan_attr_value( $nested, $block_path, $child_path, $references, $url_candidates, $depth + 1 );
			}
			return;
		}

		if ( is_int( $value ) || ( is_string( $value ) && ctype_digit( $value ) ) ) {
			if ( '' !== $attr_path ) {
				self::maybe_add_attachment_id( $value, $block_path, $attr_path, $references );
			}
			return;
		}

		if ( is_float( $value ) && floor( $value ) === $value ) {
			if ( '' !== $attr_path ) {
				self::maybe_add_attachment_id( (int) $value, $block_path, $attr_path, $references );
			}
			return;
		}

		if ( is_string( $value ) ) {
			self::collect_url_candidates( $value, $block_path, $url_candidates );
		}
	}

	/**
	 * Records an integer attribute value when it is an attachment.
	 *
	 * Results are memoized per ID for the request: attribute scans revisit
	 * the same small integers (counts, years) across blocks.
	 *
	 * Normal posts, pages, and missing IDs are skipped silently: only the
	 * known core slots report missing media, so generic numbers (counts,
	 * post selectors, years) never produce warnings here.
	 *
	 * @param mixed  $value      Integer or digit string to test.
	 * @param string $block_path Dot-notation path of the block.
	 * @param string $attr_key   Attribute slot key for the schema contract.
	 * @param array  $references Map of attachment ID to block references (appended to).
	 * @param bool   $strong     Whether the slot is designated to hold media
	 *                           (known core slots, designated ACF media
	 *                           fields). Generic integer attributes are weak:
	 *                           any number may coincide with an attachment ID.
	 * @return void
	 */
	private static function maybe_add_attachment_id( $value, string $block_path, string $attr_key, array &$references, bool $strong = false ): void {
		if ( is_int( $value ) ) {
			$attachment_id = $value;
		} elseif ( is_string( $value ) && ctype_digit( $value ) ) {
			$attachment_id = (int) $value;
		} else {
			return;
		}

		if ( 0 >= $attachment_id ) {
			return;
		}

		if ( ! self::is_attachment_id( $attachment_id ) ) {
			return;
		}

		self::add_reference( $attachment_id, $block_path, $attr_key, $references, $strong );
	}

	/**
	 * Checks whether an ID belongs to an attachment, memoized per request.
	 *
	 * @param int $post_id Post ID to test.
	 * @return bool Whether the post exists and is an attachment.
	 */
	private static function is_attachment_id( int $post_id ): bool {
		static $cache = array();

		if ( ! isset( $cache[ $post_id ] ) ) {
			$cache[ $post_id ] = 'attachment' === get_post_type( $post_id );
		}

		return $cache[ $post_id ];
	}

	/**
	 * Appends one block reference, ignoring exact duplicates.
	 *
	 * Known-slot collection and the generic scan overlap on core blocks, so
	 * the same slot is often found twice; the manifest keeps a single entry
	 * (a later strong claim upgrades an earlier weak one). The strength
	 * marker stays internal: emitted block_refs keep the pinned {path, key}
	 * shape, and only roll up into the item's likely_false_positive flag.
	 *
	 * @param int    $attachment_id Attachment ID on the source site.
	 * @param string $block_path    Dot-notation path of the block.
	 * @param string $key           Attribute slot key for the schema contract.
	 * @param array  $references    Map of attachment ID to block references (appended to).
	 * @param bool   $strong        Whether the slot is designated to hold media.
	 * @return void
	 */
	private static function add_reference( int $attachment_id, string $block_path, string $key, array &$references, bool $strong = false ): void {
		if ( ! isset( $references[ $attachment_id ] ) ) {
			$references[ $attachment_id ] = array();
		}

		foreach ( $references[ $attachment_id ] as $position => $existing ) {
			if ( isset( $existing['path'], $existing['key'] ) && $existing['path'] === $block_path && $existing['key'] === $key ) {
				if ( $strong && empty( $existing['strong'] ) ) {
					$references[ $attachment_id ][ $position ]['strong'] = true;
				}

				return;
			}
		}

		$references[ $attachment_id ][] = array(
			'path'   => $block_path,
			'key'    => $key,
			'strong' => $strong,
		);
	}

	/**
	 * Appends one URL- or class-derived reference for a block.
	 *
	 * Definite evidence (a matching ID already collected from this block's
	 * attributes, or a matching HTML/media URL) suppresses the redundant
	 * second reference: the attribute remap plus the URL rewrite already
	 * cover it. A suppressed ID ref is upgraded to strong — the same-block
	 * URL resolving to the same attachment corroborates it, so it is no
	 * longer a likely false positive. URL-only references (no
	 * same-attachment ref from this block yet) are kept — they are genuinely
	 * additional media.
	 *
	 * @param int    $attachment_id Attachment ID on the source site.
	 * @param string $block_path    Dot-notation path of the block.
	 * @param array  $references    Map of attachment ID to block references (appended to).
	 * @return void
	 */
	private static function add_html_reference( int $attachment_id, string $block_path, array &$references ): void {
		if ( isset( $references[ $attachment_id ] ) && is_array( $references[ $attachment_id ] ) ) {
			$corroborated = false;

			foreach ( $references[ $attachment_id ] as $position => $existing ) {
				if ( isset( $existing['path'] ) && $existing['path'] === $block_path ) {
					$corroborated = true;

					if ( empty( $existing['strong'] ) ) {
						$references[ $attachment_id ][ $position ]['strong'] = true;
					}
				}
			}

			if ( $corroborated ) {
				return;
			}
		}

		self::add_reference( $attachment_id, $block_path, 'html', $references, true );
	}

	/**
	 * Extracts media URL candidates from a free-form string.
	 *
	 * Absolute URLs and upload-relative paths are remembered with the block
	 * they came from; resolution against the media index happens once after
	 * the whole tree is walked.
	 *
	 * @param string $text           String to inspect.
	 * @param string $block_path     Dot-notation path of the block.
	 * @param array  $url_candidates Map of URL string to block paths (appended to).
	 * @return void
	 */
	private static function collect_url_candidates( string $text, string $block_path, array &$url_candidates ): void {
		if ( '' === $text ) {
			return;
		}

		if ( ! str_contains( $text, '://' ) && ! str_contains( $text, 'uploads' ) && ! str_contains( $text, 'wp-content' ) ) {
			return;
		}

		$absolute_matches = array();
		$absolute_count   = preg_match_all( '#https?://[^\s"\'<>()`]+#', $text, $absolute_matches );

		if ( 0 < $absolute_count ) {
			foreach ( $absolute_matches as $match_group ) {
				foreach ( (array) $match_group as $url ) {
					$cleaned = rtrim( (string) $url, '.,;:!?' );

					if ( '' !== $cleaned ) {
						self::remember_candidate( $cleaned, $block_path, $url_candidates );
					}
				}
			}
		}

		$relative_matches = array();
		$relative_count   = preg_match_all( '#/[^\s"\'<>()`]*?uploads/[^\s"\'<>()`]+#', $text, $relative_matches );

		if ( 0 < $relative_count ) {
			foreach ( $relative_matches as $match_group ) {
				foreach ( (array) $match_group as $url ) {
					$cleaned = rtrim( (string) $url, '.,;:!?' );

					if ( '' !== $cleaned ) {
						self::remember_candidate( $cleaned, $block_path, $url_candidates );
					}
				}
			}
		}
	}

	/**
	 * Remembers one URL candidate and every block path that mentioned it.
	 *
	 * @param string $url            Candidate URL or path.
	 * @param string $block_path     Dot-notation path of the block.
	 * @param array  $url_candidates Map of URL string to block paths (appended to).
	 * @return void
	 */
	private static function remember_candidate( string $url, string $block_path, array &$url_candidates ): void {
		if ( ! isset( $url_candidates[ $url ] ) ) {
			$url_candidates[ $url ] = array();
		}

		if ( ! in_array( $block_path, $url_candidates[ $url ], true ) ) {
			$url_candidates[ $url ][] = $block_path;
		}
	}

	/**
	 * Scans saved block HTML for media without ever rendering the block.
	 *
	 * Every HTML attribute (src, srcset, href, poster, data-*, style, ...)
	 * contributes URL candidates; legacy wp-image-ID classes are definite
	 * references; literal upload URLs in the raw markup cover style tags
	 * and embedded JSON. Attribute values that merely look like JSON are
	 * scanned for URLs, never decoded into fake attribute paths — their
	 * media resolves through the URL index and the markup is rewritten by
	 * the importer's URL pass. Bare numbers in markup (widths, prices,
	 * years) are never treated as attachment IDs.
	 *
	 * @param string $html           Saved block markup.
	 * @param string $block_path     Dot-notation path of the block.
	 * @param array  $references     Map of attachment ID to block references (appended to).
	 * @param array  $url_candidates Map of URL string to block paths (appended to).
	 * @return void
	 */
	private static function scan_html( string $html, string $block_path, array &$references, array &$url_candidates ): void {
		if ( '' === $html ) {
			return;
		}

		$processor = new WP_HTML_Tag_Processor( $html );

		while ( $processor->next_tag() ) {
			$names = $processor->get_attribute_names_with_prefix( '' );

			if ( ! $names ) {
				continue;
			}

			foreach ( $names as $name ) {
				$attr_value = $processor->get_attribute( $name );

				if ( ! is_string( $attr_value ) || '' === $attr_value ) {
					continue;
				}

				if ( 'srcset' === strtolower( (string) $name ) ) {
					self::scan_srcset( $attr_value, $block_path, $url_candidates );
					continue;
				}

				if ( 'class' === strtolower( (string) $name ) ) {
					continue;
				}

				self::collect_url_candidates( $attr_value, $block_path, $url_candidates );
			}
		}

		// Legacy/core image references are redundant when the same block
		// already cites the attachment: the URL rewrite covers the markup.
		// Only the capture group (index 1) is read — never the full match.
		$wp_image_matches = array();
		$wp_image_count   = preg_match_all( '/\bwp-image-(\d+)\b/', $html, $wp_image_matches );
		$wp_image_ids     = array();

		foreach ( $wp_image_matches as $group_index => $group ) {
			if ( 1 === $group_index ) {
				$wp_image_ids = $group;
			}
		}

		if ( 0 < $wp_image_count && array() !== $wp_image_ids ) {
			foreach ( (array) $wp_image_ids as $raw_id ) {
				$match_id = (int) $raw_id;

				if ( 0 >= $match_id || ! self::is_attachment_id( $match_id ) ) {
					continue;
				}

				self::add_html_reference( $match_id, $block_path, $references );
			}
		}

		self::collect_url_candidates( $html, $block_path, $url_candidates );
	}

	/**
	 * Splits a srcset attribute into per-candidate URLs.
	 *
	 * @param string $srcset         Raw srcset attribute value.
	 * @param string $block_path     Dot-notation path of the block.
	 * @param array  $url_candidates Map of URL string to block paths (appended to).
	 * @return void
	 */
	private static function scan_srcset( string $srcset, string $block_path, array &$url_candidates ): void {
		foreach ( explode( ',', $srcset ) as $part ) {
			$part = trim( $part );

			if ( '' === $part ) {
				continue;
			}

			$tokens = preg_split( '/\s+/', $part );

			if ( ! is_array( $tokens ) ) {
				continue;
			}

			$first_token = (string) reset( $tokens );

			if ( '' === $first_token ) {
				continue;
			}

			self::collect_url_candidates( $first_token, $block_path, $url_candidates );
		}
	}

	/**
	 * Resolves gathered URL candidates to attachments.
	 *
	 * The reverse media index is built lazily: pages without URL references
	 * never pay for a media-library scan.
	 *
	 * @param array $url_candidates Map of URL string to block paths.
	 * @param array $references     Map of attachment ID to block references (appended to).
	 * @return void
	 */
	private static function resolve_url_candidates( array $url_candidates, array &$references ): void {
		if ( array() === $url_candidates ) {
			return;
		}

		$index = self::build_url_index();

		foreach ( $url_candidates as $url => $paths ) {
			$attachment_id = self::resolve_url_to_attachment( (string) $url, $index );

			if ( null === $attachment_id ) {
				continue;
			}

			foreach ( $paths as $block_path ) {
				self::add_html_reference( $attachment_id, (string) $block_path, $references );
			}
		}
	}

	/**
	 * Builds a reverse index of media files to attachment IDs.
	 *
	 * Every attachment contributes its original file, every generated image
	 * size, the preserved original image when present, and its filtered
	 * attachment URL (so offloaded/CDN URLs resolve too). Keys are
	 * upload-relative paths and normalized full URLs.
	 *
	 * @return array{relative: array<string, int>, url: array<string, int>} Reverse index.
	 */
	private static function build_url_index(): array {
		$by_relative = array();
		$by_url      = array();
		$uploads     = wp_get_upload_dir();
		$basedir     = isset( $uploads['basedir'] ) && is_string( $uploads['basedir'] ) ? $uploads['basedir'] : '';
		$baseurl     = isset( $uploads['baseurl'] ) && is_string( $uploads['baseurl'] ) ? rtrim( $uploads['baseurl'], '/' ) : '';

		$attachment_ids = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);

		foreach ( (array) $attachment_ids as $raw_id ) {
			$attachment_id = (int) $raw_id;

			if ( 0 >= $attachment_id ) {
				continue;
			}

			$attached_file = get_attached_file( $attachment_id );
			$relative_path = is_string( $attached_file ) && '' !== $attached_file && '' !== $basedir && str_starts_with( $attached_file, $basedir )
				? ltrim( (string) substr( $attached_file, strlen( $basedir ) ), '/' )
				: '';

			if ( '' !== $relative_path ) {
				self::index_relative( $relative_path, $attachment_id, $baseurl, $by_relative, $by_url );
			}

			$metadata = wp_get_attachment_metadata( $attachment_id );

			if ( is_array( $metadata ) ) {
				// Real metadata varies (audio/video/PDF carry no image keys;
				// scaled images add 'original_image'), so reads stay
				// defensive even though the stubs declare a fixed shape.
				$directory     = '';
				$metadata_file = array_key_exists( 'file', $metadata ) ? $metadata['file'] : ''; // @phpstan-ignore function.alreadyNarrowedType

				if ( '' !== $metadata_file ) {
					self::index_relative( (string) $metadata_file, $attachment_id, $baseurl, $by_relative, $by_url );
					$directory = (string) dirname( (string) $metadata_file );

					if ( '.' === $directory ) {
						$directory = '';
					}
				}

				$metadata_sizes = array_key_exists( 'sizes', $metadata ) ? $metadata['sizes'] : array(); // @phpstan-ignore function.alreadyNarrowedType

				foreach ( (array) $metadata_sizes as $size ) {
					$size_file = is_array( $size ) && array_key_exists( 'file', $size ) ? $size['file'] : '';

					if ( ! is_string( $size_file ) || '' === $size_file ) {
						continue;
					}

					$sized_relative = '' !== $directory ? $directory . '/' . $size_file : $size_file;
					self::index_relative( $sized_relative, $attachment_id, $baseurl, $by_relative, $by_url );
				}

				foreach ( array_diff_key( $metadata, array_flip( array( 'width', 'height', 'file', 'sizes', 'image_meta', 'filesize' ) ) ) as $extra_value ) {
					if ( ! is_string( $extra_value ) || '' === $extra_value ) {
						continue;
					}

					$original_relative = '' !== $directory ? $directory . '/' . $extra_value : $extra_value;
					self::index_relative( $original_relative, $attachment_id, $baseurl, $by_relative, $by_url );
				}
			}

			$attachment_url = wp_get_attachment_url( $attachment_id );

			if ( is_string( $attachment_url ) && '' !== $attachment_url ) {
				$by_url[ self::strip_url_query_fragment( $attachment_url ) ] = $attachment_id;
			}
		}

		return array(
			'relative' => $by_relative,
			'url'      => $by_url,
		);
	}

	/**
	 * Indexes one upload-relative path plus its full URL.
	 *
	 * @param string $relative    Upload-relative file path.
	 * @param int    $attachment_id Attachment ID owning the file.
	 * @param string $baseurl     Uploads base URL without trailing slash.
	 * @param array  $by_relative Relative-path index (appended to).
	 * @param array  $by_url      Full-URL index (appended to).
	 * @return void
	 */
	private static function index_relative( string $relative, int $attachment_id, string $baseurl, array &$by_relative, array &$by_url ): void {
		if ( '' === $relative || str_contains( $relative, '..' ) ) {
			return;
		}

		$by_relative[ $relative ] = $attachment_id;

		if ( '' !== $baseurl ) {
			$by_url[ $baseurl . '/' . $relative ] = $attachment_id;
		}
	}

	/**
	 * Resolves one URL or path candidate to an attachment ID.
	 *
	 * Tries the normalized full URL, attachment_url_to_postid(), the exact
	 * upload-relative path, and finally the size-suffix-stripped variant
	 * (so "-300x200" and "-scaled" derivatives map to their original).
	 * Only the host-agnostic path is compared, so staging URLs resolve on
	 * any host serving the same uploads layout.
	 *
	 * @param string $url   Candidate URL or path.
	 * @param array  $index Reverse index from build_url_index().
	 * @return int|null Attachment ID, or null when unresolvable.
	 */
	private static function resolve_url_to_attachment( string $url, array $index ): ?int {
		$cleaned = self::strip_url_query_fragment( $url );

		if ( '' === $cleaned ) {
			return null;
		}

		$url_index      = isset( $index['url'] ) && is_array( $index['url'] ) ? $index['url'] : array();
		$relative_index = isset( $index['relative'] ) && is_array( $index['relative'] ) ? $index['relative'] : array();

		if ( isset( $url_index[ $cleaned ] ) ) {
			return (int) $url_index[ $cleaned ];
		}

		$direct = attachment_url_to_postid( $cleaned );

		if ( 0 < $direct ) {
			return (int) $direct;
		}

		$relative = self::upload_relative_from_url( $cleaned );

		if ( null === $relative ) {
			$uploads_position = strpos( $cleaned, 'uploads/' );

			if ( false === $uploads_position ) {
				return null;
			}

			$relative = (string) substr( $cleaned, $uploads_position + 8 );
		}

		if ( '' === $relative ) {
			return null;
		}

		if ( isset( $relative_index[ $relative ] ) ) {
			return (int) $relative_index[ $relative ];
		}

		$stripped = self::strip_size_suffix( $relative );

		if ( null === $stripped || $stripped === $relative ) {
			return null;
		}

		if ( isset( $relative_index[ $stripped ] ) ) {
			return (int) $relative_index[ $stripped ];
		}

		$uploads  = wp_get_upload_dir();
		$baseurl  = isset( $uploads['baseurl'] ) && is_string( $uploads['baseurl'] ) ? rtrim( $uploads['baseurl'], '/' ) : '';
		$fallback = 0;

		if ( '' !== $baseurl ) {
			$fallback = attachment_url_to_postid( $baseurl . '/' . $stripped );
		}

		return 0 < $fallback ? (int) $fallback : null;
	}

	/**
	 * Strips the query string and fragment from a URL.
	 *
	 * @param string $url Candidate URL.
	 * @return string URL without query or fragment.
	 */
	private static function strip_url_query_fragment( string $url ): string {
		$fragment_position = strpos( $url, '#' );

		if ( false !== $fragment_position ) {
			$url = (string) substr( $url, 0, $fragment_position );
		}

		$query_position = strpos( $url, '?' );

		if ( false !== $query_position ) {
			$url = (string) substr( $url, 0, $query_position );
		}

		return trim( $url );
	}

	/**
	 * Extracts the upload-relative path from a URL, ignoring the host.
	 *
	 * @param string $clean_url URL without query or fragment.
	 * @return string|null Upload-relative path, or null when outside uploads.
	 */
	private static function upload_relative_from_url( string $clean_url ): ?string {
		$uploads = wp_get_upload_dir();

		if ( empty( $uploads['baseurl'] ) ) {
			return null;
		}

		$baseurl  = (string) $uploads['baseurl'];
		$url_path = wp_parse_url( $clean_url, PHP_URL_PATH );

		if ( empty( $url_path ) ) {
			return null;
		}

		$url_path_value = rawurldecode( (string) $url_path );
		$base_path      = wp_parse_url( $baseurl, PHP_URL_PATH );

		if ( is_string( $base_path ) && '' !== $base_path && '/' !== $base_path ) {
			$decoded_base = rawurldecode( $base_path );

			if ( str_starts_with( $url_path_value, $decoded_base ) ) {
				return ltrim( (string) substr( $url_path_value, strlen( $decoded_base ) ), '/' );
			}
		}

		$uploads_position = strpos( $url_path_value, '/uploads/' );

		if ( false !== $uploads_position ) {
			return ltrim( (string) substr( $url_path_value, $uploads_position + 9 ), '/' );
		}

		return null;
	}

	/**
	 * Strips WordPress size suffixes ("-300x200", "-scaled", "-rotated").
	 *
	 * A file whose real name ends in such a suffix (e.g. photo-scaled.jpg
	 * uploaded as-is) resolves to its unsuffixed sibling when that exists —
	 * an accepted recall-first false positive, documented here.
	 *
	 * @param string $relative Upload-relative file path.
	 * @return string|null Path without the size suffix, or null when none present.
	 */
	private static function strip_size_suffix( string $relative ): ?string {
		$slash_position = strrpos( $relative, '/' );
		$directory      = false !== $slash_position ? substr( $relative, 0, (int) $slash_position ) : '';
		$basename       = false !== $slash_position ? substr( $relative, (int) $slash_position + 1 ) : $relative;
		$basename       = (string) $basename;
		$directory      = (string) $directory;

		if ( '' === $basename ) {
			return null;
		}

		$dot_position = strrpos( $basename, '.' );

		if ( false === $dot_position ) {
			return null;
		}

		$file_name     = (string) substr( $basename, 0, (int) $dot_position );
		$extension     = (string) substr( $basename, (int) $dot_position );
		$stripped_name = preg_replace( '/-(?:\d+x\d+|scaled|rotated)$/', '', $file_name );

		if ( ! is_string( $stripped_name ) ) {
			return null;
		}

		$rebuilt_base = $stripped_name . $extension;

		if ( '' === $rebuilt_base || $rebuilt_base === $basename ) {
			return null;
		}

		return '' !== $directory ? $directory . '/' . $rebuilt_base : $rebuilt_base;
	}

	/**
	 * Expands a reusable-block reference into the collection walk.
	 *
	 * A synced pattern is deterministic content transclusion: its media
	 * displays as part of this page, so the referenced wp_block post is
	 * parsed and walked with cycle protection (an active-expansion stack:
	 * the ID is removed again after the walk, so the same pattern used
	 * twice records refs for both instances while a true cycle still
	 * terminates). Queries, post selectors, and bindings are still never
	 * resolved — only this explicit reference.
	 *
	 * @param array  $attributes        Block delimiter attributes.
	 * @param int    $post_id           Post being collected.
	 * @param string $block_path       Dot-notation path of the referring block.
	 * @param array  $references        Map of attachment ID to block references (appended to).
	 * @param array  $url_candidates    Map of URL string to block paths (appended to).
	 * @param array  $warnings          Collected warnings (appended to).
	 * @param bool   $found_named_block Whether any named block was seen (set by reference).
	 * @param bool   $found_query_loop  Whether a core/query block was seen (set by reference).
	 * @param array  $visited_patterns  Reusable-block IDs already expanded (cycle guard).
	 * @return void
	 */
	private static function expand_pattern_block( array $attributes, int $post_id, string $block_path, array &$references, array &$url_candidates, array &$warnings, bool &$found_named_block, bool &$found_query_loop, array &$visited_patterns ): void {
		if ( ! isset( $attributes['ref'] ) || ! is_numeric( $attributes['ref'] ) ) {
			return;
		}

		$reference_id = (int) $attributes['ref'];

		if ( 0 >= $reference_id || isset( $visited_patterns[ $reference_id ] ) ) {
			return;
		}

		$reference_post = get_post( $reference_id );

		if ( ! $reference_post instanceof WP_Post || 'wp_block' !== $reference_post->post_type ) {
			$warnings[] = sprintf( 'Reusable block %d referenced at path %s was not found; its media was not collected.', $reference_id, $block_path );
			return;
		}

		$visited_patterns[ $reference_id ] = true;

		self::walk_blocks( parse_blocks( $reference_post->post_content ), $block_path . '.ref' . $reference_id, $post_id, $references, $url_candidates, $warnings, $found_named_block, $found_query_loop, $visited_patterns );

		unset( $visited_patterns[ $reference_id ] );
	}

	/**
	 * Checks whether a block name belongs to an ACF block.
	 *
	 * Blocks registered with acf_register_block_type() always carry the
	 * "acf/" prefix, but blocks registered via block.json keep any custom
	 * namespace (ACF only adds "acf/" when the name has no namespace at
	 * all). The block-types store covers both paths, mirroring ACF's own
	 * save-time check; the prefix remains as a fallback for content whose
	 * block type is no longer registered (e.g. ACF disabled).
	 *
	 * @param string $block_name Full block name, e.g. "acf/hero" or "my-ns/hero".
	 * @return bool Whether the block is an ACF block.
	 */
	private static function is_acf_block( string $block_name ): bool {
		if ( function_exists( 'acf_has_block_type' ) && acf_has_block_type( $block_name ) ) {
			return true;
		}

		if ( function_exists( 'acf_get_block_type' ) && null !== acf_get_block_type( $block_name ) ) {
			return true;
		}

		return str_starts_with( $block_name, 'acf/' );
	}

	/**
	 * Returns the top-level ACF fields for a block, memoized per request.
	 *
	 * Field definitions carry the reliable type signal: only image, file,
	 * gallery, and media-library icon_picker values can be attachment IDs.
	 *
	 * @param string $block_name Full ACF block name.
	 * @return array List of ACF field arrays.
	 */
	private static function get_acf_block_fields( string $block_name ): array {
		static $cache = array();

		if ( isset( $cache[ $block_name ] ) ) {
			return $cache[ $block_name ];
		}

		$cache[ $block_name ] = array();

		if ( ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
			return $cache[ $block_name ];
		}

		$field_groups = acf_get_field_groups( array( 'block' => $block_name ) );

		if ( ! is_array( $field_groups ) ) {
			return $cache[ $block_name ];
		}

		foreach ( $field_groups as $field_group ) {
			if ( ! is_array( $field_group ) ) {
				continue;
			}

			$fields = acf_get_fields( $field_group );

			if ( ! is_array( $fields ) ) {
				continue;
			}

			foreach ( $fields as $field ) {
				if ( is_array( $field ) ) {
					$cache[ $block_name ][] = $field;
				}
			}
		}

		return $cache[ $block_name ];
	}

	/**
	 * Scans an ACF block's delimiter field data with field-type awareness.
	 *
	 * Values live in attrs['data'] keyed by field name once saved (by field
	 * key before the first save); "_"-prefixed companions hold field keys,
	 * never values. Known fields are scanned by type so integers in number,
	 * choice, post-selector, relationship, taxonomy, and user fields never
	 * become references. Data keys with no matching field definition keep a
	 * generic scan so unknown or stale fields cannot cause misses.
	 *
	 * @param string $block_name     Full ACF block name.
	 * @param array  $attributes     Block delimiter attributes.
	 * @param string $block_path     Dot-notation path of the block.
	 * @param array  $references     Map of attachment ID to block references (appended to).
	 * @param array  $url_candidates Map of URL string to block paths (appended to).
	 * @return bool Whether the typed scan ran (field definitions found).
	 */
	private static function scan_acf_data_block( string $block_name, array $attributes, string $block_path, array &$references, array &$url_candidates ): bool {
		if ( ! isset( $attributes['data'] ) || ! is_array( $attributes['data'] ) ) {
			return false;
		}

		$fields = self::get_acf_block_fields( $block_name );

		if ( array() === $fields ) {
			return false;
		}

		$data    = $attributes['data'];
		$covered = array();

		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$field_name = isset( $field['name'] ) && is_string( $field['name'] ) ? $field['name'] : '';
			$field_key  = isset( $field['key'] ) && is_string( $field['key'] ) ? $field['key'] : '';
			$data_key   = null;

			if ( '' !== $field_name && array_key_exists( $field_name, $data ) ) {
				$data_key = $field_name;
			} elseif ( '' !== $field_key && array_key_exists( $field_key, $data ) ) {
				$data_key = $field_key;
			} else {
				continue;
			}

			$covered[] = $data_key;

			self::scan_acf_field_value( $data[ $data_key ], $field, $block_path, 'data.' . $data_key, $references, $url_candidates, 0 );
		}

		$uncovered = array();

		foreach ( $data as $data_key => $data_value ) {
			$data_key_string = (string) $data_key;

			if ( str_starts_with( $data_key_string, '_' ) || in_array( $data_key_string, $covered, true ) ) {
				continue;
			}

			$uncovered[ $data_key_string ] = $data_value;
		}

		if ( array() !== $uncovered ) {
			self::scan_attr_value( $uncovered, $block_path, 'data', $references, $url_candidates, 0 );
		}

		return true;
	}

	/**
	 * Scans one ACF field value according to its field type.
	 *
	 * ACF stores attachment IDs verbatim (image, file, gallery) regardless
	 * of return_format; every other integer-capable type (numbers, choices,
	 * post_object, relationship, page_link IDs, taxonomy, users, dates) is
	 * ignored by design. URL-capable text fields contribute URL candidates
	 * only. Containers (group, clone, repeater, flexible_content) recurse
	 * into their sub-fields; raw container values are keyed by sub-field
	 * key (falling back to name for pre-save block data).
	 *
	 * @param mixed  $value          Raw field value (acf_get_value or block data).
	 * @param array  $field          ACF field definition.
	 * @param string $block_path     Dot-notation path of the block.
	 * @param string $attr_path      Dot-notation attribute path for this field.
	 * @param array  $references     Map of attachment ID to block references (appended to).
	 * @param array  $url_candidates Map of URL string to block paths (appended to).
	 * @param int    $depth          Current recursion depth (guard).
	 * @return void
	 */
	private static function scan_acf_field_value( $value, array $field, string $block_path, string $attr_path, array &$references, array &$url_candidates, int $depth ): void {
		if ( self::MAX_SCAN_DEPTH < $depth ) {
			return;
		}

		$field_type = isset( $field['type'] ) && is_string( $field['type'] ) ? $field['type'] : '';

		switch ( $field_type ) {
			case 'image':
			case 'file':
				if ( is_int( $value ) || ( is_string( $value ) && ctype_digit( $value ) ) ) {
					self::maybe_add_attachment_id( $value, $block_path, $attr_path, $references, true );
					return;
				}

				if ( is_float( $value ) && floor( $value ) === $value ) {
					self::maybe_add_attachment_id( (int) $value, $block_path, $attr_path, $references, true );
					return;
				}

				if ( is_string( $value ) ) {
					self::collect_url_candidates( $value, $block_path, $url_candidates );
					return;
				}

				if ( is_array( $value ) ) {
					self::scan_acf_url_value( $value, $block_path, $url_candidates, $depth + 1 );
				}

				return;
			case 'gallery':
				if ( is_int( $value ) || ( is_string( $value ) && ctype_digit( $value ) ) ) {
					self::maybe_add_attachment_id( $value, $block_path, $attr_path, $references, true );
					return;
				}

				if ( is_float( $value ) && floor( $value ) === $value ) {
					self::maybe_add_attachment_id( (int) $value, $block_path, $attr_path, $references, true );
					return;
				}

				if ( is_string( $value ) ) {
					self::collect_url_candidates( $value, $block_path, $url_candidates );
					return;
				}

				if ( ! is_array( $value ) ) {
					return;
				}

				foreach ( $value as $position => $item ) {
					$item_path = $attr_path . '.' . (string) $position;

					if ( is_int( $item ) || ( is_string( $item ) && ctype_digit( $item ) ) ) {
						self::maybe_add_attachment_id( $item, $block_path, $item_path, $references, true );
					} elseif ( is_float( $item ) && floor( $item ) === $item ) {
						self::maybe_add_attachment_id( (int) $item, $block_path, $item_path, $references, true );
					} elseif ( is_string( $item ) ) {
						self::collect_url_candidates( $item, $block_path, $url_candidates );
					} elseif ( is_array( $item ) ) {
						self::scan_acf_url_value( $item, $block_path, $url_candidates, $depth + 1 );
					}
				}

				return;
			case 'icon_picker':
				if ( ! is_array( $value ) ) {
					if ( is_string( $value ) ) {
						self::collect_url_candidates( $value, $block_path, $url_candidates );
					}

					return;
				}

				$icon_type  = isset( $value['type'] ) && is_string( $value['type'] ) ? $value['type'] : '';
				$icon_value = array_key_exists( 'value', $value ) ? $value['value'] : null;

				if ( 'media_library' === $icon_type ) {
					if ( is_int( $icon_value ) || ( is_string( $icon_value ) && ctype_digit( $icon_value ) ) ) {
						self::maybe_add_attachment_id( $icon_value, $block_path, $attr_path . '.value', $references, true );
					} elseif ( is_float( $icon_value ) && floor( $icon_value ) === $icon_value ) {
						self::maybe_add_attachment_id( (int) $icon_value, $block_path, $attr_path . '.value', $references, true );
					} elseif ( is_string( $icon_value ) ) {
						self::collect_url_candidates( $icon_value, $block_path, $url_candidates );
					}
				} elseif ( 'url' === $icon_type && is_string( $icon_value ) ) {
					self::collect_url_candidates( $icon_value, $block_path, $url_candidates );
				} else {
					self::scan_acf_url_value( $value, $block_path, $url_candidates, $depth + 1 );
				}

				return;
			case 'group':
			case 'clone':
				$sub_fields = self::acf_sub_fields( $field );

				if ( array() === $sub_fields || ! is_array( $value ) ) {
					return;
				}

				foreach ( $sub_fields as $sub_field ) {
					if ( ! is_array( $sub_field ) ) {
						continue;
					}

					$used_key = self::acf_matching_value_key( $value, $sub_field );

					if ( null === $used_key ) {
						continue;
					}

					self::scan_acf_field_value( $value[ $used_key ], $sub_field, $block_path, $attr_path . '.' . $used_key, $references, $url_candidates, $depth + 1 );
				}

				return;
			case 'repeater':
				$sub_fields = self::acf_sub_fields( $field );

				if ( array() === $sub_fields || ! is_array( $value ) ) {
					return;
				}

				foreach ( $value as $row_index => $row ) {
					if ( ! is_array( $row ) ) {
						continue;
					}

					foreach ( $sub_fields as $sub_field ) {
						if ( ! is_array( $sub_field ) ) {
							continue;
						}

						$used_key = self::acf_matching_value_key( $row, $sub_field );

						if ( null === $used_key ) {
							continue;
						}

						self::scan_acf_field_value( $row[ $used_key ], $sub_field, $block_path, $attr_path . '.' . (string) $row_index . '.' . $used_key, $references, $url_candidates, $depth + 1 );
					}
				}

				return;
			case 'flexible_content':
				if ( ! is_array( $value ) ) {
					return;
				}

				$layouts = isset( $field['layouts'] ) && is_array( $field['layouts'] ) ? $field['layouts'] : array();

				foreach ( $value as $row_index => $row ) {
					if ( ! is_array( $row ) ) {
						continue;
					}

					$layout_name = isset( $row['acf_fc_layout'] ) && is_string( $row['acf_fc_layout'] ) ? $row['acf_fc_layout'] : '';

					if ( '' === $layout_name ) {
						self::scan_acf_url_value( $row, $block_path, $url_candidates, $depth + 1 );
						continue;
					}

					$layout_fields = null;

					foreach ( $layouts as $layout ) {
						if ( is_array( $layout ) && isset( $layout['name'] ) && $layout_name === $layout['name'] && isset( $layout['sub_fields'] ) && is_array( $layout['sub_fields'] ) ) {
							$layout_fields = $layout['sub_fields'];
							break;
						}
					}

					if ( ! is_array( $layout_fields ) ) {
						continue;
					}

					foreach ( $layout_fields as $sub_field ) {
						if ( ! is_array( $sub_field ) ) {
							continue;
						}

						$used_key = self::acf_matching_value_key( $row, $sub_field );

						if ( null === $used_key ) {
							continue;
						}

						self::scan_acf_field_value( $row[ $used_key ], $sub_field, $block_path, $attr_path . '.' . (string) $row_index . '.' . $used_key, $references, $url_candidates, $depth + 1 );
					}
				}

				return;
			case 'text':
			case 'textarea':
			case 'wysiwyg':
			case 'url':
			case 'link':
			case 'oembed':
			case 'email':
			case 'page_link':
				self::scan_acf_url_value( $value, $block_path, $url_candidates, $depth + 1 );
				return;
			default:
				return;
		}
	}

	/**
	 * Returns a container field's sub-fields, loading them when needed.
	 *
	 * @param array $field ACF field definition.
	 * @return array List of sub-field arrays.
	 */
	private static function acf_sub_fields( array $field ): array {
		if ( isset( $field['sub_fields'] ) && is_array( $field['sub_fields'] ) && array() !== $field['sub_fields'] ) {
			return $field['sub_fields'];
		}

		if ( function_exists( 'acf_get_fields' ) ) {
			$loaded = acf_get_fields( $field );

			if ( is_array( $loaded ) ) {
				return $loaded;
			}
		}

		return array();
	}

	/**
	 * Finds the array key holding a sub-field's value (key first, then name).
	 *
	 * Raw container values are keyed by sub-field key; pre-save block data
	 * may use names instead.
	 *
	 * @param array $values    Container value array.
	 * @param array $sub_field Sub-field definition.
	 * @return string|null Matching key, or null when absent.
	 */
	private static function acf_matching_value_key( array $values, array $sub_field ): ?string {
		$sub_key  = isset( $sub_field['key'] ) && is_string( $sub_field['key'] ) ? $sub_field['key'] : '';
		$sub_name = isset( $sub_field['name'] ) && is_string( $sub_field['name'] ) ? $sub_field['name'] : '';

		if ( '' !== $sub_key && array_key_exists( $sub_key, $values ) ) {
			return $sub_key;
		}

		if ( '' !== $sub_name && array_key_exists( $sub_name, $values ) ) {
			return $sub_name;
		}

		return null;
	}

	/**
	 * Collects URL candidates from a value without ever treating integers as IDs.
	 *
	 * Used for URL-capable ACF fields (text, link, page_link URLs, …): post
	 * IDs stored by page_link and relationship-style fields die here by
	 * design, while upload URLs still resolve through the media index.
	 *
	 * @param mixed  $value          Field value of any shape.
	 * @param string $block_path     Dot-notation path of the block.
	 * @param array  $url_candidates Map of URL string to block paths (appended to).
	 * @param int    $depth          Current recursion depth (guard).
	 * @return void
	 */
	private static function scan_acf_url_value( $value, string $block_path, array &$url_candidates, int $depth ): void {
		if ( self::MAX_SCAN_DEPTH < $depth ) {
			return;
		}

		if ( is_string( $value ) ) {
			self::collect_url_candidates( $value, $block_path, $url_candidates );
			return;
		}

		if ( ! is_array( $value ) ) {
			return;
		}

		foreach ( $value as $nested ) {
			self::scan_acf_url_value( $nested, $block_path, $url_candidates, $depth + 1 );
		}
	}

	/**
	 * Collects ACF usePostMeta field values for a post, via ACF APIs only.
	 *
	 * Since ACF 6.3 a block may set usePostMeta (block.json `acf.usePostMeta`
	 * or `use_post_meta` in acf_register_block_type()), in which case its
	 * values live in this post's meta instead of the block comment delimiter
	 * (attrs carry only id/name). The full block tree is walked: block.json
	 * registrations force top-level single instances, but PHP-registered
	 * blocks may nest, and a relocated block keeps loading its post meta —
	 * so nested instances ferry too. Reusable-pattern content is excluded
	 * (it belongs to the wp_block post, not this one). Values are read via
	 * acf_get_value(), never via direct database access. All field values
	 * are returned (media and non-media alike) so the importer can restore
	 * the block faithfully; media IDs are remapped there. Source-unset
	 * fields (null) are omitted: on update imports the target keeps its
	 * existing value for omitted fields. Field groups are located by the
	 * Block rule alone, mirroring the media scan; groups combining Block
	 * with other location rules (e.g. Post Type) are not matched — a known
	 * ACF-visibility edge, accepted.
	 *
	 * @param int $post_id Post ID to read.
	 * @return array List of array(block, path, block_id, fields).
	 */
	public static function collect_acf_post_meta( int $post_id ): array {
		$source_post = get_post( $post_id );

		if ( ! $source_post instanceof WP_Post ) {
			return array();
		}

		if ( ! function_exists( 'acf_block_uses_post_meta' ) || ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) || ! function_exists( 'acf_get_value' ) ) {
			return array();
		}

		$entries = array();
		/** Parsed blocks as a plain list. @var array $parsed_blocks Unshaped parse_blocks() result for PHPStan. */
		$parsed_blocks = parse_blocks( $source_post->post_content );

		self::collect_acf_meta_from_blocks( $parsed_blocks, '', $post_id, $entries );

		return $entries;
	}

	/**
	 * Walks one level of parsed blocks collecting usePostMeta values.
	 *
	 * Paths follow the collector convention ("0", "0.innerBlocks.1"), so
	 * media refs and value entries address the same instance.
	 *
	 * @param array  $blocks      Parsed blocks at this level.
	 * @param string $path_prefix Dot-notation prefix for this level ('' at the top).
	 * @param int    $post_id     Post being read (ACF post-meta reads).
	 * @param array  $entries     Collected entries (appended to).
	 * @return void
	 */
	private static function collect_acf_meta_from_blocks( array $blocks, string $path_prefix, int $post_id, array &$entries ): void {
		if ( ! function_exists( 'acf_block_uses_post_meta' ) || ! function_exists( 'acf_get_value' ) ) {
			return;
		}

		foreach ( $blocks as $index => $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$block_path = '' === $path_prefix ? (string) $index : $path_prefix . '.' . $index;
			$block_name = isset( $block['blockName'] ) && is_string( $block['blockName'] ) ? $block['blockName'] : '';

			if ( '' !== $block_name && self::is_acf_block( $block_name ) ) {
				$attributes = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
				$probe      = $attributes;

				if ( ! isset( $probe['name'] ) ) {
					$probe['name'] = $block_name;
				}

				if ( acf_block_uses_post_meta( $probe ) ) {
					$fields = self::get_acf_block_fields( $block_name );

					if ( array() !== $fields ) {
						$values = array();

						foreach ( $fields as $field ) {
							if ( ! is_array( $field ) ) {
								continue;
							}

							$field_name = isset( $field['name'] ) && is_string( $field['name'] ) ? $field['name'] : '';

							if ( '' === $field_name ) {
								continue;
							}

							$field_value = acf_get_value( $post_id, $field );

							if ( null === $field_value ) {
								continue;
							}

							$values[ $field_name ] = $field_value;
						}

						if ( array() !== $values ) {
							$entries[] = array(
								'block'    => $block_name,
								'path'     => $block_path,
								'block_id' => isset( $attributes['id'] ) && is_string( $attributes['id'] ) ? $attributes['id'] : null,
								'fields'   => $values,
							);
						}
					}
				}
			}

			if ( isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::collect_acf_meta_from_blocks( $block['innerBlocks'], $block_path . '.innerBlocks', $post_id, $entries );
			}
		}
	}

	/**
	 * Scans an ACF block that stores its fields in post meta.
	 *
	 * Since ACF 6.3 a block may set usePostMeta, in which case its values
	 * live in this post's meta instead of the block comment. Only the field
	 * groups belonging to that block are read via ACF APIs; page-level meta
	 * is never scanned wholesale. Raw values are scanned by field type
	 * without loading related posts, so integers in number, choice,
	 * post-selector, relationship, taxonomy, and user fields never become
	 * references while image, file, gallery, and media-library icon values
	 * still collect. The collected media rides the normal dedupe/sideload
	 * pipeline and the exporter ferries the full field values in
	 * `acf_post_meta`, so the importer can remap and restore them.
	 *
	 * @param string $block_name     ACF block name, e.g. "acf/hero" or "my-ns/hero".
	 * @param array  $attributes     Block delimiter attributes.
	 * @param int    $post_id        Post being collected.
	 * @param string $block_path     Dot-notation path of the block.
	 * @param array  $references     Map of attachment ID to block references (appended to).
	 * @param array  $url_candidates Map of URL string to block paths (appended to).
	 * @param array  $warnings       Collected warnings (appended to).
	 * @return void
	 */
	private static function scan_acf_meta_block( string $block_name, array $attributes, int $post_id, string $block_path, array &$references, array &$url_candidates, array &$warnings ): void {
		if ( ! function_exists( 'acf_block_uses_post_meta' ) || ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) || ! function_exists( 'acf_get_value' ) ) {
			return;
		}

		$probe = $attributes;

		if ( ! isset( $probe['name'] ) ) {
			$probe['name'] = $block_name;
		}

		if ( ! acf_block_uses_post_meta( $probe ) ) {
			return;
		}

		$field_groups = acf_get_field_groups( array( 'block' => $block_name ) );

		if ( ! is_array( $field_groups ) || array() === $field_groups ) {
			return;
		}

		$has_reference_values = false;

		foreach ( self::get_acf_block_fields( $block_name ) as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$field_name = isset( $field['name'] ) && is_string( $field['name'] ) ? $field['name'] : '';

			if ( '' === $field_name ) {
				continue;
			}

			$field_value = acf_get_value( $post_id, $field );

			self::scan_acf_field_value( $field_value, $field, $block_path, 'meta:' . $field_name, $references, $url_candidates, 0 );

			if ( ! $has_reference_values && self::is_acf_reference_field( $field ) && self::has_acf_value( $field_value ) ) {
				$has_reference_values = true;
			}
		}

		if ( $has_reference_values ) {
			$warnings[] = sprintf( 'ACF block %s at path %s stores post, term, or user reference IDs; they point at source-site content and ferry verbatim.', $block_name, $block_path );
		}
	}

	/**
	 * Checks whether an ACF field stores IDs of other site content.
	 *
	 * Post, relationship, taxonomy, user, and page-link fields hold IDs of
	 * posts, terms, or users — a single-page mover cannot remap those, so
	 * their values cross sites unchanged (unlike attachment IDs, which the
	 * importer remaps through the media pipeline).
	 *
	 * @param array $field ACF field definition.
	 * @return bool Whether the field is reference-capable.
	 */
	private static function is_acf_reference_field( array $field ): bool {
		$field_type = isset( $field['type'] ) && is_string( $field['type'] ) ? $field['type'] : '';

		return in_array( $field_type, array( 'post_object', 'relationship', 'taxonomy', 'user', 'page_link' ), true );
	}

	/**
	 * Checks whether an ACF raw value holds anything to ferry.
	 *
	 * @param mixed $value Raw field value.
	 * @return bool Whether the value is non-empty.
	 */
	private static function has_acf_value( $value ): bool {
		if ( null === $value || '' === $value || false === $value ) {
			return false;
		}

		if ( is_array( $value ) && array() === $value ) {
			return false;
		}

		return true;
	}

	/**
	 * Records a single numeric ID attribute as a reference.
	 *
	 * Non-numeric, missing, or non-positive values are skipped silently:
	 * external-URL blocks legitimately carry no attachment ID. Known slots
	 * designate their media, so their refs are strong evidence.
	 *
	 * @param array  $attributes   Block delimiter attributes.
	 * @param string $attribute_name Attribute holding the attachment ID.
	 * @param string $block_path   Dot-notation path of the block.
	 * @param string $key          Attribute slot key for the schema contract.
	 * @param array  $references   Map of attachment ID to block references (appended to).
	 * @return void
	 */
	private static function add_id_reference( array $attributes, string $attribute_name, string $block_path, string $key, array &$references ): void {
		if ( ! isset( $attributes[ $attribute_name ] ) || ! is_numeric( $attributes[ $attribute_name ] ) ) {
			return;
		}

		$attachment_id = (int) $attributes[ $attribute_name ];

		if ( 0 >= $attachment_id ) {
			return;
		}

		self::add_reference( $attachment_id, $block_path, $key, $references, true );
	}

	/**
	 * Records every entry of a gallery ids array as a reference.
	 *
	 * Gallery slots designate their media, so their refs are strong evidence.
	 *
	 * @param array  $attributes Block delimiter attributes.
	 * @param string $block_path Dot-notation path of the gallery block.
	 * @param array  $references Map of attachment ID to block references (appended to).
	 * @return void
	 */
	private static function add_gallery_references( array $attributes, string $block_path, array &$references ): void {
		if ( ! isset( $attributes['ids'] ) || ! is_array( $attributes['ids'] ) ) {
			return;
		}

		foreach ( $attributes['ids'] as $position => $gallery_id ) {
			if ( ! is_numeric( $gallery_id ) ) {
				continue;
			}

			$attachment_id = (int) $gallery_id;

			if ( 0 >= $attachment_id ) {
				continue;
			}

			$slot = is_int( $position ) ? 'ids.' . $position : 'ids.' . (string) $position;

			self::add_reference( $attachment_id, $block_path, $slot, $references, true );
		}
	}

	/**
	 * Records a cover block reference or a URL-only warning.
	 *
	 * A cover with an attachment ID is collected normally. A cover using the
	 * featured image or a URL-only background carries no attachment ID, so it
	 * produces a warning and no item.
	 *
	 * @param array  $attributes Block delimiter attributes.
	 * @param string $block_path Dot-notation path of the cover block.
	 * @param array  $references Map of attachment ID to block references (appended to).
	 * @param array  $warnings   Collected warnings (appended to).
	 * @return void
	 */
	private static function add_cover_reference( array $attributes, string $block_path, array &$references, array &$warnings ): void {
		$cover_id = isset( $attributes['id'] ) && is_numeric( $attributes['id'] ) ? (int) $attributes['id'] : 0;

		if ( 0 < $cover_id ) {
			self::add_id_reference( $attributes, 'id', $block_path, 'id', $references );
			return;
		}

		$uses_featured_image = ! empty( $attributes['useFeaturedImage'] );
		$background_url      = isset( $attributes['url'] ) && is_string( $attributes['url'] ) ? $attributes['url'] : '';

		if ( $uses_featured_image ) {
			$warnings[] = sprintf( 'Cover block at path %s uses the featured image; resolved via the post thumbnail only.', $block_path );
			return;
		}

		if ( '' !== $background_url ) {
			$warnings[] = sprintf( 'Cover block at path %s has a URL-only background with no attachment id; the URL is kept as-is on import.', $block_path );
		}
	}

	/**
	 * Builds one schema item for an attachment ID.
	 *
	 * Missing attachments and missing files yield null file_path/sha256 plus
	 * a warning — never a fatal error. Emitted block_refs keep the pinned
	 * {path, key} shape; the internal strength marker only rolls up into
	 * likely_false_positive.
	 *
	 * @param int   $attachment_id Attachment ID on the source site.
	 * @param array $block_refs    Block references recorded for this ID.
	 * @param bool  $is_featured   Whether this ID is the post's _thumbnail_id.
	 * @param array $warnings      Collected warnings (appended to).
	 * @return array<string, mixed> Schema item.
	 */
	private static function build_item( int $attachment_id, array $block_refs, bool $is_featured, array &$warnings ): array {
		$attachment_post   = get_post( $attachment_id );
		$attachment_exists = $attachment_post instanceof WP_Post && 'attachment' === $attachment_post->post_type;
		$export_refs       = self::export_refs( $block_refs );

		if ( ! $attachment_exists ) {
			$warnings[] = sprintf( 'Attachment %d is referenced in content but does not exist; it will be skipped on import.', $attachment_id );
			return array(
				'old_id'                => $attachment_id,
				'file_path'             => null,
				'sha256'                => null,
				'url'                   => null,
				'alt'                   => null,
				'caption'               => null,
				'title'                 => null,
				'description'           => null,
				'featured'              => $is_featured,
				'likely_false_positive' => self::is_likely_false_positive( $block_refs ),
				'block_refs'            => $export_refs,
			);
		}

		$attached_file    = get_attached_file( $attachment_id );
		$file_is_readable = is_string( $attached_file ) && is_readable( $attached_file );

		$file_path = null;
		$file_hash = null;
		if ( $file_is_readable ) {
			$file_path      = $attached_file;
			$computed_hash  = hash_file( 'sha256', $attached_file );
			$hash_is_usable = is_string( $computed_hash );
			if ( $hash_is_usable ) {
				$file_hash = $computed_hash;
			} else {
				$warnings[] = sprintf( 'Attachment %d file could not be hashed.', $attachment_id );
			}
		} else {
			$missing_path = is_string( $attached_file ) ? basename( $attached_file ) : '(unknown file)';
			$warnings[]   = sprintf( 'Attachment %d file is missing: %s.', $attachment_id, $missing_path );
		}

		$attachment_url         = wp_get_attachment_url( $attachment_id );
		$alt_meta               = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
		$attachment_caption     = wp_get_attachment_caption( $attachment_id );
		$attachment_title       = $attachment_post->post_title;
		$attachment_description = $attachment_post->post_content;

		return array(
			'old_id'                => $attachment_id,
			'file_path'             => $file_path,
			'sha256'                => $file_hash,
			'url'                   => is_string( $attachment_url ) ? $attachment_url : null,
			'alt'                   => is_string( $alt_meta ) ? $alt_meta : '',
			'caption'               => is_string( $attachment_caption ) ? $attachment_caption : '',
			'title'                 => $attachment_title,
			'description'           => $attachment_description,
			'featured'              => $is_featured,
			'likely_false_positive' => self::is_likely_false_positive( $block_refs ),
			'block_refs'            => $export_refs,
		);
	}

	/**
	 * Strips the internal strength marker from refs for the schema contract.
	 *
	 * @param array $block_refs Internal block references with strength markers.
	 * @return array Block refs in the pinned {path, key} shape, order kept.
	 */
	private static function export_refs( array $block_refs ): array {
		$exported = array();

		foreach ( $block_refs as $reference ) {
			if ( ! is_array( $reference ) || ! isset( $reference['path'], $reference['key'] ) ) {
				continue;
			}

			$exported[] = array(
				'path' => $reference['path'],
				'key'  => $reference['key'],
			);
		}

		return $exported;
	}

	/**
	 * Decides whether an item is likely a false-positive detection.
	 *
	 * True only when the item cites media solely through bare media IDs
	 * with no designated media slot or URL evidence behind them (generic
	 * integer attributes on any block, including ACF data keys with no
	 * field definition). Featured-only items, known core slots, designated
	 * ACF media fields, and URL-derived refs are strong evidence.
	 *
	 * @param array $block_refs Internal block references with strength markers.
	 * @return bool Whether the item is likely a false positive.
	 */
	private static function is_likely_false_positive( array $block_refs ): bool {
		if ( array() === $block_refs ) {
			return false;
		}

		foreach ( $block_refs as $reference ) {
			if ( is_array( $reference ) && ! empty( $reference['strong'] ) ) {
				return false;
			}
		}

		return true;
	}
}
