<?php
/**
 * Builder guard for PageFerry.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/**
 * Detects page-builder usage from post meta markers.
 *
 * Meta keys only: content sniffing is unreliable because a page can carry
 * both Gutenberg blocks and stale builder meta from an uninstalled plugin.
 * Detection reports what exists; it never guesses intent.
 */
class PageFerry_Builder_Guard {

	/**
	 * Detects the builder that touched a post, if any.
	 *
	 * Priority on multiple matches: elementor, divi, beaver, bricks, wpbakery.
	 * Implemented keys (verified 2026-09-12 against builder docs/forums):
	 * elementor (_elementor_data JSON, _elementor_edit_mode=builder),
	 * divi (_et_pb_use_builder=on, _et_pb_old_content, _et_pb_built_for_post_type),
	 * beaver (_fl_builder_data, _fl_builder_enabled),
	 * bricks (_bricks_page_content_2 current, _bricks_page_content legacy),
	 * wpbakery (_wpb_vc_js_status=true, _wpb_shortcodes_custom_css, _wpb_post_custom_css).
	 *
	 * @param int $post_id Post ID to inspect.
	 * @return string|false Builder slug, or false when no builder markers exist.
	 */
	public static function detect( int $post_id ): string|false {
		$source_post = get_post( $post_id );

		if ( ! $source_post instanceof WP_Post ) {
			return false;
		}

		if ( self::has_elementor_meta( $post_id ) ) {
			return 'elementor';
		}

		if ( self::meta_equals( $post_id, '_et_pb_use_builder', 'on' )
			|| self::has_non_empty_meta( $post_id, '_et_pb_old_content' )
			|| self::has_non_empty_meta( $post_id, '_et_pb_built_for_post_type' ) ) {
			return 'divi';
		}

		if ( self::has_non_empty_meta( $post_id, '_fl_builder_data' )
			|| self::has_truthy_meta( $post_id, '_fl_builder_enabled' ) ) {
			return 'beaver';
		}

		if ( self::has_non_empty_meta( $post_id, '_bricks_page_content_2' )
			|| self::has_non_empty_meta( $post_id, '_bricks_page_content' ) ) {
			return 'bricks';
		}

		if ( self::meta_equals( $post_id, '_wpb_vc_js_status', 'true' )
			|| self::has_non_empty_meta( $post_id, '_wpb_shortcodes_custom_css' )
			|| self::has_non_empty_meta( $post_id, '_wpb_post_custom_css' ) ) {
			return 'wpbakery';
		}

		return false;
	}

	/**
	 * Checks Elementor markers, treating an emptied data array as absent.
	 *
	 * Elementor leaves _elementor_data='[]' behind on pages whose builder
	 * content was removed; that is not a builder page worth refusing.
	 *
	 * @param int $post_id Post ID to inspect.
	 * @return bool Whether Elementor markers exist.
	 */
	private static function has_elementor_meta( int $post_id ): bool {
		if ( self::meta_equals( $post_id, '_elementor_edit_mode', 'builder' ) ) {
			return true;
		}

		$raw_data = get_post_meta( $post_id, '_elementor_data', true );

		if ( ! is_string( $raw_data ) || '' === trim( $raw_data ) ) {
			return false;
		}

		$decoded_data = json_decode( $raw_data, true );

		if ( is_array( $decoded_data ) ) {
			return array() !== $decoded_data;
		}

		return true;
	}

	/**
	 * Checks whether a meta value is a non-empty string or array.
	 *
	 * @param int    $post_id  Post ID to inspect.
	 * @param string $meta_key Meta key to read.
	 * @return bool Whether the meta value is meaningfully present.
	 */
	private static function has_non_empty_meta( int $post_id, string $meta_key ): bool {
		$meta_value = get_post_meta( $post_id, $meta_key, true );

		if ( is_array( $meta_value ) ) {
			return array() !== $meta_value;
		}

		if ( is_string( $meta_value ) ) {
			return '' !== trim( $meta_value );
		}

		return ! empty( $meta_value );
	}

	/**
	 * Checks whether a meta value strictly equals an expected string.
	 *
	 * @param int    $post_id  Post ID to inspect.
	 * @param string $meta_key Meta key to read.
	 * @param string $expected Expected string value.
	 * @return bool Whether the meta value equals the expected string.
	 */
	private static function meta_equals( int $post_id, string $meta_key, string $expected ): bool {
		$meta_value = get_post_meta( $post_id, $meta_key, true );

		return is_string( $meta_value ) && $expected === $meta_value;
	}

	/**
	 * Checks whether a meta flag is truthy ('1' or 'true').
	 *
	 * @param int    $post_id  Post ID to inspect.
	 * @param string $meta_key Meta key to read.
	 * @return bool Whether the meta flag is truthy.
	 */
	private static function has_truthy_meta( int $post_id, string $meta_key ): bool {
		$meta_value = get_post_meta( $post_id, $meta_key, true );

		return is_scalar( $meta_value ) && in_array( (string) $meta_value, array( '1', 'true' ), true );
	}
}
