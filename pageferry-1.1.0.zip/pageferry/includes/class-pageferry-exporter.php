<?php
/**
 * Page exporter for PageFerry.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/**
 * Exports a page, post, or Gutenberg-edited custom post type to a portable
 * ZIP bundle (manifest + media).
 */
class PageFerry_Exporter {

	/**
	 * Post types this exporter accepts.
	 *
	 * Pages and posts always ferry; custom post types join the list when
	 * they are editable in the block editor (editor support + show_in_rest,
	 * via use_block_editor_for_post_type()). Media (attachment) and
	 * revisions never ferry — attachments ride as bundle cargo, revisions
	 * are WordPress-managed history.
	 *
	 * @return array Sorted list of ferryable post-type slugs.
	 */
	public static function ferryable_post_types(): array {
		$supported = array( 'page', 'post' );

		foreach ( get_post_types( array( 'show_in_rest' => true ), 'names' ) as $post_type ) {
			if ( in_array( $post_type, $supported, true ) || 'attachment' === $post_type || 'revision' === $post_type ) {
				continue;
			}

			if ( function_exists( 'use_block_editor_for_post_type' ) && use_block_editor_for_post_type( $post_type ) ) {
				$supported[] = $post_type;
			}
		}

		sort( $supported );

		return $supported;
	}

	/**
	 * Manifest schema version written by this exporter.
	 *
	 * @var int
	 */
	const MANIFEST_VERSION = 1;

	/**
	 * Builds the export ZIP for a post.
	 *
	 * Flow: collect() -> copy each item file into media/ -> re-hash each copy
	 * and assert it matches the manifest sha256 (integrity) -> write manifest
	 * JSON. Missing media files log a warning, flag that manifest item as
	 * missing, and continue — never fatal.
	 *
	 * @param int $post_id Post ID to export.
	 * @return string|WP_Error Absolute path to the built ZIP, or WP_Error.
	 */
	public static function export( int $post_id ): string|WP_Error {
		$validation_error = self::validate_post( $post_id );

		if ( $validation_error instanceof WP_Error ) {
			return $validation_error;
		}

		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error(
				'pageferry_no_zip',
				__( 'PageFerry export needs the PHP zip extension, which is missing on this host. Ask your host to enable it.', 'pageferry' )
			);
		}

		$collection    = PageFerry_Media_Collector::collect( $post_id );
		$media_map     = self::build_media_entries( $collection['items'] );
		$acf_post_meta = PageFerry_Media_Collector::collect_acf_post_meta( $post_id );

		$temp_zip = wp_tempnam( 'pageferry-export.zip' );

		if ( ! $temp_zip ) {
			return new WP_Error(
				'pageferry_tempnam_failed',
				__( 'PageFerry could not create a temporary export file.', 'pageferry' )
			);
		}

		$zip         = new ZipArchive();
		$open_result = $zip->open( $temp_zip, ZipArchive::OVERWRITE );

		if ( true !== $open_result ) {
			wp_delete_file( $temp_zip );
			return new WP_Error(
				'pageferry_zip_open_failed',
				__( 'PageFerry could not open the export ZIP for writing.', 'pageferry' )
			);
		}

		$copy_failed   = false;
		$media_entries = array();

		foreach ( $media_map as $entry ) {
			$media_entries[] = $entry['manifest'];

			if ( ! isset( $entry['source_path'] ) || ! is_string( $entry['source_path'] ) ) {
				continue;
			}

			if ( ! $zip->addFile( $entry['source_path'], 'media/' . $entry['manifest']['file'] ) ) {
				$copy_failed = true;
				break;
			}
		}

		if ( ! $copy_failed ) {
			$source_post   = get_post( $post_id );
			$manifest_json = wp_json_encode( self::build_manifest( $source_post, $media_entries, $collection['warnings'], $acf_post_meta ), JSON_UNESCAPED_SLASHES );

			if ( ! is_string( $manifest_json ) ) {
				$copy_failed = true;
			} elseif ( ! $zip->addFromString( 'pageferry-manifest.json', $manifest_json ) ) {
				$copy_failed = true;
			}
		}

		$zip->close();

		if ( $copy_failed ) {
			wp_delete_file( $temp_zip );
			return new WP_Error(
				'pageferry_zip_write_failed',
				__( 'PageFerry could not write the export ZIP.', 'pageferry' )
			);
		}

		$integrity_error = self::verify_zip_integrity( $temp_zip, $media_entries );

		if ( $integrity_error instanceof WP_Error ) {
			wp_delete_file( $temp_zip );
			return $integrity_error;
		}

		return $temp_zip;
	}

	/**
	 * Streams an export ZIP to the browser and exits.
	 *
	 * The ZIP is deleted after streaming. Called only from the
	 * admin-post handler after nonce + capability checks pass.
	 *
	 * @param int $post_id Post ID to export.
	 * @return void
	 */
	public static function stream_download( int $post_id ): void {
		$build_result = self::export( $post_id );

		if ( $build_result instanceof WP_Error ) {
			wp_die(
				esc_html( $build_result->get_error_message() ),
				esc_html__( 'PageFerry export failed', 'pageferry' ),
				array( 'response' => 500 )
			);
		}

		$source_post = get_post( $post_id );
		$post_slug   = $source_post instanceof WP_Post ? $source_post->post_name : 'page';
		$zip_name    = sprintf( 'pageferry-%s-%s.zip', sanitize_title( $post_slug ), gmdate( 'YmdHis' ) );

		nocache_headers();
		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename="' . $zip_name . '"' );
		header( 'Content-Length: ' . filesize( $build_result ) );

		while ( 0 < ob_get_level() ) {
			ob_end_clean();
		}

		readfile( $build_result ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- readfile() is the correct way to stream a binary download.
		wp_delete_file( $build_result );
		exit;
	}

	/**
	 * Registers the export metabox on page, post, and Gutenberg-edited
	 * custom post type edit screens.
	 *
	 * @return void
	 */
	public static function register_metabox(): void {
		add_meta_box(
			'pageferry-export',
			__( 'PageFerry Export', 'pageferry' ),
			array( __CLASS__, 'render_metabox' ),
			self::ferryable_post_types(),
			'side',
			'default'
		);
	}

	/**
	 * Renders the export metabox with the Ferry button.
	 *
	 * @param WP_Post $source_post Post being edited.
	 * @return void
	 */
	public static function render_metabox( WP_Post $source_post ): void {
		$export_url = add_query_arg(
			array(
				'action' => 'pageferry_export',
				'post'   => $source_post->ID,
			),
			admin_url( 'admin-post.php' )
		);
		$export_url = wp_nonce_url( $export_url, 'pageferry_export_' . $source_post->ID );
		$import_url = admin_url( 'tools.php?page=pageferry-import' );

		printf(
			'<p>%s</p><p><a class="button button-primary" href="%s">%s</a></p><p><a href="%s">%s</a></p>',
			esc_html__( 'Download this page as a portable ZIP (content + media).', 'pageferry' ),
			esc_url( $export_url ),
			esc_html__( 'Ferry this page', 'pageferry' ),
			esc_url( $import_url ),
			esc_html__( 'Import a ferried page', 'pageferry' )
		);
	}

	/**
	 * Handles the admin-post export request.
	 *
	 * @return void
	 */
	public static function handle_export_request(): void {
		$post_id = isset( $_GET['post'] ) ? absint( wp_unslash( $_GET['post'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce is verified below.
		$nonce   = isset( $_GET['_wpnonce'] ) ? sanitize_key( wp_unslash( $_GET['_wpnonce'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce is verified below.

		if ( 0 === $post_id || ! wp_verify_nonce( $nonce, 'pageferry_export_' . $post_id ) ) {
			wp_die(
				esc_html__( 'This export link is invalid or expired. Return to the page editor and try again.', 'pageferry' ),
				esc_html__( 'PageFerry export failed', 'pageferry' ),
				array( 'response' => 403 )
			);
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			wp_die(
				esc_html__( 'You do not have permission to export this page.', 'pageferry' ),
				esc_html__( 'PageFerry export failed', 'pageferry' ),
				array( 'response' => 403 )
			);
		}

		self::stream_download( $post_id );
	}

	/**
	 * Validates that a post exists and is a supported post type
	 * (Gutenberg-edited: page, post, or a block-editor custom post type).
	 *
	 * @param int $post_id Post ID to validate.
	 * @return WP_Error|null WP_Error on failure, null when valid.
	 */
	private static function validate_post( int $post_id ): ?WP_Error {
		$source_post = get_post( $post_id );

		if ( ! $source_post instanceof WP_Post ) {
			return new WP_Error(
				'pageferry_post_not_found',
				__( 'PageFerry could not find that page.', 'pageferry' )
			);
		}

		if ( ! in_array( $source_post->post_type, self::ferryable_post_types(), true ) ) {
			return new WP_Error(
				'pageferry_unsupported_post_type',
				__( 'PageFerry exports Gutenberg content only (pages, posts, and block-editor custom post types).', 'pageferry' )
			);
		}

		return null;
	}

	/**
	 * Turns collector items into manifest media entries plus copy sources.
	 *
	 * Manifest media entries keep the a02 schema (old_id, sha256, url, alt,
	 * caption, title, description, featured, block_refs) plus bytes (integer
	 * size of the copied file), file (collision-safe path inside the zip) and
	 * filename (the original file basename for the media library; the
	 * importer sideloadds under this name so WordPress applies its standard
	 * wp_unique_filename suffixing). likely_false_positive mirrors the
	 * collector flag: true when every block_ref is a bare media ID with no
	 * designated media slot or URL evidence. Absolute server filesystem paths are
	 * never written to the manifest (info leak).
	 *
	 * @param array $items Collector schema items.
	 * @return array List of array( 'manifest' => array, 'source_path' => ?string ).
	 */
	private static function build_media_entries( array $items ): array {
		$media_map  = array();
		$used_names = array();

		foreach ( $items as $item ) {
			$old_id = isset( $item['old_id'] ) ? (int) $item['old_id'] : 0;

			$file_missing = ! isset( $item['file_path'] ) || ! is_string( $item['file_path'] );
			$hash_missing = ! isset( $item['sha256'] ) || ! is_string( $item['sha256'] );

			if ( $file_missing || $hash_missing ) {
				$media_map[] = array(
					'manifest' => array(
						'old_id'                => $old_id,
						'file'                  => null,
						'filename'              => null,
						'sha256'                => null,
						'bytes'                 => null,
						'url'                   => isset( $item['url'] ) && is_string( $item['url'] ) ? $item['url'] : null,
						'alt'                   => $item['alt'] ?? null,
						'caption'               => $item['caption'] ?? null,
						'title'                 => $item['title'] ?? null,
						'description'           => $item['description'] ?? null,
						'featured'              => ! empty( $item['featured'] ),
						'likely_false_positive' => ! empty( $item['likely_false_positive'] ),
						'block_refs'            => $item['block_refs'] ?? array(),
						'missing'               => true,
					),
				);
				continue;
			}

			$zip_name = self::unique_zip_name( basename( $item['file_path'] ), $used_names );

			$media_map[] = array(
				'source_path' => $item['file_path'],
				'manifest'    => array(
					'old_id'                => $old_id,
					'file'                  => $zip_name,
					'filename'              => basename( $item['file_path'] ),
					'sha256'                => $item['sha256'],
					'bytes'                 => (int) filesize( $item['file_path'] ),
					'url'                   => isset( $item['url'] ) && is_string( $item['url'] ) ? $item['url'] : null,
					'alt'                   => $item['alt'] ?? null,
					'caption'               => $item['caption'] ?? null,
					'title'                 => $item['title'] ?? null,
					'description'           => $item['description'] ?? null,
					'featured'              => ! empty( $item['featured'] ),
					'likely_false_positive' => ! empty( $item['likely_false_positive'] ),
					'block_refs'            => $item['block_refs'] ?? array(),
					'missing'               => false,
				),
			);
		}

		return $media_map;
	}

	/**
	 * Builds a collision-safe, filesystem-safe name for a zip entry.
	 *
	 * The name stays the original basename whenever possible; entries that
	 * would collide get WordPress-style numeric suffixes (foo.png,
	 * foo-1.png), so names stay human-readable. The manifest's old_id
	 * already disambiguates entries — no ID prefix is needed.
	 *
	 * @param string $basename   Original file basename.
	 * @param array  $used_names Names already taken (appended to).
	 * @return string Unique safe name.
	 */
	private static function unique_zip_name( string $basename, array &$used_names ): string {
		$safe_basename = (string) preg_replace( '/[^A-Za-z0-9._-]+/', '-', $basename );
		$safe_basename = trim( $safe_basename, '.-' );

		if ( '' === $safe_basename ) {
			$safe_basename = 'media-file';
		}

		if ( ! isset( $used_names[ $safe_basename ] ) ) {
			$used_names[ $safe_basename ] = true;

			return $safe_basename;
		}

		$dot_position = strrpos( $safe_basename, '.' );

		if ( false === $dot_position ) {
			$stem      = $safe_basename;
			$extension = '';
		} else {
			$stem      = substr( $safe_basename, 0, $dot_position );
			$extension = substr( $safe_basename, (int) $dot_position );
		}

		$suffix = 1;

		do {
			$candidate_name = $stem . '-' . $suffix . $extension;
			++$suffix;
		} while ( isset( $used_names[ $candidate_name ] ) );

		$used_names[ $candidate_name ] = true;

		return $candidate_name;
	}

	/**
	 * Builds the manifest array for a post.
	 *
	 * ACF usePostMeta values (ACF 6.3+, read via acf_get_value()) ride as
	 * top-level `acf_post_meta`: list of array(block, path, block_id,
	 * fields) where fields maps field name to its raw value. Media IDs
	 * inside are remapped on import; every other value is restored verbatim.
	 *
	 * @param WP_Post|false|null $source_post   Post being exported.
	 * @param array              $media_entries Manifest media entries.
	 * @param array              $warnings      Collector warnings.
	 * @param array              $acf_post_meta ACF usePostMeta entries.
	 * @return array Manifest array.
	 */
	private static function build_manifest( WP_Post|false|null $source_post, array $media_entries, array $warnings, array $acf_post_meta = array() ): array {
		$post_type     = $source_post instanceof WP_Post ? $source_post->post_type : 'page';
		$thumbnail_raw = $source_post instanceof WP_Post ? get_post_meta( $source_post->ID, '_thumbnail_id', true ) : 0;
		$thumbnail_id  = is_numeric( $thumbnail_raw ) ? (int) $thumbnail_raw : 0;

		$taxonomies = array();
		$tax_detail = array();
		if ( $source_post instanceof WP_Post ) {
			// Core pair first: v1 bundles always carried category/post_tag
			// (even onto pages, which UI-wise support neither), so keep
			// recording them whenever terms exist — then every taxonomy
			// attached to the post type, core or custom.
			$taxonomy_slugs = array_unique(
				array_merge(
					array( 'category', 'post_tag' ),
					get_object_taxonomies( $source_post->post_type, 'names' )
				)
			);

			foreach ( $taxonomy_slugs as $taxonomy_slug ) {
				$term_names                   = wp_get_object_terms( $source_post->ID, $taxonomy_slug, array( 'fields' => 'names' ) );
				$taxonomies[ $taxonomy_slug ] = is_wp_error( $term_names ) ? array() : array_values( $term_names );

				$object_terms = wp_get_object_terms( $source_post->ID, $taxonomy_slug );
				$term_ids     = is_wp_error( $object_terms ) ? array() : wp_list_pluck( $object_terms, 'term_id' );

				$tax_detail[ $taxonomy_slug ] = self::describe_terms( $term_ids, $taxonomy_slug );
			}
		}

		return array(
			'plugin'           => 'pageferry',
			'manifest_version' => self::MANIFEST_VERSION,
			'source'           => array(
				'url'        => home_url(),
				'wp_version' => get_bloginfo( 'version' ),
				'date'       => gmdate( 'c' ),
			),
			'post'             => array(
				'post_type'        => $source_post instanceof WP_Post ? $source_post->post_type : '',
				'slug'             => $source_post instanceof WP_Post ? $source_post->post_name : '',
				'title'            => $source_post instanceof WP_Post ? $source_post->post_title : '',
				'status'           => $source_post instanceof WP_Post ? $source_post->post_status : '',
				'content'          => $source_post instanceof WP_Post ? $source_post->post_content : '',
				'excerpt'          => $source_post instanceof WP_Post ? $source_post->post_excerpt : '',
				'tax'              => $taxonomies,
				'thumbnail_old_id' => 0 < $thumbnail_id ? $thumbnail_id : null,
			),
			'media'            => $media_entries,
			'tax_terms'        => $tax_detail,
			'options'          => array(
				'land_as_draft' => true,
			),
			'builder_detected' => $source_post instanceof WP_Post ? PageFerry_Builder_Guard::detect( $source_post->ID ) : false,
			'export_warnings'  => array_values( $warnings ),
			'acf_post_meta'    => array_values( $acf_post_meta ),
			'supports'         => array( $post_type ),
		);
	}

	/**
	 * Describes terms with parent names first so the importer can rebuild
	 * hierarchy (parents first) without trusting term IDs.
	 *
	 * @param array  $term_ids Term IDs on the source site.
	 * @param string $taxonomy Taxonomy slug.
	 * @return array List of array( 'name' => string, 'slug' => string, 'parent' => string ).
	 */
	private static function describe_terms( array $term_ids, string $taxonomy ): array {
		$by_id = array();

		foreach ( $term_ids as $term_id ) {
			$term = get_term( (int) $term_id, $taxonomy );

			if ( ! $term instanceof WP_Term ) {
				continue;
			}

			$by_id[ (int) $term->term_id ] = $term;
		}

		$ordered = array();

		foreach ( $by_id as $term ) {
			$chain          = array();
			$current        = $term;
			$guard          = 0;
			$parent_term_id = (int) $current->parent;

			while ( 0 < $parent_term_id && isset( $by_id[ $parent_term_id ] ) && 10 > $guard ) {
				$current        = $by_id[ $parent_term_id ];
				$chain[]        = $current;
				$parent_term_id = (int) $current->parent;
				++$guard;
			}

			foreach ( array_reverse( $chain ) as $ancestor ) {
				$ordered[ (int) $ancestor->term_id ] = $ancestor;
			}

			$ordered[ (int) $term->term_id ] = $term;
		}

		$described = array();

		foreach ( $ordered as $term ) {
			$parent_name = '';

			if ( 0 < (int) $term->parent ) {
				$parent_term = get_term( (int) $term->parent, $taxonomy );

				if ( $parent_term instanceof WP_Term ) {
					$parent_name = $parent_term->name;
				}
			}

			$described[] = array(
				'name'   => $term->name,
				'slug'   => $term->slug,
				'parent' => $parent_name,
			);
		}

		return $described;
	}

	/**
	 * Re-opens a built ZIP and validates every media entry against it.
	 *
	 * Each copied file is re-hashed and asserted against the manifest
	 * sha256; the open mode is read-only so verification never mutates the
	 * archive it checks.
	 *
	 * @param string $zip_path      Absolute path to the built ZIP.
	 * @param array  $media_entries Manifest media entries.
	 * @return WP_Error|null WP_Error on mismatch, null when valid.
	 */
	private static function verify_zip_integrity( string $zip_path, array $media_entries ): ?WP_Error {
		$zip = new ZipArchive();

		if ( true !== $zip->open( $zip_path, ZipArchive::RDONLY ) ) {
			return new WP_Error(
				'pageferry_zip_verify_failed',
				__( 'PageFerry could not verify the export ZIP.', 'pageferry' )
			);
		}

		foreach ( $media_entries as $entry ) {
			if ( ! isset( $entry['file'] ) || ! is_string( $entry['file'] ) || ! isset( $entry['sha256'] ) || ! is_string( $entry['sha256'] ) ) {
				continue;
			}

			$stream = $zip->getStream( 'media/' . $entry['file'] );

			if ( ! is_resource( $stream ) ) {
				$zip->close();
				return new WP_Error(
					'pageferry_zip_verify_failed',
					sprintf(
						/* translators: %s: media file name inside the export ZIP. */
						__( 'PageFerry could not verify media file %s in the export ZIP.', 'pageferry' ),
						$entry['file']
					)
				);
			}

			$hash_context = hash_init( 'sha256' );
			hash_update_stream( $hash_context, $stream );
			fclose( $stream ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- closing a ZipArchive stream handle, not a filesystem write.

			if ( hash_final( $hash_context ) !== $entry['sha256'] ) {
				$zip->close();
				return new WP_Error(
					'pageferry_zip_verify_failed',
					sprintf(
						/* translators: %s: media file name inside the export ZIP. */
						__( 'Export integrity check failed for media file %s.', 'pageferry' ),
						$entry['file']
					)
				);
			}
		}

		$zip->close();

		return null;
	}
}
