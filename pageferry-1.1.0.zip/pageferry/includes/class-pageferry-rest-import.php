<?php
/**
 * REST import routes for PageFerry (Path B transport).
 *
 * Manifest-first session: validate → per-file uploads → commit. Every route
 * requires the import capability plus cookie auth (X-WP-Nonce); the session
 * transient doubles as the validated stash the dry-run-lite step needs.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers the pageferry/v1 import routes.
 */
class PageFerry_Rest_Import {

	/**
	 * REST namespace for the import routes.
	 *
	 * @var string
	 */
	const NAMESPACE = 'pageferry/v1';

	/**
	 * Session time-to-live in seconds (~1 hour).
	 *
	 * @var int
	 */
	const SESSION_TTL = 3600;

	/**
	 * Registers routes on rest_api_init.
	 *
	 * @return void
	 */
	public static function register_routes(): void {
		register_rest_route(
			self::NAMESPACE,
			'/import/validate',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_validate' ),
				'permission_callback' => array( __CLASS__, 'check_permissions' ),
				'args'                => array(
					'manifest' => array(
						'type'     => 'object',
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/import/file',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_file' ),
				'permission_callback' => array( __CLASS__, 'check_permissions' ),
				'args'                => array(
					'session_id' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/import/commit',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_commit' ),
				'permission_callback' => array( __CLASS__, 'check_permissions' ),
				'args'                => array(
					'session_id' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);
	}

	/**
	 * Mirrors the import-screen capability.
	 *
	 * @return bool Whether the current user may import.
	 */
	public static function check_permissions(): bool {
		return current_user_can( 'import' );
	}

	/**
	 * Validates a manifest, creates a session + workspace, returns the plan.
	 *
	 * @param WP_REST_Request $request REST request with a manifest param.
	 * @return WP_REST_Response|WP_Error Session plan or error.
	 */
	public static function handle_validate( WP_REST_Request $request ) {
		$manifest = $request->get_param( 'manifest' );

		if ( ! is_array( $manifest ) ) {
			return new WP_Error(
				'pageferry_manifest_invalid',
				__( 'PageFerry needs a manifest object to start an import session.', 'pageferry' ),
				array( 'status' => 400 )
			);
		}

		$validated = PageFerry_Importer::validate( $manifest );

		if ( $validated instanceof WP_Error ) {
			$validated->add_data( array( 'status' => 400 ) );
			return $validated;
		}

		$limit_bytes = (int) wp_max_upload_size();
		$plan        = array();

		foreach ( $validated['media_index'] as $media_state ) {
			if ( $media_state['missing'] ) {
				continue;
			}

			$file_name   = (string) $media_state['entry']['file'];
			$entry_bytes = isset( $media_state['entry']['bytes'] ) && is_numeric( $media_state['entry']['bytes'] )
				? (int) $media_state['entry']['bytes']
				: 0;

			if ( 0 < $limit_bytes && 0 < $entry_bytes && $limit_bytes < $entry_bytes ) {
				return new WP_Error(
					'pageferry_media_too_large',
					sprintf(
						/* translators: 1: media file name, 2: human-readable size limit. */
						__( 'PageFerry cannot import media file %1$s: it is larger than this site allows (%2$s).', 'pageferry' ),
						PageFerry_Importer::original_filename( $media_state['entry'] ),
						size_format( $limit_bytes )
					),
					array( 'status' => 400 )
				);
			}

			$plan[] = array(
				'file'     => $file_name,
				'filename' => PageFerry_Importer::original_filename( $media_state['entry'] ),
				'bytes'    => $entry_bytes,
				'received' => false,
			);
		}

		$workspace = PageFerry_Importer::make_workspace( 'pageferry-session-' );

		if ( is_wp_error( $workspace ) ) {
			$workspace->add_data( array( 'status' => 500 ) );
			return $workspace;
		}

		// Per-user session-creation quota: each session reserves a workspace
		// directory, so bound how many one user may open per hour.
		$quota_key   = PageFerry::TRANSIENT_QUOTA_PREFIX . get_current_user_id();
		$quota_used  = (int) get_transient( $quota_key );
		$quota_limit = 20;

		if ( $quota_limit <= $quota_used ) {
			PageFerry_Importer::remove_directory( $workspace );
			return new WP_Error(
				'pageferry_rate_limited',
				__( 'PageFerry opened too many import sessions recently. Finish or abandon an open import and try again later.', 'pageferry' ),
				array( 'status' => 429 )
			);
		}

		set_transient( $quota_key, $quota_used + 1, HOUR_IN_SECONDS );

		$session_id = 'pf-' . wp_generate_password( 16, false );

		set_transient(
			PageFerry::TRANSIENT_SESSION_PREFIX . $session_id,
			array(
				'workspace' => $workspace,
				'manifest'  => $validated['manifest'],
				'received'  => array(),
				'user_id'   => get_current_user_id(),
			),
			self::SESSION_TTL
		);

		return rest_ensure_response(
			array(
				'session_id' => $session_id,
				'received'   => array(),
				'plan'       => $plan,
			)
		);
	}

	/**
	 * Stores ONE manifest-declared media file into the session workspace.
	 *
	 * @param WP_REST_Request $request REST request with session_id + file upload.
	 * @return WP_REST_Response|WP_Error Receipt or error.
	 */
	public static function handle_file( WP_REST_Request $request ) {
		$session_id = (string) $request->get_param( 'session_id' );
		$session    = self::get_session( $session_id );

		if ( is_wp_error( $session ) ) {
			return $session;
		}

		$file_params = $request->get_file_params();

		if ( ! isset( $file_params['file'] ) || ! is_array( $file_params['file'] ) ) {
			return new WP_Error(
				'pageferry_file_missing',
				__( 'PageFerry needs one file per request under the "file" field.', 'pageferry' ),
				array( 'status' => 400 )
			);
		}

		$uploaded = $file_params['file'];

		if ( ! isset( $uploaded['error'] ) || UPLOAD_ERR_OK !== (int) $uploaded['error'] ) {
			return new WP_Error(
				'pageferry_file_upload',
				__( 'PageFerry could not receive that file. It may exceed the host body limit — the worker retries each file individually.', 'pageferry' ),
				array( 'status' => 413 )
			);
		}

		$declared = self::declared_basenames( $session['manifest'] );
		$basename = isset( $uploaded['name'] ) ? basename( (string) $uploaded['name'] ) : '';

		if ( '' === $basename || ! isset( $declared[ $basename ] ) ) {
			return new WP_Error(
				'pageferry_file_undeclared',
				__( 'PageFerry refused that file: it is not declared in the validated manifest.', 'pageferry' ),
				array( 'status' => 400 )
			);
		}

		$tmp_name = isset( $uploaded['tmp_name'] ) ? (string) $uploaded['tmp_name'] : '';

		if ( '' === $tmp_name || ! is_readable( $tmp_name ) ) {
			return new WP_Error(
				'pageferry_file_upload',
				__( 'PageFerry could not read the uploaded file.', 'pageferry' ),
				array( 'status' => 400 )
			);
		}

		$destination = $session['workspace'] . '/' . $basename;

		if ( ! move_uploaded_file( $tmp_name, $destination ) && ! copy( $tmp_name, $destination ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions -- storing a validated upload into our own session workspace.
			return new WP_Error(
				'pageferry_file_store',
				__( 'PageFerry could not store that file in the import workspace.', 'pageferry' ),
				array( 'status' => 500 )
			);
		}

		// The manifest-declared count is untrusted; the received bytes decide.
		$received_bytes = filesize( $destination );
		$size_limit     = (int) wp_max_upload_size();

		if ( is_int( $received_bytes ) && 0 < $size_limit && $size_limit < $received_bytes ) {
			wp_delete_file( $destination );
			return new WP_Error(
				'pageferry_media_too_large',
				sprintf(
					/* translators: 1: media file name, 2: human-readable size limit. */
					__( 'PageFerry cannot import media file %1$s: it is larger than this site allows (%2$s).', 'pageferry' ),
					$basename,
					size_format( $size_limit )
				),
				array( 'status' => 400 )
			);
		}

		$session['received'][ $basename ] = true;
		set_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id, $session, self::SESSION_TTL );

		return rest_ensure_response(
			array(
				'session_id' => $session_id,
				'file'       => $basename,
				'received'   => array_keys( $session['received'] ),
			)
		);
	}

	/**
	 * Re-hashes every received file, shows the dry-run summary, then — only
	 * with confirm=true — runs the shared import pipeline.
	 *
	 * @param WP_REST_Request $request REST request with session_id + target args.
	 * @return WP_REST_Response|WP_Error Summary, result, or error.
	 */
	public static function handle_commit( WP_REST_Request $request ) {
		$session_id = (string) $request->get_param( 'session_id' );
		$session    = self::get_session( $session_id );

		if ( is_wp_error( $session ) ) {
			return $session;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$validated = PageFerry_Importer::validate( $session['manifest'] );

		if ( $validated instanceof WP_Error ) {
			self::destroy_session( $session_id, $session );
			$validated->add_data( array( 'status' => 400 ) );
			return $validated;
		}

		foreach ( $validated['media_index'] as $media_state ) {
			if ( $media_state['missing'] ) {
				continue;
			}

			$file_name  = (string) $media_state['entry']['file'];
			$media_file = PageFerry_Importer::workspace_file( $session['workspace'], $file_name );

			if ( ! is_string( $media_file ) ) {
				self::destroy_session( $session_id, $session );
				return new WP_Error(
					'pageferry_file_incomplete',
					sprintf(
						/* translators: %s: media file name not yet uploaded. */
						__( 'PageFerry is still waiting for media file %s.', 'pageferry' ),
						PageFerry_Importer::original_filename( $media_state['entry'] )
					),
					array( 'status' => 400 )
				);
			}

			$actual_hash = hash_file( 'sha256', $media_file );

			if ( ! is_string( $actual_hash ) || ! hash_equals( strtolower( (string) $media_state['entry']['sha256'] ), strtolower( $actual_hash ) ) ) {
				self::destroy_session( $session_id, $session );
				return new WP_Error(
					'pageferry_media_hash',
					sprintf(
						/* translators: %s: media file name with a hash mismatch. */
						__( 'PageFerry refused media file %s: it does not match the manifest hash.', 'pageferry' ),
						PageFerry_Importer::original_filename( $media_state['entry'] )
					),
					array( 'status' => 400 )
				);
			}

			// Declared bytes are untrusted; enforce the limit on staged bytes.
			$staged_bytes = filesize( $media_file );
			$size_limit   = (int) wp_max_upload_size();

			if ( is_int( $staged_bytes ) && 0 < $size_limit && $size_limit < $staged_bytes ) {
				self::destroy_session( $session_id, $session );
				return new WP_Error(
					'pageferry_media_too_large',
					sprintf(
						/* translators: 1: media file name, 2: human-readable size limit. */
						__( 'PageFerry cannot import media file %1$s: it is larger than this site allows (%2$s).', 'pageferry' ),
						PageFerry_Importer::original_filename( $media_state['entry'] ),
						size_format( $size_limit )
					),
					array( 'status' => 400 )
				);
			}
		}

		$target_mode    = 'update' === (string) $request->get_param( 'target' ) ? 'update' : 'create';
		$target_post_id = absint( (string) $request->get_param( 'target_post_id' ) );
		$confirmed      = rest_sanitize_boolean( $request->get_param( 'confirm' ) );

		$preview = PageFerry_Importer::preview(
			$session['workspace'],
			$validated['manifest'],
			array(
				'target'         => $target_mode,
				'target_post_id' => $target_post_id,
			)
		);

		if ( is_wp_error( $preview ) ) {
			self::destroy_session( $session_id, $session );
			$preview->add_data( array( 'status' => 400 ) );
			return $preview;
		}

		if ( ! $confirmed ) {
			return rest_ensure_response(
				array(
					'session_id' => $session_id,
					'preview'    => $preview,
				)
			);
		}

		if ( 'update' === $target_mode ) {
			$target_post = get_post( $target_post_id );

			if ( ! $target_post instanceof WP_Post ) {
				self::destroy_session( $session_id, $session );
				return new WP_Error(
					'pageferry_target_missing',
					__( 'PageFerry cannot update: the selected target page no longer exists.', 'pageferry' ),
					array( 'status' => 400 )
				);
			}

			if ( ! current_user_can( 'edit_post', $target_post->ID ) ) {
				self::destroy_session( $session_id, $session );
				return new WP_Error(
					'pageferry_target_cap',
					__( 'PageFerry cannot update: you do not have permission to edit the selected target page.', 'pageferry' ),
					array( 'status' => 403 )
				);
			}
		}

		$imported = PageFerry_Importer::run(
			$session['workspace'],
			$validated['manifest'],
			array(
				'target'         => $target_mode,
				'target_post_id' => $target_post_id,
			)
		);

		self::destroy_session( $session_id, $session );

		if ( is_wp_error( $imported ) ) {
			$imported->add_data( array( 'status' => 400 ) );
			return $imported;
		}

		return rest_ensure_response(
			array(
				'session_id' => $session_id,
				'post_id'    => $imported->ID,
				'slug'       => $imported->post_name,
				'edit_url'   => get_edit_post_link( $imported->ID, 'raw' ),
				'view_url'   => get_permalink( $imported->ID ),
				'preview'    => $preview,
			)
		);
	}

	/**
	 * Loads a session or fails closed (expired/unknown → error + no writes).
	 *
	 * @param string $session_id Session ID from the request.
	 * @return array|WP_Error Session array or WP_Error.
	 */
	private static function get_session( string $session_id ) {
		if ( '' === $session_id || 1 !== preg_match( '/^[A-Za-z0-9-]+$/', $session_id ) ) {
			return new WP_Error(
				'pageferry_session_invalid',
				__( 'PageFerry import session is invalid. Start again from the manifest step.', 'pageferry' ),
				array( 'status' => 400 )
			);
		}

		$session = get_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id );

		if ( ! is_array( $session ) || ! isset( $session['workspace'], $session['manifest'] ) ) {
			return new WP_Error(
				'pageferry_session_expired',
				__( 'PageFerry import session expired. Start again from the manifest step.', 'pageferry' ),
				array( 'status' => 410 )
			);
		}

		// Sessions belong to the user that validated the manifest; another
		// `import`-capable user must not drive or commit them.
		if ( ! isset( $session['user_id'] ) || get_current_user_id() !== (int) $session['user_id'] ) {
			return new WP_Error(
				'pageferry_session_expired',
				__( 'PageFerry import session expired. Start again from the manifest step.', 'pageferry' ),
				array( 'status' => 410 )
			);
		}

		if ( ! is_dir( $session['workspace'] ) ) {
			delete_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id );
			return new WP_Error(
				'pageferry_session_expired',
				__( 'PageFerry import session expired. Start again from the manifest step.', 'pageferry' ),
				array( 'status' => 410 )
			);
		}

		if ( ! isset( $session['received'] ) || ! is_array( $session['received'] ) ) {
			$session['received'] = array();
		}

		return $session;
	}

	/**
	 * Destroys a session: workspace removed, transient deleted, zero DB writes.
	 *
	 * @param string $session_id Session ID.
	 * @param array  $session Session array.
	 * @return void
	 */
	private static function destroy_session( string $session_id, array $session ): void {
		if ( isset( $session['workspace'] ) && is_string( $session['workspace'] ) ) {
			PageFerry_Importer::remove_directory( $session['workspace'] );
		}

		delete_transient( PageFerry::TRANSIENT_SESSION_PREFIX . $session_id );
	}

	/**
	 * Lists manifest-declared media basenames for the /file allow-list.
	 *
	 * @param array $manifest Validated manifest array.
	 * @return array Map of basename => true.
	 */
	private static function declared_basenames( array $manifest ): array {
		$declared = array();

		if ( ! isset( $manifest['media'] ) || ! is_array( $manifest['media'] ) ) {
			return $declared;
		}

		foreach ( $manifest['media'] as $media_entry ) {
			if ( ! is_array( $media_entry ) || empty( $media_entry['missing'] ) ) {
				if ( is_array( $media_entry ) && isset( $media_entry['file'] ) && is_string( $media_entry['file'] ) && '' !== $media_entry['file'] ) {
					$declared[ basename( $media_entry['file'] ) ] = true;
				}
			}
		}

		return $declared;
	}
}
