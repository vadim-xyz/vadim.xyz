<?php
/**
 * Admin UI consolidation for PageFerry.
 *
 * Owns every admin screen the plugin shows: the export metabox (rendered by
 * PageFerry_Exporter), the import screen (Path A form served by
 * PageFerry_Import_Admin), and the log/backups views added here. Markup moves
 * only — importer/exporter logic and public method signatures stay untouched.
 *
 * Guidelines 7/8/11: own screens only, no external iframes, no remote calls,
 * no site-wide nags, no forced links. All notices are dismissible and scoped
 * to these screens.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers the consolidated admin screens and serves the log/backups views.
 */
class PageFerry_Admin {

	/**
	 * Import screen hook suffix (set on admin_menu).
	 *
	 * @var string
	 */
	private static $hook_suffix = '';

	/**
	 * Registers the import screen with its log/backups tabs.
	 *
	 * @return void
	 */
	public static function register_menu(): void {
		self::$hook_suffix = add_management_page(
			__( 'PageFerry Import', 'pageferry' ),
			__( 'PageFerry Import', 'pageferry' ),
			'import',
			'pageferry-import',
			array( __CLASS__, 'render_screen' )
		);

		add_action( 'load-' . self::$hook_suffix, array( 'PageFerry_Import_Admin', 'handle_post' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Registers the export metabox on page, post, and Gutenberg-edited custom post type edit screens.
	 *
	 * Delegates rendering to the exporter; this keeps every add_meta_boxes
	 * call in one wiring owner while the download logic stays where it is.
	 *
	 * @return void
	 */
	public static function register_export_metabox(): void {
		PageFerry_Exporter::register_metabox();
	}

	/**
	 * Enqueues the Path B worker handoff script on the import screen only.
	 *
	 * Hands its own hook suffix to the transport owner so asset versions
	 * stay in one place while the suffix has a single owner (this class —
	 * PageFerry_Import_Admin::register_menu() is legacy and never runs).
	 *
	 * @param string $hook_suffix Current admin screen hook suffix.
	 * @return void
	 */
	public static function enqueue_assets( string $hook_suffix ): void {
		if ( '' === self::$hook_suffix || $hook_suffix !== self::$hook_suffix ) {
			return;
		}

		PageFerry_Import_Admin::enqueue_assets( $hook_suffix );
	}

	/**
	 * Exposes the import screen hook suffix for asset gating.
	 *
	 * @return string Hook suffix from register_menu(), '' before admin_menu runs.
	 */
	public static function hook_suffix(): string {
		return self::$hook_suffix;
	}

	/**
	 * Renders the import screen: upload form, log viewer, or backups view.
	 *
	 * Tabs are explicit ?tab= params (default import); unknown tabs fall back
	 * to the import form. Log/backups reads are option reads only — nothing
	 * here writes, deletes, or restores.
	 *
	 * @return void
	 */
	public static function render_screen(): void {
		if ( ! current_user_can( 'import' ) ) {
			wp_die(
				esc_html__( 'You do not have permission to import pages.', 'pageferry' ),
				esc_html__( 'PageFerry import failed', 'pageferry' ),
				array( 'response' => 403 )
			);
		}

		$active_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'import'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- tab switch is a read-only view toggle, not a state change.

		if ( 'logs' === $active_tab ) {
			self::render_page_shell( 'logs', array( __CLASS__, 'render_logs_view' ) );
			return;
		}

		if ( 'backups' === $active_tab ) {
			self::render_page_shell( 'backups', array( __CLASS__, 'render_backups_view' ) );
			return;
		}

		PageFerry_Import_Admin::render_screen();
	}

	/**
	 * Renders the wrap shell (title + tabs + dismissible notices) around a view.
	 *
	 * @param string   $active_tab Active tab slug.
	 * @param callable $view_callback View renderer (echoes its inner content).
	 * @return void
	 */
	private static function render_page_shell( string $active_tab, callable $view_callback ): void {
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'PageFerry Import', 'pageferry' ); ?></h1>
			<?php self::render_tabs( $active_tab ); ?>
			<?php call_user_func( $view_callback ); ?>
		</div>
		<?php
	}

	/**
	 * Renders the import/logs/backups tab nav.
	 *
	 * @param string $active_tab Active tab slug.
	 * @return void
	 */
	private static function render_tabs( string $active_tab ): void {
		$tabs = array(
			'import'  => __( 'Import', 'pageferry' ),
			'logs'    => __( 'Logs', 'pageferry' ),
			'backups' => __( 'Backups', 'pageferry' ),
		);
		?>
		<h2 class="nav-tab-wrapper">
			<?php foreach ( $tabs as $tab_slug => $tab_label ) : ?>
				<?php
				$tab_url = add_query_arg(
					array(
						'page' => 'pageferry-import',
						'tab'  => $tab_slug,
					),
					admin_url( 'tools.php' )
				);
				?>
				<a href="<?php echo esc_url( $tab_url ); ?>" class="nav-tab<?php echo $tab_slug === $active_tab ? ' nav-tab-active' : ''; ?>"><?php echo esc_html( $tab_label ); ?></a>
			<?php endforeach; ?>
		</h2>
		<?php
	}

	/**
	 * Renders the import log viewer (newest first).
	 *
	 * Read-only: timestamp, action, target, reused/uploaded counts, result,
	 * backup reference. An empty log explains where rows come from instead of
	 * showing a bare table.
	 *
	 * @return void
	 */
	private static function render_logs_view(): void {
		$log_rows = get_option( PageFerry::OPTION_LOGS, array() );

		if ( ! is_array( $log_rows ) ) {
			$log_rows = array();
		}

		$log_rows = array_reverse( $log_rows );

		if ( array() === $log_rows ) {
			echo '<div class="notice notice-info is-dismissible"><p>';
			esc_html_e( 'No imports logged yet. Completed imports record one row each here.', 'pageferry' );
			echo '</p></div>';
			return;
		}
		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Time', 'pageferry' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Action', 'pageferry' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Target', 'pageferry' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Media', 'pageferry' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Result', 'pageferry' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Backup', 'pageferry' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $log_rows as $log_row ) : ?>
					<?php self::render_log_row( is_array( $log_row ) ? $log_row : array() ); ?>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Renders one import log row.
	 *
	 * Missing keys render as dashes so a hand-edited option cannot break the
	 * table; the backup reference links to the backups tab for restore steps.
	 *
	 * @param array $log_row Log row array.
	 * @return void
	 */
	private static function render_log_row( array $log_row ): void {
		$time_stamp = isset( $log_row['time'] ) && is_string( $log_row['time'] ) ? $log_row['time'] : '';
		$action     = isset( $log_row['action'] ) && is_string( $log_row['action'] ) ? $log_row['action'] : '';
		$target_id  = isset( $log_row['target'] ) ? (int) $log_row['target'] : 0;
		$reused     = isset( $log_row['reused'] ) ? (int) $log_row['reused'] : 0;
		$uploaded   = isset( $log_row['uploaded'] ) ? (int) $log_row['uploaded'] : 0;
		$result     = isset( $log_row['result'] ) && is_string( $log_row['result'] ) ? $log_row['result'] : '';
		$backup_ref = isset( $log_row['backup'] ) && is_string( $log_row['backup'] ) ? $log_row['backup'] : '';
		?>
		<tr>
			<td><?php echo '' !== $time_stamp ? esc_html( $time_stamp ) : '&mdash;'; ?></td>
			<td><?php echo '' !== $action ? esc_html( $action ) : '&mdash;'; ?></td>
			<td>
				<?php if ( 0 < $target_id ) : ?>
					<a href="<?php echo esc_url( (string) get_edit_post_link( $target_id, 'display' ) ); ?>"><?php echo esc_html( (string) $target_id ); ?></a>
				<?php else : ?>
					&mdash;
				<?php endif; ?>
			</td>
			<td>
				<?php
				printf(
					/* translators: 1: reused media count, 2: uploaded media count. */
					esc_html__( '%1$d reused, %2$d uploaded', 'pageferry' ),
					esc_html( (string) $reused ),
					esc_html( (string) $uploaded )
				);
				?>
			</td>
			<td><?php echo '' !== $result ? esc_html( $result ) : '&mdash;'; ?></td>
			<td>
				<?php if ( '' !== $backup_ref ) : ?>
					<?php
					$backups_url = add_query_arg(
						array(
							'page' => 'pageferry-import',
							'tab'  => 'backups',
						),
						admin_url( 'tools.php' )
					);
					?>
					<a href="<?php echo esc_url( $backups_url ); ?>"><?php echo esc_html( $backup_ref ); ?></a>
				<?php else : ?>
					&mdash;
				<?php endif; ?>
			</td>
		</tr>
		<?php
	}

	/**
	 * Renders the pre-overwrite backups view with restore instructions.
	 *
	 * Read-only: each snapshot lists its key, time, and target post. Restore
	 * is a documented manual step (copy content/meta back via the editor or
	 * wp post update) — v1 ships no one-click rollback UI; that is Pro scope.
	 *
	 * @return void
	 */
	private static function render_backups_view(): void {
		$backups = get_option( PageFerry::OPTION_BACKUPS, array() );

		if ( ! is_array( $backups ) ) {
			$backups = array();
		}

		if ( array() === $backups ) {
			echo '<div class="notice notice-info is-dismissible"><p>';
			esc_html_e( 'No pre-import backups yet. Updating an existing page stores its prior content and meta here first.', 'pageferry' );
			echo '</p></div>';
			return;
		}

		echo '<div class="notice notice-info is-dismissible"><p>';
		esc_html_e( 'To restore a snapshot, open the target page editor and paste the stored content back, or ask a developer to re-apply the stored post meta. One-click rollback is out of scope for v1.', 'pageferry' );
		echo '</p></div>';
		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Backup', 'pageferry' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Time', 'pageferry' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Target', 'pageferry' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( array_reverse( $backups, true ) as $backup_key => $backup ) : ?>
					<?php self::render_backup_row( (string) $backup_key, is_array( $backup ) ? $backup : array() ); ?>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Renders one backup snapshot row.
	 *
	 * @param string $backup_key Snapshot key.
	 * @param array  $backup Snapshot array.
	 * @return void
	 */
	private static function render_backup_row( string $backup_key, array $backup ): void {
		$time_stamp = isset( $backup['time'] ) && is_string( $backup['time'] ) ? $backup['time'] : '';
		$post_id    = isset( $backup['post_id'] ) ? (int) $backup['post_id'] : 0;
		?>
		<tr>
			<td><code><?php echo esc_html( $backup_key ); ?></code></td>
			<td><?php echo '' !== $time_stamp ? esc_html( $time_stamp ) : '&mdash;'; ?></td>
			<td>
				<?php if ( 0 < $post_id ) : ?>
					<a href="<?php echo esc_url( (string) get_edit_post_link( $post_id, 'display' ) ); ?>"><?php echo esc_html( (string) $post_id ); ?></a>
				<?php else : ?>
					&mdash;
				<?php endif; ?>
			</td>
		</tr>
		<?php
	}
}
