<?php
/**
 * Classic + REST import transport for PageFerry.
 *
 * Path A (ZIP ≤ wp_max_upload_size()): server-rendered two-step form
 * (upload → dry-run-lite confirmation → execute) with no-JS support.
 * Path B (over the limit): Web Worker client-side unzip (vendored fflate,
 * no build step) + per-file REST upload through the pageferry/v1 routes in
 * includes/class-pageferry-rest-import.php. Both feed the shared
 * PageFerry_Importer::run() pipeline — never forked logic per path.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers the import screen, serves the Path A flow, and enqueues the
 * Path B worker assets.
 *
 * Transport owner only: PageFerry_Admin owns the menu slot, tabs, and the
 * log/backups views, and delegates here for the upload/confirm/execute flow.
 */
class PageFerry_Import_Admin {

	/**
	 * Import screen hook suffix (set on admin_menu).
	 *
	 * @var string
	 */
	private static $hook_suffix = '';

	/**
	 * Confirmation args stashed by handle_upload_step() for the render pass.
	 *
	 * Keeps all echo output in render_screen() (post-headers page callback)
	 * instead of the load-* handler (pre-headers), which is what fixes the
	 * "headers already sent" warnings. Null = no upload ran this request.
	 *
	 * @var array|null
	 */
	private static $pending_confirmation = null;

	/**
	 * Upload-step error stashed for the render pass (never echoed early).
	 *
	 * @var string
	 */
	private static $pending_form_error = '';

	/**
	 * Registers the import screen under Tools.
	 *
	 * Legacy entry point kept for backward compatibility: the consolidated
	 * menu slot lives in PageFerry_Admin::register_menu(), which owns the
	 * hook suffix. This method still wires the same screen so direct callers
	 * keep working, and syncs the suffix both ways (see hook_suffix()).
	 *
	 * @return void
	 */
	public static function register_menu(): void {
		self::$hook_suffix = add_management_page(
			__( 'PageFerry Import', 'pageferry' ),
			__( 'PageFerry Import', 'pageferry' ),
			'import',
			'pageferry-import',
			array( __CLASS__, 'render_screen' )
		);

		add_action( 'load-' . self::$hook_suffix, array( __CLASS__, 'handle_post' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Exposes the import screen hook suffix for asset gating.
	 *
	 * Falls back to PageFerry_Admin::hook_suffix() when this class never
	 * registered the menu itself (the consolidated a06 wiring), so the
	 * enqueue guard below always compares against the live suffix.
	 *
	 * @return string Hook suffix, '' before admin_menu runs.
	 */
	public static function hook_suffix(): string {
		if ( '' !== self::$hook_suffix ) {
			return self::$hook_suffix;
		}

		if ( class_exists( 'PageFerry_Admin' ) ) {
			return PageFerry_Admin::hook_suffix();
		}

		return '';
	}

	/**
	 * Enqueues the Path B worker handoff script on the import screen only.
	 *
	 * @param string $hook_suffix Current admin screen hook suffix.
	 * @return void
	 */
	public static function enqueue_assets( string $hook_suffix ): void {
		$live_suffix = self::hook_suffix();

		if ( '' === $live_suffix || $hook_suffix !== $live_suffix ) {
			return;
		}

		wp_enqueue_script(
			'pageferry-fflate',
			plugins_url( 'assets/js/vendor/fflate.min.js', PAGEFERRY_FILE ),
			array(),
			'0.8.3',
			true
		);

		wp_enqueue_script(
			'pageferry-import',
			plugins_url( 'assets/js/pageferry-import.js', PAGEFERRY_FILE ),
			array( 'pageferry-fflate', 'wp-i18n' ),
			PAGEFERRY_VERSION,
			true
		);

		wp_set_script_translations( 'pageferry-import', 'pageferry' );

		wp_localize_script(
			'pageferry-import',
			'pageferryImport',
			array(
				'maxBytes'  => (int) wp_max_upload_size(),
				'restRoot'  => esc_url_raw( rest_url() ),
				'namespace' => 'pageferry/v1',
				'nonce'     => wp_create_nonce( 'wp_rest' ),
				'workerUrl' => plugins_url( 'assets/js/import-worker.js', PAGEFERRY_FILE ),
			)
		);
	}

	/**
	 * Handles Path A POSTs: upload → stash + confirmation, then execute.
	 *
	 * @return void
	 */
	public static function handle_post(): void {
		if ( ! isset( $_POST['pageferry_import_step'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- step dispatch only; each step verifies its own nonce below.
			return;
		}

		if ( ! current_user_can( 'import' ) ) {
			wp_die(
				esc_html__( 'You do not have permission to import pages.', 'pageferry' ),
				esc_html__( 'PageFerry import failed', 'pageferry' ),
				array( 'response' => 403 )
			);
		}

		$step = sanitize_key( wp_unslash( $_POST['pageferry_import_step'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- step dispatch only; each step verifies its own nonce below.

		if ( 'upload' === $step ) {
			self::handle_upload_step();
		} elseif ( 'execute' === $step ) {
			self::handle_execute_step();
		}
	}

	/**
	 * Renders the import screen (upload form, confirmation, or result notice).
	 *
	 * When handle_upload_step() ran earlier on the load-* hook it stashed
	 * either a confirmation or a form error — render it here, in the page
	 * callback, where echo output is legal. There is no cross-request pending
	 * state to restore here.
	 *
	 * @return void
	 */
	public static function render_screen(): void {
		if ( ! current_user_can( 'import' ) ) {
			wp_die(
				esc_html__( 'You do not have permission to import pages.', 'pageferry' ),
				esc_html__( 'PageFerry import failed', 'pageferry' ),
				array( 'response' => 403 )
			);
		}

		if ( is_array( self::$pending_confirmation ) ) {
			$confirmation               = self::$pending_confirmation;
			self::$pending_confirmation = null;
			self::render_confirmation( $confirmation );
			return;
		}

		if ( '' !== self::$pending_form_error ) {
			$form_error               = self::$pending_form_error;
			self::$pending_form_error = '';
			self::render_upload_form( $form_error );
			return;
		}

		$result = get_transient( PageFerry::TRANSIENT_RESULT_PREFIX . get_current_user_id() );

		if ( is_array( $result ) ) {
			delete_transient( PageFerry::TRANSIENT_RESULT_PREFIX . get_current_user_id() );
			self::render_result( $result );
			return;
		}

		self::render_upload_form( '' );
	}

	/**
	 * Upload step: validates the ZIP, stashes it, shows the confirmation.
	 *
	 * Runs on the page's load-* hook, before admin-header.php sends any
	 * output — every echo below runs pre-headers, so nothing here can trip
	 * "headers already sent". The confirmation is rendered by render_screen()
	 * (the registered page callback), not here: this step only validates,
	 * stashes, and records the confirmation args for the render pass.
	 *
	 * @return void
	 */
	private static function handle_upload_step(): void {
		check_admin_referer( 'pageferry_import_upload' );

		if ( ! isset( $_FILES['pageferry_zip'] ) || ! is_array( $_FILES['pageferry_zip'] ) ) {
			self::store_upload_error( __( 'Choose a PageFerry ZIP file first.', 'pageferry' ) );
			return;
		}

		$uploaded = $_FILES['pageferry_zip']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- file upload array handled by wp_handle_upload below.

		if ( ! isset( $uploaded['error'] ) || UPLOAD_ERR_OK !== (int) $uploaded['error'] ) {
			self::store_upload_error( __( 'The upload failed. Try again with a PageFerry export ZIP.', 'pageferry' ) );
			return;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$upload_size = isset( $uploaded['size'] ) ? (int) $uploaded['size'] : 0;
		$limit_bytes = (int) wp_max_upload_size();

		if ( 0 < $limit_bytes && $limit_bytes < $upload_size ) {
			self::store_upload_error(
				sprintf(
					/* translators: %s: human-readable upload limit. */
					__( 'That ZIP is larger than this site allows per upload (%s). Keep this screen open — the browser worker path uploads it file-by-file instead.', 'pageferry' ),
					size_format( $limit_bytes )
				)
			);
			return;
		}

		$file_check = wp_check_filetype_and_ext( $uploaded['tmp_name'], $uploaded['name'], array( 'zip' => 'application/zip' ) );

		if ( empty( $file_check['ext'] ) || 'zip' !== $file_check['ext'] ) {
			self::store_upload_error( __( 'That file is not a ZIP. Upload a PageFerry export ZIP.', 'pageferry' ) );
			return;
		}

		$moved = wp_handle_upload(
			$uploaded,
			array(
				'test_form' => false,
				'mimes'     => array( 'zip' => 'application/zip' ),
			)
		);

		if ( isset( $moved['error'] ) ) {
			self::store_upload_error( $moved['error'] );
			return;
		}

		$prepared = PageFerry_Importer::prepare_workspace_from_zip( $moved['file'] );
		wp_delete_file( $moved['file'] );

		if ( is_wp_error( $prepared ) ) {
			self::store_upload_error( $prepared->get_error_message() );
			return;
		}

		$target_mode    = isset( $_POST['pageferry_target'] ) && 'update' === sanitize_key( wp_unslash( $_POST['pageferry_target'] ) ) ? 'update' : 'create';
		$target_post_id = isset( $_POST['pageferry_target_post'] ) ? absint( wp_unslash( $_POST['pageferry_target_post'] ) ) : 0;
		$preview        = PageFerry_Importer::preview(
			$prepared['workspace'],
			$prepared['manifest'],
			array(
				'target'         => $target_mode,
				'target_post_id' => $target_post_id,
			)
		);

		if ( is_wp_error( $preview ) ) {
			PageFerry_Importer::remove_directory( $prepared['workspace'] );
			self::store_upload_error( $preview->get_error_message() );
			return;
		}

		$confirmation_key = 'pf-' . wp_generate_password( 12, false );
		set_transient(
			PageFerry::TRANSIENT_IMPORT_PREFIX . $confirmation_key,
			array(
				'workspace'      => $prepared['workspace'],
				'manifest'       => $prepared['manifest'],
				'target'         => $preview['target'],
				'target_post_id' => $target_post_id,
			),
			HOUR_IN_SECONDS
		);

		self::$pending_confirmation = array(
			'key'     => $confirmation_key,
			'preview' => $preview,
		);
	}

	/**
	 * Stashes an upload-step error for the render pass (never echoes here).
	 *
	 * @param string $error_message Already-localized error text.
	 * @return void
	 */
	private static function store_upload_error( string $error_message ): void {
		self::$pending_form_error = $error_message;
	}

	/**
	 * Execute step: revalidates the stashed bundle, then runs the import.
	 *
	 * Runs on the page's load-* hook, before admin-header.php sends any
	 * output — like the upload step, it only stashes errors for render_screen()
	 * (the registered page callback) instead of echoing them here.
	 *
	 * @return void
	 */
	private static function handle_execute_step(): void {
		check_admin_referer( 'pageferry_import_execute' );

		$confirmation_key = isset( $_POST['pageferry_key'] ) ? sanitize_key( wp_unslash( $_POST['pageferry_key'] ) ) : '';
		$stashed          = '' !== $confirmation_key ? get_transient( PageFerry::TRANSIENT_IMPORT_PREFIX . $confirmation_key ) : false;

		if ( ! is_array( $stashed ) || ! isset( $stashed['workspace'], $stashed['manifest'] ) ) {
			self::store_upload_error( __( 'That confirmation expired. Upload the ZIP again.', 'pageferry' ) );
			return;
		}

		delete_transient( PageFerry::TRANSIENT_IMPORT_PREFIX . $confirmation_key );

		$imported = PageFerry_Importer::run(
			$stashed['workspace'],
			$stashed['manifest'],
			array(
				'target'         => isset( $stashed['target'] ) ? $stashed['target'] : 'create',
				'target_post_id' => isset( $stashed['target_post_id'] ) ? (int) $stashed['target_post_id'] : 0,
			)
		);

		PageFerry_Importer::remove_directory( $stashed['workspace'] );

		if ( is_wp_error( $imported ) ) {
			self::store_upload_error( $imported->get_error_message() );
			return;
		}

		set_transient(
			PageFerry::TRANSIENT_RESULT_PREFIX . get_current_user_id(),
			array(
				'post_id' => $imported->ID,
				'title'   => $imported->post_title,
				'slug'    => $imported->post_name,
			),
			MINUTE_IN_SECONDS
		);

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'     => 'pageferry-import',
					'imported' => 1,
				),
				admin_url( 'tools.php' )
			)
		);
		exit;
	}

	/**
	 * Renders the upload form with target picker + worker mount point.
	 *
	 * @param string $error_message Optional error shown above the form.
	 * @return void
	 */
	private static function render_upload_form( string $error_message ): void {
		$limit_bytes    = (int) wp_max_upload_size();
		$candidate_args = array(
			'post_type'      => PageFerry_Exporter::ferryable_post_types(),
			'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
			'posts_per_page' => 50,
			'orderby'        => 'modified',
			'order'          => 'DESC',
		);
		$candidates     = get_posts( $candidate_args );

		// The dropdown otherwise discloses other authors' private/draft titles
		// and slugs to anyone holding `import`; only offer targets the current
		// user may actually overwrite (run() re-checks edit_post regardless).
		$editable_candidates = array();

		foreach ( $candidates as $candidate_post ) {
			if ( current_user_can( 'edit_post', $candidate_post->ID ) ) {
				$editable_candidates[] = $candidate_post;
			}
		}

		$candidates = $editable_candidates;
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'PageFerry Import', 'pageferry' ); ?></h1>
			<?php if ( '' !== $error_message ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( $error_message ); ?></p></div>
			<?php endif; ?>
			<p><?php esc_html_e( 'Upload a PageFerry export ZIP. Small bundles import in one step; larger ones upload file-by-file through the browser worker.', 'pageferry' ); ?></p>
			<p>
				<?php
				printf(
					/* translators: %s: human-readable upload limit. */
					esc_html__( 'Single-upload limit on this site: %s.', 'pageferry' ),
					esc_html( size_format( $limit_bytes ) )
				);
				?>
			</p>
			<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'tools.php?page=pageferry-import' ) ); ?>">
				<?php wp_nonce_field( 'pageferry_import_upload' ); ?>
				<input type="hidden" name="pageferry_import_step" value="upload" />
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="pageferry-zip"><?php esc_html_e( 'PageFerry ZIP file', 'pageferry' ); ?></label></th>
						<td><input type="file" id="pageferry-zip" name="pageferry_zip" accept=".zip,application/zip" required /></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Target', 'pageferry' ); ?></th>
						<td>
							<fieldset>
								<label><input type="radio" name="pageferry_target" value="create" checked /> <?php esc_html_e( 'Create new (lands as draft)', 'pageferry' ); ?></label><br />
								<label><input type="radio" name="pageferry_target" value="update" /> <?php esc_html_e( 'Update selected page', 'pageferry' ); ?></label><br />
								<select name="pageferry_target_post">
									<?php foreach ( $candidates as $candidate_post ) : ?>
										<option value="<?php echo esc_attr( (string) $candidate_post->ID ); ?>">
											<?php echo esc_html( $candidate_post->post_title . ' — ' . $candidate_post->post_name . ' (' . $candidate_post->post_type . ')' ); ?>
										</option>
									<?php endforeach; ?>
								</select>
							</fieldset>
						</td>
					</tr>
				</table>
				<?php submit_button( __( 'Upload and preview', 'pageferry' ) ); ?>
			</form>
			<div id="pageferry-worker-ui" hidden>
				<h2><?php esc_html_e( 'Large bundle path', 'pageferry' ); ?></h2>
				<p><?php esc_html_e( 'This ZIP exceeds the single-upload limit, so the browser worker extracts it and uploads each media file individually.', 'pageferry' ); ?></p>
				<progress id="pageferry-worker-progress" max="100" value="0"></progress>
				<p id="pageferry-worker-status" role="status"></p>
			</div>
		</div>
		<?php
	}

	/**
	 * Renders the dry-run-lite confirmation screen.
	 *
	 * @param array $confirmation Array with key + preview summary.
	 * @return void
	 */
	private static function render_confirmation( array $confirmation ): void {
		$preview = $confirmation['preview'];
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Confirm PageFerry import', 'pageferry' ); ?></h1>
			<p>
				<?php
				printf(
					/* translators: 1: post title, 2: slug, 3: new media count, 4: reused count. */
					esc_html__( 'Will %1$s "%2$s" (slug %3$s) with %4$d new media (%5$d reused).', 'pageferry' ),
					'update' === $preview['target'] ? esc_html__( 'update', 'pageferry' ) : esc_html__( 'create', 'pageferry' ),
					esc_html( $preview['title'] ),
					esc_html( $preview['slug'] ),
					(int) $preview['media_new'],
					(int) $preview['reused']
				);
				?>
			</p>
		<ul>
			<?php
			$preview_terms = isset( $preview['terms'] ) && is_array( $preview['terms'] ) ? $preview['terms'] : array();

			foreach ( $preview_terms as $taxonomy_slug => $term_names ) :
				$taxonomy_object = get_taxonomy( (string) $taxonomy_slug );
				$taxonomy_label  = $taxonomy_object instanceof WP_Taxonomy ? $taxonomy_object->label : (string) $taxonomy_slug;
				$term_list       = is_array( $term_names ) && array() !== $term_names ? implode( ', ', array_map( 'strval', $term_names ) ) : '—';
				?>
				<li>
					<?php
					printf(
						/* translators: 1: taxonomy label, 2: comma-separated term names. */
						esc_html__( '%1$s: %2$s', 'pageferry' ),
						esc_html( $taxonomy_label ),
						esc_html( $term_list )
					);
					?>
				</li>
			<?php endforeach; ?>
			<?php if ( 0 < (int) $preview['missing'] ) : ?>
				<li>
					<?php
					printf(
						/* translators: %d: count of media entries with no file. */
						esc_html__( '%d media entries have no file and will be skipped.', 'pageferry' ),
						(int) $preview['missing']
					);
					?>
				</li>
			<?php endif; ?>
			</ul>
			<form method="post" action="<?php echo esc_url( admin_url( 'tools.php?page=pageferry-import' ) ); ?>">
				<?php wp_nonce_field( 'pageferry_import_execute' ); ?>
				<input type="hidden" name="pageferry_import_step" value="execute" />
				<input type="hidden" name="pageferry_key" value="<?php echo esc_attr( $confirmation['key'] ); ?>" />
				<?php submit_button( __( 'Confirm import', 'pageferry' ), 'primary' ); ?>
				<a class="button" href="<?php echo esc_url( admin_url( 'tools.php?page=pageferry-import' ) ); ?>"><?php esc_html_e( 'Cancel', 'pageferry' ); ?></a>
			</form>
		</div>
		<?php
	}

	/**
	 * Renders the success notice after the redirect.
	 *
	 * @param array $result Array with post_id + title + slug.
	 * @return void
	 */
	private static function render_result( array $result ): void {
		$edit_link = get_edit_post_link( (int) $result['post_id'], 'display' );
		$view_link = get_permalink( (int) $result['post_id'] );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'PageFerry Import', 'pageferry' ); ?></h1>
			<div class="notice notice-success"><p>
				<?php
				printf(
					/* translators: 1: post title, 2: slug. */
					esc_html__( 'Imported "%1$s" (slug %2$s).', 'pageferry' ),
					esc_html( $result['title'] ),
					esc_html( $result['slug'] )
				);
				?>
			</p></div>
			<p>
				<?php if ( is_string( $edit_link ) ) : ?>
					<a class="button button-primary" href="<?php echo esc_url( $edit_link ); ?>"><?php esc_html_e( 'Edit imported page', 'pageferry' ); ?></a>
				<?php endif; ?>
				<?php if ( is_string( $view_link ) ) : ?>
					<a class="button" href="<?php echo esc_url( $view_link ); ?>"><?php esc_html_e( 'View imported page', 'pageferry' ); ?></a>
				<?php endif; ?>
				<a class="button" href="<?php echo esc_url( admin_url( 'tools.php?page=pageferry-import' ) ); ?>"><?php esc_html_e( 'Import another', 'pageferry' ); ?></a>
			</p>
		</div>
		<?php
	}
}
