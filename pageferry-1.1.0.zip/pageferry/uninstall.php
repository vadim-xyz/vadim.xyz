<?php
/**
 * Uninstall cleanup for PageFerry.
 *
 * Removes ONLY the plugin's own options and transients (canonical names on
 * the PageFerry class). Abandoned import workspaces under uploads are
 * reclaimed; imported posts, attachments, and terms are user content and are
 * never deleted here. No foreign data is touched.
 *
 * @package PageFerry
 * License: GPL-2.0-or-later
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Canonical option names (duplicated as literals so uninstall works even if
// the main class file moves; keep in sync with PageFerry::OPTION_*).
$pageferry_uninstall_option_names = array(
	'pageferry_hash_index',
	'pageferry_logs',
	'pageferry_backups',
	'pageferry_last_gc',
);

foreach ( $pageferry_uninstall_option_names as $pageferry_uninstall_option_name ) {
	delete_option( $pageferry_uninstall_option_name );
	delete_transient( $pageferry_uninstall_option_name );
}

// Import sessions, Path A stashes, and result notices are transients keyed by
// random IDs; sweep by prefix. Only our own prefixes are matched. The LIKE
// sweep covers the plain-options case; wp_cache_flush() drops any copies the
// object cache still holds (transients are cache-first on cached hosts).
global $wpdb;

$pageferry_uninstall_prefixes = array(
	'_transient_pageferry_session_',
	'_transient_timeout_pageferry_session_',
	'_transient_pageferry_import_',
	'_transient_timeout_pageferry_import_',
	'_transient_pageferry_quota_',
	'_transient_timeout_pageferry_quota_',
);

foreach ( $pageferry_uninstall_prefixes as $pageferry_uninstall_prefix ) {
	$pageferry_uninstall_like = $wpdb->esc_like( $pageferry_uninstall_prefix ) . '%';

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- uninstall cleanup has no API for prefix-matched transients.
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $pageferry_uninstall_like ) );
}

// Reclaim abandoned import workspaces (pageferry-import-*/pageferry-session-*
// under the uploads basedir). Transients for these are gone by definition at
// uninstall time, so every matching directory is stale. Implemented inline:
// the plugin classes are not loaded in the uninstall context.
$pageferry_upload_dir = wp_get_upload_dir();
$pageferry_basedir    = isset( $pageferry_upload_dir['basedir'] ) && is_string( $pageferry_upload_dir['basedir'] ) ? $pageferry_upload_dir['basedir'] : '';

if ( '' !== $pageferry_basedir && is_dir( $pageferry_basedir ) ) {
	$pageferry_real_base = realpath( $pageferry_basedir );

	if ( is_string( $pageferry_real_base ) ) {
		$pageferry_top_entries = scandir( $pageferry_real_base );

		if ( is_array( $pageferry_top_entries ) ) {
			foreach ( $pageferry_top_entries as $pageferry_top_entry ) {
				if ( 0 !== strpos( $pageferry_top_entry, 'pageferry-import-' ) && 0 !== strpos( $pageferry_top_entry, 'pageferry-session-' ) ) {
					continue;
				}

				$pageferry_candidate = $pageferry_real_base . '/' . $pageferry_top_entry;

				if ( ! is_dir( $pageferry_candidate ) ) {
					continue;
				}

				$pageferry_stack = array( $pageferry_candidate );

				while ( array() !== $pageferry_stack ) {
					$pageferry_current = array_pop( $pageferry_stack );
					$pageferry_inner   = scandir( $pageferry_current );

					if ( ! is_array( $pageferry_inner ) ) {
						continue;
					}

					foreach ( $pageferry_inner as $pageferry_inner_entry ) {
						if ( '.' === $pageferry_inner_entry || '..' === $pageferry_inner_entry ) {
							continue;
						}

						$pageferry_inner_path = $pageferry_current . '/' . $pageferry_inner_entry;

						if ( is_dir( $pageferry_inner_path ) ) {
							$pageferry_stack[] = $pageferry_inner_path;
						} else {
							wp_delete_file( $pageferry_inner_path );
						}
					}

					rmdir( $pageferry_current ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- uninstall reclaim of our own abandoned workspace dirs.
				}
			}
		}
	}
}

wp_cache_flush();
